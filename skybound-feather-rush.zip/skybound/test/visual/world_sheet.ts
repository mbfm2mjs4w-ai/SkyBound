import { WORLDS } from '../../src/data/worlds';
import { WorldRenderer } from '../../src/render/WorldRenderer';
import { QUALITY } from '../../src/config/gameConfig';
import type { ViewState } from '../../src/core/types';

const cv = document.getElementById('c') as HTMLCanvasElement;
const ctx = cv.getContext('2d')!;
const cols = 3, cw = 560, ch = 315, VW = 1422, VH = 800;
cv.width = cols * cw; cv.height = Math.ceil(WORLDS.length / cols) * ch;
const R = new WorldRenderer(QUALITY.high);
const t0 = performance.now();
WORLDS.forEach((w, i) => {
  R.prepare(w.id, VW, VH, 1);
  const c = document.createElement('canvas'); c.width = cw; c.height = ch; const g = c.getContext('2d')!;
  g.scale(cw / VW, ch / VH);
  const view: ViewState = { W: VW, H: VH, time: 5 + i, scroll: 3000, camY: 0, tod: 0.22, intensity: 0.3, quality: QUALITY.high, reducedMotion: false };
  for (let k = 0; k < 60; k++) R.update(1 / 30, w.id, 235, view);
  R.drawBackground(g, w.id, view); R.drawForeground(g, w.id, view); R.drawLighting(g, w.id, view);
  g.setTransform(1, 0, 0, 1, 0, 0); g.fillStyle = '#fff'; g.font = 'bold 15px sans-serif'; g.shadowColor = '#000'; g.shadowBlur = 4; g.fillText(`${w.index}. ${w.name}`, 10, 22);
  ctx.drawImage(c, (i % cols) * cw, Math.floor(i / cols) * ch);
  R.release(w.id);
});
console.log('ms', Math.round(performance.now() - t0));
(window as any).done = true;
