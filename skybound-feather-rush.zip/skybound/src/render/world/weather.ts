import type { WeatherKind } from '../../data/worlds';
import { clamp, rgba, TAU } from '../../core/util';
import { drawGlow, type Ctx } from '../gfx';

const MAX = 260;
const FIELDS = 7;

interface Group { kind: WeatherKind; n: number; off: number }

/** Pooled typed-array particles for one world's weather (no per-frame allocation). */
export class WeatherSystem {
  private d = new Float32Array(MAX * FIELDS);    // x, y, vx, vy, size, phase, life
  private groups: Group[] = [];
  private total = 0;
  private lastW = 0; private lastH = 0;

  constructor(private kinds: { kind: WeatherKind; density: number }[], private accent: string, quality: number, W = 900, H = 800) {
    this.configure(quality, W, H);
  }
  configure(quality: number, W: number, H: number): void {
    this.groups = []; let off = 0;
    for (const k of this.kinds) {
      const n = Math.min(MAX - off, Math.round(70 * k.density * quality));
      if (n > 0) { this.groups.push({ kind: k.kind, n, off }); off += n; }
    }
    this.total = off; this.lastW = W; this.lastH = H;
    for (const g of this.groups) for (let i = 0; i < g.n; i++) this.respawn(g, g.off + i, true);
  }
  private respawn(g: Group, idx: number, initial: boolean): void {
    const d = this.d, o = idx * FIELDS, W = this.lastW + 200, H = this.lastH;
    const r = Math.random;
    d[o] = r() * W - 100; d[o + 1] = initial ? r() * H : -20 - r() * 60; d[o + 5] = r() * TAU; d[o + 6] = r();
    switch (g.kind) {
      case 'snow': d[o + 2] = -10 + r() * 20; d[o + 3] = 40 + r() * 70; d[o + 4] = 1.4 + r() * 2.6; break;
      case 'blizzard': d[o + 2] = -240 - r() * 160; d[o + 3] = 120 + r() * 120; d[o + 4] = 1.2 + r() * 1.4; d[o] = r() * W + 200; break;
      case 'rain': d[o + 2] = -60; d[o + 3] = 700 + r() * 250; d[o + 4] = 1; break;
      case 'pollen': case 'light_motes': case 'fireflies': case 'wisps': d[o + 1] = r() * H; d[o + 2] = -8 + r() * 16; d[o + 3] = -8 - r() * 14; d[o + 4] = 1.5 + r() * 2.5; break;
      case 'leaves': d[o + 2] = -50 - r() * 30; d[o + 3] = 18 + r() * 30; d[o + 4] = 4 + r() * 3; d[o] = r() * W + 100; break;
      case 'petals': d[o + 2] = -70 - r() * 50; d[o + 3] = 22 + r() * 34; d[o + 4] = 3 + r() * 2.5; d[o] = r() * W + 100; break;
      case 'feathers': d[o + 2] = -14 + r() * 8; d[o + 3] = 14 + r() * 22; d[o + 4] = 5 + r() * 4; break;
      case 'ash': d[o + 2] = -30 - r() * 20; d[o + 3] = 20 + r() * 26; d[o + 4] = 1.4 + r() * 2; break;
      case 'embers': case 'sparks': d[o + 1] = initial ? r() * H : H + 20; d[o + 2] = -20 + r() * 40; d[o + 3] = -40 - r() * 80; d[o + 4] = 1.4 + r() * 2.2; break;
      case 'digital_rain': d[o + 2] = 0; d[o + 3] = 180 + r() * 220; d[o + 4] = 8 + r() * 14; break;
      case 'cosmic_dust': d[o + 2] = -60 - r() * 90; d[o + 3] = (r() - 0.5) * 12; d[o + 4] = 0.8 + r() * 1.6; d[o + 1] = r() * H; break;
      case 'bubbles': d[o + 1] = initial ? r() * H : H + 20; d[o + 2] = -6 + r() * 12; d[o + 3] = -30 - r() * 50; d[o + 4] = 2 + r() * 5; break;
      case 'stars': d[o + 1] = r() * H; d[o + 2] = -16 - r() * 24; d[o + 3] = 0; d[o + 4] = 1 + r() * 2; break;
    }
  }
  update(dt: number, scrollSpeed: number, reduced: boolean): void {
    const d = this.d, k = reduced ? 0.4 : 1, wind = scrollSpeed * 0.55;
    const W = this.lastW + 100, H = this.lastH + 40;
    for (const g of this.groups) {
      for (let i = 0; i < g.n; i++) {
        const o = (g.off + i) * FIELDS;
        d[o + 5] += dt * (1.2 + d[o + 4] * 0.2);
        let vx = d[o + 2] * k - wind * (g.kind === 'rain' ? 0.2 : 0.25);
        let vy = d[o + 3] * k;
        if (g.kind === 'snow' || g.kind === 'petals' || g.kind === 'leaves' || g.kind === 'feathers') vx += Math.sin(d[o + 5]) * 22 * k;
        if (g.kind === 'bubbles' || g.kind === 'pollen' || g.kind === 'fireflies' || g.kind === 'wisps' || g.kind === 'light_motes') vx += Math.sin(d[o + 5]) * 14 * k;
        if (g.kind === 'petals' || g.kind === 'leaves') vy += Math.cos(d[o + 5] * 1.3) * 16 * k;
        d[o] += vx * dt; d[o + 1] += vy * dt;
        const up = vy < 0;
        if (d[o] < -110) { d[o] = W + Math.random() * 60; d[o + 1] = Math.random() * H; }
        if (d[o] > W + 120) d[o] = -100;
        if (!up && d[o + 1] > H) { d[o + 1] = -20; if (g.kind === 'digital_rain' || g.kind === 'rain') d[o] = Math.random() * W; }
        if (up && d[o + 1] < -30) { d[o + 1] = H; d[o] = Math.random() * W; }
      }
    }
  }
  draw(c: Ctx, t: number, bloom: boolean): void {
    const d = this.d;
    for (const g of this.groups) {
      for (let i = 0; i < g.n; i++) {
        const o = (g.off + i) * FIELDS, x = d[o], y = d[o + 1], s = d[o + 4], ph = d[o + 5];
        switch (g.kind) {
          case 'snow': case 'blizzard': c.fillStyle = 'rgba(255,255,255,0.85)'; c.beginPath(); c.arc(x, y, s, 0, TAU); c.fill(); break;
          case 'rain': c.strokeStyle = 'rgba(190,220,255,0.45)'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(x, y); c.lineTo(x + 6, y - 24); c.stroke(); break;
          case 'ash': c.fillStyle = 'rgba(70,60,60,0.55)'; c.beginPath(); c.arc(x, y, s, 0, TAU); c.fill(); break;
          case 'pollen': case 'light_motes': { const a = 0.35 + 0.35 * Math.sin(t * 2 + ph); if (bloom) drawGlow(c, x, y, s * 5, '#fff2b0', a); else { c.fillStyle = rgba('#fff2b0', a); c.beginPath(); c.arc(x, y, s, 0, TAU); c.fill(); } break; }
          case 'fireflies': { const a = clamp(Math.sin(t * 2.4 + ph * 3) * 0.7 + 0.3, 0, 1); if (a > 0.05) drawGlow(c, x, y, s * 6, '#d8ff7a', a * 0.9); break; }
          case 'wisps': drawGlow(c, x, y, s * 9, i % 2 ? '#ff4ad0' : '#a070ff', 0.5 + 0.3 * Math.sin(t * 3 + ph)); break;
          case 'leaves': c.save(); c.translate(x, y); c.rotate(ph); c.fillStyle = i % 3 ? '#5fcf7a' : '#d9a640'; c.beginPath(); c.ellipse(0, 0, s, s * 0.5, 0, 0, TAU); c.fill(); c.restore(); break;
          case 'petals': c.save(); c.translate(x, y); c.rotate(ph); c.scale(1, 0.55 + 0.45 * Math.sin(ph * 1.7)); c.fillStyle = i % 2 ? '#ffc0dc' : '#ffffff'; c.beginPath(); c.ellipse(0, 0, s, s * 0.6, 0, 0, TAU); c.fill(); c.restore(); break;
          case 'feathers': c.save(); c.translate(x, y); c.rotate(Math.sin(ph) * 0.8); c.fillStyle = 'rgba(255,255,255,0.8)'; c.beginPath(); c.ellipse(0, 0, s, s * 0.28, 0, 0, TAU); c.fill(); c.restore(); break;
          case 'embers': case 'sparks': { const a = 0.6 + 0.4 * Math.sin(t * 8 + ph); if (bloom) drawGlow(c, x, y, s * 5, g.kind === 'sparks' ? '#9ff3ff' : '#ff8a2b', a); else { c.fillStyle = rgba('#ff8a2b', a); c.beginPath(); c.arc(x, y, s, 0, TAU); c.fill(); } break; }
          case 'digital_rain': { const len = s * 3; const gr = c.createLinearGradient(x, y - len, x, y); gr.addColorStop(0, 'rgba(0,255,200,0)'); gr.addColorStop(1, 'rgba(0,255,200,0.75)'); c.fillStyle = gr; c.fillRect(x, y - len, 2, len); c.fillStyle = '#c8fff4'; c.fillRect(x, y - 1, 2, 3); break; }
          case 'cosmic_dust': c.fillStyle = `rgba(200,190,255,${0.35 + 0.3 * Math.sin(t + ph)})`; c.beginPath(); c.arc(x, y, s, 0, TAU); c.fill(); break;
          case 'bubbles': c.strokeStyle = 'rgba(220,255,255,0.7)'; c.lineWidth = 1.2; c.beginPath(); c.arc(x, y, s, 0, TAU); c.stroke(); c.fillStyle = 'rgba(255,255,255,0.5)'; c.beginPath(); c.arc(x - s * 0.3, y - s * 0.3, s * 0.22, 0, TAU); c.fill(); break;
          case 'stars': { const a = 0.4 + 0.6 * Math.abs(Math.sin(t * 2 + ph)); c.fillStyle = `rgba(255,255,255,${a})`; c.beginPath(); c.arc(x, y, s * 0.8, 0, TAU); c.fill(); break; }
        }
      }
    }
  }
  get count(): number { return this.total; }
}
