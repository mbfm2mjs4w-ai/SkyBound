import type { Tuning } from '../config/gameConfig';

export interface BirdBody {
  y: number; prevY: number; vy: number; rot: number;
}

/** Semi-implicit Euler at a fixed step. Deterministic and frame-rate independent (the caller
 *  accumulates real time and calls this with FIXED_DT; rendering interpolates prevY → y). */
export function stepBird(b: BirdBody, dt: number, t: Tuning): void {
  b.prevY = b.y;
  b.vy += t.gravity * dt;
  if (b.vy > t.terminal) b.vy = t.terminal;
  b.y += b.vy * dt;
  // body tilt follows velocity (nose up when rising, nose down when falling)
  const target = b.vy < 0 ? Math.max(-0.5, b.vy / 1100) : Math.min(1.15, b.vy / 780);
  const k = 1 - Math.exp(-12 * dt);
  b.rot += (target - b.rot) * k;
}

export function applyFlap(b: BirdBody, t: Tuning, power = 1): void {
  b.vy = t.jump * power;
}

/** Maximum height the bird rises from one flap (used by the generator and the test bot). */
export function flapRise(t: Tuning): number {
  return (t.jump * t.jump) / (2 * t.gravity);
}
