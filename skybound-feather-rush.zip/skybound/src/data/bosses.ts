import type { L10n } from '../core/types';

export type BossId = 'stone_golem' | 'frost_wyrm' | 'inferno_titan' | 'cyber_sentinel' | 'void_eye';
/** Gap-center patterns understood by the obstacle generator. */
export type PatternId = 'walk' | 'stairs_up' | 'stairs_down' | 'zigzag' | 'sine' | 'narrow' | 'breather' | 'wave';

export interface BossDef {
  id: BossId;
  name: L10n;
  title: L10n;
  world: string;           // arena world id (visual backdrop)
  hp: number;              // number of gates to clear to defeat the boss
  speedMul: number;
  gapMul: number;
  patterns: PatternId[];   // cycled in order, each pattern runs 5-6 gates
  reward: { coins: number; gems: number; xp: number };
  color: string;
}

export const BOSSES: BossDef[] = [
  { id: 'stone_golem', name: { vi: 'Golem Đá Cổ', en: 'Stone Golem' }, title: { vi: 'Kẻ Canh Giữ Thung Lũng', en: 'Guardian of the Valley' }, world: 'emerald_valley', hp: 16, speedMul: 1.0, gapMul: 1.0, patterns: ['walk', 'stairs_up', 'breather', 'stairs_down'], reward: { coins: 150, gems: 2, xp: 120 }, color: '#8d9a7a' },
  { id: 'frost_wyrm', name: { vi: 'Băng Long', en: 'Frost Wyrm' }, title: { vi: 'Ác Mộng Phương Bắc', en: 'Terror of the North' }, world: 'frozen_empire', hp: 20, speedMul: 1.03, gapMul: 0.99, patterns: ['sine', 'zigzag', 'breather', 'wave'], reward: { coins: 220, gems: 3, xp: 170 }, color: '#8fd6ff' },
  { id: 'inferno_titan', name: { vi: 'Titan Dung Nham', en: 'Inferno Titan' }, title: { vi: 'Chúa Tể Núi Lửa', en: 'Lord of the Volcano' }, world: 'inferno_realm', hp: 24, speedMul: 1.06, gapMul: 0.98, patterns: ['stairs_up', 'narrow', 'zigzag', 'breather', 'sine'], reward: { coins: 300, gems: 4, xp: 230 }, color: '#ff6a2a' },
  { id: 'cyber_sentinel', name: { vi: 'Lính Gác Cyber', en: 'Cyber Sentinel' }, title: { vi: 'Con Mắt Của Nexus', en: 'Eye of the Nexus' }, world: 'cyber_nexus', hp: 28, speedMul: 1.09, gapMul: 0.97, patterns: ['wave', 'narrow', 'stairs_down', 'zigzag', 'breather'], reward: { coins: 400, gems: 5, xp: 300 }, color: '#00e5ff' },
  { id: 'void_eye', name: { vi: 'Mắt Hư Vô', en: 'Void Eye' }, title: { vi: 'Kẻ Nuốt Chiều Không Gian', en: 'Devourer of Dimensions' }, world: 'dark_dimension', hp: 34, speedMul: 1.12, gapMul: 0.96, patterns: ['zigzag', 'narrow', 'sine', 'stairs_up', 'wave', 'breather'], reward: { coins: 600, gems: 8, xp: 420 }, color: '#a070ff' },
];
export const BOSS_BY_ID: Record<string, BossDef> = Object.fromEntries(BOSSES.map((b) => [b.id, b]));
