// Small shared drawing toolkit for all procedural renderers.
import { hexToRgb } from '../core/util';

export type Ctx = CanvasRenderingContext2D;

export function makeCanvas(w: number, h: number): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.ceil(w));
  c.height = Math.max(1, Math.ceil(h));
  return c;
}
export function ctx2d(c: HTMLCanvasElement): Ctx {
  return c.getContext('2d') as Ctx;
}

const glowCache = new Map<string, HTMLCanvasElement>();
/** 128px soft radial sprite (bright core, long falloff). Cached per color. */
export function glowSprite(color: string): HTMLCanvasElement {
  let c = glowCache.get(color);
  if (c) return c;
  c = makeCanvas(128, 128);
  const g = ctx2d(c);
  const [r, gr, b] = hexToRgb(color);
  const grad = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  grad.addColorStop(0, `rgba(${Math.min(255, r + 70)},${Math.min(255, gr + 70)},${Math.min(255, b + 70)},1)`);
  grad.addColorStop(0.18, `rgba(${r},${gr},${b},0.75)`);
  grad.addColorStop(0.5, `rgba(${r},${gr},${b},0.22)`);
  grad.addColorStop(1, `rgba(${r},${gr},${b},0)`);
  g.fillStyle = grad;
  g.fillRect(0, 0, 128, 128);
  if (glowCache.size > 200) glowCache.clear();
  glowCache.set(color, c);
  return c;
}
/** Additive glow ("bloom") blob centered at x,y with radius r. */
export function drawGlow(ctx: Ctx, x: number, y: number, r: number, color: string, alpha = 1): void {
  if (alpha <= 0.002 || r <= 0.5) return;
  const prevOp = ctx.globalCompositeOperation;
  const prevA = ctx.globalAlpha;
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = Math.min(1, alpha) * prevA;
  ctx.drawImage(glowSprite(color), x - r, y - r, r * 2, r * 2);
  ctx.globalAlpha = prevA;
  ctx.globalCompositeOperation = prevOp;
}
/** Soft elliptical drop shadow. */
export function softShadow(ctx: Ctx, x: number, y: number, rx: number, ry: number, alpha: number): void {
  if (alpha <= 0.002) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(1, ry / rx);
  const g = ctx.createRadialGradient(0, 0, 0, 0, 0, rx);
  g.addColorStop(0, `rgba(0,0,0,${alpha})`);
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, 0, rx, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}
export function roundRect(ctx: Ctx, x: number, y: number, w: number, h: number, r: number): void {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}
export function lg(ctx: Ctx, x0: number, y0: number, x1: number, y1: number, stops: ReadonlyArray<readonly [number, string]>): CanvasGradient {
  const g = ctx.createLinearGradient(x0, y0, x1, y1);
  for (const [o, c] of stops) g.addColorStop(o, c);
  return g;
}
export function rg(ctx: Ctx, x: number, y: number, r0: number, r1: number, stops: ReadonlyArray<readonly [number, string]>): CanvasGradient {
  const g = ctx.createRadialGradient(x, y, r0, x, y, r1);
  for (const [o, c] of stops) g.addColorStop(o, c);
  return g;
}
/** Path through a flat [x0,y0,x1,y1,...] array (does not fill/stroke). */
export function polyPath(ctx: Ctx, pts: ReadonlyArray<number>, close = true): void {
  ctx.beginPath();
  ctx.moveTo(pts[0], pts[1]);
  for (let i = 2; i < pts.length; i += 2) ctx.lineTo(pts[i], pts[i + 1]);
  if (close) ctx.closePath();
}
export function starPath(ctx: Ctx, x: number, y: number, outer: number, inner: number, points: number, rot = -Math.PI / 2): void {
  ctx.beginPath();
  for (let i = 0; i < points * 2; i++) {
    const r = i % 2 === 0 ? outer : inner;
    const a = rot + (i * Math.PI) / points;
    const px = x + Math.cos(a) * r, py = y + Math.sin(a) * r;
    if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
  }
  ctx.closePath();
}
/** Draw `fn` into a fresh offscreen canvas of w x h (logical px) at the given pixel ratio. */
export function bake(w: number, h: number, ratio: number, fn: (g: Ctx, w: number, h: number) => void): HTMLCanvasElement {
  const c = makeCanvas(w * ratio, h * ratio);
  const g = ctx2d(c);
  g.scale(ratio, ratio);
  fn(g, w, h);
  return c;
}
