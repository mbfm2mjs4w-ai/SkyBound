import { h, icon } from '../dom';
import type { AppApi } from '../../app/types';
import type { Screen } from '../UI';
import { tr } from '../../core/i18n';
import { formatNumber } from '../../core/util';

/** Base for screens that need cleanup (event subscriptions). */
export class Scr implements Screen {
  el: HTMLElement; private offs: (() => void)[] = [];
  constructor(cls = '') { this.el = h('div', { class: `screen ${cls}` }); }
  on(off: () => void): void { this.offs.push(off); }
  destroy(): void { for (const o of this.offs) o(); this.offs = []; }
}

export function wallet(app: AppApi, scr?: Scr): HTMLElement {
  const c = h('span', {}, formatNumber(app.save.data.coins)), g = h('span', {}, formatNumber(app.save.data.gems));
  const el = h('div', { class: 'wallet' }, h('div', { class: 'chip' }, icon('coin', 20), c), h('div', { class: 'chip' }, icon('gem', 20), g));
  const off = app.save.onChange((d) => { c.textContent = formatNumber(d.coins); g.textContent = formatNumber(d.gems); });
  scr?.on(off);
  return el;
}
export function header(app: AppApi, scr: Scr, title: string, onBack: () => void, extra?: HTMLElement | null): HTMLElement {
  return h('div', { class: 'topbar' },
    h('button', { class: 'glass-btn back', 'aria-label': tr('Quay lại', 'Back'), on: { click: onBack } }, icon('back', 22)),
    h('h2', {}, title), extra ?? null, wallet(app, scr));
}
export function tabs(items: { id: string; label: string }[], cur: string, onPick: (id: string) => void): HTMLElement {
  const el = h('div', { class: 'tabs', role: 'tablist' });
  for (const it of items) el.appendChild(h('button', { class: `tab${it.id === cur ? ' on' : ''}`, role: 'tab', on: { click: () => onPick(it.id) } }, it.label));
  return el;
}
export const price = (p: { coins?: number; gems?: number }): HTMLElement =>
  h('span', { class: 'price' }, p.coins ? [icon('coin', 16), p.coins] : null, p.gems ? [icon('gem', 16), p.gems] : null);
