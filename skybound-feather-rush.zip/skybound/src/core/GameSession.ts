// Pure gameplay simulation (no DOM / canvas). Deterministic given the seed + the flap times.
import { DEFAULT_TUNING, FIXED_DT, MILESTONES, type Tuning } from '../config/gameConfig';
import type { PowerUpType } from './types';
import { Emitter } from './events';
import { clamp, dateKey } from './util';
import { MODES, ADVENTURE_BY_ID, buildDaily, type ModeDef, type ModeId, type DailyDef, type AdventureLevel } from '../data/modes';
import { BOSSES, type BossDef } from '../data/bosses';
import { POWERUPS } from '../data/powerups';
import { WORLD_BY_ID, WORLDS } from '../data/worlds';
import { Bird } from '../entities/Bird';
import { gapAt, type Gate } from '../entities/Obstacle';
import type { Pickup } from '../entities/Coin';
import type { ActivePowerUp } from '../entities/PowerUp';
import { ObstacleGenerator } from '../systems/ObstacleGenerator';
import { applyFlap, stepBird } from '../systems/PhysicsSystem';
import { gateHitsCircle } from '../systems/CollisionSystem';

export type SessionState = 'ready' | 'playing' | 'bossintro' | 'dying' | 'over' | 'victory' | 'finished';

export interface SessionEvents {
  [k: string]: unknown;
  start: null;
  flap: null;
  score: { score: number; gained: number; combo: number; perfect: boolean };
  milestone: { value: number };
  record: { score: number };
  coin: { total: number; value: number; x: number; y: number };
  gem: { total: number; x: number; y: number };
  power: { type: PowerUpType; x: number; y: number };
  powerEnd: { type: PowerUpType };
  hit: { blocked: 'shield' | 'life' | 'time' | 'phoenix' | 'none'; kind: 'gate' | 'floor' };
  death: null;
  gameover: null;
  worldchange: { from: string; to: string };
  bossIntro: { boss: BossDef; index: number };
  bossHit: { hp: number; max: number };
  bossDefeat: { boss: BossDef; index: number };
  secret: null;
  nearMiss: null;
  combo: { combo: number };
  complete: { stars: number };
  tick: null;
}

export interface SessionConfig {
  mode: ModeId;
  worldId: string;
  seed?: number;
  tuning?: Tuning;
  adventureId?: string;
  worldCycle: string[];
  assist?: number;
  bestScore?: number;
  birdX: number;
  hasShieldStart?: boolean;
}

export interface RunResult {
  mode: ModeId; score: number; coins: number; gems: number; distance: number; time: number; gates: number;
  maxCombo: number; perfects: number; powerups: number; bossesDefeated: number; stars: number; completed: boolean;
  newRecord: boolean; worldId: string; secretFound: boolean; flaps: number; adventureId?: string; dailyKey?: string; hits: number;
  worldsVisited: number;
}

const INVULN_TIME = 1.3;

export class GameSession {
  readonly ev = new Emitter<SessionEvents>();
  readonly cfg: SessionConfig;
  readonly mode: ModeDef;
  readonly tuning: Tuning;
  readonly gen: ObstacleGenerator;
  readonly bird = new Bird();
  readonly daily: DailyDef | null;
  readonly level: AdventureLevel | null;

  state: SessionState = 'ready';
  gates: Gate[] = [];
  pickups: Pickup[] = [];
  dist = 0;
  prevDist = 0;
  time = 0;                 // real play time (s)
  worldTime = 0;
  score = 0;
  coins = 0;
  gems = 0;
  combo = 0;
  maxCombo = 0;
  perfects = 0;
  gatesPassed = 0;
  flaps = 0;
  hits = 0;
  powerupsTaken = 0;
  secretFound = false;
  worldId: string;
  tod = 0.12;
  active: ActivePowerUp[] = [];
  shield = false;
  phoenix = false;
  invuln = 0;
  lives = 1;
  maxLives = 1;
  timeLeft = 0;
  timeScale = 1;
  speed = 0;
  speedFactor = 1;           // 0..1 slows the world when dying / finishing
  newRecord = false;
  recordAnnounced = false;
  worldsVisited = 1;
  // boss state
  boss: BossDef | null = null;
  bossIndex = 0;
  bossHp = 0;
  bossMaxHp = 0;
  bossesDefeated = 0;
  private bossGatesLeftToSpawn = 0;
  private bossIntroT = 0;
  // world change
  pendingWorld: string | null = null;
  private stateT = 0;
  private bestScore: number;
  private acc = 0;
  private victoryStars = 0;

  constructor(cfg: SessionConfig) {
    this.cfg = cfg;
    this.mode = MODES[cfg.mode];
    this.tuning = { ...(cfg.tuning ?? DEFAULT_TUNING) };
    this.bestScore = cfg.bestScore ?? 0;
    this.daily = cfg.mode === 'daily' ? buildDaily(dateKey()) : null;
    this.level = cfg.mode === 'adventure' && cfg.adventureId ? ADVENTURE_BY_ID[cfg.adventureId] ?? null : null;
    this.worldId = cfg.worldId;
    if (this.daily) {
      this.worldId = this.daily.worldId;
      for (const m of this.daily.mods) {
        if (m.gravity) this.tuning.gravity *= m.gravity;
        if (m.jump) this.tuning.jump *= m.jump;
      }
    }
    if (this.level) this.worldId = this.level.worldId;
    let startScore = this.mode.startScore;
    if (this.level) startScore = this.level.startScore;
    if (this.daily) for (const m of this.daily.mods) if (m.startScore) startScore += m.startScore;
    let speedMul = 1, gapMul = 1;
    if (this.daily) for (const m of this.daily.mods) { speedMul *= m.speed ?? 1; gapMul *= m.gap ?? 1; }
    const seed = cfg.seed ?? (this.daily ? this.daily.seed : (Math.random() * 0xffffffff) >>> 0);
    this.gen = new ObstacleGenerator({
      tuning: this.tuning, mode: this.mode, seed, startWorld: this.worldId, worldCycle: cfg.worldCycle,
      startScore, assist: cfg.assist ?? 0, daily: this.daily, speedMul, gapMul,
    });
    this.lives = this.maxLives = this.mode.lives >= 999 ? 1 : this.mode.lives;
    if (cfg.mode === 'timeattack') this.timeLeft = this.mode.timeLimit ?? 60;
    this.shield = !!cfg.hasShieldStart;
    this.bird.reset(420, cfg.birdX);
    this.bird.x = cfg.birdX;
    this.bird.shield = this.shield;
    this.tod = WORLD_BY_ID[this.worldId]?.cycle === 'fixed' ? WORLD_BY_ID[this.worldId].fixedTod ?? 0.1 : 0.1 + (Math.random() * 0.3);
    this.speed = this.gen.speedFor(0);
    this.bossIndex = 0;
    if (cfg.mode === 'bossrush') this.beginBoss(0, true);
    this.fill();
  }

  // ------------------------------------------------------------------ public API
  get goal(): number { return this.level?.goal ?? this.daily?.goal ?? 0; }
  get birdX(): number { return this.cfg.birdX; }
  get activeWorld(): string { return this.worldId; }
  has(t: PowerUpType): boolean { return this.active.some((a) => a.type === t); }

  /** Called on every tap / click / space. */
  flap(): void {
    if (this.state === 'ready') {
      if (this.boss && this.bossIntroT > 0) { this.state = 'bossintro'; this.ev.emit('start', null); this.ev.emit('bossIntro', { boss: this.boss, index: this.bossIndex }); }
      else { this.state = 'playing'; this.ev.emit('start', null); }
    }
    if (this.state !== 'playing' && this.state !== 'bossintro') return;
    applyFlap(this.bird.body, this.tuning, 1);
    this.bird.onFlap(1);
    this.flaps++;
    this.ev.emit('flap', null);
  }

  /** Fixed-step update. dt should be FIXED_DT (callers accumulate real time). */
  step(dt: number): void {
    this.stateT += dt;
    const st = this.state;
    if (st === 'ready') {
      // idle hover until the first tap
      this.bird.state = 'idle';
      this.bird.body.prevY = this.bird.body.y;
      this.worldTime += dt * 0.3;
      this.prevDist = this.dist;
      this.dist += this.speed * 0.35 * dt; // gentle parallax in the ready state so the world is alive
      this.advanceTod(dt * 0.3);
      return;
    }
    if (st === 'over' || st === 'finished') return;

    // ---- timers that run in real time
    this.time += dt;
    this.invuln = Math.max(0, this.invuln - dt);
    this.updatePowerups(dt);
    if (this.mode.timeLimit && st === 'playing') {
      this.timeLeft -= dt;
      if (this.timeLeft <= 0) { this.timeLeft = 0; this.finishRun(); return; }
    }

    // ---- time scale / speed
    const warp = this.has('timewarp') ? 0.55 : 1;
    this.timeScale = warp;
    const wdt = dt * warp;
    this.worldTime += wdt;
    let sp = this.gen.speedFor(this.boss ? this.bossIndex * 9 : this.score);
    if (this.has('turbo')) sp *= 1.45;
    if (st === 'dying') this.speedFactor = Math.max(0, this.speedFactor - dt * 2.2);
    else if (st === 'victory') this.speedFactor = Math.max(0.12, this.speedFactor - dt * 0.9);
    else this.speedFactor = Math.min(1, this.speedFactor + dt * 3);
    this.speed = sp;
    this.prevDist = this.dist;
    this.dist += sp * this.speedFactor * wdt;
    this.advanceTod(wdt);

    // ---- bird
    const b = this.bird;
    if (st === 'dying') {
      stepBird(b.body, wdt, this.tuning);
      b.body.rot = Math.min(b.body.rot + dt * 5, 1.5);
      if (b.body.y + this.tuning.birdRadius > this.tuning.floorY + 30) { b.body.y = this.tuning.floorY + 30 - this.tuning.birdRadius; b.body.vy = 0; }
      b.alpha = clamp(1 - Math.max(0, this.stateT - 0.9) * 2.5, 0, 1);
      if (this.stateT > 1.35) { this.state = 'over'; this.ev.emit('gameover', null); }
    } else if (st === 'victory') {
      // glide to mid height and celebrate
      const goalY = 360;
      b.body.prevY = b.body.y;
      b.body.vy += (goalY - b.body.y) * 14 * dt - b.body.vy * 4 * dt;
      b.body.y += b.body.vy * dt;
      b.body.rot *= 0.9;
      if (this.stateT > 2.4) { this.state = 'finished'; this.ev.emit('complete', { stars: this.victoryStars }); }
    } else {
      stepBird(b.body, wdt, this.tuning);
      if (b.body.y < this.tuning.birdRadius) { b.body.y = this.tuning.birdRadius; if (b.body.vy < 0) b.body.vy = 0; }
      // bird anim state
      if (this.has('turbo')) { b.state = 'boost'; b.boost = true; }
      else {
        b.boost = false;
        b.state = b.hurt > 0.4 ? 'damage' : b.body.vy > 330 ? 'falling' : 'flying';
      }
      b.ghost = this.has('ghost');
      b.shield = this.shield;
    }
    b.update(dt, this.animOf());

    if (st === 'playing' || st === 'bossintro') {
      this.fill();
      this.collisions(wdt);
      this.collect(wdt);
      this.scoring();
      if (this.state === 'bossintro') {
        this.bossIntroT -= dt;
        if (this.bossIntroT <= 0) this.state = 'playing';
      }
      this.bossProgress();
    } else if (st === 'victory') {
      this.collect(wdt);
    }
    // drop things far behind
    while (this.gates.length > 2 && this.gates[0].wx < this.dist - 400) this.gates.shift();
    while (this.pickups.length > 0 && this.pickups[0].wx < this.dist - 400) this.pickups.shift();
  }

  /** Real-time driver: accumulates dt, runs fixed steps, returns the interpolation alpha. */
  advance(realDt: number): number {
    this.acc += Math.min(realDt, 0.1);
    let n = 0;
    while (this.acc >= FIXED_DT && n < 24) { this.step(FIXED_DT); this.acc -= FIXED_DT; n++; }
    if (n >= 24) this.acc = 0;
    return this.acc / FIXED_DT;
  }

  private animOf(): { flapSpeed: number; flapAmp: number; bob: number; tilt: number } {
    return this.animOverride ?? { flapSpeed: 1, flapAmp: 1, bob: 1, tilt: 1 };
  }
  animOverride: { flapSpeed: number; flapAmp: number; bob: number; tilt: number } | null = null;

  private advanceTod(dt: number): void {
    const w = WORLD_BY_ID[this.worldId];
    if (w && w.cycle === 'fixed') return;
    this.tod = (this.tod + dt / 140) % 1;
  }

  // ------------------------------------------------------------------ spawning
  private fill(): void {
    const horizon = this.dist + 1500;
    // boss sections only generate exactly `hp` gates
    let guard = 0;
    while ((this.gates.length === 0 || this.gates[this.gates.length - 1].wx < horizon) && guard++ < 40) {
      if (this.boss && this.bossGatesLeftToSpawn <= 0) break;
      const out = this.gen.next(this.boss ? this.bossIndex * 9 : this.score);
      out.gate.spawnedAt = this.time;
      this.gates.push(out.gate);
      for (const p of out.pickups) this.pickups.push(p);
      if (this.boss) this.bossGatesLeftToSpawn--;
    }
  }

  // ------------------------------------------------------------------ collisions
  private collisions(wdt: number): void {
    const t = this.tuning;
    const r = t.birdRadius * t.hitboxScale;
    const b = this.bird.body;
    // floor
    if (b.y + r > t.floorY) {
      b.y = t.floorY - r;
      this.hit('floor');
      return;
    }
    if (this.invuln > 0 || this.has('ghost') || this.has('turbo') || this.mode.deathless) return;
    for (const g of this.gates) {
      const rel = g.wx - this.dist;
      if (rel > 120) break;
      if (rel < -120) continue;
      if (gateHitsCircle(g, rel, b.y, r)) { this.hit('gate', g); return; }
    }
    void wdt;
  }

  private hit(kind: 'gate' | 'floor', g?: Gate): void {
    const t = this.tuning;
    const b = this.bird;
    const bounce = (): void => { b.body.y = Math.min(b.body.y, t.floorY - t.birdRadius - 1); b.body.vy = t.jump * 1.05; b.onFlap(1.2); };
    if (this.mode.deathless) { if (kind === 'floor') bounce(); return; }
    if (this.invuln > 0 || this.has('ghost') || this.has('turbo')) { if (kind === 'floor') bounce(); return; }
    this.hits++;
    this.combo = 0;
    if (this.shield) {
      this.shield = false; b.shield = false; this.invuln = INVULN_TIME; b.onHurt();
      if (kind === 'floor') bounce();
      this.ev.emit('hit', { blocked: 'shield', kind });
      return;
    }
    if (this.mode.timeLimit) {
      this.timeLeft = Math.max(0, this.timeLeft - (this.mode.hitPenalty ?? 5)); this.invuln = INVULN_TIME; b.onHurt();
      if (kind === 'floor') bounce();
      this.ev.emit('hit', { blocked: 'time', kind });
      return;
    }
    if (this.lives > 1) {
      this.lives--; this.invuln = INVULN_TIME * 1.2; b.onHurt();
      if (kind === 'floor') bounce();
      this.ev.emit('hit', { blocked: 'life', kind });
      return;
    }
    if (this.phoenix) {
      this.phoenix = false; this.invuln = 2.6; b.onHurt();
      this.reviveToSafety();
      this.ev.emit('hit', { blocked: 'phoenix', kind });
      return;
    }
    // death
    this.ev.emit('hit', { blocked: 'none', kind });
    void g;
    this.die();
  }

  private reviveToSafety(): void {
    const b = this.bird.body;
    let target: Gate | null = null;
    for (const g of this.gates) if (g.wx + g.halfW + 20 > this.dist) { target = g; break; }
    if (target) {
      const rel = Math.max(0, target.wx - this.dist);
      const gp = gapAt(target, rel, { center: 0, half: 0 });
      b.y = clamp(gp.center, 90, this.tuning.floorY - 90); b.prevY = b.y;
    } else { b.y = 380; b.prevY = 380; }
    b.vy = this.tuning.jump * 0.6;
  }

  private die(): void {
    if (this.state === 'dying' || this.state === 'over') return;
    this.state = 'dying'; this.stateT = 0;
    this.bird.state = 'death'; this.bird.deathT = 0;
    this.bird.body.vy = this.tuning.jump * 0.55;
    this.ev.emit('death', null);
  }

  // ------------------------------------------------------------------ pickups
  private collect(wdt: number): void {
    const b = this.bird.body;
    const r = this.tuning.birdRadius;
    const magnet = this.has('magnet');
    const storm = this.has('featherstorm');
    const bx = this.dist; // world distance of the bird
    for (const p of this.pickups) {
      if (p.collected) continue;
      const dx = p.wx - bx, dy = p.y - b.y;
      const d2 = dx * dx + dy * dy;
      if ((magnet || storm) && (p.kind === 'coin' || p.kind === 'gem')) {
        const range = magnet ? 230 : 160;
        if (d2 < range * range && d2 > 1) {
          const d = Math.sqrt(d2);
          const pull = Math.min(d, 900 * wdt + 4);
          p.wx -= (dx / d) * pull; p.y -= (dy / d) * pull;
        }
      }
      const rr = p.r + r;
      if (d2 < rr * rr) {
        p.collected = true; p.collectT = 0.001;
        this.onPickup(p);
      }
    }
  }

  private onPickup(p: Pickup): void {
    const x = this.bird.x + (p.wx - this.dist), y = p.y;
    switch (p.kind) {
      case 'coin': {
        const v = Math.max(1, Math.round(p.value * this.mode.coinMul));
        this.coins += v; this.ev.emit('coin', { total: this.coins, value: v, x, y });
        break;
      }
      case 'gem': this.gems += 1; this.ev.emit('gem', { total: this.gems, x, y }); break;
      case 'power': if (p.power) this.grant(p.power, x, y); break;
      case 'secret': this.secretFound = true; this.coins += 50; this.ev.emit('secret', null); break;
    }
  }

  grant(type: PowerUpType, x = this.bird.x, y = this.bird.body.y): void {
    const def = POWERUPS[type];
    this.powerupsTaken++;
    if (type === 'shield') { this.shield = true; this.bird.shield = true; }
    else if (type === 'phoenix') { this.phoenix = true; }
    else {
      const ex = this.active.find((a) => a.type === type);
      if (ex) { ex.remaining = def.duration; ex.total = def.duration; }
      else this.active.push({ type, remaining: def.duration, total: def.duration });
    }
    this.ev.emit('power', { type, x, y });
  }

  private updatePowerups(dt: number): void {
    for (let i = this.active.length - 1; i >= 0; i--) {
      const a = this.active[i];
      a.remaining -= dt;
      if (a.remaining <= 0) {
        this.active.splice(i, 1);
        if (a.type === 'turbo') this.invuln = Math.max(this.invuln, 0.9);
        if (a.type === 'ghost') this.invuln = Math.max(this.invuln, 0.7);
        this.ev.emit('powerEnd', { type: a.type });
      }
    }
  }

  // ------------------------------------------------------------------ scoring / progression
  private scoring(): void {
    for (const g of this.gates) {
      if (g.passed) continue;
      const rel = g.wx - this.dist;
      if (rel > 0) break;
      g.passed = true;
      this.gatesPassed++;
      const gp = gapAt(g, 0, { center: 0, half: 0 });
      const free = Math.max(1, gp.half - this.tuning.birdRadius);
      const off = Math.abs(this.bird.body.y - gp.center);
      const perfect = off < free * 0.55;
      const graze = off > free * 0.88;
      if (perfect) { this.combo++; this.perfects++; this.maxCombo = Math.max(this.maxCombo, this.combo); this.ev.emit('combo', { combo: this.combo }); }
      else if (graze) { this.combo = 0; this.ev.emit('nearMiss', null); }
      let gained = 1;
      if (this.has('multiplier')) gained *= 2;
      if (this.has('featherstorm')) gained += 2;
      if (this.mode.scored) {
        const prev = this.score;
        this.score += gained;
        this.ev.emit('score', { score: this.score, gained, combo: this.combo, perfect });
        for (const m of MILESTONES) if (prev < m && this.score >= m) this.ev.emit('milestone', { value: m });
        if (!this.recordAnnounced && this.bestScore > 5 && this.score > this.bestScore && this.mode.id !== 'daily') {
          this.recordAnnounced = true; this.newRecord = true; this.ev.emit('record', { score: this.score });
        }
        if (this.combo > 0 && this.combo % 5 === 0) { this.coins += 2; this.ev.emit('coin', { total: this.coins, value: 2, x: this.bird.x, y: this.bird.body.y - 30 }); }
      }
      if (g.nextWorld) this.changeWorld(g.nextWorld);
      if (g.bossIndex !== undefined && this.boss) {
        this.bossHp = Math.max(0, this.bossHp - 1);
        this.ev.emit('bossHit', { hp: this.bossHp, max: this.bossMaxHp });
      }
      this.checkGoal();
    }
    if (this.score > this.bestScore && this.mode.scored && this.score > 0) { /* record tracked above */ }
  }

  private changeWorld(to: string): void {
    const from = this.worldId;
    if (from === to) return;
    this.worldId = to; this.worldsVisited++;
    this.ev.emit('worldchange', { from, to });
  }

  private checkGoal(): void {
    const goal = this.goal;
    if (!goal || this.state === 'victory' || this.state === 'finished' || this.state === 'dying') return;
    if (this.score >= goal) {
      let stars = 1;
      if (this.level) {
        if (this.coins >= this.level.coinGoal) stars++;
        if (this.maxCombo >= Math.ceil(this.level.goal * 0.7)) stars++;
      } else stars = 3;
      this.victoryStars = stars;
      this.state = 'victory'; this.stateT = 0; this.bird.state = 'victory'; this.bird.victoryT = 0;
      this.invuln = 99;
    }
  }

  // ------------------------------------------------------------------ bosses
  private beginBoss(index: number, initial = false): void {
    const boss = BOSSES[index];
    this.boss = boss; this.bossIndex = index;
    this.bossHp = this.bossMaxHp = boss.hp;
    this.bossGatesLeftToSpawn = boss.hp;
    this.bossIntroT = 2.8;
    if (!initial) this.state = 'bossintro';
    else this.state = 'ready';
    // the arena world replaces the current one (cinematic world change)
    const from = this.worldId;
    this.worldId = boss.world;
    if (!initial && from !== boss.world) this.ev.emit('worldchange', { from, to: boss.world });
    const startWx = initial ? 700 : Math.max(this.gates.length ? this.gates[this.gates.length - 1].wx : this.dist, this.dist) + 300;
    this.gen.startSection(startWx, boss, boss.world);
    if (!initial) this.ev.emit('bossIntro', { boss, index });
  }

  private bossProgress(): void {
    if (!this.boss) return;
    if (this.state === 'bossintro') return;
    if (this.bossHp <= 0 && this.bossGatesLeftToSpawn <= 0) {
      const defeated = this.boss; const idx = this.bossIndex;
      this.bossesDefeated++;
      this.score += 10;
      this.coins += defeated.reward.coins;
      this.gems += defeated.reward.gems;
      this.ev.emit('bossDefeat', { boss: defeated, index: idx });
      this.boss = null;
      if (idx + 1 >= BOSSES.length) {
        this.victoryStars = 3; this.state = 'victory'; this.stateT = 0; this.bird.state = 'victory'; this.invuln = 99;
      } else {
        this.beginBoss(idx + 1);
      }
    }
  }

  /** Force-end (time attack timer / quit). */
  finishRun(): void {
    if (this.state === 'over' || this.state === 'finished') return;
    if (this.mode.timeLimit) { this.state = 'over'; this.ev.emit('gameover', null); return; }
    if (this.mode.deathless) { this.state = 'finished'; this.ev.emit('complete', { stars: 0 }); return; }
    this.die();
  }

  /** Progress indicator for the HUD: 0..1 + label key. */
  progress(): { frac: number; kind: 'goal' | 'boss' | 'time' | 'world' | 'none' } {
    if (this.boss) return { frac: 1 - this.bossHp / Math.max(1, this.bossMaxHp), kind: 'boss' };
    if (this.goal) return { frac: clamp(this.score / this.goal, 0, 1), kind: 'goal' };
    if (this.mode.timeLimit) return { frac: 1 - this.timeLeft / this.mode.timeLimit, kind: 'time' };
    const rot = this.mode.worldRotate;
    if (rot > 0) return { frac: clamp((this.gatesPassed % rot) / rot, 0, 1), kind: 'world' };
    return { frac: 0, kind: 'none' };
  }

  result(): RunResult {
    const completed = this.state === 'finished' || this.state === 'victory';
    const best = this.bestScore;
    return {
      mode: this.mode.id, score: this.score, coins: this.coins, gems: this.gems,
      distance: Math.floor(this.dist / 50), time: this.time, gates: this.gatesPassed, maxCombo: this.maxCombo,
      perfects: this.perfects, powerups: this.powerupsTaken, bossesDefeated: this.bossesDefeated,
      stars: completed ? this.victoryStars : 0, completed: completed && (this.mode.id !== 'zen'),
      newRecord: this.mode.scored && this.mode.id !== 'daily' && this.score > best && this.score > 0,
      worldId: this.worldId, secretFound: this.secretFound, flaps: this.flaps, hits: this.hits,
      adventureId: this.level?.id, dailyKey: this.daily?.key, worldsVisited: this.worldsVisited,
    };
  }
}

export const NON_HIDDEN_WORLDS = WORLDS.filter((w) => !w.hidden).map((w) => w.id);
