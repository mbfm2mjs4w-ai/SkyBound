import type { L10n, Lang } from './types';

let current: Lang = 'vi';
const listeners = new Set<() => void>();

export function getLang(): Lang { return current; }
export function setLang(l: Lang): void {
  if (l !== 'vi' && l !== 'en') return;
  if (l === current) return;
  current = l;
  try { document.documentElement.lang = l; } catch { /* non-DOM */ }
  for (const fn of Array.from(listeners)) fn();
}
export function onLangChange(fn: () => void): () => void { listeners.add(fn); return () => { listeners.delete(fn); }; }

/** Pick the string for the current language. Both languages live at the call site (no key lookup needed). */
export function tr(vi: string, en: string): string { return current === 'vi' ? vi : en; }
export function loc(l: L10n): string { return l[current]; }
export function detectLang(): Lang {
  try { return (navigator.language || 'vi').toLowerCase().startsWith('vi') ? 'vi' : 'en'; } catch { return 'vi'; }
}
