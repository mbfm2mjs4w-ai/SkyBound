// Five distinct bosses drawn procedurally. (x,y) = centre; s = scale; look = target to stare at (bird).
import type { BossDef } from '../data/bosses';
import { clamp, rgba, shadeHex, TAU } from '../core/util';
import { drawGlow, roundRect, starPath, type Ctx } from './gfx';

export function drawBoss(c: Ctx, boss: BossDef, x: number, y: number, s: number, t: number, hurt: number, lookX: number, lookY: number, appear = 1): void {
  c.save(); c.translate(x, y); c.scale(s, s); c.globalAlpha *= clamp(appear, 0, 1);
  const flash = hurt > 0 ? hurt : 0;
  const body = (col: string): string => (flash > 0.01 ? '#ffffff' : col);
  switch (boss.id) {
    case 'stone_golem': {
      const sw = Math.sin(t * 1.4) * 0.12;
      for (const sd of [-1, 1]) { c.save(); c.translate(sd * 92, -10); c.rotate(sd * (0.3 + sw)); c.fillStyle = body('#7d8a72'); roundRect(c, -22, 0, 44, 120, 14); c.fill(); c.fillStyle = body('#5d6a52'); roundRect(c, -28, 110, 56, 50, 12); c.fill(); c.restore(); }
      c.fillStyle = body('#8b987e'); roundRect(c, -80, -90, 160, 190, 26); c.fill();
      c.fillStyle = body('#6c7a60'); roundRect(c, -60, -170, 120, 96, 22); c.fill();
      c.fillStyle = rgba('#4caf50', 0.75); for (let i = 0; i < 8; i++) { c.beginPath(); c.arc(-70 + i * 20, -92 + Math.sin(i) * 6, 12, 0, TAU); c.fill(); }
      const e = 0.7 + 0.3 * Math.sin(t * 3); for (const sd of [-1, 1]) { drawGlow(c, sd * 24 + lookX * 6, -128 + lookY * 4, 26, '#9dffb8', e); c.fillStyle = '#d7ffe3'; c.beginPath(); c.arc(sd * 24 + lookX * 6, -128 + lookY * 4, 8, 0, TAU); c.fill(); }
      c.strokeStyle = rgba('#2f3b28', 0.6); c.lineWidth = 3; c.beginPath(); c.moveTo(-30, -30); c.lineTo(-10, 10); c.lineTo(-34, 50); c.moveTo(40, -50); c.lineTo(22, -10); c.stroke(); break;
    }
    case 'frost_wyrm': {
      for (let i = 14; i >= 0; i--) {
        const u = i / 14, px = Math.sin(t * 1.6 + u * 4.5) * 40 - u * 130 + 30, py = -60 + u * 230 + Math.sin(t * 2 + u * 6) * 14, r = 46 - u * 24;
        drawGlow(c, px, py, r * 1.9, '#9fe8ff', 0.18); c.fillStyle = body(i % 2 ? '#7fd0ff' : '#a8e6ff'); c.beginPath(); c.arc(px, py, r, 0, TAU); c.fill();
        c.fillStyle = body('#e6faff'); starPath(c, px, py - r, r * 0.5, r * 0.15, 3, -Math.PI / 2); c.fill();
      }
      const hx = 30, hy = -60; c.fillStyle = body('#d6f4ff'); c.beginPath(); c.moveTo(hx - 40, hy - 30); c.lineTo(hx + 70, hy + 6); c.lineTo(hx - 30, hy + 44); c.closePath(); c.fill();
      c.fillStyle = body('#7fd0ff'); c.beginPath(); c.moveTo(hx - 30, hy - 30); c.lineTo(hx - 60, hy - 78); c.lineTo(hx - 6, hy - 34); c.fill();
      drawGlow(c, hx + 10 + lookX * 4, hy - 8, 20, '#ff6a6a', 0.9); c.fillStyle = '#ff3a3a'; c.beginPath(); c.arc(hx + 10 + lookX * 4, hy - 8, 5, 0, TAU); c.fill();
      c.globalCompositeOperation = 'lighter'; for (let i = 0; i < 6; i++) drawGlow(c, hx + 70 + i * 22, hy + 10 + Math.sin(t * 6 + i) * 8, 16 - i * 2, '#cfefff', 0.5 - i * 0.07); break;
    }
    case 'inferno_titan': {
      c.fillStyle = body('#2b100b'); c.beginPath(); c.moveTo(-130, 170); c.lineTo(-90, -40); c.lineTo(-40, -110); c.lineTo(40, -110); c.lineTo(90, -40); c.lineTo(130, 170); c.closePath(); c.fill();
      c.globalCompositeOperation = 'lighter'; c.strokeStyle = rgba('#ff8a2b', 0.8 + 0.2 * Math.sin(t * 4)); c.lineWidth = 5; c.beginPath(); c.moveTo(-60, 150); c.lineTo(-40, 60); c.lineTo(-70, 0); c.moveTo(20, 160); c.lineTo(40, 70); c.lineTo(10, -20); c.moveTo(80, 140); c.lineTo(70, 40); c.stroke();
      for (const sd of [-1, 1]) { c.globalCompositeOperation = 'source-over'; c.fillStyle = body('#3a1410'); c.beginPath(); c.moveTo(sd * 36, -100); c.lineTo(sd * 90, -190 + Math.sin(t * 2) * 6); c.lineTo(sd * 60, -90); c.fill(); }
      c.globalCompositeOperation = 'lighter'; for (const sd of [-1, 1]) { drawGlow(c, sd * 26 + lookX * 5, -62, 30, '#ffd34a', 1); } drawGlow(c, 0, -20, 40, '#ff6a1a', 0.6 + 0.3 * Math.sin(t * 5));
      for (let i = 0; i < 8; i++) drawGlow(c, -50 + i * 14, -112 - ((t * 60 + i * 23) % 60), 10, '#ff8a2b', 0.5); break;
    }
    case 'cyber_sentinel': {
      const rot = t * 0.7;
      c.strokeStyle = rgba('#00e5ff', 0.8); c.lineWidth = 4; for (let k = 0; k < 3; k++) { c.save(); c.rotate(rot * (k % 2 ? -1 : 1) + k); c.beginPath(); c.ellipse(0, 0, 120 - k * 18, 34 + k * 10, 0, 0, TAU * 0.85); c.stroke(); c.restore(); }
      const g = c.createRadialGradient(-20, -24, 6, 0, 0, 78); g.addColorStop(0, body('#5a4ad0')); g.addColorStop(1, body('#10083a')); c.fillStyle = g; c.beginPath(); c.arc(0, 0, 78, 0, TAU); c.fill(); c.strokeStyle = '#00e5ff'; c.lineWidth = 3; c.stroke();
      c.fillStyle = body('#1b1060'); c.beginPath(); c.arc(lookX * 8, lookY * 6, 40, 0, TAU); c.fill(); drawGlow(c, lookX * 12, lookY * 8, 52, '#ff2b4a', 0.9); c.fillStyle = '#ffd1d9'; c.beginPath(); c.arc(lookX * 14, lookY * 9, 11, 0, TAU); c.fill();
      for (let i = 0; i < 4; i++) { const a = rot * 1.5 + i * TAU / 4; c.fillStyle = body('#2a1a90'); c.save(); c.translate(Math.cos(a) * 110, Math.sin(a) * 60); c.rotate(a); roundRect(c, -14, -8, 28, 16, 4); c.fill(); c.restore(); }
      break;
    }
    case 'void_eye': {
      for (let i = 0; i < 9; i++) { const a = (i / 9) * TAU + t * 0.2; c.strokeStyle = rgba('#a070ff', 0.55); c.lineWidth = 9; c.lineCap = 'round'; c.beginPath(); c.moveTo(Math.cos(a) * 90, Math.sin(a) * 70); c.bezierCurveTo(Math.cos(a) * 150, Math.sin(a) * 120 + Math.sin(t * 2 + i) * 30, Math.cos(a + 0.5) * 190, Math.sin(a + 0.5) * 150, Math.cos(a + 0.2) * 220, Math.sin(a + 0.2) * 180 + Math.sin(t * 3 + i) * 20); c.stroke(); }
      drawGlow(c, 0, 0, 180, '#7a3aff', 0.5);
      c.fillStyle = body('#f4ecff'); c.beginPath(); c.ellipse(0, 0, 110, 70, 0, 0, TAU); c.fill();
      const ix = lookX * 34, iy = lookY * 20; const ig = c.createRadialGradient(ix, iy, 4, ix, iy, 44); ig.addColorStop(0, '#ff4ad0'); ig.addColorStop(0.55, '#7a3aff'); ig.addColorStop(1, '#2a0a60'); c.fillStyle = ig; c.beginPath(); c.arc(ix, iy, 44, 0, TAU); c.fill();
      c.fillStyle = '#000'; c.beginPath(); c.ellipse(ix, iy, 12, 30 * (0.8 + 0.2 * Math.sin(t * 2)), 0, 0, TAU); c.fill();
      c.strokeStyle = rgba('#2a0a60', 0.8); c.lineWidth = 6; c.beginPath(); c.ellipse(0, 0, 110, 70, 0, 0, TAU); c.stroke(); break;
    }
  }
  void shadeHex;
  c.restore();
}
