import css from './styles/main.css';
import { App } from './app/App';

const style = document.createElement('style'); style.textContent = css; document.head.appendChild(style);
const root = document.getElementById('app');
if (!root) throw new Error('#app missing');
const app = new App(root);
void app.boot();
if ('serviceWorker' in navigator && location.protocol.startsWith('http') && !location.hostname.match(/^(localhost|127\.)/)) {
  window.addEventListener('load', () => { navigator.serviceWorker.register('./sw.js').catch(() => { /* optional */ }); });
}
