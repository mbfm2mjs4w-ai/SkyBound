import type { PowerUpType } from '../core/types';

export type PickupKind = 'coin' | 'gem' | 'power' | 'secret';

/** Anything the bird can collect. `wx` is the absolute world distance, like gates. */
export interface Pickup {
  id: number;
  kind: PickupKind;
  wx: number;
  y: number;
  r: number;              // collection radius (bird radius added on top)
  power?: PowerUpType;    // for kind 'power'
  value: number;          // coin / gem amount
  collected: boolean;
  collectT: number;       // 0..1 collect animation progress (render only)
  // magnet pull offsets (render + collision use wx + ox / y + oy)
  ox: number;
  oy: number;
}
