// Application shell: boot → menu ↔ screens ↔ run. Owns every manager and the main loop.
import { Engine } from '../engine/Engine';
import { Input } from '../engine/Input';
import { AudioManager } from '../audio/AudioManager';
import { SaveManager } from '../systems/SaveManager';
import { ProgressionManager, type RunSummary } from '../systems/ProgressionManager';
import { NetworkManager } from '../net/NetworkManager';
import { WorldRenderer } from '../render/WorldRenderer';
import { ObstacleRenderer } from '../render/ObstacleRenderer';
import { drawBird } from '../render/BirdRenderer';
import { Trail, ParticleManager } from '../render/ParticleManager';
import { newPose } from '../entities/Bird';
import { GameScene } from '../scenes/GameScene';
import { GameSession, NON_HIDDEN_WORLDS, type RunResult, type SessionConfig } from '../core/GameSession';
import { UI, type Screen } from '../ui/UI';
import { h } from '../ui/dom';
import { tr, setLang, detectLang } from '../core/i18n';
import { DEFAULT_TUNING, QUALITY, type Tuning } from '../config/gameConfig';
import type { QualityName, QualityProfile, ViewState } from '../core/types';
import { WORLD_BY_ID, DEFAULT_WORLD } from '../data/worlds';
import { SKIN_BY_ID, DEFAULT_SKIN } from '../data/skins';
import { clamp, damp } from '../core/util';
import type { AppApi, RunOptions, ScreenName } from './types';
import { mainMenu, playScreen, adventureScreen, pauseScreen, gameOverScreen } from '../ui/screens/core';
import { SCREENS_EXTRA } from '../ui/screens/registry';
import type { SettingsData } from '../systems/SaveManager';

export function makeTuning(s: SettingsData): Tuning {
  const t = { ...DEFAULT_TUNING }, k = s.tuning;
  t.gravity *= k.gravity; t.jump *= k.jump; t.speedBase *= k.speed; t.speedMax *= k.speed;
  t.spacingTime *= k.spacing; t.spacingMin *= k.spacing; t.hitboxScale *= k.hitbox; t.difficultyRamp /= Math.max(0.3, k.difficulty);
  t.maxClimbRate *= clamp(k.jump / Math.sqrt(Math.max(0.3, k.gravity)), 0.5, 1.5);
  return t;
}

export class App implements AppApi {
  readonly engine: Engine; readonly input: Input; readonly audio = new AudioManager();
  readonly save: SaveManager; readonly prog: ProgressionManager; readonly net = new NetworkManager();
  readonly ui: UI; readonly worldR: WorldRenderer = new WorldRenderer(QUALITY.high); readonly obstacleR = new ObstacleRenderer();
  quality: QualityProfile = QUALITY.high;
  scene: GameScene | null = null;
  lastRun: RunOptions | null = null;
  screenName: ScreenName | 'boot' | 'game' | 'over' = 'boot';
  private backWorld = DEFAULT_WORLD; private bdScroll = 0; private bdTod = 0.12; private bdTrail = new Trail(); private bdParticles: ParticleManager; private bdPose = newPose(); private bdT = 0;
  private view: ViewState;
  private lowFpsT = 0; private autoQ = true;

  constructor(private root: HTMLElement) {
    this.save = new SaveManager();
    this.prog = new ProgressionManager(this.save);
    const s = this.save.data.settings;
    setLang(s.lang || detectLang());
    this.engine = new Engine(root);
    this.ui = new UI(root, this.audio);
    this.input = new Input(root);
    this.input.enabled = false;
    this.quality = this.resolveQuality();
    this.bdParticles = new ParticleManager(this.quality);
    this.view = { W: this.engine.W, H: this.engine.H, time: 0, scroll: 0, camY: 0, tod: 0.12, intensity: 0.2, quality: this.quality, reducedMotion: s.reducedMotion };
    this.wire();
    this.applySettings();
    this.backWorld = this.save.data.selectedWorld in WORLD_BY_ID ? this.save.data.selectedWorld : DEFAULT_WORLD;
    (window as unknown as { __sb: App }).__sb = this;
  }

  // ------------------------------------------------------------------ boot
  async boot(): Promise<void> {
    const sv = this.save.data;
    const bar = h('i', { style: 'width:0' }), msg = h('small', {}, tr('Đang tải thế giới…', 'Loading world…'));
    const splash: Screen = { el: h('div', { class: 'screen', style: 'align-items:center;justify-content:center;gap:1rem;text-align:center' },
      h('div', { class: 'logo' }, h('b', {}, 'SKYBOUND'), h('span', {}, 'FEATHER RUSH ∞')), h('div', { class: 'bar', style: 'width:min(18rem,70vw)' }, bar), msg) };
    this.ui.show(splash);
    this.engine.start((dt, now) => this.frame(dt, now));
    const world = this.backWorld;
    const it = this.worldR.prepareGen(world, this.engine.W, this.engine.H, this.engine.dpr);
    let n = 0;
    await new Promise<void>((res) => { const step = (): void => { const r = it.next(); n++; bar.style.width = `${Math.min(95, n * 22)}%`; if (r.done) res(); else setTimeout(step, 16); }; step(); });
    bar.style.width = '100%';
    void this.net.init().then(() => { if (this.net.signedIn) void this.net.setProfile(sv.profile.name, sv.profile.avatar); });
    await new Promise((r) => setTimeout(r, 250));
    this.open('menu');
  }

  private resolveQuality(): QualityProfile {
    const q = this.save.data.settings.quality;
    this.autoQ = q === 'auto';
    if (q !== 'auto') return QUALITY[q as QualityName];
    const coarse = matchMedia('(pointer:coarse)').matches, small = Math.min(innerWidth, innerHeight) < 600, mem = (navigator as Navigator & { deviceMemory?: number }).deviceMemory ?? 8;
    return QUALITY[coarse && (small || mem <= 4) ? 'medium' : 'high'];
  }
  private setQualityProfile(q: QualityProfile): void {
    this.quality = q; this.engine.setDprCap(q.dprCap); this.worldR.setQuality(q); this.view.quality = q; this.bdParticles.setQuality(q);
  }

  applySettings(): void {
    const s = this.save.data.settings;
    setLang(s.lang);
    this.audio.setVolumes({ master: s.master, music: s.music, sfx: s.sfx, muted: s.muted });
    this.input.control = s.control;
    document.documentElement.classList.toggle('reduced', s.reducedMotion);
    this.view.reducedMotion = s.reducedMotion;
    const q = this.resolveQuality(); if (q !== this.quality) this.setQualityProfile(q); else this.engine.setDprCap(q.dprCap);
  }
  toggleFullscreen(): void {
    const d = document as Document & { webkitFullscreenElement?: Element; webkitExitFullscreen?: () => void };
    const el = document.documentElement as HTMLElement & { webkitRequestFullscreen?: () => void };
    if (d.fullscreenElement || d.webkitFullscreenElement) { void (d.exitFullscreen?.() ?? d.webkitExitFullscreen?.()); }
    else { try { void (el.requestFullscreen?.() ?? el.webkitRequestFullscreen?.()); } catch { this.ui.toast(tr('Trình duyệt không hỗ trợ toàn màn hình', 'Fullscreen not supported'), 'err'); } }
  }
  resetProgress(): void {
    this.save.reset(); this.prog.ensureMissions(); this.prog.syncUnlocks(); this.applySettings(); this.backWorld = this.save.data.selectedWorld; this.open('menu');
  }

  // ------------------------------------------------------------------ wiring
  private wire(): void {
    const unlock = (): void => { this.audio.unlock(); this.audio.ready(); };
    window.addEventListener('pointerdown', unlock, { capture: true }); window.addEventListener('keydown', unlock, { capture: true }); window.addEventListener('touchend', unlock, { capture: true });
    this.input.ev.on('flap', () => this.scene?.flap());
    this.input.ev.on('pause', () => { if (this.scene) this.scene.pause(); });
    this.input.ev.on('back', () => { if (!this.scene && this.ui.closeTopModal()) return; });
    this.input.ev.on('restart', () => { if (this.scene && this.lastRun && this.scene.session.state !== 'ready') this.startRun(this.lastRun); });
    this.engine.ev.on('hidden', () => { this.scene?.pause(); this.audio.suspend(); });
    this.engine.ev.on('visible', () => { this.audio.resume(); });
    this.engine.ev.on('resize', () => { this.view.W = this.engine.W; this.view.H = this.engine.H; });
    window.addEventListener('beforeunload', () => this.save.flush());
    window.addEventListener('pagehide', () => this.save.flush());
    this.prog.ev.on('achievement', (a) => { if (this.screenName === 'game' || this.screenName === 'over') return; /* listed on the game-over card instead */ this.ui.toast(`${tr('Thành tựu', 'Achievement')}: ${a.name[this.save.data.settings.lang]}`, 'ach', 3500, 'medal'); this.audio.sfx('achievement'); });
  }

  // ------------------------------------------------------------------ screens
  open(name: ScreenName): void {
    this.endScene();
    this.ui.clearModals();
    const reg: Partial<Record<ScreenName, (a: AppApi) => Screen>> = { menu: mainMenu, play: playScreen, adventure: adventureScreen, ...SCREENS_EXTRA };
    const make = reg[name] ?? mainMenu;
    this.screenName = name;
    this.input.enabled = false;
    this.ui.show(make(this));
    this.audio.playMusic('menu'); this.audio.setAmbient('menu', null); this.audio.setIntensity(0.25);
    if (this.backWorld !== this.save.data.selectedWorld && WORLD_BY_ID[this.save.data.selectedWorld]) this.setBackdropWorld(this.save.data.selectedWorld);
  }
  /** Re-render the current menu screen (language change, purchases...). */
  refresh(): void { if (this.screenName !== 'boot' && this.screenName !== 'game' && this.screenName !== 'over') this.open(this.screenName); }
  setBackdropWorld(id: string): void { if (!WORLD_BY_ID[id]) return; this.backWorld = id; this.worldR.prepare(id, this.engine.W, this.engine.H, this.engine.dpr); this.worldR.releaseExcept([id, ...(this.scene ? [this.scene.session.worldId] : [])]); }

  private endScene(): void { if (this.scene) { this.scene.destroy(); this.scene = null; } }

  // ------------------------------------------------------------------ runs
  startRun(o: RunOptions): void {
    this.endScene(); this.ui.clearModals(); this.ui.hide();
    const sv = this.save.data;
    this.lastRun = { ...o };
    const unlocked = NON_HIDDEN_WORLDS.filter((id) => sv.unlockedWorlds.includes(id));
    const cycle = unlocked.length >= 2 ? unlocked : NON_HIDDEN_WORLDS.slice(0, 4);
    const world = o.worldId ?? (sv.unlockedWorlds.includes(sv.selectedWorld) ? sv.selectedWorld : DEFAULT_WORLD);
    const cfg: SessionConfig = { mode: o.mode, worldId: world, tuning: makeTuning(sv.settings), adventureId: o.adventureId, worldCycle: cycle, assist: this.prog.assist(), bestScore: sv.best[o.mode] ?? 0, birdX: this.engine.W * DEFAULT_TUNING.birdXFrac };
    this.screenName = 'game';
    this.scene = new GameScene({
      engine: this.engine, audio: this.audio, save: this.save, prog: this.prog, worldR: this.worldR, obstacleR: this.obstacleR, quality: this.quality, hudParent: this.ui.hudLayer,
      onRunEnd: (s, r, v) => this.showGameOver(s, r, v),
      onPause: (sc) => this.showPause(sc),
    }, cfg);
    this.input.enabled = true;
  }
  private showPause(sc: GameScene): void {
    const resume = (): void => { this.ui.hide(); this.input.enabled = true; sc.resume(); };
    this.input.enabled = false;
    this.ui.show(pauseScreen(this, { resume, restart: () => this.lastRun && this.startRun(this.lastRun), quit: () => this.open('menu'), end: () => { this.ui.hide(); this.input.enabled = false; sc.endRun(); }, canEnd: sc.session.state !== 'ready' }));
    const off = this.input.ev.on('confirm', () => { off(); });
  }
  showGameOver(s: RunSummary, r: RunResult, victory: boolean): void {
    const world = this.scene?.session.worldId; this.endScene(); this.input.enabled = false; this.screenName = 'over';
    if (world && WORLD_BY_ID[world]) this.backWorld = world;
    this.audio.playMusic('menu'); this.audio.setAmbient('menu', null); this.audio.sfx(victory ? 'victory' : 'gameover');
    this.ui.show(gameOverScreen(this, s, r, victory));
  }

  // ------------------------------------------------------------------ frame
  private frame(dt: number, now: number): void {
    const sc = this.scene;
    if (sc) {
      sc.frame(dt, now);
      // adaptive quality (only when the player left quality on "auto"); the scene may have ended during the frame
      if (this.autoQ && this.scene === sc && !sc.paused && sc.session.time > 6) { if (this.engine.fps < 38 && this.engine.fps > 0) this.lowFpsT += dt; else this.lowFpsT = Math.max(0, this.lowFpsT - dt); if (this.lowFpsT > 5) { this.lowFpsT = 0; this.downgrade(); } }
      return;
    }
    this.backdrop(dt);
  }
  private downgrade(): void {
    const order: QualityName[] = ['ultra', 'high', 'medium']; const i = order.indexOf(this.quality.name);
    if (i >= 0 && i < order.length - 1) { this.setQualityProfile(QUALITY[order[i + 1]]); this.ui.toast(tr(`Tự động giảm đồ hoạ xuống ${order[i + 1]} để chơi mượt hơn`, `Graphics automatically lowered to ${order[i + 1]} for smoother play`), 'info'); }
  }

  private backdrop(dt: number): void {
    const e = this.engine, c = e.begin(), v = this.view, w = WORLD_BY_ID[this.backWorld] ?? WORLD_BY_ID[DEFAULT_WORLD];
    this.bdT += dt; this.bdScroll += dt * 70; if (w.cycle === 'full') this.bdTod = (this.bdTod + dt / 120) % 1;
    v.W = e.W; v.H = e.H; v.time = this.bdT; v.scroll = this.bdScroll; v.tod = this.bdTod; v.camY = 0; v.intensity = 0.15;
    if (!this.worldR.isPrepared(w.id)) this.worldR.prepare(w.id, e.W, e.H, e.dpr);
    this.worldR.update(dt, w.id, 70, v);
    this.worldR.drawBackground(c, w.id, v); this.worldR.drawForeground(c, w.id, v);
    // hero bird gliding in the menu
    const skin = SKIN_BY_ID[this.save.data.equippedSkin] ?? SKIN_BY_ID[DEFAULT_SKIN];
    const p = this.bdPose, by = (e.W > e.H * 0.9 ? 380 : 585) + Math.sin(this.bdT * 1.1) * 34, bx = e.W * (e.W > e.H * 0.9 ? 0.68 : 0.5);
    p.x = bx; p.y = by; p.rot = Math.cos(this.bdT * 1.1) * 0.12; p.vy = 0; p.state = 'flying'; p.t = this.bdT; p.flapPhase = (this.bdT * 1.6) % 1; p.wingPower = 0.6; p.blink = 0; p.scale = 1.7; p.mood = 0.6; p.alpha = 1; p.shield = false; p.ghost = false; p.squash = 0;
    this.bdTrail.maxPts = this.quality.trailPoints; this.bdTrail.update(dt, bx - 14, by, 120, true);
    const item = this.save.data.equipped.item as never;
    const showBird = this.screenName === 'menu' || this.screenName === 'play' || this.screenName === 'boot' || this.screenName === 'over';
    if (showBird) { c.save(); this.bdTrail.draw(c, (this.save.data.equipped.trail as never) ?? skin.trail, skin, this.bdT, this.quality); drawBird(c, skin, p, { item, quality: this.quality }); c.restore();
    this.bdParticles.update(dt, 70); if (Math.random() < 0.3) this.bdParticles.shed(bx, by, skin, 70); this.bdParticles.draw(c); }
    this.worldR.drawLighting(c, w.id, v);
    void damp; void GameSession;
  }
}
