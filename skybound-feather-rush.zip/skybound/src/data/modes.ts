import type { L10n } from '../core/types';
import { RNG, hashString } from '../core/util';
import { WORLDS } from './worlds';

export type ModeId = 'classic' | 'endless' | 'hardcore' | 'timeattack' | 'bossrush' | 'daily' | 'adventure' | 'zen';

export interface ModeDef {
  id: ModeId;
  icon: string;
  name: L10n;
  desc: L10n;
  powerups: number;       // spawn frequency multiplier (0 = none)
  coins: number;          // coin spawn multiplier
  worldRotate: number;    // change world every N gates (0 = stay)
  speedMul: number;
  gapMul: number;
  spacingMul: number;
  startScore: number;     // difficulty offset (as if the run started with this score)
  lives: number;          // hits allowed (1 = die on first)
  timeLimit?: number;     // seconds (time attack)
  hitPenalty?: number;    // seconds lost per hit (time attack)
  deathless?: boolean;    // zen: collisions never end the run
  scored: boolean;        // shows score / ranked
  xpMul: number;
  coinMul: number;        // value of each coin
  secretPortal: boolean;
}

export const MODES: Record<ModeId, ModeDef> = {
  classic:    { id: 'classic', icon: '🕊️', name: { vi: 'Cổ Điển', en: 'Classic' }, desc: { vi: 'Bay thuần túy, không vật phẩm. Một chạm, một thế giới.', en: 'Pure flying, no power-ups. One tap, one world.' }, powerups: 0, coins: 0.8, worldRotate: 0, speedMul: 1, gapMul: 1.04, spacingMul: 1, startScore: 0, lives: 1, scored: true, xpMul: 1, coinMul: 1, secretPortal: false },
  endless:    { id: 'endless', icon: '♾️', name: { vi: 'Vô Tận', en: 'Endless' }, desc: { vi: 'Bay mãi mãi qua mọi thế giới với vật phẩm và xu.', en: 'Fly forever across every world with power-ups and coins.' }, powerups: 1, coins: 1, worldRotate: 22, speedMul: 1, gapMul: 1, spacingMul: 1, startScore: 0, lives: 1, scored: true, xpMul: 1.1, coinMul: 1, secretPortal: true },
  hardcore:   { id: 'hardcore', icon: '🔥', name: { vi: 'Hardcore', en: 'Hardcore' }, desc: { vi: 'Tốc độ cao, khe hẹp, ít vật phẩm. Thưởng gấp đôi.', en: 'High speed, tight gaps, scarce power-ups. Double rewards.' }, powerups: 0.45, coins: 1.2, worldRotate: 25, speedMul: 1.14, gapMul: 0.93, spacingMul: 0.94, startScore: 28, lives: 1, scored: true, xpMul: 1.8, coinMul: 2, secretPortal: true },
  timeattack: { id: 'timeattack', icon: '⏱️', name: { vi: 'Thử Thời Gian', en: 'Time Attack' }, desc: { vi: '60 giây để ghi nhiều điểm nhất. Va chạm trừ 5 giây.', en: '60 seconds to score big. Each hit costs 5 seconds.' }, powerups: 0.8, coins: 1.3, worldRotate: 0, speedMul: 1.08, gapMul: 1.04, spacingMul: 0.95, startScore: 8, lives: 999, timeLimit: 60, hitPenalty: 5, scored: true, xpMul: 1, coinMul: 1, secretPortal: false },
  bossrush:   { id: 'bossrush', icon: '👹', name: { vi: 'Boss Rush', en: 'Boss Rush' }, desc: { vi: '5 trùm liên tiếp. Bạn có 3 trái tim.', en: 'Five bosses in a row. You have three hearts.' }, powerups: 0, coins: 1, worldRotate: 0, speedMul: 1, gapMul: 1, spacingMul: 1, startScore: 12, lives: 3, scored: true, xpMul: 1.5, coinMul: 1, secretPortal: false },
  daily:      { id: 'daily', icon: '📅', name: { vi: 'Thử Thách Ngày', en: 'Daily Challenge' }, desc: { vi: 'Thử thách mới mỗi ngày với điều kiện đặc biệt.', en: 'A new challenge every day with special modifiers.' }, powerups: 0.8, coins: 1, worldRotate: 0, speedMul: 1, gapMul: 1, spacingMul: 1, startScore: 5, lives: 1, scored: true, xpMul: 1.3, coinMul: 1, secretPortal: false },
  adventure:  { id: 'adventure', icon: '🗺️', name: { vi: 'Phiêu Lưu', en: 'Adventure' }, desc: { vi: '20 màn chơi theo cốt truyện, chấm sao.', en: '20 story levels with star ratings.' }, powerups: 0.7, coins: 1, worldRotate: 0, speedMul: 1, gapMul: 1, spacingMul: 1, startScore: 0, lives: 1, scored: true, xpMul: 1, coinMul: 1, secretPortal: false },
  zen:        { id: 'zen', icon: '🧘', name: { vi: 'Thiền', en: 'Zen' }, desc: { vi: 'Bay thư giãn, không điểm số, không va chạm.', en: 'Relaxed flight. No score, no crashes.' }, powerups: 0, coins: 0.6, worldRotate: 60, speedMul: 0.78, gapMul: 1.3, spacingMul: 1.1, startScore: 0, lives: 999, deathless: true, scored: false, xpMul: 0.4, coinMul: 1, secretPortal: false },
};
export const MODE_LIST: ModeId[] = ['classic', 'endless', 'hardcore', 'timeattack', 'bossrush', 'daily', 'adventure', 'zen'];

// ------------------------------------------------------------------ Daily Challenge
export interface DailyMod { id: string; name: L10n; gravity?: number; jump?: number; speed?: number; gap?: number; coin?: number; startScore?: number }
export const DAILY_MODS: DailyMod[] = [
  { id: 'lowgrav', name: { vi: 'Trọng lực thấp', en: 'Low gravity' }, gravity: 0.78, jump: 0.88 },
  { id: 'fast', name: { vi: 'Tốc độ cao', en: 'Fast lane' }, speed: 1.14 },
  { id: 'narrow', name: { vi: 'Khe hẹp', en: 'Tight gaps' }, gap: 0.92 },
  { id: 'wide', name: { vi: 'Khe rộng', en: 'Wide gaps' }, gap: 1.12 },
  { id: 'coins', name: { vi: 'Mưa xu', en: 'Coin rain' }, coin: 2 },
  { id: 'heavy', name: { vi: 'Nặng nề', en: 'Heavy wings' }, gravity: 1.18, jump: 1.1 },
  { id: 'warm', name: { vi: 'Khởi động khó', en: 'No warm-up' }, startScore: 22 },
];
export interface DailyDef { key: string; seed: number; worldId: string; mods: DailyMod[]; goal: number; rewardGems: number }
export function buildDaily(dateKey: string): DailyDef {
  const seed = hashString('skybound:' + dateKey);
  const rng = new RNG(seed);
  const worlds = WORLDS.filter((w) => !w.hidden);
  const world = worlds[rng.int(0, worlds.length - 1)];
  const pool = DAILY_MODS.slice();
  const mods: DailyMod[] = [];
  const n = rng.chance(0.4) ? 2 : 1;
  for (let i = 0; i < n; i++) mods.push(pool.splice(rng.int(0, pool.length - 1), 1)[0]);
  return { key: dateKey, seed, worldId: world.id, mods, goal: 20 + rng.int(0, 3) * 5, rewardGems: 5 };
}

// ------------------------------------------------------------------ Adventure
export interface AdventureLevel {
  id: string; chapter: number; n: 1 | 2; worldId: string; goal: number; startScore: number; coinGoal: number;
  title: L10n; story: L10n;
}
export const ADVENTURE_WORLDS = ['emerald_valley', 'sunset_kingdom', 'frozen_empire', 'inferno_realm', 'cyber_nexus', 'galaxy_odyssey', 'sky_temple', 'underwater_dream', 'sakura_dream', 'celestial_kingdom'];
const STORY: L10n[] = [
  { vi: 'Chú chim nhỏ rời tổ lần đầu tiên, thung lũng xanh gọi tên cậu.', en: 'A little bird leaves the nest for the first time. The green valley calls.' },
  { vi: 'Hoàng hôn phủ vàng vương quốc cổ — ai đó đã thắp sáng mọi ngọn đèn.', en: 'Dusk gilds the old kingdom — someone has lit every lantern.' },
  { vi: 'Gió bắc dẫn lối đến vương quốc băng, nơi cực quang múa trên đỉnh núi.', en: 'The north wind leads to the frozen empire where auroras dance on the peaks.' },
  { vi: 'Tro tàn và dung nham. Chỉ phượng hoàng mới dám bay qua đây.', en: 'Ash and lava. Only a phoenix would dare fly here.' },
  { vi: 'Thành phố neon không bao giờ ngủ, hologram thì thầm những bí mật.', en: 'The neon city never sleeps; holograms whisper secrets.' },
  { vi: 'Bầu trời hết, vũ trụ bắt đầu. Sao băng vạch đường cho bạn.', en: 'The sky ends where space begins. Shooting stars light the way.' },
  { vi: 'Ngôi đền cổ nằm trên biển mây, nơi ánh sáng thần thánh chờ đợi.', en: 'An ancient temple floats above the clouds, bathed in holy light.' },
  { vi: 'Bạn lặn vào giấc mơ đại dương: sứa phát sáng và cá voi hát khẽ.', en: 'You dive into an ocean dream: glowing jellyfish and singing whales.' },
  { vi: 'Hoa anh đào bay trong gió, báo hiệu chặng cuối của hành trình.', en: 'Cherry blossoms drift on the wind, heralding the final stretch.' },
  { vi: 'Thiên giới rộng mở. Bạn đã trở thành huyền thoại bầu trời.', en: 'The heavens open. You have become a legend of the sky.' },
];
export const ADVENTURE_LEVELS: AdventureLevel[] = ADVENTURE_WORLDS.flatMap((worldId, c) =>
  ([1, 2] as const).map((n) => ({
    id: `${worldId}_${n}`, chapter: c, n, worldId,
    goal: n === 1 ? 10 + 2 * c : 16 + 3 * c,
    startScore: c * 4 + (n === 2 ? 6 : 0),
    coinGoal: n === 1 ? 8 + c * 2 : 14 + c * 3,
    title: { vi: `Chương ${c + 1}-${n}`, en: `Chapter ${c + 1}-${n}` },
    story: n === 1 ? STORY[c] : { vi: 'Thử thách cuối chương: bay xa hơn, nhanh hơn!', en: 'Chapter finale: fly farther, faster!' },
  })),
);
export const ADVENTURE_BY_ID: Record<string, AdventureLevel> = Object.fromEntries(ADVENTURE_LEVELS.map((l) => [l.id, l]));
