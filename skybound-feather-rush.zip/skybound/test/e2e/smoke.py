"""Browser smoke test: drives the BUILT game (dist/skybound-standalone.html) with real clicks.
Usage: python3 test/e2e/smoke.py [width height [mobile]]   (needs: pip playwright + a Chrome/Chromium)
Checks: no JS errors, every menu screen opens and has a working Back button, no horizontal overflow, a run can be
played / lost, game-over works, pause + visibility auto-pause, shop purchase with confirmation, save persistence."""
import sys, os, time
from playwright.sync_api import sync_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
URL = 'file://' + os.path.join(ROOT, 'dist', 'skybound-standalone.html')
OUT = os.environ.get('SHOTS', '/tmp/vis'); os.makedirs(OUT, exist_ok=True)
W = int(sys.argv[1]) if len(sys.argv) > 2 else 1280
H = int(sys.argv[2]) if len(sys.argv) > 2 else 720
MOBILE = len(sys.argv) > 3
TAG = f'{W}x{H}' + ('m' if MOBILE else '')
BOT = '''() => { if (window.__botT) clearInterval(window.__botT); window.__botT = setInterval(() => { const sc = window.__sb.scene; if (!sc) return; const S = sc.session; if (S.state==='over'||S.state==='finished'||S.state==='dying') return; const b = S.bird.body; let g = null; for (const q of S.gates) { if (q.wx - S.dist > -34) { g = q; break; } } const c = g ? g.baseCenter : 400; const tgt = c + 14; if (S.state === 'ready' || (b.y > tgt && b.vy > -40)) sc.flap(); }, 12); }'''
fails, logs = [], []
def check(cond, msg):
    print(('  ok   ' if cond else '  FAIL ') + msg)
    if not cond: fails.append(msg)

def pick_exe():
    for p in ('/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/chromium-browser'):
        if os.path.exists(p): return p
    return None

with sync_playwright() as p:
    kw = {'executable_path': pick_exe()} if pick_exe() else {}
    b = p.chromium.launch(args=['--no-sandbox'], **kw)
    ctx = b.new_context(viewport={'width': W, 'height': H}, device_scale_factor=1, has_touch=MOBILE, is_mobile=MOBILE)
    pg = ctx.new_page()
    pg.on('console', lambda m: logs.append(m.type + ': ' + m.text) if m.type in ('error', 'warning') else None)
    pg.on('pageerror', lambda e: logs.append('PAGEERROR ' + str(e)))
    pg.goto(URL)
    pg.wait_for_function('window.__sb && window.__sb.screenName === "menu"', timeout=30000)
    pg.evaluate('const d=window.__sb.save.data; d.settings.tutorial=false; d.tutorialSeen=true; d.settings.quality="medium"; window.__sb.applySettings()')
    time.sleep(0.8)
    print(f'== {TAG}')
    pg.screenshot(path=f'{OUT}/smoke_{TAG}_menu.png')

    def overflow():
        return pg.evaluate('''() => { const bad = []; const vw = innerWidth, vh = innerHeight;
          if (document.documentElement.scrollWidth > vw + 1) bad.push('page scrollWidth ' + document.documentElement.scrollWidth);
          for (const el of document.querySelectorAll('#app .screen *')) { const r = el.getBoundingClientRect(); if (r.width === 0) continue;
            let p = el, clipped = false; while ((p = p.parentElement) && p.id !== 'app') { const cs = getComputedStyle(p); if (/(auto|scroll|hidden)/.test(cs.overflowX)) { clipped = true; break; } }
            if (!clipped && (r.right > vw + 2 || r.left < -2)) { bad.push(el.className + ' ' + Math.round(r.left) + '..' + Math.round(r.right)); if (bad.length > 4) break; } }
          return bad; }''')

    # ---- every menu screen opens via a real click and has a Back button that returns to the menu
    names = ['adventure', 'worlds', 'collection', 'shop', 'missions', 'achievements', 'leaderboard', 'profile', 'settings']
    for i, n in enumerate(names):
        pg.locator('.menu-grid .tile').nth(i).click()
        pg.wait_for_function(f'window.__sb.screenName === "{n}"', timeout=5000); time.sleep(0.7)
        pg.screenshot(path=f'{OUT}/smoke_{TAG}_{n}.png')
        ov = overflow(); check(not ov, f'{n}: no horizontal overflow {ov if ov else ""}')
        hops = 0
        while pg.evaluate('window.__sb.screenName') != 'menu' and hops < 3:
            btn = pg.locator('.screen .topbar .back').first
            if btn.count() == 0: break
            btn.click(); time.sleep(0.5); hops += 1
        check(pg.evaluate('window.__sb.screenName') == 'menu' and hops >= 1, f'{n}: Back returns to menu ({hops} hop)')

    # ---- play a real run: Play -> Classic
    pg.locator('.btn.big').click(); pg.wait_for_function('window.__sb.screenName === "play"'); time.sleep(0.5)
    ov = overflow(); check(not ov, f'mode select: no overflow {ov if ov else ""}')
    pg.screenshot(path=f'{OUT}/smoke_{TAG}_modes.png')
    pg.locator('.card.mode').first.click(); pg.wait_for_function('window.__sb.screenName === "game"'); time.sleep(0.8)
    pg.screenshot(path=f'{OUT}/smoke_{TAG}_ready.png')
    check(pg.evaluate('window.__sb.scene.session.state') == 'ready', 'run starts in READY state')
    # a human-style tap starts it
    (pg.touchscreen.tap(W // 2, H // 2) if MOBILE else pg.mouse.click(W // 2, H // 2)); time.sleep(0.4)
    check(pg.evaluate('window.__sb.scene.session.state') == 'playing', 'tap starts the run')
    pg.evaluate('(' + BOT + ')()')
    t0 = time.time()
    while time.time() - t0 < 40 and pg.evaluate('window.__sb.scene.session.score') < 12: time.sleep(0.5)
    sc = pg.evaluate('window.__sb.scene.session.score'); check(sc >= 12, f'bot scored {sc} (>=12) — gates passable, scoring works')
    pg.screenshot(path=f'{OUT}/smoke_{TAG}_play.png')
    # pause (Escape) + visibility auto-pause
    pg.keyboard.press('Escape'); time.sleep(0.5)
    check(pg.locator('.pausebox').count() == 1, 'Esc opens the pause menu')
    pg.screenshot(path=f'{OUT}/smoke_{TAG}_pause.png')
    pg.locator('.pausebox .btn').first.click(); time.sleep(3.6)
    check(not pg.evaluate('window.__sb.scene.paused'), 'Resume (3-2-1) continues the run')
    pg.evaluate('Object.defineProperty(document,"hidden",{value:true,configurable:true}); document.dispatchEvent(new Event("visibilitychange"))'); time.sleep(0.5)
    check(pg.evaluate('window.__sb.scene.paused'), 'hiding the tab auto-pauses')
    pg.evaluate('Object.defineProperty(document,"hidden",{value:false,configurable:true}); document.dispatchEvent(new Event("visibilitychange"))')
    pg.locator('.pausebox .btn').first.click(); time.sleep(3.6)
    # stop the bot -> bird falls -> game over
    pg.evaluate('clearInterval(window.__botT)')
    for _ in range(60):
        if pg.evaluate('window.__sb.screenName') == 'over': break
        time.sleep(0.3)
    time.sleep(2.5)
    check(pg.evaluate('window.__sb.screenName') == 'over', 'losing shows the game-over screen')
    ov = overflow(); check(not ov, f'game over: no overflow {ov if ov else ""}')
    pg.screenshot(path=f'{OUT}/smoke_{TAG}_over.png')
    pg.locator('.over-card .btn').filter(has_text='Chơi lại').first.click(); time.sleep(1.0)
    check(pg.evaluate('window.__sb.screenName') == 'game' and pg.evaluate('window.__sb.scene.session.score') == 0, 'Retry starts a fresh run')
    pg.keyboard.press('Escape'); time.sleep(0.4); pg.locator('.pausebox .back').click(); time.sleep(0.6)
    check(pg.evaluate('window.__sb.screenName') == 'menu', 'pause → Main menu works')

    # ---- shop: buy with confirmation, persists after reload
    pg.evaluate('window.__sb.save.data.coins = 20000; window.__sb.save.data.gems = 300; window.__sb.save.touch()')
    pg.locator('.menu-grid .tile').nth(3).click(); pg.wait_for_function('window.__sb.screenName === "shop"'); time.sleep(0.8)
    before = pg.evaluate('({c: window.__sb.save.data.coins, s: window.__sb.save.data.unlockedSkins.length})')
    pg.locator('.btn.small.gold').first.click(); time.sleep(0.5)
    check(pg.locator('.modal').count() >= 1, 'purchase asks for confirmation')
    pg.screenshot(path=f'{OUT}/smoke_{TAG}_confirm.png')
    pg.locator('.modal .btn.gold').click(); time.sleep(0.8)
    after = pg.evaluate('({c: window.__sb.save.data.coins, g: window.__sb.save.data.gems, s: window.__sb.save.data.unlockedSkins.length})')
    check(after['c'] < before['c'] or after['g'] < 300 or after['s'] > before['s'], f'purchase deducted funds / granted item {before} -> {after}')
    pg.evaluate('window.__sb.save.flush()')
    snap = pg.evaluate('JSON.stringify({c: window.__sb.save.data.coins, o: window.__sb.save.data.unlockedSkins, it: window.__sb.save.data.ownedItems, tr: window.__sb.save.data.ownedTrails, fx: window.__sb.save.data.ownedFx})')
    pg.reload(); pg.wait_for_function('window.__sb && window.__sb.screenName === "menu"', timeout=30000)
    snap2 = pg.evaluate('JSON.stringify({c: window.__sb.save.data.coins, o: window.__sb.save.data.unlockedSkins, it: window.__sb.save.data.ownedItems, tr: window.__sb.save.data.ownedTrails, fx: window.__sb.save.data.ownedFx})')
    check(snap == snap2, 'save persists across reload')

    # ---- settings: language switch works
    pg.evaluate('window.__sb.open("settings")'); time.sleep(0.6)
    pg.locator('select').first.select_option('en'); time.sleep(0.6)
    check(pg.evaluate('window.__sb.save.data.settings.lang') == 'en', 'language switch to EN')
    pg.screenshot(path=f'{OUT}/smoke_{TAG}_settings_en.png')

    errs = [l for l in logs if l.startswith('PAGEERROR') or l.startswith('error')]
    check(not errs, 'no JS errors / console errors: ' + ' | '.join(errs[:4]))
    print('FPS(headless):', pg.evaluate('window.__sb.engine.fps'))
    b.close()
print('RESULT:', 'ALL PASSED' if not fails else f'{len(fails)} FAILED')
sys.exit(1 if fails else 0)
