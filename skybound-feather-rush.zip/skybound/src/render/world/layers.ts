// Painters for parallax layers. Every painter draws one horizontally TILEABLE strip (width w) into band-local coordinates:
// y = 0 is the band top, `base` is the ground line of the layer, shapes grow upward from it and the fill continues to y = h.
import { mulberry32, shadeHex, mixHex, rgba, hslToHex, TAU } from '../../core/util';
import type { LayerDef } from '../../data/worlds';
import type { Ctx } from '../gfx';
import { starPath } from '../gfx';

export interface PaintCtx {
  g: Ctx; w: number; h: number; base: number; maxH: number;
  c0: string; c1: string; rnd: () => number; p: Record<string, number | string>; pass: 'base' | 'emit'; def: LayerDef; fog: string;
}

/** Draw fn at x and its wrapped copies so shapes crossing the tile border stay seamless. */
function wrap(w: number, x: number, ext: number, fn: (x: number) => void): void {
  fn(x);
  if (x - ext < 0) fn(x + w);
  if (x + ext > w) fn(x - w);
}
const grad = (g: Ctx, y0: number, y1: number, a: string, b: string): CanvasGradient => { const r = g.createLinearGradient(0, y0, 0, y1); r.addColorStop(0, a); r.addColorStop(1, b); return r; };
const fillBelow = (P: PaintCtx, color?: string | CanvasGradient): void => {
  const { g, w, h, base } = P;
  g.fillStyle = color ?? grad(g, base - 4, h, P.c0, shadeHex(P.c0, -0.25)); g.fillRect(0, base - 1, w, h - base + 1);
};
const num = (P: PaintCtx, k: string, d = 0): number => { const v = P.p[k]; return typeof v === 'number' ? v : d; };
const emitGlow = (g: Ctx, x: number, y: number, r: number, color: string, a = 1): void => {
  const rg = g.createRadialGradient(x, y, 0, x, y, r); rg.addColorStop(0, rgba(color, a)); rg.addColorStop(1, rgba(color, 0)); g.fillStyle = rg; g.fillRect(x - r, y - r, r * 2, r * 2);
};

// ---------------------------------------------------------------- mountains / hills / rocks
function ridgeY(P: PaintCtx, x: number, harm: [number, number, number][], sharp: number): number {
  let v = 0;
  for (const [k, a, ph] of harm) { const s = Math.sin((x / P.w) * TAU * k + ph); v += a * (sharp > 0 ? 1 - Math.pow(Math.abs(s), 0.65 + (1 - sharp) * 0.8) * 2 : s); }
  return v;
}
function paintMountains(P: PaintCtx): void {
  if (P.pass === 'emit') return;
  const { g, w, base, maxH, rnd } = P;
  const peaks = num(P, 'peaks', 5), snow = num(P, 'snow', 0), jag = num(P, 'jagged', 0), fuji = num(P, 'fuji', 0);
  const ph = [rnd() * 6, rnd() * 6, rnd() * 6];
  const harm: [number, number, number][] = fuji ? [[1, 1, 1.2]] : [[peaks, 0.6, ph[0]], [peaks * 2 + 1, 0.22, ph[1]], [Math.max(1, Math.round(peaks / 2)), 0.3, ph[2]]];
  const ys: number[] = [];
  for (let x = 0; x <= w; x += 4) {
    let y: number;
    if (fuji) { const u = Math.abs(((x / w) - 0.5)) * 2; y = base - maxH * Math.max(0, 1 - u * 1.35) * (1 + 0.05 * Math.sin(x * 0.07)); y = Math.min(y, base - maxH * 0.12 * (1 - u)); y = Math.max(y, base - maxH); if (u > 0.74) y = base - 4 + u * 3; }
    else { const v = ridgeY(P, x, harm, jag ? 1 : 0.7); y = base - maxH * (0.5 + 0.5 * Math.max(-1, Math.min(1, v * 0.75))) * (0.6 + 0.4 * 1); }
    ys.push(y);
  }
  g.fillStyle = grad(g, base - maxH, base, shadeHex(P.c0, 0.15), P.c0);
  g.beginPath(); g.moveTo(0, P.h); for (let i = 0; i < ys.length; i++) g.lineTo(i * 4, ys[i]); g.lineTo(w, P.h); g.closePath(); g.fill();
  // shaded side of each slope for volume
  g.fillStyle = rgba(shadeHex(P.c0, -0.45), 0.28);
  g.beginPath(); g.moveTo(0, P.h); for (let i = 0; i < ys.length; i++) { const x = i * 4; g.lineTo(x + 18 + (base - ys[i]) * 0.18, ys[i] + (base - ys[i]) * 0.12); } g.lineTo(w, P.h); g.closePath(); g.fill();
  // ridge highlight
  g.strokeStyle = rgba(P.c1, 0.55); g.lineWidth = 2; g.beginPath(); for (let i = 0; i < ys.length; i++) i ? g.lineTo(i * 4, ys[i]) : g.moveTo(0, ys[i]); g.stroke();
  if (snow) { // snow caps on the highest parts
    const thr = base - maxH * (fuji ? 0.7 : 0.72);
    g.fillStyle = rgba(P.c1, 0.95);
    for (let i = 1; i < ys.length - 1; i++) {
      if (ys[i] < thr) { const x = i * 4, d = thr - ys[i]; g.fillRect(x, ys[i], 4, Math.min(d * 0.9 + 4, 38) + Math.sin(x * 0.4) * 3); }
    }
  }
  if (num(P, 'waterfall') && !fuji) { // a white waterfall tumbling down a face
    const x = w * 0.33; const i = Math.round(x / 4); const y0 = ys[i] + 10;
    const wg = g.createLinearGradient(0, y0, 0, base); wg.addColorStop(0, 'rgba(255,255,255,0.95)'); wg.addColorStop(1, 'rgba(255,255,255,0.15)');
    g.fillStyle = wg; g.beginPath(); g.moveTo(x - 4, y0); g.lineTo(x + 4, y0); g.lineTo(x + 9, base); g.lineTo(x - 9, base); g.closePath(); g.fill();
  }
  if (num(P, 'haze')) { g.fillStyle = grad(g, base - maxH * 0.5, base + 20, rgba(P.fog, 0), rgba(P.fog, 0.55)); g.fillRect(0, base - maxH * 0.5, w, maxH * 0.5 + 40); }
}
function paintHills(P: PaintCtx): void {
  if (P.pass === 'emit') return;
  const { g, w, base, maxH, rnd } = P;
  const ph = rnd() * 6;
  const h2: [number, number, number][] = [[2, 0.5, ph], [3, 0.3, ph * 2], [5, 0.15, ph * 3]];
  g.fillStyle = grad(g, base - maxH, base, P.c1, P.c0);
  g.beginPath(); g.moveTo(0, P.h);
  const ys: number[] = [];
  for (let x = 0; x <= w; x += 4) { const y = base - maxH * (0.55 + 0.45 * ridgeY(P, x, h2, 0)); ys.push(y); g.lineTo(x, y); }
  g.lineTo(w, P.h); g.closePath(); g.fill();
  g.strokeStyle = rgba('#ffffff', 0.25); g.lineWidth = 2; g.beginPath(); ys.forEach((y, i) => i ? g.lineTo(i * 4, y) : g.moveTo(0, y)); g.stroke();
  // tiny trees / bushes dotted on the ridge
  for (let i = 0; i < 26; i++) { const x = rnd() * w; const y = ys[Math.round(x / 4)] + 2; const r = 4 + rnd() * 5; g.fillStyle = rgba(shadeHex(P.c0, -0.25), 0.8); wrap(w, x, r, (xx) => { g.beginPath(); g.arc(xx, y, r, Math.PI, 0); g.fill(); }); }
}
function paintRocks(P: PaintCtx): void {
  const { g, w, base, maxH, rnd } = P;
  const lava = num(P, 'lava'), thorns = num(P, 'thorns');
  if (P.pass === 'emit') {
    if (!lava) return;
    g.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 12; i++) { const x = rnd() * w, y = base - rnd() * maxH * 0.7; emitGlow(g, x, y, 14 + rnd() * 20, '#ff6a1f', 0.55); }
    return;
  }
  fillBelow(P, grad(g, base, P.h, P.c0, shadeHex(P.c0, -0.4)));
  const n = 16;
  for (let i = 0; i < n; i++) {
    const x = (i + rnd() * 0.6) * (w / n), bw = 30 + rnd() * 46, bh = maxH * (0.35 + rnd() * 0.65);
    wrap(w, x, bw, (xx) => {
      g.fillStyle = grad(g, base - bh, base, shadeHex(P.c0, 0.2), P.c0);
      g.beginPath(); g.moveTo(xx - bw / 2, base + 2);
      if (thorns) { g.quadraticCurveTo(xx - bw * 0.25, base - bh * 0.5, xx + (rnd() - 0.5) * 8, base - bh); g.quadraticCurveTo(xx + bw * 0.25, base - bh * 0.4, xx + bw / 2, base + 2); }
      else { g.lineTo(xx - bw * 0.3, base - bh * 0.7); g.lineTo(xx - bw * 0.05, base - bh); g.lineTo(xx + bw * 0.22, base - bh * 0.62); g.lineTo(xx + bw / 2, base + 2); }
      g.closePath(); g.fill();
      g.fillStyle = rgba(P.c1, lava ? 0.0 : 0.18); g.beginPath(); g.moveTo(xx - bw * 0.3, base - bh * 0.7); g.lineTo(xx - bw * 0.05, base - bh); g.lineTo(xx, base - bh * 0.5); g.closePath(); g.fill();
      if (lava) { g.strokeStyle = rgba('#ff7a2b', 0.9); g.lineWidth = 2; g.beginPath(); g.moveTo(xx - 4, base - bh * 0.15); g.lineTo(xx + 3, base - bh * 0.4); g.lineTo(xx - 2, base - bh * 0.6); g.stroke(); }
    });
  }
  if (lava) { const lg = grad(g, base, P.h, '#ff9a2b', '#b01f08'); g.fillStyle = lg; g.fillRect(0, base + 6, w, P.h - base); }
}

// ---------------------------------------------------------------- vegetation
function paintForest(P: PaintCtx): void {
  if (P.pass === 'emit') return;
  const { g, w, base, maxH, rnd } = P;
  const conifer = P.p.style === 'conifer', snow = num(P, 'snow');
  fillBelow(P, P.c0);
  const n = Math.round(w / (conifer ? 34 : 46));
  for (let i = 0; i < n; i++) {
    const x = (i + rnd() * 0.8) * (w / n), th = maxH * (0.4 + rnd() * 0.6), tw = th * (conifer ? 0.38 : 0.55);
    wrap(w, x, tw, (xx) => {
      g.fillStyle = shadeHex(P.c0, -0.35); g.fillRect(xx - 2.5, base - th * 0.25, 5, th * 0.3);
      if (conifer) {
        for (let k = 0; k < 4; k++) {
          const yy = base - th * 0.15 - k * th * 0.2, ww = tw * (1 - k * 0.2);
          g.fillStyle = k % 2 ? P.c0 : shadeHex(P.c0, 0.08); g.beginPath(); g.moveTo(xx - ww / 2, yy); g.lineTo(xx, yy - th * 0.36); g.lineTo(xx + ww / 2, yy); g.closePath(); g.fill();
          if (snow) { g.fillStyle = 'rgba(255,255,255,0.9)'; g.beginPath(); g.moveTo(xx - ww * 0.2, yy - th * 0.22); g.lineTo(xx, yy - th * 0.36); g.lineTo(xx + ww * 0.2, yy - th * 0.22); g.closePath(); g.fill(); }
        }
      } else {
        const cy = base - th * 0.62;
        g.fillStyle = P.c0; g.beginPath(); g.arc(xx, cy, tw * 0.5, 0, TAU); g.arc(xx - tw * 0.3, cy + th * 0.1, tw * 0.36, 0, TAU); g.arc(xx + tw * 0.3, cy + th * 0.1, tw * 0.36, 0, TAU); g.fill();
        g.fillStyle = rgba(P.c1, 0.55); g.beginPath(); g.arc(xx - tw * 0.14, cy - tw * 0.14, tw * 0.28, 0, TAU); g.fill();
      }
    });
  }
}
function paintSakura(P: PaintCtx): void {
  if (P.pass === 'emit') return;
  const { g, w, base, maxH, rnd } = P;
  const near = num(P, 'near');
  fillBelow(P, P.c0);
  const n = near ? 4 : 7;
  for (let i = 0; i < n; i++) {
    const x = (i + 0.2 + rnd() * 0.6) * (w / n), th = maxH * (0.55 + rnd() * 0.45), sw = th * 0.9;
    wrap(w, x, sw, (xx) => {
      g.strokeStyle = P.c0; g.lineWidth = near ? 12 : 7; g.lineCap = 'round';
      g.beginPath(); g.moveTo(xx, base + 4); g.quadraticCurveTo(xx + (rnd() - 0.5) * 20, base - th * 0.4, xx + (rnd() - 0.5) * 30, base - th * 0.65); g.stroke();
      for (let k = 0; k < 16; k++) {
        const bx = xx + (rnd() - 0.5) * sw, by = base - th * (0.5 + rnd() * 0.45), r = th * (0.12 + rnd() * 0.14);
        g.fillStyle = k % 3 ? rgba(P.c1, 0.92) : rgba(mixHex(P.c1, '#ffffff', 0.5), 0.95); g.beginPath(); g.arc(bx, by, r, 0, TAU); g.fill();
      }
    });
  }
}
function paintKelp(P: PaintCtx): void {
  if (P.pass === 'emit') return;
  const { g, w, base, maxH, rnd } = P;
  for (let i = 0; i < 18; i++) {
    const x = (i + rnd() * 0.7) * (w / 18), th = maxH * (0.4 + rnd() * 0.6), ph = rnd() * 6;
    wrap(w, x, 30, (xx) => {
      g.strokeStyle = rgba(rnd() > 0.5 ? P.c0 : P.c1, 0.9); g.lineWidth = 6 + rnd() * 5; g.lineCap = 'round';
      g.beginPath(); g.moveTo(xx, base + 6); for (let s = 1; s <= 12; s++) g.lineTo(xx + Math.sin(s * 0.7 + ph) * 12 * (s / 12), base - (th * s) / 12); g.stroke();
    });
  }
}

// ---------------------------------------------------------------- architecture
function windows(P: PaintCtx, x: number, y: number, bw: number, bh: number, color: string, density = 0.55, cell = 9): void {
  const { g, rnd } = P;
  g.fillStyle = color;
  for (let wy = y + 6; wy < y + bh - 6; wy += cell + 3) for (let wx = x + 5; wx < x + bw - 5; wx += cell) if (rnd() < density) g.fillRect(wx, wy, cell - 4, cell - 3);
}
function paintCity(P: PaintCtx): void {
  const { g, w, base, maxH, rnd } = P;
  const style = String(P.p.style ?? 'skyline'), neon = num(P, 'neon');
  const n = style === 'rooftops' ? 30 : 20;
  const emitCol = style === 'rooftops' ? '#ffd27a' : P.c1;
  if (P.pass === 'base') fillBelow(P, grad(g, base, P.h, P.c0, shadeHex(P.c0, -0.3)));
  for (let i = 0; i < n; i++) {
    const bw = style === 'rooftops' ? 38 + rnd() * 34 : 26 + rnd() * 40, x = (i + rnd() * 0.5) * (w / n), bh = maxH * (style === 'rooftops' ? 0.2 + rnd() * 0.5 : 0.25 + rnd() * 0.75);
    wrap(w, x, bw, (xx) => {
      if (P.pass === 'emit') {
        g.globalCompositeOperation = 'lighter'; windows(P, xx, base - bh, bw, bh, rgba(emitCol, 0.85), 0.5);
        if (neon) { g.fillStyle = rgba(P.def.colors[1], 0.9); g.fillRect(xx, base - bh, bw, 2.2); g.fillRect(xx + bw - 2.2, base - bh, 2.2, bh * 0.8); emitGlow(g, xx + bw / 2, base - bh, 22, P.def.colors[1], 0.35); }
        return;
      }
      g.fillStyle = grad(g, base - bh, base, shadeHex(P.c0, 0.12), P.c0); g.fillRect(xx, base - bh, bw, bh + 2);
      g.fillStyle = rgba('#000000', 0.18); g.fillRect(xx + bw * 0.7, base - bh, bw * 0.3, bh + 2);
      if (style === 'rooftops') { g.fillStyle = shadeHex(P.c1, -0.1); g.beginPath(); g.moveTo(xx - 3, base - bh); g.lineTo(xx + bw / 2, base - bh - bw * 0.35); g.lineTo(xx + bw + 3, base - bh); g.closePath(); g.fill(); }
      else if (rnd() > 0.55) { g.fillStyle = P.c0; g.fillRect(xx + bw / 2 - 1, base - bh - 18, 2, 18); g.fillStyle = rgba('#ff3a5a', 0.9); g.fillRect(xx + bw / 2 - 2, base - bh - 20, 4, 3); }
      g.fillStyle = rgba(P.c1, 0.22); g.fillRect(xx, base - bh, bw * 0.12, bh);
    });
  }
}
function paintCastle(P: PaintCtx): void {
  const { g, w, base, maxH, rnd } = P;
  const near = P.p.style === 'near', bridges = num(P, 'bridges');
  if (P.pass === 'base') fillBelow(P, grad(g, base, P.h, P.c0, shadeHex(P.c0, -0.3)));
  const n = near ? 8 : 12;
  const towers: { x: number; top: number }[] = [];
  for (let i = 0; i < n; i++) {
    const x = (i + 0.3 + rnd() * 0.4) * (w / n), bw = 30 + rnd() * 26, bh = maxH * (0.3 + rnd() * 0.7), kind = rnd();
    towers.push({ x: x + bw / 2, top: base - bh });
    wrap(w, x, bw, (xx) => {
      if (P.pass === 'emit') { g.globalCompositeOperation = 'lighter'; windows(P, xx, base - bh, bw, bh, rgba('#ffd27a', 0.9), 0.35, 7); return; }
      g.fillStyle = grad(g, base - bh, base, shadeHex(P.c0, 0.1), P.c0); g.fillRect(xx, base - bh, bw, bh + 2);
      g.fillStyle = rgba('#000', 0.16); g.fillRect(xx + bw * 0.68, base - bh, bw * 0.32, bh);
      g.fillStyle = P.c1;
      if (kind < 0.4) { g.beginPath(); g.moveTo(xx - 4, base - bh); g.lineTo(xx + bw / 2, base - bh - bw * 1.1); g.lineTo(xx + bw + 4, base - bh); g.closePath(); g.fill(); }
      else if (kind < 0.75) { g.beginPath(); g.ellipse(xx + bw / 2, base - bh, bw * 0.6, bw * 0.55, 0, Math.PI, 0); g.fill(); g.fillRect(xx + bw / 2 - 1, base - bh - bw * 0.55 - 14, 2, 14); }
      else { for (let k = 0; k < 4; k++) g.fillRect(xx + k * (bw / 4), base - bh - 7, bw / 4 - 3, 8); }
    });
  }
  if (bridges && P.pass === 'base') { g.strokeStyle = rgba(P.c1, 0.8); g.lineWidth = 3; for (let i = 0; i < towers.length - 1; i++) { const a = towers[i], b = towers[i + 1]; if (b.x - a.x < 150) { g.beginPath(); g.moveTo(a.x, a.top + 36); g.quadraticCurveTo((a.x + b.x) / 2, Math.max(a.top, b.top) + 56, b.x, b.top + 36); g.stroke(); } } }
}
function paintTemple(P: PaintCtx): void {
  const { g, w, base, maxH, rnd } = P;
  const gold = num(P, 'gold');
  if (P.pass === 'base') fillBelow(P, grad(g, base, P.h, P.c0, shadeHex(P.c0, -0.2)));
  const n = 5;
  for (let i = 0; i < n; i++) {
    const cx = (i + 0.5) * (w / n) + (rnd() - 0.5) * 30, bw = 130 + rnd() * 60, bh = maxH * (0.55 + rnd() * 0.45);
    wrap(w, cx - bw / 2, bw, (xx) => {
      if (P.pass === 'emit') { g.globalCompositeOperation = 'lighter'; emitGlow(g, xx + bw / 2, base - bh * 0.55, bw * 0.55, gold ? '#ffe9a0' : '#fff2c0', 0.5); return; }
      g.fillStyle = P.c0; g.fillRect(xx, base - 16, bw, 18); g.fillRect(xx + 6, base - 28, bw - 12, 12);
      const cols = 5, cw = 11;
      for (let k = 0; k < cols; k++) { const px = xx + 14 + k * ((bw - 28 - cw) / (cols - 1)); g.fillStyle = grad(g, base - bh, base, P.c1, P.c0); g.fillRect(px, base - bh + 20, cw, bh - 44); g.fillStyle = rgba('#000', 0.12); g.fillRect(px + cw * 0.65, base - bh + 20, cw * 0.35, bh - 44); g.fillStyle = shadeHex(P.c0, 0.1); g.fillRect(px - 3, base - bh + 16, cw + 6, 6); g.fillRect(px - 3, base - 32, cw + 6, 5); }
      g.fillStyle = shadeHex(P.c0, 0.05); g.beginPath(); g.moveTo(xx - 4, base - bh + 18); g.lineTo(xx + bw / 2, base - bh - 18); g.lineTo(xx + bw + 4, base - bh + 18); g.closePath(); g.fill();
      g.fillStyle = gold ? '#ffd36b' : rgba(P.c1, 0.9); g.beginPath(); g.moveTo(xx + 10, base - bh + 16); g.lineTo(xx + bw / 2, base - bh - 10); g.lineTo(xx + bw - 10, base - bh + 16); g.closePath(); g.fill();
    });
  }
}
function paintCelestialCity(P: PaintCtx): void {
  const { g, w, base, maxH, rnd } = P;
  if (P.pass === 'base') fillBelow(P, grad(g, base, P.h, rgba(P.c0, 1), shadeHex(P.c0, -0.15)));
  const n = 16;
  for (let i = 0; i < n; i++) {
    const x = (i + rnd() * 0.5) * (w / n), bw = 24 + rnd() * 30, bh = maxH * (0.25 + rnd() * 0.75), t = rnd();
    wrap(w, x, bw, (xx) => {
      if (P.pass === 'emit') { g.globalCompositeOperation = 'lighter'; emitGlow(g, xx + bw / 2, base - bh, 28, '#fff2b0', 0.5); return; }
      g.fillStyle = grad(g, base - bh, base, '#ffffff', P.c0); g.fillRect(xx, base - bh, bw, bh + 2);
      g.fillStyle = rgba('#d9b860', 0.35); g.fillRect(xx + bw * 0.72, base - bh, bw * 0.28, bh);
      g.fillStyle = '#ffd36b';
      if (t < 0.5) { g.beginPath(); g.moveTo(xx - 2, base - bh); g.lineTo(xx + bw / 2, base - bh - bw * 1.4); g.lineTo(xx + bw + 2, base - bh); g.closePath(); g.fill(); }
      else { g.beginPath(); g.ellipse(xx + bw / 2, base - bh, bw * 0.55, bw * 0.6, 0, Math.PI, 0); g.fill(); g.fillRect(xx + bw / 2 - 1, base - bh - bw * 0.6 - 16, 2, 16); }
    });
  }
}

// ---------------------------------------------------------------- crystals / spires
function paintIceSpires(P: PaintCtx): void {
  const { g, w, base, maxH, rnd } = P;
  if (P.pass === 'base') fillBelow(P, P.c0);
  for (let i = 0; i < 14; i++) {
    const x = (i + rnd() * 0.6) * (w / 14), bw = 22 + rnd() * 36, bh = maxH * (0.35 + rnd() * 0.65), lean = (rnd() - 0.5) * 16;
    wrap(w, x, bw, (xx) => {
      if (P.pass === 'emit') { g.globalCompositeOperation = 'lighter'; emitGlow(g, xx + bw / 2 + lean / 2, base - bh * 0.5, bh * 0.5, '#9fe8ff', 0.28); return; }
      g.fillStyle = grad(g, base - bh, base, P.c1, P.c0); g.beginPath(); g.moveTo(xx, base + 2); g.lineTo(xx + bw * 0.25 + lean, base - bh * 0.7); g.lineTo(xx + bw * 0.5 + lean, base - bh); g.lineTo(xx + bw * 0.78 + lean, base - bh * 0.62); g.lineTo(xx + bw, base + 2); g.closePath(); g.fill();
      g.fillStyle = rgba('#ffffff', 0.55); g.beginPath(); g.moveTo(xx + bw * 0.25 + lean, base - bh * 0.7); g.lineTo(xx + bw * 0.5 + lean, base - bh); g.lineTo(xx + bw * 0.5, base - bh * 0.15); g.lineTo(xx + bw * 0.2, base - bh * 0.1); g.closePath(); g.fill();
    });
  }
}
function paintCrystals(P: PaintCtx): void {
  const { g, w, base, maxH, rnd } = P;
  if (P.pass === 'base') fillBelow(P, shadeHex(P.c0, -0.2));
  for (let i = 0; i < 12; i++) {
    const x = (i + rnd() * 0.6) * (w / 12);
    wrap(w, x, 60, (xx) => {
      for (let k = 0; k < 4; k++) {
        const bx = xx + (k - 1.5) * 16 + (rnd() - 0.5) * 8, bh = maxH * (0.25 + rnd() * 0.75) * (k % 3 === 1 ? 1 : 0.7), bw = 12 + rnd() * 10;
        if (P.pass === 'emit') { g.globalCompositeOperation = 'lighter'; emitGlow(g, bx, base - bh * 0.5, bh * 0.45, P.c1, 0.55); continue; }
        g.fillStyle = grad(g, base - bh, base, P.c1, P.c0);
        g.beginPath(); g.moveTo(bx - bw / 2, base); g.lineTo(bx - bw / 2, base - bh * 0.8); g.lineTo(bx, base - bh); g.lineTo(bx + bw / 2, base - bh * 0.8); g.lineTo(bx + bw / 2, base); g.closePath(); g.fill();
        g.fillStyle = rgba('#ffffff', 0.3); g.beginPath(); g.moveTo(bx - bw / 2, base - bh * 0.8); g.lineTo(bx, base - bh); g.lineTo(bx - 1, base); g.lineTo(bx - bw / 2, base); g.closePath(); g.fill();
      }
    });
  }
}
function paintDarkSpires(P: PaintCtx): void {
  const { g, w, base, maxH, rnd } = P;
  if (P.pass === 'base') fillBelow(P, P.c0);
  for (let i = 0; i < 9; i++) {
    const x = (i + 0.3 + rnd() * 0.4) * (w / 9), bw = 26 + rnd() * 26, bh = maxH * (0.45 + rnd() * 0.55), tw = (rnd() - 0.5) * 40;
    wrap(w, x, bw + 40, (xx) => {
      if (P.pass === 'emit') { g.globalCompositeOperation = 'lighter'; g.strokeStyle = rgba(P.c1, 0.9); g.lineWidth = 2; g.beginPath(); g.moveTo(xx + bw / 2, base - 10); g.quadraticCurveTo(xx + bw / 2 + tw * 0.4, base - bh * 0.5, xx + bw / 2 + tw, base - bh * 0.92); g.stroke(); emitGlow(g, xx + bw / 2 + tw, base - bh, 26, P.c1, 0.65); for (let k = 0; k < 4; k++) g.fillRect(xx + bw / 2 - 2, base - 40 - k * bh * 0.2, 4, 7); return; }
      g.fillStyle = grad(g, base - bh, base, shadeHex(P.c0, 0.1), P.c0); g.beginPath(); g.moveTo(xx, base + 2); g.quadraticCurveTo(xx + 4, base - bh * 0.5, xx + bw / 2 + tw, base - bh); g.quadraticCurveTo(xx + bw - 4, base - bh * 0.5, xx + bw, base + 2); g.closePath(); g.fill();
      g.fillStyle = rgba(P.c1, 0.25); g.beginPath(); g.moveTo(xx + bw / 2 + tw, base - bh); g.quadraticCurveTo(xx + 4, base - bh * 0.5, xx, base + 2); g.lineTo(xx + bw * 0.25, base + 2); g.closePath(); g.fill();
    });
  }
}
function paintVolcano(P: PaintCtx): void {
  const { g, w, base, maxH, rnd } = P;
  const n = num(P, 'count', 3);
  if (P.pass === 'base') fillBelow(P, shadeHex(P.c0, -0.3));
  for (let i = 0; i < n; i++) {
    const cx = (i + 0.5) * (w / n) + (rnd() - 0.5) * 60, bw = 280 + rnd() * 120, bh = maxH * (0.6 + rnd() * 0.4);
    wrap(w, cx - bw / 2, bw, (xx) => {
      const cr = bw * 0.1;
      if (P.pass === 'emit') {
        g.globalCompositeOperation = 'lighter'; emitGlow(g, xx + bw / 2, base - bh, bw * 0.55, '#ff6a1f', 0.7);
        g.strokeStyle = rgba('#ff8a2b', 0.95); g.lineWidth = 3; g.lineCap = 'round';
        for (let k = 0; k < 3; k++) { g.beginPath(); g.moveTo(xx + bw / 2 + (k - 1) * cr, base - bh + 4); g.bezierCurveTo(xx + bw / 2 + (k - 1) * 40, base - bh * 0.7, xx + bw / 2 + (k - 1) * 70, base - bh * 0.4, xx + bw / 2 + (k - 1) * 110, base); g.stroke(); }
        return;
      }
      g.fillStyle = grad(g, base - bh, base, shadeHex(P.c0, 0.2), P.c0); g.beginPath(); g.moveTo(xx, base + 2); g.lineTo(xx + bw / 2 - cr, base - bh); g.lineTo(xx + bw / 2 + cr, base - bh); g.lineTo(xx + bw, base + 2); g.closePath(); g.fill();
      g.fillStyle = rgba('#000', 0.28); g.beginPath(); g.moveTo(xx + bw / 2 + cr, base - bh); g.lineTo(xx + bw, base + 2); g.lineTo(xx + bw * 0.62, base + 2); g.closePath(); g.fill();
      g.fillStyle = rgba('#3a2a28', 0.6); g.beginPath(); g.ellipse(xx + bw / 2, base - bh - 14, cr * 2.2, 22, 0, 0, TAU); g.fill();
    });
  }
}

// ---------------------------------------------------------------- floating things / space
function paintIslands(P: PaintCtx): void {
  if (P.pass === 'emit') return;
  const { g, w, base, maxH, rnd } = P;
  const far = num(P, 'far'), temples = num(P, 'temples');
  const n = far ? 5 : 3;
  for (let i = 0; i < n; i++) {
    const x = (i + 0.3 + rnd() * 0.4) * (w / n), iw = 90 + rnd() * 110, y = base - rnd() * maxH, ih = iw * 0.28;
    wrap(w, x - iw / 2, iw, (xx) => {
      g.fillStyle = P.c0; g.beginPath(); g.moveTo(xx, y); g.quadraticCurveTo(xx + iw * 0.1, y + ih * 2.1, xx + iw / 2, y + ih * 2.8); g.quadraticCurveTo(xx + iw * 0.9, y + ih * 2.1, xx + iw, y); g.closePath(); g.fill();
      g.fillStyle = P.c1; g.beginPath(); g.ellipse(xx + iw / 2, y, iw / 2, ih * 0.5, 0, 0, TAU); g.fill();
      g.fillStyle = rgba('#7edc8c', 0.6); g.beginPath(); g.ellipse(xx + iw / 2, y - 2, iw * 0.46, ih * 0.32, 0, Math.PI, TAU); g.fill();
      if (temples && rnd() > 0.3) { g.fillStyle = rgba('#fff4d6', 0.95); g.fillRect(xx + iw * 0.35, y - 26, 4, 24); g.fillRect(xx + iw * 0.5, y - 26, 4, 24); g.fillRect(xx + iw * 0.65, y - 26, 4, 24); g.beginPath(); g.moveTo(xx + iw * 0.3, y - 26); g.lineTo(xx + iw * 0.52, y - 40); g.lineTo(xx + iw * 0.72, y - 26); g.closePath(); g.fill(); }
      else { g.fillStyle = shadeHex(P.c0, -0.2); g.beginPath(); g.arc(xx + iw * 0.5, y - 10, 12, Math.PI, 0); g.fill(); }
    });
  }
}
function paintAsteroids(P: PaintCtx): void {
  if (P.pass === 'emit') return;
  const { g, w, base, maxH, rnd } = P;
  const big = num(P, 'big');
  const n = big ? 5 : 9;
  for (let i = 0; i < n; i++) {
    const x = rnd() * w, y = base - rnd() * maxH, r = (big ? 36 : 14) + rnd() * (big ? 48 : 26);
    wrap(w, x, r, (xx) => {
      g.fillStyle = grad(g, y - r, y + r, P.c1, P.c0); g.beginPath();
      const pts = 9; for (let k = 0; k < pts; k++) { const a = (k / pts) * TAU, rr = r * (0.72 + rnd() * 0.35); const px = xx + Math.cos(a) * rr, py = y + Math.sin(a) * rr * 0.85; k ? g.lineTo(px, py) : g.moveTo(px, py); } g.closePath(); g.fill();
      g.fillStyle = rgba('#000', 0.22); for (let k = 0; k < 3; k++) { g.beginPath(); g.ellipse(xx + (rnd() - 0.5) * r, y + (rnd() - 0.5) * r * 0.7, r * 0.16, r * 0.1, 0, 0, TAU); g.fill(); }
      g.strokeStyle = rgba('#ffffff', 0.2); g.lineWidth = 1.4; g.beginPath(); g.arc(xx, y, r * 0.9, Math.PI * 1.1, Math.PI * 1.55); g.stroke();
    });
  }
}
function paintGeometry(P: PaintCtx): void {
  const { g, w, base, maxH, rnd } = P;
  const near = num(P, 'near');
  const n = near ? 6 : 9;
  for (let i = 0; i < n; i++) {
    const x = rnd() * w, y = base - rnd() * maxH, r = (near ? 30 : 20) + rnd() * (near ? 40 : 34), sides = [3, 4, 6, 8][Math.floor(rnd() * 4)], rot = rnd() * TAU, col = rnd() > 0.5 ? P.c0 : P.c1;
    wrap(w, x, r, (xx) => {
      const path = (rr: number): void => { g.beginPath(); for (let k = 0; k < sides; k++) { const a = rot + (k / sides) * TAU; const px = xx + Math.cos(a) * rr, py = y + Math.sin(a) * rr; k ? g.lineTo(px, py) : g.moveTo(px, py); } g.closePath(); };
      if (P.pass === 'emit') { g.globalCompositeOperation = 'lighter'; g.strokeStyle = rgba(col, 0.95); g.lineWidth = 2; path(r); g.stroke(); path(r * 0.55); g.stroke(); emitGlow(g, xx, y, r * 1.2, col, 0.25); return; }
      g.fillStyle = rgba(col, 0.18); path(r); g.fill(); g.fillStyle = rgba(col, 0.1); path(r * 0.55); g.fill();
    });
  }
}
function paintNeonRail(P: PaintCtx): void {
  const { g, w, base, maxH } = P;
  const col = P.c1;
  if (P.pass === 'emit') {
    g.globalCompositeOperation = 'lighter'; g.fillStyle = rgba(col, 0.9); g.fillRect(0, base - maxH * 0.55, w, 3); g.fillRect(0, base - maxH * 0.25, w, 2);
    for (let x = 30; x < w; x += 128) { g.fillRect(x - 1, base - maxH, 2, maxH); emitGlow(g, x, base - maxH, 30, col, 0.6); }
    return;
  }
  g.fillStyle = grad(g, base - maxH, P.h, rgba(P.c0, 0.2), P.c0); g.fillRect(0, base - maxH * 0.62, w, P.h);
  g.fillStyle = P.c0; for (let x = 30; x < w; x += 128) g.fillRect(x - 3, base - maxH, 6, maxH + 4);
}
function paintCloudSea(P: PaintCtx): void {
  if (P.pass === 'emit') return;
  const { g, w, base, maxH, rnd } = P;
  fillBelow(P, grad(g, base - 10, P.h, P.c0, P.c1));
  const n = 22;
  for (let i = 0; i < n; i++) {
    const x = (i + rnd() * 0.8) * (w / n), r = 28 + rnd() * 40, y = base - rnd() * maxH * 0.8;
    wrap(w, x, r * 2, (xx) => {
      g.fillStyle = grad(g, y - r, y + r, P.c0, P.c1);
      g.beginPath(); g.arc(xx, y, r, 0, TAU); g.arc(xx + r * 0.9, y + r * 0.18, r * 0.78, 0, TAU); g.arc(xx - r * 0.9, y + r * 0.22, r * 0.72, 0, TAU); g.fill();
      g.fillStyle = rgba('#ffffff', 0.5); g.beginPath(); g.arc(xx - r * 0.15, y - r * 0.28, r * 0.5, 0, TAU); g.fill();
    });
  }
}
function paintReef(P: PaintCtx): void {
  const { g, w, base, maxH, rnd } = P;
  const far = num(P, 'far'), near = num(P, 'near');
  if (P.pass === 'base') fillBelow(P, grad(g, base, P.h, P.c0, shadeHex(P.c0, -0.35)));
  const n = near ? 9 : 15;
  for (let i = 0; i < n; i++) {
    const x = (i + rnd() * 0.7) * (w / n), ch = maxH * (0.3 + rnd() * 0.7), kind = Math.floor(rnd() * 3);
    const col = rnd() > 0.5 ? P.c1 : mixHex(P.c1, P.c0, 0.5);
    wrap(w, x, 60, (xx) => {
      if (P.pass === 'emit') { if (far) return; g.globalCompositeOperation = 'lighter'; emitGlow(g, xx, base - ch, 16, col, 0.5); return; }
      g.strokeStyle = col; g.fillStyle = col; g.lineCap = 'round';
      if (kind === 0) { g.lineWidth = 7; const br = (x0: number, y0: number, a: number, len: number, d: number): void => { if (d > 3) return; const x1 = x0 + Math.cos(a) * len, y1 = y0 + Math.sin(a) * len; g.lineWidth = 8 - d * 2; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x1, y1); g.stroke(); br(x1, y1, a - 0.5, len * 0.7, d + 1); br(x1, y1, a + 0.5, len * 0.7, d + 1); }; br(xx, base + 4, -Math.PI / 2, ch * 0.4, 0); }
      else if (kind === 1) { g.beginPath(); g.moveTo(xx - 22, base + 4); g.quadraticCurveTo(xx - 22, base - ch, xx, base - ch * 0.85); g.quadraticCurveTo(xx + 22, base - ch, xx + 22, base + 4); g.closePath(); g.fill(); g.strokeStyle = rgba('#000', 0.18); g.lineWidth = 2; for (let k = -1; k <= 1; k++) { g.beginPath(); g.moveTo(xx + k * 10, base); g.lineTo(xx + k * 8, base - ch * 0.7); g.stroke(); } }
      else { for (let k = 0; k < 5; k++) { g.lineWidth = 5; g.beginPath(); g.moveTo(xx + (k - 2) * 8, base + 4); g.quadraticCurveTo(xx + (k - 2) * 14, base - ch * 0.6, xx + (k - 2) * 12, base - ch * (0.5 + (k % 2) * 0.3)); g.stroke(); g.beginPath(); g.arc(xx + (k - 2) * 12, base - ch * (0.5 + (k % 2) * 0.3), 4, 0, TAU); g.fill(); } }
    });
  }
}
function paintTorii(P: PaintCtx): void {
  const { g, w, base, maxH } = P;
  if (P.pass === 'base') fillBelow(P, shadeHex(P.c0, -0.4));
  const n = 4;
  for (let i = 0; i < n; i++) {
    const x = (i + 0.5) * (w / n), gw = 80 + i % 2 * 30, gh = maxH * (0.7 + (i % 2) * 0.3);
    wrap(w, x, gw, (xx) => {
      if (P.pass === 'emit') { g.globalCompositeOperation = 'lighter'; for (let k = -1; k <= 1; k += 2) emitGlow(g, xx + k * gw * 0.7, base - gh * 0.3, 22, '#ff8a5a', 0.7); return; }
      g.fillStyle = P.c0; g.fillRect(xx - gw / 2, base - gh, 9, gh + 2); g.fillRect(xx + gw / 2 - 9, base - gh, 9, gh + 2);
      g.fillRect(xx - gw / 2 - 12, base - gh - 4, gw + 24, 11); g.fillRect(xx - gw / 2 + 3, base - gh * 0.72, gw - 6, 7);
      g.beginPath(); g.moveTo(xx - gw / 2 - 18, base - gh - 4); g.quadraticCurveTo(xx, base - gh - 18, xx + gw / 2 + 18, base - gh - 4); g.lineTo(xx + gw / 2 + 12, base - gh + 4); g.lineTo(xx - gw / 2 - 12, base - gh + 4); g.closePath(); g.fill();
      g.fillStyle = P.c1; g.fillRect(xx - gw / 2 + 4, base - gh * 0.72 + 1, gw - 8, 2);
      for (let k = -1; k <= 1; k += 2) { g.fillStyle = '#ffb070'; g.beginPath(); g.ellipse(xx + k * gw * 0.7, base - gh * 0.3, 7, 10, 0, 0, TAU); g.fill(); }
    });
  }
}

// ---------------------------------------------------------------- sky layers
function paintNebula(P: PaintCtx): void {
  if (P.pass === 'emit') return;
  const { g, w, h, rnd } = P;
  g.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 9; i++) { const x = rnd() * w, y = rnd() * h, r = 160 + rnd() * 240, col = i % 2 ? P.c0 : P.c1; wrap(w, x, r, (xx) => { const rg = g.createRadialGradient(xx, y, 0, xx, y, r); rg.addColorStop(0, rgba(col, 0.32)); rg.addColorStop(0.5, rgba(col, 0.12)); rg.addColorStop(1, rgba(col, 0)); g.fillStyle = rg; g.fillRect(xx - r, y - r, r * 2, r * 2); }); }
  g.globalCompositeOperation = 'source-over';
}
function paintStars(P: PaintCtx): void {
  if (P.pass === 'emit') return;
  const { g, w, h, rnd } = P;
  const density = num(P, 'density', 1), big = num(P, 'big');
  const n = Math.round(w * h * 0.0009 * density);
  for (let i = 0; i < n; i++) {
    const x = rnd() * w, y = rnd() * h, r = big ? 0.9 + rnd() * 1.8 : 0.4 + rnd() * 1.1;
    g.fillStyle = rgba(rnd() > 0.7 ? P.c1 : P.c0, 0.5 + rnd() * 0.5);
    if (big && rnd() > 0.6) { starPath(g, x, y, r * 2.6, r * 0.5, 4, 0); g.fill(); } else { g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill(); }
  }
}

export const PAINTERS: Record<string, (P: PaintCtx) => void> = {
  mountains: paintMountains, hills: paintHills, forest: paintForest, city: paintCity, castle: paintCastle, ice_spires: paintIceSpires, volcano: paintVolcano,
  crystals: paintCrystals, asteroids: paintAsteroids, islands: paintIslands, temple: paintTemple, reef: paintReef, sakura: paintSakura, dark_spires: paintDarkSpires,
  celestial_city: paintCelestialCity, geometry: paintGeometry, neon_rail: paintNeonRail, cloud_sea: paintCloudSea, torii: paintTorii, rocks: paintRocks,
  nebula: paintNebula, stars: paintStars, kelp: paintKelp,
};
export function makeRnd(seed: number): () => number { return mulberry32(seed * 7919 + 17); }
void hslToHex;
