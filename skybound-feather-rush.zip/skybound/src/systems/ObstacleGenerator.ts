import type { Tuning } from '../config/gameConfig';
import type { ObstacleKind, PowerUpType } from '../core/types';
import { RNG, clamp, lerp, smoothstep, TAU } from '../core/util';
import type { ModeDef, DailyDef } from '../data/modes';
import type { BossDef, PatternId } from '../data/bosses';
import { OBSTACLES } from '../data/obstacles';
import { WORLD_BY_ID } from '../data/worlds';
import type { Gate } from '../entities/Obstacle';
import type { Pickup } from '../entities/Coin';
import { pickPowerUp } from '../entities/PowerUp';
import { flapRise } from './PhysicsSystem';

export interface GenOptions {
  tuning: Tuning;
  mode: ModeDef;
  seed: number;
  startWorld: string;
  /** Worlds the endless-style rotation may visit, in order. */
  worldCycle: string[];
  startScore: number;
  /** 0..1 — adaptive assist for struggling players (slightly wider gaps, slightly slower). */
  assist?: number;
  boss?: BossDef | null;
  daily?: DailyDef | null;
  speedMul?: number;
  gapMul?: number;
  /** Fixed obstacle kinds override (used by adventure/boss levels). */
  kinds?: ObstacleKind[];
}

export interface GenOutput { gate: Gate; pickups: Pickup[] }

/** Hard ceiling for the scroll speed in every mode (keeps reaction time humane). */
export const MAX_SPEED = 430;
const BAND_TOP = 72;            // gap top edge never closer than this to the top of the screen
const BAND_BOTTOM_MARGIN = 46;  // gap bottom edge keeps this distance above the floor

export class ObstacleGenerator {
  readonly rng: RNG;
  private opt: GenOptions;
  private idCounter = 1;
  private pickupId = 1;
  private index = 0;
  private lastCenter: number;
  private lastHalfW = 40;
  private lastWx = 0;
  private lastTe = 1;
  private pattern: PatternId = 'walk';
  private patternLeft = 3;
  private patternStep = 0;
  private patternDir = 1;
  private bossPatternIdx = 0;
  private worldIdx = 0;
  private gatesInWorld = 0;
  private currentWorld: string;
  private secretSpawned = false;
  private sinceChange = 0;
  private sectionFirst = false;
  /** Begin a new section (boss arena / next boss) whose first gate is `firstGateDistance()` after `wx`. */
  startSection(wx: number, boss: BossDef | null, worldId?: string): void {
    this.lastWx = wx;
    this.sectionFirst = true;
    this.opt.boss = boss;
    this.bossPatternIdx = 0;
    this.patternLeft = 0;
    if (worldId) this.setWorld(worldId);
  }
  private lastPowerAt = -3;
  /** current world after the most recent spawn */
  get world(): string { return this.currentWorld; }
  get gateCount(): number { return this.index; }

  constructor(opt: GenOptions) {
    this.opt = opt;
    this.rng = new RNG(opt.seed);
    this.currentWorld = opt.startWorld;
    const wi = opt.worldCycle.indexOf(opt.startWorld);
    this.worldIdx = wi >= 0 ? wi : 0;
    this.lastCenter = 400;
  }

  setBoss(b: BossDef | null, kindsOverride?: ObstacleKind[]): void {
    this.opt.boss = b;
    if (kindsOverride) this.opt.kinds = kindsOverride;
    this.bossPatternIdx = 0;
    this.patternLeft = 0;
  }
  setWorld(worldId: string): void {
    this.currentWorld = worldId;
    const wi = this.opt.worldCycle.indexOf(worldId);
    if (wi >= 0) this.worldIdx = wi;
    this.gatesInWorld = 0;
  }

  // ---------------------------------------------------------------- difficulty
  difficulty(score: number): number {
    const t = this.opt.tuning;
    return clamp((score + this.opt.startScore) / t.difficultyRamp, 0, 1);
  }
  speedFor(score: number): number {
    const t = this.opt.tuning;
    const assist = this.opt.assist ?? 0;
    const sp = Math.min(t.speedMax, t.speedBase + t.speedPerPoint * (score + this.opt.startScore));
    const final = sp * this.opt.mode.speedMul * (this.opt.speedMul ?? 1) * (this.opt.boss?.speedMul ?? 1) * (1 - 0.05 * assist);
    return Math.min(final, MAX_SPEED);
  }
  gapFor(score: number): number {
    const t = this.opt.tuning;
    const assist = this.opt.assist ?? 0;
    const g = Math.max(t.gapMin, t.gapBase - t.gapPerPoint * (score + this.opt.startScore));
    const m = this.opt.mode.gapMul * (this.opt.gapMul ?? 1) * (this.opt.boss?.gapMul ?? 1) * (1 + 0.07 * assist);
    // never smaller than the absolute floor that is humanly passable
    return Math.max(g * m, t.gapMin * 0.95);
  }
  spacingTime(score: number): number {
    const t = this.opt.tuning;
    const d = this.difficulty(score);
    return lerp(t.spacingTime, t.spacingMin, d) * this.opt.mode.spacingMul;
  }

  // ---------------------------------------------------------------- spawning
  /** First gate is placed far enough ahead to give the player time to get ready. */
  firstGateDistance(): number { return 560; }

  next(score: number, _birdX = 0): GenOutput {
    const t = this.opt.tuning;
    const rng = this.rng;
    const eff = score + this.opt.startScore;
    const d = this.difficulty(score);
    const speed = this.speedFor(score);
    const first = this.index === 0 || this.sectionFirst;
    const veryFirst = this.index === 0;

    // ---- world rotation (Endless / Hardcore / Zen): next gate becomes a portal gate that switches the world
    let nextWorld: string | undefined;
    let kind: ObstacleKind;
    const rotate = this.opt.mode.worldRotate;
    if (!first && rotate > 0 && this.gatesInWorld >= rotate && !this.opt.boss && this.opt.worldCycle.length > 1) {
      this.worldIdx = (this.worldIdx + 1) % this.opt.worldCycle.length;
      nextWorld = this.opt.worldCycle[this.worldIdx];
      kind = 'portal';
    } else {
      kind = this.pickKind();
    }
    const spec = OBSTACLES[kind];

    // ---- gap size
    let half = this.gapFor(score) / 2;
    if (spec.halfW >= 50) half += 3;          // wide columns take longer to cross
    if (this.pattern === 'narrow' && !first) half *= 0.95;

    // ---- motion
    let motion = spec.motion;
    let amp = 0;
    if (motion !== 'static') {
      const allow = (eff >= 5 || !!this.opt.boss) && !first && !nextWorld;
      const p = clamp(0.28 + 0.5 * d, 0, 0.8);
      if (!allow || !rng.chance(p)) motion = 'static';
      else amp = lerp(spec.amp[0], spec.amp[1], clamp(0.25 + 0.75 * d, 0, 1)) * (0.7 + 0.3 * rng.next());
    }
    const r = t.birdRadius * t.hitboxScale;
    const window = (2 * spec.halfW + 2 * r) / speed;
    let k = 0;
    let baseHalf = half;
    let extraHalf = 0;
    if (motion === 'bob') {
      const rate = lerp(70, 115, d);                 // max vertical speed of the gap (units/s)
      k = rate / (Math.max(amp, 1) * speed);
      extraHalf = rate * window * 0.5 + 4;           // compensates for the gap moving while the bird crosses
      half += extraHalf; baseHalf = half;
    } else if (motion === 'breathe') {
      k = Math.PI / speed;                           // ~2 s breathing period
      baseHalf = half + 2 * amp;                     // smallest breathing size == nominal gap
    }
    const bandHalf = baseHalf;

    // ---- distance from previous gate
    const spacing = this.spacingTime(score);
    let dist = speed * spacing;
    if (first) dist = this.firstGateDistance();
    // extra breathing room for wide gates
    dist += (spec.halfW + this.lastHalfW) * 0.35;
    // travel time between leaving the previous column and entering this one (the climb budget)
    const te = Math.max(0.35, (dist - this.lastHalfW - spec.halfW - 2 * r) / speed);

    // ---- target center
    const minC = BAND_TOP + bandHalf;
    const maxC = t.floorY - BAND_BOTTOM_MARGIN - bandHalf;
    let target: number;
    if (veryFirst) target = clamp(440, minC, maxC);
    else if (first) target = clamp(this.lastCenter, minC, maxC);
    else target = this.patternTarget(d, minC, maxC);

    // ---- clamp by reachability: climb is limited, falling is limited by free fall
    const climb = 0.8 * t.maxClimbRate * te;                         // up (negative y)
    const fall = Math.min(0.55 * 0.5 * t.gravity * te * te, 430);    // down
    let delta = target - this.lastCenter;
    if (delta < -climb) delta = -climb;
    if (delta > fall) delta = fall;
    let center = clamp(this.lastCenter + delta, minC, maxC);
    if (first) { center = target; this.sectionFirst = false; }

    // moving gates: crossing center = base + amp*sin(phase) → pick phase freely, then keep within band
    let phase = rng.next() * TAU;
    let baseCenter = center;
    if (motion === 'bob') {
      // keep the whole oscillation inside the band
      const room = Math.min(center - minC, maxC - center);
      amp = Math.min(amp, Math.max(0, room));
      if (amp < 8) { motion = 'static'; amp = 0; k = 0; half -= extraHalf; baseHalf = half; }
      else baseCenter = center - amp * Math.sin(phase);
    } else if (motion === 'breathe') {
      baseCenter = center;
    }
    // (for 'breathe' the nominal minimum gap is guaranteed; the max is baseHalf)

    const wx = this.lastWx + dist;
    const gate: Gate = {
      id: this.idCounter++, kind, worldId: this.currentWorld,
      wx, baseCenter, baseHalf: motion === 'breathe' ? baseHalf : half, halfW: spec.halfW, motion, amp, k, phase,
      seed: (rng.next() * 0xffffff) | 0, passed: false, spawnedAt: 0,
    };
    if (nextWorld) {
      gate.nextWorld = nextWorld;
      this.currentWorld = nextWorld;       // gates after this one belong to the new world
      this.gatesInWorld = 0;
    }
    if (this.opt.boss) gate.bossIndex = this.index;

    const crossing = center;
    const out: GenOutput = { gate, pickups: [] };
    this.makePickups(out, gate, crossing, score, first);

    this.lastCenter = crossing;
    this.lastHalfW = spec.halfW;
    this.lastWx = wx;
    this.lastTe = te;
    this.index++;
    this.gatesInWorld++;
    this.sinceChange++;
    return out;
  }

  private pickKind(): ObstacleKind {
    const rng = this.rng;
    if (this.opt.kinds && this.opt.kinds.length) return rng.pick(this.opt.kinds);
    const w = WORLD_BY_ID[this.currentWorld];
    return rng.pick(w ? w.obstacles : (['crystal'] as ObstacleKind[]));
  }

  // ---------------------------------------------------------------- patterns
  private pickPattern(d: number): void {
    const rng = this.rng;
    const boss = this.opt.boss;
    if (boss) {
      this.pattern = boss.patterns[this.bossPatternIdx % boss.patterns.length];
      this.bossPatternIdx++;
      this.patternLeft = 5 + (this.bossPatternIdx % 2);
    } else {
      const pool: [PatternId, number][] = [
        ['walk', 3], ['stairs_up', 1 + d], ['stairs_down', 1 + d], ['breather', 1.2 - d * 0.5],
        ['sine', 0.6 + d], ['zigzag', 0.3 + d * 1.4], ['wave', 0.4 + d * 0.8], ['narrow', d * 0.9],
      ];
      let total = 0; for (const p of pool) total += Math.max(0.05, p[1]);
      let x = rng.next() * total;
      this.pattern = 'walk';
      for (const p of pool) { x -= Math.max(0.05, p[1]); if (x <= 0) { this.pattern = p[0]; break; } }
      this.patternLeft = this.pattern === 'walk' ? rng.int(3, 6) : rng.int(3, 5);
    }
    this.patternStep = 0;
    this.patternDir = rng.sign();
  }

  private patternTarget(d: number, minC: number, maxC: number): number {
    if (this.patternLeft <= 0) this.pickPattern(d);
    this.patternLeft--;
    const rng = this.rng;
    const mid = (minC + maxC) / 2;
    const span = maxC - minC;
    const walkAmp = lerp(110, 230, d);
    let target = this.lastCenter;
    switch (this.pattern) {
      case 'walk':
        target = this.lastCenter + rng.range(-walkAmp, walkAmp);
        break;
      case 'stairs_up': {
        const step = lerp(55, 95, d);
        target = this.lastCenter - step;
        if (target < minC + 20) { this.pattern = 'stairs_down'; target = this.lastCenter + step; }
        break;
      }
      case 'stairs_down': {
        const step = lerp(55, 95, d);
        target = this.lastCenter + step;
        if (target > maxC - 20) { this.pattern = 'stairs_up'; target = this.lastCenter - step; }
        break;
      }
      case 'zigzag': {
        const a = lerp(90, 175, d);
        this.patternDir = -this.patternDir;
        target = this.lastCenter + this.patternDir * a;
        break;
      }
      case 'sine':
      case 'wave': {
        this.patternStep++;
        const amp = (this.pattern === 'sine' ? 0.3 : 0.38) * span;
        const f = this.pattern === 'sine' ? 0.62 : 0.95;
        target = mid + amp * Math.sin(this.patternStep * f + this.patternDir);
        break;
      }
      case 'breather':
        target = mid + rng.range(-0.12, 0.12) * span;
        break;
      case 'narrow':
        target = this.lastCenter + rng.range(-70, 70);
        break;
    }
    return clamp(target, minC, maxC);
  }

  // ---------------------------------------------------------------- pickups
  private makePickups(out: GenOutput, gate: Gate, crossing: number, score: number, first: boolean): void {
    const rng = this.rng;
    const mode = this.opt.mode;
    const eff = score + this.opt.startScore;
    const daily = this.opt.daily;
    let coinMul = mode.coins;
    if (daily) for (const m of daily.mods) if (m.coin) coinMul *= m.coin;
    if (this.index === 0 || first) return;

    const x0 = this.lastWx + this.lastHalfW + 36;
    const x1 = gate.wx - gate.halfW - 36;
    const y0 = this.lastCenter, y1 = crossing;
    const len = x1 - x0;

    const curveY = (u: number): number => lerp(y0, y1, smoothstep(0, 1, u));

    // coin line along the natural flight path between the two gates
    if (len > 90 && rng.chance(clamp(0.55 * coinMul, 0, 0.95))) {
      const n = clamp(Math.floor(len / 58), 3, 7);
      const bulge = rng.chance(0.4) ? rng.range(-22, 22) : 0;
      for (let i = 0; i < n; i++) {
        const u = (i + 0.5) / n;
        const y = curveY(u) + bulge * Math.sin(u * Math.PI);
        out.pickups.push({ id: this.pickupId++, kind: 'coin', wx: x0 + len * u, y, r: 16, value: 1, collected: false, collectT: 0, ox: 0, oy: 0 });
      }
    }
    // power-up (never next to another one)
    const pChance = 0.2 * mode.powerups * (this.index - this.lastPowerAt >= 5 ? 1.6 : 0.2);
    if (mode.powerups > 0 && this.index >= 3 && !this.opt.boss && rng.chance(clamp(pChance, 0, 0.5))) {
      const type: PowerUpType = pickPowerUp(rng);
      this.lastPowerAt = this.index;
      const u = 0.5;
      out.pickups.push({ id: this.pickupId++, kind: 'power', power: type, wx: x0 + len * u, y: curveY(u), r: 24, value: 0, collected: false, collectT: 0, ox: 0, oy: 0 });
    } else if (eff >= 12 && rng.chance(0.035 * Math.max(mode.coins, 0.3))) {
      out.pickups.push({ id: this.pickupId++, kind: 'gem', wx: x0 + len * 0.5, y: curveY(0.5), r: 18, value: 1, collected: false, collectT: 0, ox: 0, oy: 0 });
    }
    // secret portal (rare; hidden-content unlock). Sits exactly in the next gap, so it is always reachable.
    if (mode.secretPortal && !this.secretSpawned && eff >= 30 && rng.chance(0.07)) {
      this.secretSpawned = true;
      out.pickups.push({ id: this.pickupId++, kind: 'secret', wx: gate.wx, y: crossing, r: 30, value: 0, collected: false, collectT: 0, ox: 0, oy: 0 });
    }
  }
}

/** Analytic reachability check used by tests: can a flapper (climb rate cap) get from one gate crossing to the next? */
export function reachable(t: Tuning, c0: number, c1: number, te: number): boolean {
  const climb = t.maxClimbRate * te;
  const fall = 0.5 * t.gravity * te * te;
  const d = c1 - c0;
  return d >= -climb - flapRise(t) * 0 && d <= fall;
}
