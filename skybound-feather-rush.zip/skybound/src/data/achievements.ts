import type { L10n } from '../core/types';
import type { SaveData } from '../systems/SaveManager';
import type { RunResult } from '../core/GameSession';
import { SKINS } from './skins';
import { WORLDS } from './worlds';
import { ADVENTURE_LEVELS } from './modes';
import { BOSSES } from './bosses';
import type { Reward } from './missions';

export type Rarity = 'common' | 'rare' | 'epic' | 'legendary';
export interface AchCtx { save: SaveData; run: Partial<RunResult> | null }
export interface AchDef {
  id: string; rarity: Rarity; name: L10n; desc: L10n; secret?: boolean;
  check: (c: AchCtx) => boolean;
  /** [current, target] for progress bars (cumulative achievements only) */
  progress?: (c: AchCtx) => [number, number];
  reward: Reward;
}

export const RARITY_REWARD: Record<Rarity, Reward> = {
  common: { coins: 50, gems: 0, xp: 30 },
  rare: { coins: 150, gems: 1, xp: 80 },
  epic: { coins: 400, gems: 3, xp: 200 },
  legendary: { coins: 1000, gems: 10, xp: 600 },
};

const runScore = (c: AchCtx): number => c.run?.score ?? 0;
const A = (id: string, rarity: Rarity, vi: [string, string], en: [string, string], check: AchDef['check'], progress?: AchDef['progress'], secret = false): AchDef =>
  ({ id, rarity, name: { vi: vi[0], en: en[0] }, desc: { vi: vi[1], en: en[1] }, check, progress, reward: RARITY_REWARD[rarity], secret });
const cum = (get: (s: SaveData) => number, target: number): [AchDef['check'], AchDef['progress']] => [
  (c) => get(c.save) >= target, (c) => [Math.min(get(c.save), target), target],
];

const adventureDone = (s: SaveData): number => Object.values(s.adventure).filter((a) => a.stars > 0).length;
const adventureStars = (s: SaveData): number => Object.values(s.adventure).reduce((a, b) => a + b.stars, 0);

export const ACHIEVEMENTS: AchDef[] = [
  A('first_flight', 'common', ['Chuyến Bay Đầu Tiên', 'Hoàn thành ván chơi đầu tiên.'], ['First Flight', 'Finish your first game.'], ...cum((s) => s.stats.games, 1)),
  A('score_10', 'common', ['Khởi Động', 'Đạt 10 điểm trong một ván.'], ['Warming Up', 'Score 10 in a single run.'], (c) => runScore(c) >= 10),
  A('score_25', 'common', ['Đôi Cánh Vững Vàng', 'Đạt 25 điểm trong một ván.'], ['Steady Wings', 'Score 25 in a single run.'], (c) => runScore(c) >= 25),
  A('score_50', 'rare', ['Nửa Trăm', 'Đạt 50 điểm trong một ván.'], ['Half a Hundred', 'Score 50 in a single run.'], (c) => runScore(c) >= 50),
  A('score_100', 'epic', ['Trăm Điểm Vàng', 'Đạt 100 điểm trong một ván.'], ['Golden Hundred', 'Score 100 in a single run.'], (c) => runScore(c) >= 100),
  A('score_200', 'legendary', ['Huyền Thoại Bầu Trời', 'Đạt 200 điểm trong một ván.'], ['Sky Legend', 'Score 200 in a single run.'], (c) => runScore(c) >= 200),
  A('combo_10', 'rare', ['Bay Như Lụa', 'Đạt combo 10.'], ['Smooth as Silk', 'Reach a combo of 10.'], (c) => c.save.stats.maxCombo >= 10 || (c.run?.maxCombo ?? 0) >= 10, (c) => [Math.min(10, Math.max(c.save.stats.maxCombo, c.run?.maxCombo ?? 0)), 10]),
  A('combo_25', 'epic', ['Hoàn Hảo Tuyệt Đối', 'Đạt combo 25.'], ['Flawless', 'Reach a combo of 25.'], (c) => c.save.stats.maxCombo >= 25 || (c.run?.maxCombo ?? 0) >= 25, (c) => [Math.min(25, Math.max(c.save.stats.maxCombo, c.run?.maxCombo ?? 0)), 25]),
  A('coins_100', 'common', ['Người Nhặt Xu', 'Thu thập tổng cộng 100 xu.'], ['Coin Collector', 'Collect 100 coins in total.'], ...cum((s) => s.stats.coins, 100)),
  A('coins_1000', 'rare', ['Nhà Giàu Mới Nổi', 'Thu thập tổng cộng 1.000 xu.'], ['Rising Rich', 'Collect 1,000 coins in total.'], ...cum((s) => s.stats.coins, 1000)),
  A('coins_10000', 'epic', ['Tỷ Phú Bầu Trời', 'Thu thập tổng cộng 10.000 xu.'], ['Sky Tycoon', 'Collect 10,000 coins in total.'], ...cum((s) => s.stats.coins, 10000)),
  A('distance_1k', 'common', ['Lữ Khách', 'Bay tổng cộng 1.000 mét.'], ['Traveler', 'Fly 1,000 meters in total.'], ...cum((s) => s.stats.distance, 1000)),
  A('distance_20k', 'epic', ['Vòng Quanh Thế Giới', 'Bay tổng cộng 20.000 mét.'], ['Around the World', 'Fly 20,000 meters in total.'], ...cum((s) => s.stats.distance, 20000)),
  A('games_10', 'common', ['Bắt Đầu Nghiện', 'Chơi 10 ván.'], ['Getting Hooked', 'Play 10 games.'], ...cum((s) => s.stats.games, 10)),
  A('games_100', 'rare', ['Phi Công Lão Luyện', 'Chơi 100 ván.'], ['Veteran Pilot', 'Play 100 games.'], ...cum((s) => s.stats.games, 100)),
  A('games_500', 'epic', ['Cuồng Bay', 'Chơi 500 ván.'], ['Flight Fanatic', 'Play 500 games.'], ...cum((s) => s.stats.games, 500)),
  A('powerups_20', 'common', ['Thích Vật Phẩm', 'Nhặt 20 vật phẩm.'], ['Power Hungry', 'Pick up 20 power-ups.'], ...cum((s) => s.stats.powerups, 20)),
  A('powerups_all', 'rare', ['Đủ Bộ Sưu Tập', 'Dùng cả 8 loại vật phẩm.'], ['Full Arsenal', 'Use all 8 kinds of power-ups.'], (c) => c.save.stats.powerTypes.length >= 8, (c) => [c.save.stats.powerTypes.length, 8]),
  A('perfect_100', 'rare', ['Mắt Đại Bàng', 'Bay hoàn hảo qua 100 cổng.'], ['Eagle Eye', 'Fly 100 perfect gates.'], ...cum((s) => s.stats.perfects, 100)),
  A('phoenix_save', 'rare', ['Tái Sinh', 'Được Phượng Hoàng hồi sinh.'], ['Reborn', 'Get revived by the Phoenix.'], (c) => c.save.stats.phoenixUsed >= 1),
  A('boss_first', 'rare', ['Kẻ Diệt Trùm', 'Đánh bại một trùm.'], ['Boss Slayer', 'Defeat a boss.'], ...cum((s) => s.stats.bosses, 1)),
  A('boss_all', 'epic', ['Vua Boss Rush', 'Đánh bại cả 5 trùm trong một lượt Boss Rush.'], ['Boss Rush King', 'Defeat all 5 bosses in one Boss Rush.'], (c) => (c.run?.mode === 'bossrush' && (c.run?.bossesDefeated ?? 0) >= BOSSES.length) || !!c.save.achievements.boss_all),
  A('adventure_5', 'common', ['Nhà Thám Hiểm', 'Hoàn thành 5 màn Phiêu lưu.'], ['Explorer', 'Complete 5 Adventure levels.'], (c) => adventureDone(c.save) >= 5, (c) => [Math.min(5, adventureDone(c.save)), 5]),
  A('adventure_complete', 'epic', ['Hành Trình Trọn Vẹn', 'Hoàn thành cả 20 màn Phiêu lưu.'], ['Journey Complete', 'Complete all 20 Adventure levels.'], (c) => adventureDone(c.save) >= ADVENTURE_LEVELS.length, (c) => [adventureDone(c.save), ADVENTURE_LEVELS.length]),
  A('three_stars', 'legendary', ['Ngôi Sao Sáng Nhất', 'Đạt 3 sao ở mọi màn Phiêu lưu.'], ['Brightest Star', 'Earn 3 stars on every Adventure level.'], (c) => adventureStars(c.save) >= ADVENTURE_LEVELS.length * 3, (c) => [adventureStars(c.save), ADVENTURE_LEVELS.length * 3]),
  A('hardcore_50', 'epic', ['Thép Trong Lửa', 'Đạt 50 điểm trong Hardcore.'], ['Forged in Fire', 'Score 50 in Hardcore.'], (c) => c.save.best.hardcore >= 50 || (c.run?.mode === 'hardcore' && runScore(c) >= 50), (c) => [Math.min(50, Math.max(c.save.best.hardcore, c.run?.mode === 'hardcore' ? runScore(c) : 0)), 50]),
  A('hardcore_100', 'legendary', ['Hoàng Đế Vũ Trụ', 'Đạt 100 điểm trong Hardcore. Mở khóa skin bí mật.'], ['Cosmic Emperor', 'Score 100 in Hardcore. Unlocks a secret skin.'], (c) => c.save.best.hardcore >= 100 || (c.run?.mode === 'hardcore' && runScore(c) >= 100), undefined, true),
  A('time_attack_40', 'rare', ['Đua Với Thời Gian', 'Đạt 40 điểm trong Time Attack.'], ['Racing the Clock', 'Score 40 in Time Attack.'], (c) => c.save.best.timeattack >= 40 || (c.run?.mode === 'timeattack' && runScore(c) >= 40)),
  A('zen_10min', 'common', ['Tĩnh Tâm', 'Bay 10 phút trong chế độ Thiền.'], ['Inner Peace', 'Fly 10 minutes in Zen mode.'], (c) => c.save.stats.zenTime >= 600, (c) => [Math.min(600, Math.floor(c.save.stats.zenTime)), 600]),
  A('daily_first', 'common', ['Thử Thách Đầu Tiên', 'Hoàn thành một Thử thách ngày.'], ['First Challenge', 'Complete a Daily Challenge.'], (c) => c.save.stats.dailyDone >= 1),
  A('daily_7', 'rare', ['Thói Quen Tốt', 'Hoàn thành 7 Thử thách ngày.'], ['Good Habit', 'Complete 7 Daily Challenges.'], ...cum((s) => s.stats.dailyDone, 7)),
  A('level_10', 'common', ['Cấp 10', 'Đạt cấp độ 10.'], ['Level 10', 'Reach level 10.'], ...cum((s) => s.level, 10)),
  A('level_25', 'rare', ['Cấp 25', 'Đạt cấp độ 25.'], ['Level 25', 'Reach level 25.'], ...cum((s) => s.level, 25)),
  A('level_50', 'epic', ['Cấp 50', 'Đạt cấp độ 50.'], ['Level 50', 'Reach level 50.'], ...cum((s) => s.level, 50)),
  A('skins_5', 'common', ['Nhà Sưu Tầm', 'Sở hữu 5 skin.'], ['Collector', 'Own 5 skins.'], ...cum((s) => s.unlockedSkins.length, 5)),
  A('skins_12', 'rare', ['Bộ Sưu Tập Quý', 'Sở hữu 12 skin.'], ['Fine Collection', 'Own 12 skins.'], ...cum((s) => s.unlockedSkins.length, 12)),
  A('skins_all', 'legendary', ['Hoàn Tất Bộ Sưu Tập', `Sở hữu cả ${SKINS.length} skin.`], ['Collection Complete', `Own all ${SKINS.length} skins.`], (c) => c.save.unlockedSkins.length >= SKINS.length, (c) => [c.save.unlockedSkins.length, SKINS.length]),
  A('worlds_5', 'rare', ['Du Hành Thế Giới', 'Mở khóa 5 thế giới.'], ['World Traveler', 'Unlock 5 worlds.'], ...cum((s) => s.unlockedWorlds.length, 5)),
  A('worlds_all', 'legendary', ['Chúa Tể Đa Vũ Trụ', `Mở khóa cả ${WORLDS.length} thế giới.`], ['Multiverse Master', `Unlock all ${WORLDS.length} worlds.`], (c) => c.save.unlockedWorlds.length >= WORLDS.length, (c) => [c.save.unlockedWorlds.length, WORLDS.length]),
  A('score_60_secret', 'epic', ['Cánh Cửa Bóng Tối', 'Đạt 60 điểm trong một ván. Mở ra Chiều Không Gian Tối.'], ['Door to Darkness', 'Score 60 in one run. Opens the Dark Dimension.'], (c) => runScore(c) >= 60 || !!c.save.secrets.score_60, undefined, true),
  A('secret_portal', 'legendary', ['Kẻ Tìm Cổng Bí Mật', 'Bay qua một Cổng Bí Mật.'], ['Secret Seeker', 'Fly through a Secret Portal.'], (c) => !!c.save.secrets.secret_portal || !!c.run?.secretFound, undefined, true),
];
export const ACH_BY_ID: Record<string, AchDef> = Object.fromEntries(ACHIEVEMENTS.map((a) => [a.id, a]));
