import { runBot } from './botsim';
import { MODE_LIST } from '../src/data/modes';
import { OBSTACLE_KINDS } from '../src/data/obstacles';

let fails = 0, runs = 0;
const worstMargins: number[] = [];

function check(label: string, o: Parameters<typeof runBot>[0], expectPass = true): void {
  const r = runBot(o);
  runs++;
  worstMargins.push(r.minMargin);
  if (expectPass && r.died) {
    fails++;
    console.log(`  FAIL ${label} seed=${o.seed}: died after ${r.passed} gates (${r.reason}) startScore=${o.startScore}`);
  }
}

console.log('1) All modes, 40 seeds each, 150 gates, bot with human-like latency (50 ms) and aim noise');
for (const m of MODE_LIST) {
  if (m === 'zen' || m === 'bossrush') { /* zen is deathless; boss rush is checked in the session test */ }
  for (let s = 1; s <= 40; s++) check(`mode=${m}`, { seed: s * 7919 + 13, mode: m, gates: 150, latencyFrames: 3, skill: 0.85 });
}
console.log('2) Maximum difficulty (startScore 100), every obstacle kind forced, 30 seeds each');
for (const k of OBSTACLE_KINDS) for (let s = 1; s <= 30; s++) check(`kind=${k} maxdiff`, { seed: s * 104729 + 7, mode: 'hardcore', gates: 120, startScore: 100, kinds: [k], latencyFrames: 3, skill: 0.85 });
console.log('3) Low-skill bot (100 ms latency, sloppy aim) must still clear the first 25 gates at normal difficulty');
for (let s = 1; s <= 60; s++) check('lowskill', { seed: s * 31 + 5, mode: 'endless', gates: 25, latencyFrames: 5, skill: 0.7 });

worstMargins.sort((a, b) => a - b);
console.log(`runs=${runs} failures=${fails}; smallest clearance across all runs: ${worstMargins[0].toFixed(1)} units (p5=${worstMargins[Math.floor(worstMargins.length * 0.05)].toFixed(1)})`);
if (fails > 0) process.exit(1);
console.log('GENERATOR OK');
