// 12 world-transition overlays. `p` is the coverage 0..1 (1 = background fully hidden). Drawn over the BACKGROUND only,
// so gameplay (bird / obstacles) stays readable while the world swaps underneath.
import type { TransitionStyle } from '../data/worlds';
import { mulberry32, rgba, shadeHex, TAU } from '../core/util';
import { drawGlow, starPath, type Ctx } from './gfx';

export function drawTransition(c: Ctx, W: number, H: number, style: TransitionStyle, color: string, p: number, t: number, cx = W * 0.3, cy = H * 0.5): void {
  if (p <= 0.001) return;
  const R = Math.hypot(W, H);
  c.save();
  switch (style) {
    case 'iris': {
      c.fillStyle = rgba(shadeHex(color, -0.55), 0.96); c.beginPath(); c.rect(-10, -10, W + 20, H + 20); c.arc(cx, cy, Math.max(0, (1 - p) * R), 0, TAU, true); c.fill('evenodd');
      c.strokeStyle = rgba(color, 0.9 * p); c.lineWidth = 6; c.beginPath(); c.arc(cx, cy, Math.max(0, (1 - p) * R), 0, TAU); c.stroke(); break;
    }
    case 'sunburst': {
      c.fillStyle = rgba(color, p * p * 0.85); c.fillRect(0, 0, W, H);
      const n = 18; for (let i = 0; i < n; i++) { const a = (i / n) * TAU + t * 0.4, w = (TAU / n) * 0.5 * p; c.fillStyle = rgba('#fff6c8', 0.75 * p); c.beginPath(); c.moveTo(cx, cy); c.arc(cx, cy, R, a - w, a + w); c.closePath(); c.fill(); }
      drawGlow(c, cx, cy, R * 0.5 * p, '#ffffff', p); break;
    }
    case 'frost': {
      c.fillStyle = rgba('#bfe9ff', p * 0.92); c.fillRect(0, 0, W, H);
      const r = mulberry32(7); c.fillStyle = rgba('#ffffff', 0.9);
      for (let i = 0; i < 36; i++) { const x = r() * W, d = (60 + r() * 220) * (1 - p); c.beginPath(); c.moveTo(x - 16, -2); c.lineTo(x, d + 40 * r()); c.lineTo(x + 16, -2); c.fill(); c.beginPath(); c.moveTo(x - 16, H + 2); c.lineTo(x, H - d - 40 * r()); c.lineTo(x + 16, H + 2); c.fill(); }
      break;
    }
    case 'flame': {
      const top = H * (1 - p * 1.25);
      const g = c.createLinearGradient(0, top, 0, H); g.addColorStop(0, rgba('#ffd34a', 0.95)); g.addColorStop(0.4, rgba('#ff6a1a', 0.95)); g.addColorStop(1, rgba('#7a0f08', 1));
      c.fillStyle = g; c.beginPath(); c.moveTo(0, H + 4); for (let x = 0; x <= W; x += 18) c.lineTo(x, top - Math.abs(Math.sin(x * 0.04 + t * 9)) * 60 * (1 - p * 0.6) - Math.sin(x * 0.13 + t * 14) * 14); c.lineTo(W, H + 4); c.fill();
      break;
    }
    case 'glitch': {
      c.fillStyle = rgba('#05031a', p * 0.8); c.fillRect(0, 0, W, H);
      const r = mulberry32(Math.floor(t * 18) + 3);
      for (let i = 0; i < 22; i++) { const y = r() * H, h = 6 + r() * 60, off = (r() - 0.5) * 220 * p; c.fillStyle = rgba(r() > 0.5 ? '#00e5ff' : '#ff2bd6', 0.55 * p); c.fillRect(off, y, W, h); }
      break;
    }
    case 'warp': {
      c.fillStyle = rgba('#050a28', p * p * 0.9); c.fillRect(0, 0, W, H);
      const r = mulberry32(11); c.lineCap = 'round';
      for (let i = 0; i < 90; i++) { const a = r() * TAU, d0 = (0.05 + r() * 0.5) * R, len = (0.1 + r() * 0.6) * R * p; c.strokeStyle = rgba(r() > 0.5 ? '#9fd8ff' : '#ffffff', 0.8 * p); c.lineWidth = 1 + r() * 2.5; c.beginPath(); c.moveTo(cx + Math.cos(a) * d0, cy + Math.sin(a) * d0); c.lineTo(cx + Math.cos(a) * (d0 + len), cy + Math.sin(a) * (d0 + len)); c.stroke(); }
      break;
    }
    case 'light': c.fillStyle = rgba('#ffffff', p * p); c.fillRect(0, 0, W, H); drawGlow(c, cx, cy, R * p, color, p); break;
    case 'ripple': {
      c.fillStyle = rgba(color, p * 0.7); c.fillRect(0, 0, W, H); c.strokeStyle = rgba('#ffffff', 0.7 * p); c.lineWidth = 4;
      for (let i = 0; i < 7; i++) { c.beginPath(); c.arc(cx, cy, ((i / 7 + t * 0.6) % 1) * R * p, 0, TAU); c.stroke(); }
      break;
    }
    case 'petals': {
      c.fillStyle = rgba('#ffd1e6', p * 0.75); c.fillRect(0, 0, W, H);
      const r = mulberry32(5); for (let i = 0; i < 70; i++) { const x = W * (1.1 - ((r() * 0.6 + p * 0.7) % 1.3)), y = r() * H + Math.sin(t * 3 + i) * 20; c.save(); c.translate(x, y); c.rotate(i + t * 2); c.fillStyle = rgba(i % 2 ? '#ff9ac6' : '#ffffff', 0.85); c.beginPath(); c.ellipse(0, 0, 16 * p + 4, 8 * p + 2, 0, 0, TAU); c.fill(); c.restore(); }
      break;
    }
    case 'void': {
      c.fillStyle = rgba('#05010a', p); c.fillRect(0, 0, W, H);
      const r = mulberry32(9); for (let i = 0; i < 8; i++) { const x = r() * W, y = r() * H, rad = (60 + r() * 220) * p; const g = c.createRadialGradient(x, y, 0, x, y, rad); g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(160,112,255,0)'); c.fillStyle = g; c.fillRect(x - rad, y - rad, rad * 2, rad * 2); }
      break;
    }
    case 'halo': {
      c.fillStyle = rgba('#fff3c8', p * 0.9); c.fillRect(0, 0, W, H); c.strokeStyle = rgba('#ffd56b', 0.9 * p);
      for (let i = 0; i < 4; i++) { c.lineWidth = 8 - i * 1.5; c.beginPath(); c.arc(cx, cy, ((i / 4 + t * 0.4) % 1) * R * 0.8 * p + 20, 0, TAU); c.stroke(); }
      drawGlow(c, cx, cy, R * 0.6 * p, '#ffffff', p); break;
    }
    case 'kaleido': {
      c.fillStyle = rgba('#10082a', p * 0.6); c.fillRect(0, 0, W, H);
      c.translate(cx, cy); c.rotate(t * 0.8);
      for (let i = 0; i < 12; i++) { c.rotate(TAU / 12); c.fillStyle = `hsla(${i * 30 + t * 120},85%,60%,${0.6 * p})`; c.beginPath(); c.moveTo(0, 0); c.lineTo(R * p, -R * 0.12 * p); c.lineTo(R * p, R * 0.12 * p); c.closePath(); c.fill(); }
      c.setTransform(c.getTransform()); break;
    }
  }
  c.restore();
  void starPath;
}
