-- SKYBOUND: FEATHER RUSH ∞  —  Supabase schema (run in the SQL editor of a new project).
-- Enables: profiles, server-validated score submission, leaderboards (all/week/day), friends, cloud save.
-- Auth: enable Email provider and (optionally) "Allow anonymous sign-ins" for guest play.

create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 3 and 20),
  avatar text not null default 'sakura_bird',
  created_at timestamptz not null default now()
);
create unique index if not exists profiles_name_lower_idx on public.profiles (lower(name));

create table if not exists public.scores (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  mode text not null,
  score int not null check (score >= 0),
  run_time real not null,
  gates int not null,
  created_at timestamptz not null default now()
);
create index if not exists scores_mode_score_idx on public.scores (mode, score desc);
create index if not exists scores_user_idx on public.scores (user_id, created_at desc);

create table if not exists public.friends (
  user_id uuid not null references auth.users(id) on delete cascade,
  friend_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, friend_id),
  check (user_id <> friend_id)
);

create table if not exists public.saves (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null,
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.scores   enable row level security;
alter table public.friends  enable row level security;
alter table public.saves    enable row level security;

-- profiles: everyone can read names (needed for leaderboards); users write only their own row
create policy "profiles read" on public.profiles for select using (true);
create policy "profiles insert own" on public.profiles for insert with check (auth.uid() = id);
create policy "profiles update own" on public.profiles for update using (auth.uid() = id);
-- scores: readable by all, but NEVER writable directly — only through submit_score()
create policy "scores read" on public.scores for select using (true);
-- friends / saves: private to the owner
create policy "friends own" on public.friends for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "saves own" on public.saves for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Basic anti-cheat: plausibility checks against the physical limits of the game.
--   * one point per gate; gates cannot be closer than ~1.2 s apart (spacingMin) -> score <= run_time / 1.15 + 2
--   * a run must last at least 0.9 s per point on average at the lowest difficulty  (very generous upper bound)
--   * rate limit: at most 1 submission every 4 seconds per user
create or replace function public.submit_score(p_mode text, p_score int, p_time real, p_gates int)
returns void language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); last_at timestamptz;
begin
  if uid is null then raise exception 'not authenticated'; end if;
  if p_mode not in ('classic','endless','hardcore','timeattack','bossrush','daily','adventure','zen') then raise exception 'bad mode'; end if;
  if p_score < 0 or p_score > 100000 or p_time <= 0 or p_gates < 0 then raise exception 'bad values'; end if;
  if p_score > p_time / 1.15 + 3 then raise exception 'implausible score'; end if;
  if p_gates < p_score / 3 then raise exception 'implausible gates'; end if;
  select max(created_at) into last_at from scores where user_id = uid;
  if last_at is not null and now() - last_at < interval '4 seconds' then raise exception 'rate limited'; end if;
  insert into scores(user_id, mode, score, run_time, gates) values (uid, p_mode, p_score, p_time, p_gates);
end $$;

create or replace function public.get_leaderboard(p_mode text, p_period text default 'all', p_limit int default 50)
returns table(rank bigint, user_id uuid, name text, avatar text, score int) language sql stable security definer set search_path = public as $$
  with best as (
    select s.user_id, max(s.score) as score from scores s
    where s.mode = p_mode and case p_period when 'day' then s.created_at > now() - interval '1 day' when 'week' then s.created_at > now() - interval '7 days' else true end
    group by s.user_id)
  select row_number() over (order by b.score desc, p.created_at asc) as rank, b.user_id, p.name, p.avatar, b.score
  from best b join profiles p on p.id = b.user_id order by b.score desc, p.created_at asc limit least(greatest(p_limit,1),100);
$$;

create or replace function public.add_friend(p_name text) returns void language plpgsql security definer set search_path = public as $$
declare fid uuid;
begin
  select id into fid from profiles where lower(name) = lower(p_name);
  if fid is null then raise exception 'player not found'; end if;
  if fid = auth.uid() then raise exception 'cannot add yourself'; end if;
  insert into friends(user_id, friend_id) values (auth.uid(), fid) on conflict do nothing;
end $$;

create or replace function public.get_friends() returns table(name text, avatar text, best int) language sql stable security definer set search_path = public as $$
  select p.name, p.avatar, coalesce((select max(score) from scores s where s.user_id = f.friend_id), 0)::int
  from friends f join profiles p on p.id = f.friend_id where f.user_id = auth.uid() order by 3 desc;
$$;

grant execute on function public.submit_score(text,int,real,int) to authenticated;
grant execute on function public.get_leaderboard(text,text,int) to anon, authenticated;
grant execute on function public.add_friend(text) to authenticated;
grant execute on function public.get_friends() to authenticated;
