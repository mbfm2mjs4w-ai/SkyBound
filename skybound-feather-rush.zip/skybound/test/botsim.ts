// Headless bot simulation used by tests: flies the real physics + collision against the real generator.
import { DEFAULT_TUNING, FIXED_DT, type Tuning } from '../src/config/gameConfig';
import { MODES, type ModeId } from '../src/data/modes';
import { WORLDS } from '../src/data/worlds';
import { ObstacleGenerator } from '../src/systems/ObstacleGenerator';
import { stepBird, applyFlap, type BirdBody } from '../src/systems/PhysicsSystem';
import { gateHitsCircle } from '../src/systems/CollisionSystem';
import { gapAt, type Gate } from '../src/entities/Obstacle';
import type { Pickup } from '../src/entities/Coin';
import { RNG } from '../src/core/util';

export interface BotOptions {
  seed: number; mode: ModeId; gates: number; startScore?: number; tuning?: Tuning;
  latencyFrames?: number;     // human-like reaction delay (60 Hz frames)
  skill?: number;             // 0..1: 1 = precise, lower = sloppier aim offset
  world?: string;
  kinds?: string[];
}
export interface BotResult { passed: number; died: boolean; reason: string; atGate?: Gate; minMargin: number; coins: number; stats: { maxDelta: number; minHalf: number } }

export function runBot(o: BotOptions): BotResult {
  const t = o.tuning ?? DEFAULT_TUNING;
  const mode = MODES[o.mode];
  const worldCycle = WORLDS.filter((w) => !w.hidden).map((w) => w.id);
  const gen = new ObstacleGenerator({
    tuning: t, mode, seed: o.seed, startWorld: o.world ?? worldCycle[o.seed % worldCycle.length], worldCycle,
    startScore: o.startScore ?? mode.startScore,
    kinds: o.kinds as never,
  });
  const birdX = 250;
  const body: BirdBody = { y: 420, prevY: 420, vy: 0, rot: 0 };
  const rng = new RNG(o.seed ^ 0x9e3779b9);
  const gates: Gate[] = [];
  const pickups: Pickup[] = [];
  let dist = 0, score = 0, coins = 0, frame = 0, queuedFlaps: number[] = [];
  let minMargin = 1e9;
  const r = t.birdRadius * t.hitboxScale;
  let maxDelta = 0, minHalf = 1e9, lastC = 420;
  const spawnAhead = (): void => {
    while (gates.length === 0 || gates[gates.length - 1].wx < dist + 1400) {
      const out = gen.next(score, birdX);
      out.gate.wx += gates.length === 0 ? dist : 0;
      gates.push(out.gate);
      for (const p of out.pickups) pickups.push(p);
    }
  };
  // generator positions are relative to 0; shift once so the first gate is ahead of the bird
  spawnAhead();
  const latency = o.latencyFrames ?? 3;
  const skill = o.skill ?? 1;
  let acc = 0;
  const aimBias = 42;
  let aimNoise = 0;
  const maxSteps = 120 * 60 * 60 * 6;
  for (let step = 0; step < maxSteps; step++) {
    frame++;
    const speed = gen.speedFor(score);
    // ---- bot decision at 60 Hz
    if (step % 2 === 0) {
      // target = next gate not yet cleared
      let tg: Gate | null = null;
      for (const g of gates) { if (g.wx + g.halfW + r + 6 > dist) { tg = g; break; } }
      if (tg) {
        const rel = tg.wx - dist;
        const gp = { center: 0, half: 0 };
        // aim at where the gap will be when we reach it (the bot knows the motion law, a human reads it visually)
        gapAt(tg, Math.max(0, rel - 0), gp);
        const cx = gapAt(tg, 0, { center: 0, half: 0 }).center;
        if (frame % 90 === 0) aimNoise = (rng.next() - 0.5) * 2 * (1 - skill) * 40;
        const aim = (rel > 330 ? cx : gp.center) + aimNoise;
        const tau = latency / 60;                      // the bot plans ahead by its own reaction time
        const yPred = body.y + body.vy * tau + 0.5 * t.gravity * tau * tau;
        if (yPred > aim + aimBias && body.vy > -80) queuedFlaps.push(step + latency * 2);
      }
    }
    if (queuedFlaps.length && queuedFlaps[0] <= step) { queuedFlaps.shift(); applyFlap(body, t); queuedFlaps = []; }

    // ---- physics
    stepBird(body, FIXED_DT, t);
    dist += speed * FIXED_DT;
    if (body.y < r) { body.y = r; if (body.vy < 0) body.vy = 0; }
    if (body.y + r > t.floorY) return { passed: score, died: true, reason: 'floor', minMargin, coins, stats: { maxDelta, minHalf } };

    spawnAhead();
    // ---- collisions
    for (const g of gates) {
      const rel = g.wx - dist;
      if (rel > 200 || rel < -200) continue;
      if (gateHitsCircle(g, rel, body.y, r)) return { passed: score, died: true, reason: 'gate ' + g.kind + ' motion=' + g.motion, atGate: g, minMargin, coins, stats: { maxDelta, minHalf } };
      if (Math.abs(rel) < 3) {
        const gp = gapAt(g, rel, { center: 0, half: 0 });
        minMargin = Math.min(minMargin, gp.half - Math.abs(body.y - gp.center) - r);
      }
      if (!g.passed && rel < -g.halfW - 4) {
        g.passed = true; score++;
        const gp = gapAt(g, 0, { center: 0, half: 0 });
        maxDelta = Math.max(maxDelta, Math.abs(gp.center - lastC)); lastC = gp.center;
        minHalf = Math.min(minHalf, gp.half);
        if (score >= o.gates) return { passed: score, died: false, reason: 'done', minMargin, coins, stats: { maxDelta, minHalf } };
      }
    }
    for (const p of pickups) {
      if (p.collected) continue;
      const dx = p.wx - dist, dy = p.y - body.y;
      if (dx * dx + dy * dy < (p.r + r) ** 2) { p.collected = true; if (p.kind === 'coin') coins++; }
    }
    // drop old
    while (gates.length > 6 && gates[0].wx < dist - 300) gates.shift();
    while (pickups.length > 80 && pickups[0].wx < dist - 300) pickups.shift();
    acc += FIXED_DT;
  }
  return { passed: score, died: false, reason: 'timeout', minMargin, coins, stats: { maxDelta, minHalf } };
}
