// Online layer (Supabase over plain REST/fetch, no SDK). Fully optional: when SUPABASE_URL / SUPABASE_ANON_KEY were not
// provided at build time the game runs 100% offline and the UI says so — there are NO fake leaderboards.
import { BUILD } from '../config/gameConfig';
import { Emitter } from '../core/events';
import type { SaveData } from '../systems/SaveManager';

export interface AuthSession { access_token: string; refresh_token: string; expires_at: number; user: { id: string; email?: string; is_anonymous?: boolean } }
export interface LeaderEntry { rank: number; name: string; avatar: string; score: number; me: boolean }
export interface FriendEntry { name: string; avatar: string; best: number }
export type NetResult<T> = { ok: true; data: T } | { ok: false; error: string };
const AUTH_KEY = 'skybound.auth';

export class NetworkManager {
  readonly ev = new Emitter<{ change: null; [k: string]: unknown }>();
  readonly configured: boolean;
  private url: string; private key: string;
  session: AuthSession | null = null;
  lastError: string | null = null;
  online = false;

  constructor() {
    this.url = (BUILD.supabaseUrl || '').replace(/\/+$/, ''); this.key = BUILD.supabaseKey || '';
    this.configured = !!(this.url && this.key);
    try { const raw = localStorage.getItem(AUTH_KEY); if (raw) this.session = JSON.parse(raw) as AuthSession; } catch { /* */ }
  }
  get signedIn(): boolean { return !!this.session; }
  get status(): 'unconfigured' | 'signedout' | 'online' | 'offline' { return !this.configured ? 'unconfigured' : this.session ? (this.online ? 'online' : 'offline') : 'signedout'; }

  private async call<T>(path: string, init: RequestInit & { auth?: boolean } = {}): Promise<NetResult<T>> {
    if (!this.configured) return { ok: false, error: 'not-configured' };
    const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 9000);
    try {
      const headers: Record<string, string> = { apikey: this.key, 'Content-Type': 'application/json', ...(init.headers as Record<string, string> | undefined) };
      headers.Authorization = `Bearer ${init.auth !== false && this.session ? this.session.access_token : this.key}`;
      const r = await fetch(this.url + path, { ...init, headers, signal: ctl.signal });
      const text = await r.text(); let json: unknown = null; try { json = text ? JSON.parse(text) : null; } catch { /* */ }
      if (!r.ok) { const msg = (json as { msg?: string; message?: string; error_description?: string } | null); this.online = r.status < 500; return { ok: false, error: msg?.msg || msg?.message || msg?.error_description || `HTTP ${r.status}` }; }
      this.online = true; return { ok: true, data: json as T };
    } catch (e) { this.online = false; return { ok: false, error: (e as Error).name === 'AbortError' ? 'timeout' : 'network' }; }
    finally { clearTimeout(to); this.ev.emit('change', null); }
  }
  private store(s: AuthSession | null): void { this.session = s; try { if (s) localStorage.setItem(AUTH_KEY, JSON.stringify(s)); else localStorage.removeItem(AUTH_KEY); } catch { /* */ } this.ev.emit('change', null); }
  private fromTokenResponse(j: { access_token?: string; refresh_token?: string; expires_in?: number; user?: AuthSession['user'] }): AuthSession | null {
    if (!j.access_token || !j.user) return null;
    return { access_token: j.access_token, refresh_token: j.refresh_token ?? '', expires_at: Math.floor(Date.now() / 1000) + (j.expires_in ?? 3600), user: j.user };
  }
  async init(): Promise<void> {
    if (!this.configured || !this.session) return;
    if (this.session.expires_at - 60 < Date.now() / 1000) await this.refresh();
    else this.online = true;
  }
  async refresh(): Promise<boolean> {
    if (!this.session?.refresh_token) return false;
    const r = await this.call<Parameters<NetworkManager['fromTokenResponse']>[0]>('/auth/v1/token?grant_type=refresh_token', { method: 'POST', body: JSON.stringify({ refresh_token: this.session.refresh_token }), auth: false });
    if (!r.ok) { if (r.error !== 'network' && r.error !== 'timeout') this.store(null); return false; }
    const s = this.fromTokenResponse(r.data); if (s) { this.store(s); return true; } return false;
  }
  async signUp(email: string, password: string): Promise<NetResult<null>> {
    const r = await this.call<Parameters<NetworkManager['fromTokenResponse']>[0]>('/auth/v1/signup', { method: 'POST', body: JSON.stringify({ email, password }), auth: false });
    if (!r.ok) return r; const s = this.fromTokenResponse(r.data); if (s) this.store(s); return { ok: true, data: null };
  }
  async signIn(email: string, password: string): Promise<NetResult<null>> {
    const r = await this.call<Parameters<NetworkManager['fromTokenResponse']>[0]>('/auth/v1/token?grant_type=password', { method: 'POST', body: JSON.stringify({ email, password }), auth: false });
    if (!r.ok) return r; const s = this.fromTokenResponse(r.data); if (!s) return { ok: false, error: 'bad-response' }; this.store(s); return { ok: true, data: null };
  }
  /** Anonymous sign-in (requires "Allow anonymous sign-ins" in the Supabase project). */
  async signInGuest(): Promise<NetResult<null>> {
    const r = await this.call<Parameters<NetworkManager['fromTokenResponse']>[0]>('/auth/v1/signup', { method: 'POST', body: JSON.stringify({ data: {} }), auth: false });
    if (!r.ok) return r; const s = this.fromTokenResponse(r.data); if (!s) return { ok: false, error: 'bad-response' }; this.store(s); return { ok: true, data: null };
  }
  signOut(): void { this.store(null); this.online = false; }

  async setProfile(name: string, avatar: string): Promise<NetResult<null>> {
    if (!this.session) return { ok: false, error: 'signed-out' };
    const r = await this.call<unknown>('/rest/v1/profiles?on_conflict=id', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }, body: JSON.stringify({ id: this.session.user.id, name, avatar }) });
    return r.ok ? { ok: true, data: null } : r;
  }
  /** Score submission goes through a SECURITY DEFINER RPC that rejects implausible runs (see supabase/schema.sql). */
  async submitScore(mode: string, score: number, runTime: number, gates: number): Promise<NetResult<null>> {
    if (!this.session) return { ok: false, error: 'signed-out' };
    const r = await this.call<unknown>('/rest/v1/rpc/submit_score', { method: 'POST', body: JSON.stringify({ p_mode: mode, p_score: score, p_time: runTime, p_gates: gates }) });
    return r.ok ? { ok: true, data: null } : r;
  }
  async leaderboard(mode: string, period: 'all' | 'week' | 'day', limit = 50): Promise<NetResult<LeaderEntry[]>> {
    const r = await this.call<{ rank: number; name: string; avatar: string; score: number; user_id: string }[]>('/rest/v1/rpc/get_leaderboard', { method: 'POST', body: JSON.stringify({ p_mode: mode, p_period: period, p_limit: limit }) });
    if (!r.ok) return r; const me = this.session?.user.id;
    return { ok: true, data: (r.data ?? []).map((e) => ({ rank: e.rank, name: e.name, avatar: e.avatar, score: e.score, me: e.user_id === me })) };
  }
  async friends(): Promise<NetResult<FriendEntry[]>> {
    const r = await this.call<{ name: string; avatar: string; best: number }[]>('/rest/v1/rpc/get_friends', { method: 'POST', body: '{}' });
    return r.ok ? { ok: true, data: r.data ?? [] } : r;
  }
  async addFriend(name: string): Promise<NetResult<null>> {
    const r = await this.call<unknown>('/rest/v1/rpc/add_friend', { method: 'POST', body: JSON.stringify({ p_name: name }) });
    return r.ok ? { ok: true, data: null } : r;
  }
  async pushSave(data: SaveData): Promise<NetResult<null>> {
    if (!this.session) return { ok: false, error: 'signed-out' };
    const r = await this.call<unknown>('/rest/v1/saves?on_conflict=user_id', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }, body: JSON.stringify({ user_id: this.session.user.id, data, updated_at: new Date().toISOString() }) });
    return r.ok ? { ok: true, data: null } : r;
  }
  async pullSave(): Promise<NetResult<{ data: SaveData; updated_at: string } | null>> {
    if (!this.session) return { ok: false, error: 'signed-out' };
    const r = await this.call<{ data: SaveData; updated_at: string }[]>(`/rest/v1/saves?user_id=eq.${this.session.user.id}&select=data,updated_at&limit=1`);
    return r.ok ? { ok: true, data: r.data?.[0] ?? null } : r;
  }
}
