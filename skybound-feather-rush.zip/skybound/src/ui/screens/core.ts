// Main menu, mode select, adventure map, game-over (with reward reveal) and pause screens.
import { h, icon, clear } from '../dom';
import { Scr, header, wallet } from './common';
import type { AppApi } from '../../app/types';
import type { Screen } from '../UI';
import { tr, loc, getLang } from '../../core/i18n';
import { formatNumber, formatTime, dateKey } from '../../core/util';
import { MODES, MODE_LIST, ADVENTURE_LEVELS, ADVENTURE_WORLDS, buildDaily, ADVENTURE_BY_ID } from '../../data/modes';
import { WORLD_BY_ID } from '../../data/worlds';
import { GAME_TITLE, SLOGAN } from '../../config/gameConfig';
import type { RunSummary } from '../../systems/ProgressionManager';
import type { RunResult } from '../../core/GameSession';
import { drawRewardBox, drawStarRating } from '../../render/PowerUpRenderer';
import { SKIN_BY_ID } from '../../data/skins';
import { missionText, MISSION_BY_ID } from '../../data/missions';
import { drawSkinPreview } from '../../render/BirdRenderer';
import { QUALITY } from '../../config/gameConfig';

// ---------------------------------------------------------------- main menu
export function mainMenu(app: AppApi): Screen {
  const s = new Scr('menu'), sv = app.save.data;
  const lp = app.prog.levelProgress();
  const claimable = [...sv.missions.daily, ...sv.missions.weekly].some((m) => m.progress >= m.target && !m.claimed);
  const lvl = h('div', { class: 'lvl glass' }, h('div', { class: 'badge' }, lp.level), h('div', { class: 'col', style: 'gap:.15rem' }, h('span', { style: 'font-size:.8rem' }, sv.profile.name), h('div', { class: 'bar' }, h('i', { style: `width:${Math.round(lp.frac * 100)}%` }))));
  const mute = h('button', { class: 'glass-btn quiet', 'aria-label': 'Mute', on: { click: () => { sv.settings.muted = !sv.settings.muted; app.applySettings(); app.save.touch(); app.audio.sfx('click'); redrawMute(); } } });
  const redrawMute = (): void => { clear(mute); mute.appendChild(icon(sv.settings.muted ? 'mute' : 'sound', 20)); };
  redrawMute();
  const top = h('div', { class: 'topbar' }, lvl, h('div', { class: 'sp' }), wallet(app, s), mute, h('button', { class: 'glass-btn', 'aria-label': 'Fullscreen', on: { click: () => app.toggleFullscreen() } }, icon('full', 20)));
  const tile = (ico: string, label: string, to: Parameters<AppApi['open']>[0], dot = false): HTMLElement => h('button', { class: 'tile', on: { click: () => app.open(to) } }, icon(ico, 26), h('span', {}, label), dot ? h('i', { class: 'dot' }) : null);
  const net = app.net.status;
  const left = h('div', { class: 'left' },
    h('div', { class: 'logo' }, h('b', {}, 'SKYBOUND'), h('span', {}, 'FEATHER RUSH ∞'), h('small', {}, SLOGAN)),
    h('button', { class: 'btn big', on: { click: () => app.open('play') } }, icon('play', 26), tr('CHƠI', 'PLAY')),
    h('div', { class: 'menu-grid' },
      tile('map', tr('PHIÊU LƯU', 'ADVENTURE'), 'adventure'), tile('globe', tr('THẾ GIỚI', 'WORLDS'), 'worlds'), tile('feather', tr('NHÂN VẬT', 'COLLECTION'), 'collection'),
      tile('bag', tr('CỬA HÀNG', 'SKIN SHOP'), 'shop'), tile('target', tr('NHIỆM VỤ', 'MISSIONS'), 'missions', claimable), tile('medal', tr('THÀNH TỰU', 'ACHIEVEMENTS'), 'achievements'),
      tile('chart', tr('XẾP HẠNG', 'LEADERBOARD'), 'leaderboard'), tile('user', tr('HỒ SƠ', 'PROFILE'), 'profile'), tile('gear', tr('CÀI ĐẶT', 'SETTINGS'), 'settings')),
    h('div', { class: 'muted', style: 'font-size:.72rem;display:flex;gap:.5rem;align-items:center' }, icon(net === 'online' ? 'cloud' : 'wifioff', 14), net === 'online' ? tr('Trực tuyến', 'Online') : net === 'unconfigured' ? tr('Chế độ ngoại tuyến — máy chủ online chưa được kết nối', 'Offline mode — online services not connected') : net === 'signedout' ? tr('Chưa đăng nhập online', 'Not signed in online') : tr('Mất kết nối máy chủ', 'Server unreachable'), h('span', {}, '· v1.0')));
  s.el.append(top, h('div', { class: 'menu-body' }, left, h('div', { class: 'grow' })));
  return s;
}

// ---------------------------------------------------------------- mode select
export function playScreen(app: AppApi): Screen {
  const s = new Scr(), sv = app.save.data, w = WORLD_BY_ID[sv.selectedWorld];
  const daily = buildDaily(dateKey());
  const worldBtn = h('button', { class: 'btn ghost small', on: { click: () => app.open('worlds') } }, icon('globe', 16), `${tr('Thế giới', 'World')}: ${w?.name ?? '—'}`);
  const grid = h('div', { class: 'grid wide' });
  for (const id of MODE_LIST) {
    const m = MODES[id];
    const extra = id === 'daily' ? `${tr('Hôm nay', 'Today')}: ${WORLD_BY_ID[daily.worldId]?.name} · ${daily.mods.map((x) => loc(x.name)).join(', ')} · ${tr('Mục tiêu', 'Goal')} ${daily.goal}${sv.daily.key === daily.key && sv.daily.done ? ' ✓' : ''}` : '';
    const best = m.scored ? `${tr('Kỷ lục', 'Best')}: ${formatNumber(sv.best[id] ?? 0)}` : id === 'zen' ? `${tr('Thời gian thiền', 'Zen time')}: ${formatTime(sv.stats.zenTime)}` : '';
    grid.appendChild(h('button', { class: 'card mode', on: { click: () => (id === 'adventure' ? app.open('adventure') : app.startRun({ mode: id })) } },
      h('div', { class: 'row' }, h('span', { class: 'em' }, m.icon), h('div', { class: 'col grow', style: 'gap:.15rem' }, h('h3', {}, loc(m.name)), h('span', { class: 'badge-best' }, best))),
      h('p', {}, loc(m.desc)), extra ? h('p', { style: 'color:var(--gold);font-weight:700' }, extra) : null));
  }
  s.el.append(header(app, s, tr('Chọn chế độ', 'Select mode'), () => app.open('menu'), worldBtn), h('div', { class: 'content' }, grid));
  return s;
}

// ---------------------------------------------------------------- adventure
export function adventureScreen(app: AppApi): Screen {
  const s = new Scr(), sv = app.save.data;
  const total = ADVENTURE_LEVELS.reduce((a, l) => a + (sv.adventure[l.id]?.stars ?? 0), 0);
  const body = h('div', { class: 'col', style: 'gap:1rem' });
  ADVENTURE_WORLDS.forEach((wid, c) => {
    const w = WORLD_BY_ID[wid]; const lvls = ADVENTURE_LEVELS.filter((l) => l.chapter === c);
    const grid = h('div', { class: 'lvlgrid' });
    for (const l of lvls) {
      const idx = ADVENTURE_LEVELS.indexOf(l), ok = app.prog.adventureUnlocked(idx), st = sv.adventure[l.id]?.stars ?? 0;
      grid.appendChild(h('button', { class: `lv${ok ? '' : ' locked'}`, disabled: !ok, on: { click: () => app.startRun({ mode: 'adventure', adventureId: l.id }) } },
        h('b', {}, loc(l.title)), h('div', { class: 'stars', style: 'transform:scale(.55);margin:-.4rem 0' }, [0, 1, 2].map((i) => h('span', { class: i < st ? '' : 'off' }, icon('star', 24)))),
        h('small', { class: 'muted' }, ok ? `${tr('Mục tiêu', 'Goal')}: ${l.goal} · ${l.coinGoal} ${tr('xu', 'coins')}` : tr('Đang khoá', 'Locked')), ok ? null : h('div', { class: 'lock' }, icon('lock', 24))));
    }
    body.appendChild(h('div', { class: 'card glass', style: 'gap:.5rem' }, h('div', { class: 'row sb' }, h('h3', {}, `${c + 1}. ${w.name}`), h('span', { class: 'muted' }, loc(w.tagline))), h('p', {}, loc(lvls[0].story)), grid));
  });
  s.el.append(header(app, s, `${tr('Phiêu lưu', 'Adventure')}  ★ ${total}/${ADVENTURE_LEVELS.length * 3}`, () => app.open('play')), h('div', { class: 'content' }, body));
  return s;
}

// ---------------------------------------------------------------- pause
export function pauseScreen(app: AppApi, o: { resume(): void; restart(): void; quit(): void; end(): void; canEnd: boolean }): Screen {
  const s = new Scr('pausebox'), sv = app.save.data;
  const slider = (label: string, key: 'music' | 'sfx'): HTMLElement => h('label', { class: 'field' }, h('label', {}, label), h('input', { type: 'range', min: 0, max: 100, value: Math.round(sv.settings[key] * 100), on: { input: (e: Event) => { sv.settings[key] = +(e.target as HTMLInputElement).value / 100; app.applySettings(); app.save.touch(); } } }));
  s.el.appendChild(h('div', { class: 'glass' },
    h('h2', {}, tr('TẠM DỪNG', 'PAUSED')),
    h('button', { class: 'btn', on: { click: o.resume } }, icon('play', 20), tr('Tiếp tục', 'Resume')),
    h('button', { class: 'btn blue', on: { click: o.restart } }, icon('retry', 20), tr('Chơi lại (R)', 'Restart (R)')),
    slider(tr('Nhạc nền', 'Music'), 'music'), slider(tr('Hiệu ứng', 'SFX'), 'sfx'),
    o.canEnd ? h('button', { class: 'btn gold', on: { click: o.end } }, icon('flag', 20), tr('Kết thúc & nhận thưởng', 'Finish & collect rewards')) : null,
    h('button', { class: 'btn ghost back', on: { click: o.quit } }, icon('home', 20), tr('Về menu', 'Main menu'))));
  return s;
}

// ---------------------------------------------------------------- game over / victory
export function gameOverScreen(app: AppApi, sum: RunSummary, res: RunResult, victory: boolean): Screen {
  const s = new Scr('over'), sv = app.save.data;
  const card = h('div', { class: 'over-card glass' });
  const mode = MODES[res.mode];
  const title = victory ? (res.mode === 'adventure' ? tr('HOÀN THÀNH!', 'LEVEL COMPLETE!') : tr('CHIẾN THẮNG!', 'VICTORY!')) : res.mode === 'timeattack' ? tr('HẾT GIỜ!', "TIME'S UP!") : res.mode === 'zen' ? tr('KẾT THÚC THIỀN', 'ZEN SESSION') : tr('KẾT THÚC', 'GAME OVER');
  card.appendChild(h('h1', {}, title));
  // reward reveal (canvas box that opens)
  const gotRewards = sum.coinsGained + sum.gemsGained + sum.xpGained > 0;
  let rafId = 0;
  if (gotRewards) {
    const cv = h('canvas', { width: 420, height: 300, style: 'width:11rem;height:8rem;margin:0 auto' });
    const g = cv.getContext('2d')!; const t0 = performance.now(); let opened = false;
    const loop = (now: number): void => {
      const t = (now - t0) / 1000, open = Math.min(1, Math.max(0, (t - 0.6) / 0.7));
      g.clearRect(0, 0, 420, 300); g.save(); g.translate(0, 0);
      drawRewardBox(g, 210, 190, 130, open, t, sum.achievements.length || sum.levelUps.length ? '#c27aff' : '#ffb347');
      g.restore();
      if (!opened && open >= 0.5) { opened = true; app.audio.sfx('rewardOpen'); }
      rafId = requestAnimationFrame(loop);
    };
    rafId = requestAnimationFrame(loop); s.on(() => cancelAnimationFrame(rafId));
    card.appendChild(h('div', { class: 'reveal' }, cv));
  }
  if (res.mode === 'adventure' && victory) card.appendChild(h('div', { class: 'stars' }, [0, 1, 2].map((i) => h('span', { class: i < sum.stars ? '' : 'off', style: `animation-delay:${0.3 + i * 0.25}s` }, icon('star', 40)))));
  if (mode.scored) {
    card.appendChild(h('div', { class: 'big-score' }, formatNumber(res.score)));
    card.appendChild(h('div', { class: 'muted' }, `${tr('Kỷ lục', 'Best')}: ${formatNumber(Math.max(sum.previousBest, res.score))}`));
    if (sum.newBest) card.appendChild(h('div', {}, h('span', { class: 'newrec' }, tr('KỶ LỤC MỚI!', 'NEW RECORD!'))));
  } else card.appendChild(h('div', { class: 'big-score' }, formatTime(res.time)));
  card.appendChild(h('div', { class: 'stat-row' },
    h('div', { class: 'stat' }, h('b', {}, `+${formatNumber(sum.coinsGained)}`), h('small', {}, tr('Xu', 'Coins'))),
    h('div', { class: 'stat' }, h('b', {}, `+${formatNumber(sum.gemsGained)}`), h('small', {}, tr('Ngọc', 'Gems'))),
    h('div', { class: 'stat' }, h('b', {}, `+${formatNumber(sum.xpGained)}`), h('small', {}, 'XP')),
    h('div', { class: 'stat' }, h('b', {}, formatNumber(res.gates)), h('small', {}, tr('Cổng', 'Gates'))),
    h('div', { class: 'stat' }, h('b', {}, `x${res.maxCombo}`), h('small', {}, 'Combo')),
    h('div', { class: 'stat' }, h('b', {}, `${res.distance}m`), h('small', {}, tr('Quãng đường', 'Distance')))));
  // level bar
  const lp = app.prog.levelProgress();
  const bar = h('i', { style: `width:${Math.round((sum.levelBefore === sum.levelAfter ? sum.xpBefore / Math.max(1, lp.need) : 0) * 100)}%` });
  card.appendChild(h('div', { class: 'col', style: 'gap:.25rem' }, h('div', { class: 'row sb' }, h('b', {}, `${tr('Cấp', 'Level')} ${lp.level}`), h('small', { class: 'muted' }, `${lp.xp}/${lp.need} XP`)), h('div', { class: 'bar' }, bar)));
  setTimeout(() => { bar.style.width = `${Math.round(lp.frac * 100)}%`; }, 500);
  const list = h('div', { class: 'list' });
  for (const u of sum.levelUps) list.appendChild(h('div', { class: 'item' }, icon('bolt', 20), h('b', {}, `${tr('LÊN CẤP', 'LEVEL UP')} ${u.level}`), h('span', { class: 'muted' }, `+${u.reward.coins} ${tr('xu', 'coins')}${u.reward.gems ? ` +${u.reward.gems} ${tr('ngọc', 'gems')}` : ''}`)));
  for (const a of sum.achievements) list.appendChild(h('div', { class: 'item' }, icon('medal', 20), h('div', { class: 'col grow', style: 'gap:0' }, h('b', {}, loc(a.name)), h('small', { class: 'muted' }, loc(a.desc))), h('span', { class: `tag ${a.rarity}` }, a.rarity)));
  for (const m of sum.missionsDone) list.appendChild(h('div', { class: 'item' }, icon('target', 20), h('span', { class: 'grow' }, m.text), h('span', { class: 'tag ok' }, tr('Xong', 'Done')), ));
  for (const u of sum.unlocked) list.appendChild(h('div', { class: 'item' }, icon('lock', 20), h('b', {}, u.kind === 'skin' ? `${tr('Mở khoá nhân vật', 'Unlocked skin')}: ${SKIN_BY_ID[u.id]?.name}` : `${tr('Mở khoá thế giới', 'Unlocked world')}: ${WORLD_BY_ID[u.id]?.name}`)));
  if (list.children.length) card.appendChild(list);
  if (res.secretFound) card.appendChild(h('div', { class: 'notice' }, icon('star', 18), tr('Bạn đã tìm thấy một Cổng Bí Mật!', 'You found a Secret Portal!')));
  // online submit status
  if (mode.scored && res.score > 0 && app.net.configured) {
    const st = h('small', { class: 'muted' }, tr('Đang gửi điểm lên bảng xếp hạng…', 'Submitting score to the leaderboard…'));
    card.appendChild(st);
    if (!app.net.signedIn) st.textContent = tr('Đăng nhập trong Hồ sơ để lên bảng xếp hạng online.', 'Sign in from Profile to rank online.');
    else void app.net.submitScore(res.mode, res.score, res.time, res.gates).then((r) => { st.textContent = r.ok ? tr('Đã gửi điểm lên bảng xếp hạng!', 'Score submitted to the leaderboard!') : `${tr('Không gửi được điểm', 'Could not submit score')}: ${r.error}`; });
  }
  const next = res.adventureId && victory ? (() => { const i = ADVENTURE_LEVELS.findIndex((l) => l.id === res.adventureId); return ADVENTURE_LEVELS[i + 1]; })() : null;
  const share = (): void => {
    const text = `${tr('Mình đạt', 'I scored')} ${res.score} ${tr('điểm trong', 'in')} ${GAME_TITLE}!`;
    const nav = navigator as Navigator & { share?: (d: { text: string }) => Promise<void> };
    if (nav.share) void nav.share({ text }).catch(() => {}); else { void navigator.clipboard?.writeText(text).then(() => app.ui.toast(tr('Đã sao chép!', 'Copied!'), 'ok')).catch(() => {}); }
  };
  card.appendChild(h('div', { class: 'row wrap actions', style: 'justify-content:center;gap:.6rem' },
    next ? h('button', { class: 'btn gold', on: { click: () => app.startRun({ mode: 'adventure', adventureId: next.id }) } }, icon('play', 20), tr('Màn tiếp', 'Next level')) : null,
    h('button', { class: 'btn', on: { click: () => app.lastRun && app.startRun(app.lastRun) } }, icon('retry', 20), tr('Chơi lại', 'Retry')),
    h('button', { class: 'btn blue', on: { click: () => app.open(res.mode === 'adventure' ? 'adventure' : 'play') } }, icon('swords', 20), tr('Chế độ', 'Modes')),
    h('button', { class: 'glass-btn', 'aria-label': 'Share', on: { click: share } }, icon('share', 20)),
    h('button', { class: 'glass-btn back', 'aria-label': 'Menu', on: { click: () => app.open('menu') } }, icon('home', 20))));
  s.el.appendChild(card);
  void sv; void getLang; void drawStarRating; void missionText; void MISSION_BY_ID; void drawSkinPreview; void QUALITY; void ADVENTURE_BY_ID; void header;
  return s;
}
