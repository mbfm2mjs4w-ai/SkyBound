import type { BirdPose, BirdState, QualityProfile } from '../core/types';
import { clamp, hslToHex, lerp, mixHex, rgba, shadeHex, TAU } from '../core/util';
import type { CosmeticItemId } from '../data/cosmetics';
import type { SkinDef, SkinColors, WingStyle, TailStyle, CrestStyle } from '../data/skins';
import { drawGlow, softShadow, starPath, type Ctx } from './gfx';

export interface DrawBirdOpts { item?: CosmeticItemId | null; quality: QualityProfile }

const OUTLINE = 'rgba(20,10,40,0.28)';

// ------------------------------------------------------------------ feather shapes (pointing along +x from the origin)
function featherPath(c: Ctx, style: WingStyle, L: number, W: number, t: number): void {
  c.beginPath();
  switch (style) {
    case 'crystal': {
      c.moveTo(0, 0); c.lineTo(L * 0.45, -W); c.lineTo(L, 0); c.lineTo(L * 0.45, W); c.closePath(); break;
    }
    case 'flame': {
      const k = Math.sin(t * 9 + L) * W * 0.35;
      c.moveTo(0, -W * 0.5);
      c.bezierCurveTo(L * 0.3, -W * 1.1, L * 0.6, -W * 0.3 + k, L, k * 0.6);
      c.bezierCurveTo(L * 0.65, W * 0.2 - k, L * 0.35, W * 1.1, 0, W * 0.5);
      c.closePath(); break;
    }
    case 'electric': {
      c.moveTo(0, -W * 0.25);
      c.lineTo(L * 0.3, -W * 0.55); c.lineTo(L * 0.26, -W * 0.05); c.lineTo(L * 0.62, -W * 0.4); c.lineTo(L * 0.55, W * 0.05); c.lineTo(L, 0);
      c.lineTo(L * 0.5, W * 0.45); c.lineTo(L * 0.5, W * 0.05); c.lineTo(L * 0.2, W * 0.5); c.lineTo(0, W * 0.25);
      c.closePath(); break;
    }
    case 'petal': {
      c.moveTo(0, 0); c.bezierCurveTo(L * 0.1, -W * 1.5, L * 0.95, -W * 1.2, L, -W * 0.1);
      c.quadraticCurveTo(L * 0.92, 0, L, W * 0.1); c.bezierCurveTo(L * 0.95, W * 1.2, L * 0.1, W * 1.5, 0, 0); c.closePath(); break;
    }
    case 'leaf': {
      c.moveTo(0, 0); c.bezierCurveTo(L * 0.3, -W * 1.2, L * 0.75, -W * 0.9, L, 0); c.bezierCurveTo(L * 0.75, W * 0.9, L * 0.3, W * 1.2, 0, 0); c.closePath(); break;
    }
    case 'bat': {
      c.moveTo(0, -W * 0.2); c.lineTo(L, -W * 0.1); c.quadraticCurveTo(L * 0.7, W * 0.5, L * 0.78, W * 1.1); c.lineTo(0, W * 0.4); c.closePath(); break;
    }
    default: { // feather, star, ethereal
      c.moveTo(0, 0); c.bezierCurveTo(L * 0.2, -W * 1.05, L * 0.8, -W * 0.95, L, -W * 0.05);
      c.bezierCurveTo(L * 0.8, W * 0.95, L * 0.2, W * 1.05, 0, 0); c.closePath();
    }
  }
}

interface Pal { body: string; body2: string; belly: string; wing: string; wing2: string; tail: string; beak: string; eye: string; accent: string; glow: string }

function palette(skin: SkinDef, pose: BirdPose): Pal {
  const k = skin.colors;
  let p: Pal = { body: k.body, body2: k.body2, belly: k.belly, wing: k.wing, wing2: k.wing2, tail: k.tail, beak: k.beak, eye: k.eye, accent: k.accent, glow: k.glow };
  if (skin.rainbow) {
    const h = (pose.t * 70) % 360;
    p = { ...p, body: hslToHex(h, 85, 66), body2: hslToHex(h + 50, 80, 55), wing: hslToHex(h + 120, 85, 62), wing2: hslToHex(h + 180, 90, 75), tail: hslToHex(h + 240, 80, 62), glow: hslToHex(h + 20, 90, 75) };
  }
  if (pose.ghost) {
    const g = (c: string): string => mixHex(c, '#cfefff', 0.55);
    p = { ...p, body: g(p.body), body2: g(p.body2), belly: '#ffffff', wing: g(p.wing), wing2: g(p.wing2), tail: g(p.tail), glow: '#bfeaff' };
  }
  if (pose.hurt > 0.01) {
    const h = pose.hurt * 0.65;
    const m = (c: string): string => mixHex(c, (Math.floor(pose.t * 30) % 2) ? '#ffffff' : '#ff3a3a', h);
    p = { ...p, body: m(p.body), body2: m(p.body2), wing: m(p.wing), wing2: m(p.wing2), tail: m(p.tail), belly: m(p.belly) };
  }
  return p;
}

// ------------------------------------------------------------------ wings
function wingAngle(w: number, amp: number, glide: number): number {
  // 0 = wings up, 0.5 = wings down. angle measured from straight-back (π): + = up
  return Math.PI + glide + amp * Math.cos(w * TAU);
}

function drawWing(c: Ctx, skin: SkinDef, p: Pal, pose: BirdPose, far: boolean, sx: number, sy: number, open: number): void {
  const n = skin.wingLayers + 2;
  const amp = (0.55 + 0.75 * clamp(pose.wingPower, 0, 1.2)) * skin.anim.flapAmp * (pose.state === 'boost' ? 0.2 : 1);
  let glide = 0.15;
  if (pose.state === 'falling') glide = 0.55 + 0.1 * Math.sin(pose.t * 18);
  if (pose.state === 'boost') glide = 0.15;
  if (pose.state === 'death') glide = -0.25;
  if (pose.state === 'victory') glide = 0.5;
  const style = skin.wing;
  const baseAmp = pose.state === 'death' ? 0.05 : pose.state === 'falling' ? 0.25 + 0.2 * pose.wingPower : amp;
  const phase = pose.flapPhase + (far ? 0.07 : 0);
  const alpha = style === 'ethereal' ? 0.72 : 1;
  c.save();
  c.translate(sx, sy);
  if (style === 'bat') {
    // membrane: fingers + scalloped skin
    const a0 = wingAngle(phase, baseAmp, glide), a1 = wingAngle(phase - 0.1, baseAmp * 1.05, glide + 0.1), a2 = wingAngle(phase - 0.2, baseAmp * 1.1, glide + 0.2);
    const R = 40 * open;
    const pts: [number, number][] = [[Math.cos(a0) * R * 0.7, Math.sin(a0) * R * 0.7], [Math.cos(a1) * R, Math.sin(a1) * R], [Math.cos(a2) * R * 0.95, Math.sin(a2) * R * 0.95], [Math.cos(a2 + 0.35) * R * 0.5, Math.sin(a2 + 0.35) * R * 0.5]];
    c.fillStyle = far ? shadeHex(p.wing, -0.35) : p.wing;
    c.beginPath(); c.moveTo(0, 0);
    for (let i = 0; i < pts.length; i++) {
      const [x, y] = pts[i]; const [px, py] = i ? pts[i - 1] : [0, 0];
      c.quadraticCurveTo((x + px) / 2 * 0.8, (y + py) / 2 * 0.8 + 4, x, y);
    }
    c.closePath(); c.fill(); c.strokeStyle = OUTLINE; c.lineWidth = 1.2; c.stroke();
    c.strokeStyle = p.wing2; c.lineWidth = 2.2; c.lineCap = 'round';
    for (const [x, y] of pts.slice(0, 3)) { c.beginPath(); c.moveTo(0, 0); c.lineTo(x, y); c.stroke(); }
    c.restore(); return;
  }
  for (let i = n - 1; i >= 0; i--) {
    const f = i / (n - 1);
    const a = wingAngle(phase - 0.045 * i, baseAmp, glide) + (i - n / 2) * 0.05;
    const dist = 3 + 2.3 * i;
    const L = (13 + f * 28) * open;
    const W = 5.2 + f * 2.4;
    c.save();
    c.translate(Math.cos(a) * dist, Math.sin(a) * dist);
    c.rotate(a);
    c.globalAlpha *= alpha;
    featherPath(c, style, L, W, pose.t);
    const col = far ? shadeHex(mixHex(p.wing, p.wing2, f * 0.5), -0.32) : mixHex(p.wing, p.wing2, f * 0.55);
    c.fillStyle = col; c.fill();
    c.strokeStyle = OUTLINE; c.lineWidth = 1.1; c.stroke();
    if (!far) { // highlight stripe along the shaft
      c.strokeStyle = rgba(p.wing2, 0.55); c.lineWidth = 1.4; c.beginPath(); c.moveTo(L * 0.12, 0); c.lineTo(L * 0.82, 0); c.stroke();
    }
    if (style === 'star' && !far && i % 2 === 0) { c.fillStyle = rgba('#ffffff', 0.9); starPath(c, L * 0.62, 0, 2.4, 1, 4, pose.t); c.fill(); }
    c.restore();
  }
  c.restore();
}

// ------------------------------------------------------------------ tail
function drawTail(c: Ctx, skin: SkinDef, p: Pal, pose: BirdPose): void {
  const t = pose.t;
  const wag = Math.sin(t * 5 + 1) * 0.08 + clamp(pose.vy / 1500, -0.4, 0.4) * 0.5;
  c.save();
  c.translate(-19, 4);
  c.rotate(Math.PI + wag - 0.15);
  const col = p.tail;
  const leaf = (L: number, W: number, ang: number, color: string, style: WingStyle = 'feather'): void => {
    c.save(); c.rotate(ang); featherPath(c, style, L, W, t); c.fillStyle = color; c.fill(); c.strokeStyle = OUTLINE; c.lineWidth = 1.1; c.stroke(); c.restore();
  };
  const st: TailStyle = skin.tail;
  switch (st) {
    case 'fan': for (let i = -2; i <= 2; i++) leaf(26 - Math.abs(i) * 3, 6, i * 0.28 + wag, mixHex(col, p.wing2, Math.abs(i) * 0.12)); break;
    case 'split':
      leaf(30, 4.2, -0.3 + wag, col); leaf(30, 4.2, 0.3 + wag, col); leaf(22, 5, 0, mixHex(col, p.wing2, 0.3)); break;
    case 'ribbon': {
      c.strokeStyle = col; c.lineWidth = 7; c.lineCap = 'round';
      for (let k = 0; k < 2; k++) {
        c.strokeStyle = k ? mixHex(col, p.wing2, 0.5) : col; c.lineWidth = k ? 3.5 : 7;
        c.beginPath(); c.moveTo(0, 0);
        for (let s = 1; s <= 12; s++) c.lineTo(s * 3.4, Math.sin(t * 6 - s * 0.6 + k) * (2 + s * 0.6));
        c.stroke();
      }
      break;
    }
    case 'peacock':
      for (let i = -2; i <= 2; i++) {
        const a = i * 0.24 + wag; const L = 36 - Math.abs(i) * 2;
        leaf(L, 4, a, col);
        c.save(); c.rotate(a); c.translate(L * 0.82, 0);
        c.fillStyle = p.wing2; c.beginPath(); c.ellipse(0, 0, 6, 4.5, 0, 0, TAU); c.fill();
        c.fillStyle = p.body; c.beginPath(); c.ellipse(0, 0, 3.8, 2.8, 0, 0, TAU); c.fill();
        c.fillStyle = p.accent; c.beginPath(); c.arc(0, 0, 1.4, 0, TAU); c.fill(); c.restore();
      }
      break;
    case 'flame': for (let i = -2; i <= 2; i++) leaf(26 - Math.abs(i) * 3, 7, i * 0.3 + wag, mixHex(col, p.accent, Math.abs(i) * 0.2), 'flame'); break;
    case 'crystal': for (let i = -1; i <= 1; i++) leaf(26 - Math.abs(i) * 5, 7, i * 0.38 + wag, mixHex(col, '#ffffff', 0.15 * (i + 1)), 'crystal'); break;
    case 'comet': {
      const g = c.createLinearGradient(0, 0, 44, 0);
      g.addColorStop(0, col); g.addColorStop(1, rgba(col, 0));
      c.fillStyle = g; c.beginPath(); c.moveTo(0, -8); c.quadraticCurveTo(24, -4 + wag * 20, 46, 0); c.quadraticCurveTo(24, 4 + wag * 20, 0, 8); c.closePath(); c.fill();
      c.fillStyle = rgba(p.accent, 0.9);
      for (let i = 0; i < 4; i++) { const x = 10 + i * 9 + ((t * 20) % 9); c.beginPath(); c.arc(x, Math.sin(t * 4 + i * 2) * 4, 1.5 - i * 0.2, 0, TAU); c.fill(); }
      break;
    }
    case 'dragon': {
      c.strokeStyle = col; c.lineCap = 'round'; c.lineWidth = 8;
      c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(18, Math.sin(t * 4) * 6, 34, Math.sin(t * 4 + 1) * 8); c.stroke();
      c.fillStyle = p.wing2; c.save(); c.translate(34, Math.sin(t * 4 + 1) * 8); c.rotate(0.1);
      c.beginPath(); c.moveTo(0, 0); c.lineTo(10, -9); c.lineTo(8, 0); c.lineTo(10, 9); c.closePath(); c.fill(); c.strokeStyle = OUTLINE; c.lineWidth = 1; c.stroke(); c.restore();
      break;
    }
    case 'halo': {
      for (let i = -2; i <= 2; i++) leaf(24 - Math.abs(i) * 3, 5, i * 0.25 + wag, rgba(col, 0.85));
      c.strokeStyle = rgba(p.accent, 0.8); c.lineWidth = 2; c.beginPath(); c.ellipse(26, 0, 5, 12, 0, 0, TAU); c.stroke();
      break;
    }
  }
  c.restore();
}

// ------------------------------------------------------------------ crest
function drawCrest(c: Ctx, style: CrestStyle, p: Pal, pose: BirdPose, topY: number): void {
  if (style === 'none') return;
  const t = pose.t;
  const sway = Math.sin(t * 3) * 0.06 - clamp(pose.vy / 1800, -0.3, 0.3);
  c.save(); c.translate(5, topY + 2); c.rotate(sway);
  const f = (color: string): void => { c.fillStyle = color; c.fill(); c.strokeStyle = OUTLINE; c.lineWidth = 1; c.stroke(); };
  switch (style) {
    case 'tuft': for (let i = -1; i <= 1; i++) { c.save(); c.rotate(-Math.PI / 2 + i * 0.5 + sway); featherPath(c, 'feather', 15 - Math.abs(i) * 3, 4.5, t); f(mixHex(p.body, p.accent, 0.25)); c.restore(); } break;
    case 'spike': for (let i = -1; i <= 1; i++) { c.save(); c.rotate(-Math.PI / 2 + i * 0.45); featherPath(c, 'crystal', 17 - Math.abs(i) * 3, 4, t); f(i === 0 ? p.accent : p.wing2); c.restore(); } break;
    case 'plume':
      c.strokeStyle = p.wing; c.lineWidth = 2.6; c.lineCap = 'round';
      for (let i = -1; i <= 1; i++) { c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(-8 + i * 7, -16, -4 + i * 12 + sway * 30, -24 - (1 - Math.abs(i)) * 4); c.stroke(); c.fillStyle = i === 0 ? p.accent : p.wing2; c.beginPath(); c.arc(-4 + i * 12 + sway * 30, -24 - (1 - Math.abs(i)) * 4, 3.6, 0, TAU); c.fill(); }
      break;
    case 'crown': {
      c.beginPath(); c.moveTo(-10, 0); c.lineTo(-11, -13); c.lineTo(-5, -7); c.lineTo(0, -16); c.lineTo(5, -7); c.lineTo(11, -13); c.lineTo(10, 0); c.closePath(); f('#ffd23f');
      c.fillStyle = '#ff4a6a'; c.beginPath(); c.arc(0, -5, 2.4, 0, TAU); c.fill(); break;
    }
    case 'horns':
      for (const s of [-1, 1]) { c.beginPath(); c.moveTo(s * 5, 2); c.quadraticCurveTo(s * 14, -4, s * 11, -17); c.quadraticCurveTo(s * 7, -7, s * 2, -1); c.closePath(); f(p.accent); }
      break;
    case 'flame':
      for (let i = -1; i <= 1; i++) { c.save(); c.rotate(-Math.PI / 2 + i * 0.4); featherPath(c, 'flame', 18 - Math.abs(i) * 4, 6, t + i); f(i === 0 ? '#fff3a0' : p.accent); c.restore(); }
      break;
    case 'halo':
      c.strokeStyle = rgba('#fff2a0', 0.95); c.lineWidth = 3; c.beginPath(); c.ellipse(-2, -12 + Math.sin(t * 3) * 1.5, 13, 4.5, 0, 0, TAU); c.stroke();
      c.strokeStyle = rgba('#ffffff', 0.7); c.lineWidth = 1; c.stroke();
      break;
    case 'antenna':
      c.strokeStyle = p.accent; c.lineWidth = 2; c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(-6, -12, -2 + sway * 20, -20); c.stroke();
      c.fillStyle = p.glow; c.beginPath(); c.arc(-2 + sway * 20, -21, 3.2 + Math.sin(t * 6) * 0.6, 0, TAU); c.fill(); break;
    case 'petal':
      for (let i = -1; i <= 1; i++) { c.save(); c.rotate(-Math.PI / 2 + i * 0.7); featherPath(c, 'petal', 12, 4.4, t); f(i === 0 ? '#ffffff' : p.wing2); c.restore(); }
      c.fillStyle = '#ffe27a'; c.beginPath(); c.arc(0, -1, 2, 0, TAU); c.fill(); break;
    case 'moonhorn':
      c.beginPath(); c.arc(1, -10, 9, Math.PI * 0.15, Math.PI * 1.6); c.arc(4, -9, 6.6, Math.PI * 1.55, Math.PI * 0.2, true); c.closePath(); f(p.accent); break;
  }
  c.restore();
}

// ------------------------------------------------------------------ items
function drawItem(c: Ctx, item: CosmeticItemId, p: Pal, pose: BirdPose, topY: number, ex: number, ey: number): void {
  c.save();
  switch (item) {
    case 'sunglasses':
      c.fillStyle = '#10121c'; c.beginPath(); c.roundRect?.(ex - 9, ey - 6, 19, 11, 4); if (!c.roundRect) c.rect(ex - 9, ey - 6, 19, 11); c.fill();
      c.strokeStyle = '#2c2f48'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(ex - 9, ey - 2); c.lineTo(-18, ey - 3); c.stroke();
      c.fillStyle = 'rgba(255,255,255,0.45)'; c.beginPath(); c.moveTo(ex - 5, ey - 4); c.lineTo(ex - 1, ey - 4); c.lineTo(ex - 5, ey + 2); c.closePath(); c.fill(); break;
    case 'crown': c.translate(3, topY + 3); c.rotate(-0.1); c.beginPath(); c.moveTo(-10, 0); c.lineTo(-11, -13); c.lineTo(-5, -7); c.lineTo(0, -16); c.lineTo(5, -7); c.lineTo(11, -13); c.lineTo(10, 0); c.closePath(); c.fillStyle = '#ffd23f'; c.fill(); c.strokeStyle = '#b8860b'; c.lineWidth = 1.2; c.stroke(); c.fillStyle = '#ff4a6a'; c.beginPath(); c.arc(0, -5, 2.4, 0, TAU); c.fill(); break;
    case 'halo': c.strokeStyle = '#fff2a0'; c.lineWidth = 3; c.beginPath(); c.ellipse(2, topY - 8 + Math.sin(pose.t * 3) * 1.5, 14, 4.5, 0, 0, TAU); c.stroke(); break;
    case 'scarf': c.strokeStyle = '#ff4a5e'; c.lineWidth = 7; c.lineCap = 'round'; c.beginPath(); c.moveTo(-8, 10); c.quadraticCurveTo(4, 17, 14, 8); c.stroke();
      c.lineWidth = 5; c.beginPath(); c.moveTo(-8, 11); for (let s = 1; s <= 6; s++) c.lineTo(-8 - s * 3.5, 11 + Math.sin(pose.t * 9 - s) * 3 + s * 0.5); c.stroke(); break;
    case 'wizard_hat': c.translate(3, topY + 4); c.rotate(-0.25); c.fillStyle = '#5b3cc4'; c.beginPath(); c.moveTo(-14, 0); c.lineTo(0, -30); c.lineTo(14, 0); c.closePath(); c.fill(); c.strokeStyle = OUTLINE; c.lineWidth = 1; c.stroke();
      c.fillStyle = '#7d5bff'; c.beginPath(); c.ellipse(0, 0, 19, 4.5, 0, 0, TAU); c.fill(); c.stroke(); c.fillStyle = '#ffe27a'; starPath(c, 1, -14, 3.6, 1.6, 5); c.fill(); break;
    case 'headphones': c.strokeStyle = '#2a2d44'; c.lineWidth = 3.4; c.beginPath(); c.arc(0, -2, 19, Math.PI * 1.15, Math.PI * 1.9); c.stroke(); c.fillStyle = '#ff3d7a'; c.beginPath(); c.ellipse(-2, 0, 5, 7, 0, 0, TAU); c.fill(); c.strokeStyle = '#2a2d44'; c.lineWidth = 1.5; c.stroke(); break;
  }
  c.restore();
}

// ------------------------------------------------------------------ main
export function drawBird(ctx: Ctx, skin: SkinDef, pose: BirdPose, opts: DrawBirdOpts): void {
  if (pose.alpha <= 0.01) return;
  const q = opts.quality;
  const p = palette(skin, pose);
  const bodyStyle = skin.body;
  const rx = bodyStyle === 'sleek' ? 24.5 : bodyStyle === 'plump' ? 23.5 : 22;
  const ry = bodyStyle === 'sleek' ? 18.5 : bodyStyle === 'plump' ? 23 : 21;
  const topY = -ry + 1;
  const eyeX = rx * 0.38, eyeY = -ry * 0.22;
  const stretch = pose.squash;
  const open = pose.state === 'boost' ? 0.8 : pose.state === 'death' ? 0.7 : 1;

  ctx.save();
  ctx.globalAlpha *= clamp(pose.alpha, 0, 1) * (pose.ghost ? 0.62 : 1);
  ctx.translate(pose.x, pose.y);
  ctx.rotate(pose.rot);
  ctx.scale(pose.scale * (1 - stretch * 0.35), pose.scale * (1 + stretch * 0.5));

  // aura
  if (q.bloom || pose.glow > 0.05) {
    const g = 0.18 + pose.glow * 0.6 + (skin.tier !== 'standard' ? 0.1 : 0);
    drawGlow(ctx, 0, 0, 58 + pose.glow * 30, p.glow, g);
  }
  if (pose.state === 'boost') { // speed lines
    ctx.strokeStyle = rgba(p.glow, 0.55 * pose.glow); ctx.lineWidth = 2.4; ctx.lineCap = 'round';
    for (let i = 0; i < 4; i++) { const y = -16 + i * 11, l = 28 + ((pose.t * 260 + i * 37) % 40); ctx.beginPath(); ctx.moveTo(-26, y); ctx.lineTo(-26 - l, y); ctx.stroke(); }
  }

  // tail + far wing (behind the body)
  drawTail(ctx, skin, p, pose);
  drawWing(ctx, skin, p, pose, true, -3, -1, open);

  // body
  const g = ctx.createRadialGradient(-rx * 0.25, -ry * 0.45, 2, 0, 0, Math.max(rx, ry) * 1.15);
  g.addColorStop(0, shadeHex(p.body, 0.25)); g.addColorStop(0.55, p.body); g.addColorStop(1, p.body2);
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.ellipse(0, 0, rx, ry, 0, 0, TAU); ctx.fill();
  ctx.strokeStyle = OUTLINE; ctx.lineWidth = 1.6; ctx.stroke();
  // belly patch
  ctx.fillStyle = p.belly; ctx.globalAlpha *= 0.92;
  ctx.beginPath(); ctx.ellipse(rx * 0.12, ry * 0.4, rx * 0.62, ry * 0.5, 0.1, 0, TAU); ctx.fill();
  ctx.globalAlpha /= 0.92;
  // rim light
  ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(0, 0, rx - 1.5, ry - 1.5, 0, -Math.PI * 0.9, -Math.PI * 0.25); ctx.stroke();

  drawCrest(ctx, skin.crest, p, pose, topY);

  // cheek
  ctx.fillStyle = 'rgba(255,110,150,0.35)'; ctx.beginPath(); ctx.ellipse(eyeX + 3, eyeY + 9, 4.2, 2.8, 0, 0, TAU); ctx.fill();

  // beak
  const gape = pose.state === 'damage' || pose.hurt > 0.3 ? 5 : pose.state === 'falling' ? 3.5 : pose.wingPower > 0.7 ? 2 : 0;
  const bx = rx - 3, by = eyeY + 9;
  ctx.fillStyle = shadeHex(p.beak, -0.12);
  ctx.beginPath(); ctx.moveTo(bx - 3, by + 1); ctx.lineTo(bx + 11, by + 2 + gape * 0.5); ctx.lineTo(bx - 3, by + 6 + gape); ctx.closePath(); ctx.fill(); ctx.strokeStyle = OUTLINE; ctx.lineWidth = 1; ctx.stroke();
  ctx.fillStyle = p.beak;
  ctx.beginPath(); ctx.moveTo(bx - 3, by - 5); ctx.quadraticCurveTo(bx + 7, by - 4, bx + 12, by + 1 - gape * 0.2); ctx.lineTo(bx - 3, by + 2 - gape * 0.4); ctx.closePath(); ctx.fill(); ctx.stroke();

  // eye
  drawEye(ctx, p, pose, eyeX, eyeY, opts.item === 'sunglasses');
  if (opts.item === 'sunglasses') drawItem(ctx, 'sunglasses', p, pose, topY, eyeX, eyeY);

  // near wing
  drawWing(ctx, skin, p, pose, false, -2, 2, open);

  if (opts.item && opts.item !== 'sunglasses') drawItem(ctx, opts.item, p, pose, topY, eyeX, eyeY);

  // death: dizzy stars
  if (pose.state === 'death') {
    ctx.fillStyle = '#ffe27a';
    for (let i = 0; i < 3; i++) { const a = pose.t * 8 + i * TAU / 3; starPath(ctx, Math.cos(a) * 17, topY - 12 + Math.sin(a) * 5, 4, 1.8, 5, a); ctx.fill(); }
  }
  if (pose.state === 'victory') {
    ctx.fillStyle = '#fff6b0';
    for (let i = 0; i < 4; i++) { const a = pose.victoryT * 4 + i * TAU / 4; const r = 34 + Math.sin(pose.victoryT * 6 + i) * 4; starPath(ctx, Math.cos(a) * r, Math.sin(a) * r * 0.8 - 6, 3.4, 1.4, 4, a); ctx.fill(); }
  }
  // shield bubble
  if (pose.shield) {
    const r = 38 + Math.sin(pose.t * 5) * 1.5;
    const sg = ctx.createRadialGradient(0, 0, r * 0.55, 0, 0, r);
    sg.addColorStop(0, 'rgba(120,220,255,0.02)'); sg.addColorStop(0.8, 'rgba(120,220,255,0.18)'); sg.addColorStop(1, 'rgba(200,245,255,0.7)');
    ctx.fillStyle = sg; ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.8)'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(0, 0, r - 1, -2.6, -1.6); ctx.stroke();
  }
  void q;
  ctx.restore();
}

function drawEye(c: Ctx, p: Pal, pose: BirdPose, ex: number, ey: number, covered: boolean): void {
  const st: BirdState = pose.state;
  if (covered) return;
  c.save(); c.translate(ex, ey);
  if (st === 'damage' || st === 'death') {
    c.strokeStyle = '#2a1a3a'; c.lineWidth = 2.6; c.lineCap = 'round';
    c.beginPath(); c.moveTo(-5, -5); c.lineTo(5, 5); c.moveTo(5, -5); c.lineTo(-5, 5); c.stroke(); c.restore(); return;
  }
  if (st === 'victory') {
    c.strokeStyle = '#2a1a3a'; c.lineWidth = 2.8; c.lineCap = 'round'; c.beginPath(); c.arc(0, 2, 5, Math.PI * 1.1, Math.PI * 1.9); c.stroke(); c.restore(); return;
  }
  const open = 1 - pose.blink;
  const scared = pose.mood < -0.3;
  c.fillStyle = '#ffffff'; c.strokeStyle = OUTLINE; c.lineWidth = 1.2;
  c.beginPath(); c.ellipse(0, 0, 7.4, 8.4 * Math.max(0.08, open), 0, 0, TAU); c.fill(); c.stroke();
  if (open > 0.25) {
    const pr = scared ? 3.2 : 4.6;
    const px = pose.lookX * 2.2, py = pose.lookY * 2 + (scared ? -0.5 : 0);
    c.fillStyle = p.eye; c.beginPath(); c.ellipse(px, py, pr, pr * 1.12, 0, 0, TAU); c.fill();
    c.fillStyle = '#ffffff'; c.beginPath(); c.arc(px - 1.5, py - 2, 1.7, 0, TAU); c.fill(); c.beginPath(); c.arc(px + 1.8, py + 1.6, 0.9, 0, TAU); c.fill();
  }
  // brows: tilt with mood
  c.strokeStyle = '#2a1a3a'; c.lineWidth = 2; c.lineCap = 'round';
  const tilt = scared ? -3 : pose.mood > 0.6 ? 1.5 : 0;
  c.beginPath(); c.moveTo(-6, -11 + (scared ? 0 : 1)); c.lineTo(5, -11 + tilt - (scared ? 1 : 0)); c.stroke();
  c.restore();
}

export function drawBirdShadow(ctx: Ctx, x: number, y: number, scale: number, alpha: number): void { softShadow(ctx, x, y, 34 * scale, 8 * scale, alpha); }

export function idlePose(t: number): BirdPose {
  const ph = (t * 1.1) % 1;
  return {
    x: 0, y: Math.sin(t * 2.4) * 4, rot: Math.sin(t * 1.7) * 0.06, vy: 0, state: 'idle', t, flapPhase: ph, wingPower: 0.3,
    blink: (t % 3.2) < 0.12 ? 1 : 0, squash: 0, glow: 0, hurt: 0, alpha: 1, scale: 1, lookX: 0.45, lookY: 0, shield: false, ghost: false, deathT: 0, victoryT: 0, mood: 0.4,
  };
}

const PREVIEW_Q: QualityProfile = { name: 'high', dprCap: 2, maxParticles: 0, particleScale: 1, fog: false, shafts: false, bloom: true, decor: false, shadows: true, weather: 0, layerScale: 1, trailPoints: 0 };

/** Showcase draw for shop / collection: bird at `size` px wide centered at (cx, cy). yaw fakes a turntable. */
export function drawSkinPreview(ctx: Ctx, skin: SkinDef, cx: number, cy: number, size: number, time: number, o: { yaw?: number; item?: CosmeticItemId | null; state?: BirdState; quality?: QualityProfile; background?: boolean } = {}): void {
  const s = size / 92;
  ctx.save();
  ctx.translate(cx, cy);
  if (o.background) {
    drawGlow(ctx, 0, 0, size * 0.95, skin.colors.glow, 0.5);
    drawGlow(ctx, 0, 0, size * 0.5, '#ffffff', 0.12);
  }
  const yaw = o.yaw ?? 0;
  let sx = Math.cos(yaw);
  if (Math.abs(sx) < 0.16) sx = sx < 0 ? -0.16 : 0.16;
  ctx.scale(sx, 1);
  const pose = idlePose(time);
  pose.state = o.state ?? (o.yaw !== undefined ? 'flying' : 'idle');
  if (pose.state === 'flying') { pose.flapPhase = (time * 1.9) % 1; pose.wingPower = 0.6; }
  if (pose.state === 'victory') pose.victoryT = time;
  pose.scale = s;
  drawBird(ctx, skin, pose, { item: o.item ?? null, quality: o.quality ?? PREVIEW_Q });
  if (sx < 0) { ctx.fillStyle = 'rgba(10,6,30,0.22)'; ctx.beginPath(); ctx.ellipse(0, 0, 26 * s, 22 * s, 0, 0, TAU); ctx.fill(); }
  ctx.restore();
  void lerp;
}
