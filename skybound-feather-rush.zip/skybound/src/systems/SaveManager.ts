import { BACKUP_KEY, SAVE_KEY, SAVE_VERSION } from '../config/gameConfig';
import type { Lang, QualityName } from '../core/types';
import { dateKey, weekKey } from '../core/util';
import { SKINS, DEFAULT_SKIN } from '../data/skins';
import { WORLDS, DEFAULT_WORLD } from '../data/worlds';
import { ITEMS, TRAILS, PARTICLE_FX, THEMES } from '../data/cosmetics';
import { ADVENTURE_LEVELS, MODE_LIST, type ModeId } from '../data/modes';
import type { PowerUpType } from '../core/types';

export interface MissionState { id: string; tpl: string; progress: number; target: number; claimed: boolean }
export interface SettingsData {
  lang: Lang; quality: QualityName | 'auto'; master: number; music: number; sfx: number; muted: boolean;
  fps: boolean; shake: boolean; reducedMotion: boolean; tutorial: boolean; control: 'all' | 'keyboard' | 'mouse' | 'touch';
  tuning: { gravity: number; jump: number; speed: number; spacing: number; hitbox: number; difficulty: number };
}
export interface StatsData {
  games: number; deaths: number; gates: number; coins: number; gems: number; distance: number; flaps: number;
  powerups: number; perfects: number; bosses: number; playTime: number; maxCombo: number; zenTime: number;
  worldsSeen: string[]; powerTypes: PowerUpType[]; modesPlayed: ModeId[]; dailyDone: number; phoenixUsed: number; secretsFound: number;
}
export interface SaveData {
  version: number;
  created: number;
  updated: number;
  profile: { name: string; avatar: string; id: string };
  coins: number; gems: number; xp: number; level: number;
  best: Record<ModeId, number>;
  stats: StatsData;
  unlockedSkins: string[]; equippedSkin: string;
  ownedTrails: string[]; ownedFx: string[]; ownedThemes: string[]; ownedItems: string[];
  equipped: { trail: string | null; fx: string | null; theme: string; item: string | null };
  unlockedWorlds: string[]; selectedWorld: string;
  achievements: Record<string, number>;         // id → unlockedAt
  secrets: Record<string, boolean>;
  missions: { dayKey: string; daily: MissionState[]; weekKey: string; weekly: MissionState[] };
  adventure: Record<string, { stars: number; best: number }>;
  daily: { key: string; done: boolean; best: number };
  recent: number[];                              // last scores (adaptive assist)
  tutorialSeen: boolean;
  settings: SettingsData;
}

export const DEFAULT_SETTINGS: SettingsData = {
  lang: 'vi', quality: 'auto', master: 0.8, music: 0.7, sfx: 0.9, muted: false, fps: false, shake: true, reducedMotion: false, tutorial: true, control: 'all',
  tuning: { gravity: 1, jump: 1, speed: 1, spacing: 1, hitbox: 1, difficulty: 1 },
};

export function uuid(): string {
  const a = new Uint8Array(16);
  try { crypto.getRandomValues(a); } catch { for (let i = 0; i < 16; i++) a[i] = Math.floor(Math.random() * 256); }
  return Array.from(a, (b) => b.toString(16).padStart(2, '0')).join('');
}

export function defaultSave(): SaveData {
  const best = {} as Record<ModeId, number>;
  for (const m of MODE_LIST) best[m] = 0;
  const now = Date.now();
  return {
    version: SAVE_VERSION, created: now, updated: now,
    profile: { name: 'Player', avatar: DEFAULT_SKIN, id: uuid() },
    coins: 150, gems: 5, xp: 0, level: 1,
    best,
    stats: { games: 0, deaths: 0, gates: 0, coins: 0, gems: 0, distance: 0, flaps: 0, powerups: 0, perfects: 0, bosses: 0, playTime: 0, maxCombo: 0, zenTime: 0, worldsSeen: [], powerTypes: [], modesPlayed: [], dailyDone: 0, phoenixUsed: 0, secretsFound: 0 },
    unlockedSkins: [DEFAULT_SKIN], equippedSkin: DEFAULT_SKIN,
    ownedTrails: [], ownedFx: [], ownedThemes: ['default'], ownedItems: [],
    equipped: { trail: null, fx: null, theme: 'default', item: null },
    unlockedWorlds: [DEFAULT_WORLD], selectedWorld: DEFAULT_WORLD,
    achievements: {}, secrets: {},
    missions: { dayKey: '', daily: [], weekKey: '', weekly: [] },
    adventure: {},
    daily: { key: '', done: false, best: 0 },
    recent: [],
    tutorialSeen: false,
    settings: JSON.parse(JSON.stringify(DEFAULT_SETTINGS)) as SettingsData,
  };
}

// ------------------------------------------------------------------ validation
const isObj = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v);
const num = (v: unknown, def: number, min = 0, max = 1e12): number => (typeof v === 'number' && Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : def);
const str = (v: unknown, def: string, maxLen = 40): string => (typeof v === 'string' ? v.slice(0, maxLen) : def);
const bool = (v: unknown, def: boolean): boolean => (typeof v === 'boolean' ? v : def);
function strArr(v: unknown, allowed: ReadonlySet<string> | null, max = 400): string[] {
  if (!Array.isArray(v)) return [];
  const out: string[] = [];
  for (const x of v) if (typeof x === 'string' && (!allowed || allowed.has(x)) && !out.includes(x)) out.push(x);
  return out.slice(0, max);
}
const SKIN_IDS = new Set(SKINS.map((s) => s.id));
const WORLD_IDS = new Set(WORLDS.map((w) => w.id));
const TRAIL_IDS = new Set(TRAILS.map((t) => t.id as string));
const FX_IDS = new Set(PARTICLE_FX.map((t) => t.id as string));
const THEME_IDS = new Set(THEMES.map((t) => t.id));
const ITEM_IDS = new Set(ITEMS.map((t) => t.id as string));
const LEVEL_IDS = new Set(ADVENTURE_LEVELS.map((l) => l.id));
const MODE_SET = new Set<string>(MODE_LIST);
const POWER_TYPES = new Set(['shield', 'timewarp', 'phoenix', 'multiplier', 'magnet', 'ghost', 'turbo', 'featherstorm']);

function validMissions(v: unknown): MissionState[] {
  if (!Array.isArray(v)) return [];
  const out: MissionState[] = [];
  for (const m of v.slice(0, 6)) {
    if (!isObj(m)) continue;
    out.push({ id: str(m.id, 'm', 60), tpl: str(m.tpl, '', 40), progress: num(m.progress, 0, 0, 1e9), target: Math.max(1, num(m.target, 1, 1, 1e9)), claimed: bool(m.claimed, false) });
  }
  return out;
}

/** Defensive parse: returns a fully-valid SaveData built from whatever (partially broken) object was given, or null if it is unusable. */
export function validateSave(raw: unknown): SaveData | null {
  if (!isObj(raw)) return null;
  const migrated = migrate(raw);
  if (!migrated) return null;
  const d = defaultSave();
  const r = migrated;
  const out: SaveData = d;
  out.version = SAVE_VERSION;
  out.created = num(r.created, d.created, 0, 4e12);
  out.updated = num(r.updated, d.updated, 0, 4e12);
  const p = isObj(r.profile) ? r.profile : {};
  out.profile = { name: str(p.name, d.profile.name, 16) || 'Player', avatar: SKIN_IDS.has(str(p.avatar, '')) ? str(p.avatar, '') : DEFAULT_SKIN, id: str(p.id, d.profile.id, 64) || d.profile.id };
  out.coins = Math.floor(num(r.coins, d.coins, 0, 1e9));
  out.gems = Math.floor(num(r.gems, d.gems, 0, 1e7));
  out.xp = Math.floor(num(r.xp, 0, 0, 1e10));
  out.level = Math.floor(num(r.level, 1, 1, 200));
  const b = isObj(r.best) ? r.best : {};
  for (const m of MODE_LIST) out.best[m] = Math.floor(num(b[m], 0, 0, 1e6));
  const s = isObj(r.stats) ? r.stats : {};
  const ds = d.stats;
  out.stats = {
    games: num(s.games, 0), deaths: num(s.deaths, 0), gates: num(s.gates, 0), coins: num(s.coins, 0), gems: num(s.gems, 0), distance: num(s.distance, 0),
    flaps: num(s.flaps, 0), powerups: num(s.powerups, 0), perfects: num(s.perfects, 0), bosses: num(s.bosses, 0), playTime: num(s.playTime, 0), maxCombo: num(s.maxCombo, 0),
    zenTime: num(s.zenTime, 0), worldsSeen: strArr(s.worldsSeen, WORLD_IDS), powerTypes: strArr(s.powerTypes, POWER_TYPES) as PowerUpType[],
    modesPlayed: strArr(s.modesPlayed, MODE_SET) as ModeId[], dailyDone: num(s.dailyDone, 0), phoenixUsed: num(s.phoenixUsed, 0), secretsFound: num(s.secretsFound, 0),
  };
  void ds;
  out.unlockedSkins = strArr(r.unlockedSkins, SKIN_IDS);
  if (!out.unlockedSkins.includes(DEFAULT_SKIN)) out.unlockedSkins.unshift(DEFAULT_SKIN);
  out.equippedSkin = out.unlockedSkins.includes(str(r.equippedSkin, '')) ? str(r.equippedSkin, '') : DEFAULT_SKIN;
  out.ownedTrails = strArr(r.ownedTrails, TRAIL_IDS); out.ownedFx = strArr(r.ownedFx, FX_IDS);
  out.ownedThemes = strArr(r.ownedThemes, THEME_IDS); if (!out.ownedThemes.includes('default')) out.ownedThemes.unshift('default');
  out.ownedItems = strArr(r.ownedItems, ITEM_IDS);
  const e = isObj(r.equipped) ? r.equipped : {};
  out.equipped = {
    trail: out.ownedTrails.includes(str(e.trail, '')) ? str(e.trail, '') : null,
    fx: out.ownedFx.includes(str(e.fx, '')) ? str(e.fx, '') : null,
    theme: out.ownedThemes.includes(str(e.theme, '')) ? str(e.theme, '') : 'default',
    item: out.ownedItems.includes(str(e.item, '')) ? str(e.item, '') : null,
  };
  out.unlockedWorlds = strArr(r.unlockedWorlds, WORLD_IDS);
  if (!out.unlockedWorlds.includes(DEFAULT_WORLD)) out.unlockedWorlds.unshift(DEFAULT_WORLD);
  out.selectedWorld = out.unlockedWorlds.includes(str(r.selectedWorld, '')) ? str(r.selectedWorld, '') : DEFAULT_WORLD;
  out.achievements = {};
  if (isObj(r.achievements)) for (const k of Object.keys(r.achievements).slice(0, 200)) out.achievements[k.slice(0, 40)] = num(r.achievements[k], Date.now(), 0, 4e12);
  out.secrets = {};
  if (isObj(r.secrets)) for (const k of Object.keys(r.secrets).slice(0, 50)) if (r.secrets[k] === true) out.secrets[k.slice(0, 40)] = true;
  const m = isObj(r.missions) ? r.missions : {};
  out.missions = { dayKey: str(m.dayKey, ''), daily: validMissions(m.daily), weekKey: str(m.weekKey, ''), weekly: validMissions(m.weekly) };
  out.adventure = {};
  if (isObj(r.adventure)) for (const k of Object.keys(r.adventure)) {
    if (!LEVEL_IDS.has(k)) continue;
    const a = r.adventure[k];
    if (isObj(a)) out.adventure[k] = { stars: Math.floor(num(a.stars, 0, 0, 3)), best: Math.floor(num(a.best, 0, 0, 1e5)) };
  }
  const dl = isObj(r.daily) ? r.daily : {};
  out.daily = { key: str(dl.key, '', 12), done: bool(dl.done, false), best: Math.floor(num(dl.best, 0, 0, 1e5)) };
  out.recent = Array.isArray(r.recent) ? r.recent.filter((x): x is number => typeof x === 'number' && Number.isFinite(x)).slice(-8) : [];
  out.tutorialSeen = bool(r.tutorialSeen, false);
  const st = isObj(r.settings) ? r.settings : {};
  const dst = DEFAULT_SETTINGS;
  const tn = isObj(st.tuning) ? st.tuning : {};
  out.settings = {
    lang: st.lang === 'en' ? 'en' : st.lang === 'vi' ? 'vi' : dst.lang,
    quality: (['auto', 'low', 'medium', 'high', 'ultra'] as const).includes(st.quality as never) ? (st.quality as SettingsData['quality']) : 'auto',
    master: num(st.master, dst.master, 0, 1), music: num(st.music, dst.music, 0, 1), sfx: num(st.sfx, dst.sfx, 0, 1), muted: bool(st.muted, false),
    fps: bool(st.fps, false), shake: bool(st.shake, true), reducedMotion: bool(st.reducedMotion, false), tutorial: bool(st.tutorial, true),
    control: (['all', 'keyboard', 'mouse', 'touch'] as const).includes(st.control as never) ? (st.control as SettingsData['control']) : 'all',
    tuning: {
      gravity: num(tn.gravity, 1, 0.6, 1.6), jump: num(tn.jump, 1, 0.7, 1.4), speed: num(tn.speed, 1, 0.6, 1.4),
      spacing: num(tn.spacing, 1, 0.8, 1.4), hitbox: num(tn.hitbox, 1, 0.6, 1.3), difficulty: num(tn.difficulty, 1, 0.5, 1.5),
    },
  };
  return out;
}

/** Version migrations. Each step upgrades the raw object one version. Unknown / future versions are accepted best-effort. */
export function migrate(raw: Record<string, unknown>): Record<string, unknown> | null {
  let v = typeof raw.version === 'number' ? raw.version : 1;
  if (v > SAVE_VERSION + 10 || v < 1) return null;
  const r: Record<string, unknown> = { ...raw };
  if (v < 2) {
    // v1 stored `skins` / `bestScore` at the top level
    if (Array.isArray(r.skins) && !r.unlockedSkins) r.unlockedSkins = r.skins;
    if (typeof r.bestScore === 'number') r.best = { classic: r.bestScore, endless: r.bestScore };
    v = 2;
  }
  if (v < 3) {
    // v2 had flat settings volume fields
    if (!isObj(r.settings) && typeof r.volume === 'number') r.settings = { master: r.volume };
    if (isObj(r.stats) && typeof (r.stats as Record<string, unknown>).totalGames === 'number') {
      const s = r.stats as Record<string, unknown>;
      r.stats = { ...s, games: s.totalGames };
    }
    v = 3;
  }
  r.version = v;
  return r;
}

/** A save that has never held real progress. Never allowed to replace a stored save that has some. */
export function isBlank(d: SaveData): boolean {
  return d.xp === 0 && d.stats.games === 0 && d.unlockedSkins.length <= 1 && Object.keys(d.achievements).length === 0 && d.coins <= 150 && d.gems <= 5;
}

export interface KV { getItem(k: string): string | null; setItem(k: string, v: string): void; removeItem(k: string): void }

export class SaveManager {
  data: SaveData;
  private store: KV | null;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private dirty = false;
  private listeners = new Set<(d: SaveData) => void>();
  loadedFrom: 'primary' | 'backup' | 'fresh' | 'memory' = 'fresh';
  error: string | null = null;

  constructor(store?: KV | null) {
    this.store = store === undefined ? SaveManager.defaultStore() : store;
    this.data = defaultSave();
    this.load();
  }
  static defaultStore(): KV | null {
    try { const s = window.localStorage; s.setItem('__sb', '1'); s.removeItem('__sb'); return s; } catch { return null; }
  }
  private read(key: string): SaveData | null {
    if (!this.store) return null;
    try {
      const txt = this.store.getItem(key);
      if (!txt) return null;
      return validateSave(JSON.parse(txt));
    } catch { return null; }
  }
  load(): void {
    if (!this.store) { this.loadedFrom = 'memory'; return; }
    const prim = this.read(SAVE_KEY);
    if (prim) { this.data = prim; this.loadedFrom = 'primary'; this.afterLoad(); return; }
    const hadRaw = (() => { try { return !!this.store!.getItem(SAVE_KEY); } catch { return false; } })();
    const back = this.read(BACKUP_KEY);
    if (back) {
      this.data = back; this.loadedFrom = 'backup';
      this.error = hadRaw ? 'primary-corrupt-restored-from-backup' : null;
      this.afterLoad(); return;
    }
    this.data = defaultSave(); this.loadedFrom = 'fresh';
    if (hadRaw) {
      // unreadable data and no backup: keep the broken payload under a rescue key instead of destroying it
      try { this.store.setItem(SAVE_KEY + '.corrupt', this.store.getItem(SAVE_KEY) ?? ''); } catch { /* ignore */ }
      this.error = 'primary-corrupt-no-backup';
    }
  }
  private afterLoad(): void { /* hook for daily/weekly mission rollovers etc. */ }

  onChange(fn: (d: SaveData) => void): () => void { this.listeners.add(fn); return () => { this.listeners.delete(fn); }; }
  /** Call after mutating `data`. Debounced write. */
  touch(): void {
    this.data.updated = Date.now();
    this.dirty = true;
    for (const fn of Array.from(this.listeners)) fn(this.data);
    if (this.timer) return;
    this.timer = setTimeout(() => { this.timer = null; this.flush(); }, 350);
  }
  /** Immediate write. Rotates the previous valid primary into the backup slot; refuses to overwrite real progress with a blank save. */
  flush(): boolean {
    if (this.timer) { clearTimeout(this.timer); this.timer = null; }
    if (!this.dirty && this.loadedFrom !== 'fresh') return true;
    if (!this.store) { this.dirty = false; return false; }
    try {
      const existing = this.read(SAVE_KEY);
      if (existing && isBlank(this.data) && !isBlank(existing)) { this.error = 'blocked-blank-overwrite'; return false; }
      if (existing && !isBlank(existing)) this.store.setItem(BACKUP_KEY, JSON.stringify(existing));
      this.store.setItem(SAVE_KEY, JSON.stringify(this.data));
      this.dirty = false;
      return true;
    } catch (e) { this.error = 'write-failed:' + String(e); return false; }
  }
  /** Explicit user reset (settings). Keeps a backup of what was there. */
  reset(): void {
    if (this.store) { try { const cur = this.store.getItem(SAVE_KEY); if (cur) this.store.setItem(BACKUP_KEY, cur); } catch { /* ignore */ } }
    this.data = defaultSave();
    this.dirty = true;
    if (this.store) { try { this.store.setItem(SAVE_KEY, JSON.stringify(this.data)); this.dirty = false; } catch { /* ignore */ } }
    for (const fn of Array.from(this.listeners)) fn(this.data);
  }
  exportJSON(): string { return JSON.stringify(this.data); }
  importJSON(text: string): boolean {
    try {
      const v = validateSave(JSON.parse(text));
      if (!v) return false;
      this.data = v; this.touch(); this.flush(); return true;
    } catch { return false; }
  }
  today(): string { return dateKey(); }
  thisWeek(): string { return weekKey(); }
}
