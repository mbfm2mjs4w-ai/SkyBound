// Missions, achievements, leaderboard, profile and settings screens.
import { h, icon, clear } from '../dom';
import { Scr, header, tabs } from './common';
import type { AppApi } from '../../app/types';
import type { Screen } from '../UI';
import { tr, loc, setLang, getLang } from '../../core/i18n';
import { formatNumber, formatTime } from '../../core/util';
import { MISSION_BY_ID, missionText, type Reward } from '../../data/missions';
import { ACHIEVEMENTS, type Rarity } from '../../data/achievements';
import { MODES, MODE_LIST } from '../../data/modes';
import { SKIN_BY_ID, SKINS } from '../../data/skins';
import { drawSkinPreview } from '../../render/BirdRenderer';
import { QUALITY } from '../../config/gameConfig';
import type { LeaderEntry, FriendEntry } from '../../net/NetworkManager';
import type { SettingsData } from '../../systems/SaveManager';

const rewardChips = (r: Reward): HTMLElement => h('span', { class: 'row', style: 'gap:.5rem;font-weight:800' }, r.coins ? h('span', { class: 'price' }, icon('coin', 16), r.coins) : null, r.gems ? h('span', { class: 'price' }, icon('gem', 16), r.gems) : null, r.xp ? h('span', { class: 'price' }, `${r.xp} XP`) : null);
function untilReset(kind: 'daily' | 'weekly'): string {
  const now = new Date(), n = new Date(now);
  if (kind === 'daily') { n.setHours(24, 0, 0, 0); } else { const d = (8 - (now.getDay() || 7)) % 7 || 7; n.setDate(now.getDate() + d); n.setHours(0, 0, 0, 0); }
  const s = Math.max(0, Math.floor((n.getTime() - now.getTime()) / 1000)), hh = Math.floor(s / 3600);
  return hh >= 24 ? `${Math.floor(hh / 24)}${tr('ng', 'd')} ${hh % 24}${tr('g', 'h')}` : `${hh}${tr('g', 'h')} ${Math.floor((s % 3600) / 60)}${tr('p', 'm')}`;
}

// ---------------------------------------------------------------- missions
export function missionsScreen(app: AppApi): Screen {
  const s = new Scr(), sv = app.save.data, content = h('div', { class: 'content' });
  const build = (): void => {
    clear(content);
    const section = (kind: 'daily' | 'weekly', list: typeof sv.missions.daily): HTMLElement => {
      const box = h('div', { class: 'section glass' }, h('div', { class: 'row sb' }, h('h3', {}, kind === 'daily' ? tr('Nhiệm vụ hằng ngày', 'Daily missions') : tr('Nhiệm vụ hằng tuần', 'Weekly missions')), h('span', { class: 'chip' }, icon('clock', 16), `${tr('Làm mới sau', 'Resets in')} ${untilReset(kind)}`)));
      for (const m of list) {
        const tpl = MISSION_BY_ID[m.tpl]; if (!tpl) continue;
        const done = m.progress >= m.target, frac = Math.min(1, m.progress / m.target);
        box.appendChild(h('div', { class: 'list' }, h('div', { class: 'item', style: 'flex-wrap:wrap' },
          h('div', { class: 'col grow', style: 'gap:.25rem;min-width:10rem' }, h('b', {}, missionText(m, getLang())), h('div', { class: 'bar' }, h('i', { style: `width:${Math.round(frac * 100)}%` })), h('small', { class: 'muted' }, `${Math.min(m.progress, m.target)}/${m.target}`)),
          rewardChips(tpl.reward),
          m.claimed ? h('span', { class: 'tag ok' }, tr('Đã nhận', 'Claimed')) : h('button', { class: `btn small gold${done ? '' : ' disabled'}`, on: { click: () => { const r = app.prog.claimMission(m.id); if (r) { app.audio.sfx('reward'); app.ui.toast(`+${r.coins} ${tr('xu', 'coins')}${r.gems ? ` +${r.gems} ${tr('ngọc', 'gems')}` : ''} +${r.xp} XP`, 'ok', 2500, 'gift'); app.save.flush(); build(); } } } }, tr('Nhận', 'Claim')))));
      }
      return box;
    };
    content.append(section('daily', sv.missions.daily), section('weekly', sv.missions.weekly));
  };
  build();
  s.el.append(header(app, s, tr('Nhiệm vụ', 'Missions'), () => app.open('menu')), content);
  return s;
}

// ---------------------------------------------------------------- achievements
export function achievementsScreen(app: AppApi): Screen {
  const s = new Scr(), sv = app.save.data, content = h('div', { class: 'content' });
  let filter = 'all';
  const order: Record<Rarity, number> = { legendary: 0, epic: 1, rare: 2, common: 3 };
  const done = ACHIEVEMENTS.filter((a) => sv.achievements[a.id]).length;
  const build = (): void => {
    clear(content);
    content.appendChild(tabs([{ id: 'all', label: tr('Tất cả', 'All') }, { id: 'done', label: tr('Đã đạt', 'Unlocked') }, { id: 'todo', label: tr('Chưa đạt', 'Locked') }], filter, (id) => { filter = id; build(); }));
    const grid = h('div', { class: 'grid wide' });
    const list = ACHIEVEMENTS.slice().sort((a, b) => order[a.rarity] - order[b.rarity]);
    for (const a of list) {
      const got = !!sv.achievements[a.id]; if ((filter === 'done' && !got) || (filter === 'todo' && got)) continue;
      const hide = a.secret && !got, pr = a.progress?.({ save: sv, run: null });
      grid.appendChild(h('div', { class: 'card', style: got ? `border-color:var(--${a.rarity})` : '' },
        h('div', { class: 'row sb' }, h('h3', {}, hide ? '???' : loc(a.name)), h('span', { class: `tag ${a.rarity}` }, a.rarity)),
        h('p', {}, hide ? tr('Thành tựu bí mật — hãy khám phá!', 'Secret achievement — go explore!') : loc(a.desc)),
        pr && !got ? h('div', { class: 'col', style: 'gap:.15rem' }, h('div', { class: 'bar' }, h('i', { style: `width:${Math.round(Math.min(1, pr[0] / pr[1]) * 100)}%` })), h('small', { class: 'muted' }, `${formatNumber(Math.min(pr[0], pr[1]))}/${formatNumber(pr[1])}`)) : null,
        h('div', { class: 'row sb' }, rewardChips(a.reward), got ? h('span', { class: 'tag ok' }, icon('check', 12), ' ', tr('Đã đạt', 'Done')) : h('span', { class: 'muted' }, icon('lock', 14)))));
    }
    content.appendChild(grid);
  };
  build();
  s.el.append(header(app, s, `${tr('Thành tựu', 'Achievements')}  ${done}/${ACHIEVEMENTS.length}`, () => app.open('menu')), content);
  return s;
}

// ---------------------------------------------------------------- leaderboard
export function leaderboardScreen(app: AppApi): Screen {
  const s = new Scr(), sv = app.save.data, content = h('div', { class: 'content' });
  let mode = 'classic', period: 'all' | 'week' | 'day' = 'all';
  const scoredModes = MODE_LIST.filter((m) => MODES[m].scored);
  const online = h('div', { class: 'section glass' });
  const loadOnline = async (): Promise<void> => {
    clear(online); online.appendChild(h('h3', {}, tr('Bảng xếp hạng online', 'Online leaderboard')));
    if (!app.net.configured) { online.appendChild(h('div', { class: 'notice' }, icon('wifioff', 20), h('div', {}, h('b', {}, tr('Online chưa được kết nối', 'Online not connected')), h('br'), tr('Bản build này chưa cấu hình Supabase (SUPABASE_URL / SUPABASE_ANON_KEY), nên không có bảng xếp hạng toàn cầu. Game vẫn chơi đầy đủ ngoại tuyến; kỷ lục cá nhân được lưu bên dưới.', 'This build has no Supabase configuration (SUPABASE_URL / SUPABASE_ANON_KEY), so there is no global leaderboard. The game is fully playable offline; your personal bests are listed below.')))); return; }
    if (!app.net.signedIn) { online.append(h('div', { class: 'notice' }, icon('user', 20), tr('Đăng nhập (hoặc chơi với tư cách khách) trong Hồ sơ để tham gia bảng xếp hạng.', 'Sign in (or continue as guest) in Profile to join the leaderboard.')), h('button', { class: 'btn small', on: { click: () => app.open('profile') } }, tr('Đến Hồ sơ', 'Go to Profile'))); return; }
    online.appendChild(h('div', { class: 'muted' }, tr('Đang tải…', 'Loading…')));
    const r = await app.net.leaderboard(mode, period);
    clear(online); online.appendChild(h('h3', {}, tr('Bảng xếp hạng online', 'Online leaderboard')));
    if (!r.ok) { online.appendChild(h('div', { class: 'notice' }, icon('wifioff', 20), `${tr('Không tải được', 'Could not load')}: ${r.error}`)); return; }
    if (!r.data.length) { online.appendChild(h('div', { class: 'muted' }, tr('Chưa có ai trên bảng xếp hạng này. Hãy là người đầu tiên!', 'Nobody on this board yet. Be the first!'))); return; }
    const tbl = h('table', { class: 'table' }, h('tr', {}, h('th', {}, '#'), h('th', {}, tr('Người chơi', 'Player')), h('th', {}, tr('Điểm', 'Score'))));
    for (const e of r.data as LeaderEntry[]) tbl.appendChild(h('tr', { style: e.me ? 'background:rgba(122,255,193,.15)' : '' }, h('td', {}, e.rank), h('td', {}, e.name), h('td', {}, formatNumber(e.score))));
    online.appendChild(tbl);
  };
  const personal = h('div', { class: 'section glass' });
  const buildPersonal = (): void => {
    clear(personal); personal.appendChild(h('h3', {}, tr('Kỷ lục cá nhân (lưu trên máy này)', 'Personal bests (stored on this device)')));
    const tbl = h('table', { class: 'table' }, h('tr', {}, h('th', {}, tr('Chế độ', 'Mode')), h('th', {}, tr('Kỷ lục', 'Best'))));
    for (const m of scoredModes) tbl.appendChild(h('tr', {}, h('td', {}, `${MODES[m].icon} ${loc(MODES[m].name)}`), h('td', {}, formatNumber(sv.best[m] ?? 0))));
    personal.appendChild(tbl);
  };
  const friends = h('div', { class: 'section glass' });
  const buildFriends = async (): Promise<void> => {
    clear(friends); friends.appendChild(h('h3', {}, tr('Bạn bè', 'Friends')));
    if (!app.net.configured || !app.net.signedIn) { friends.appendChild(h('div', { class: 'muted' }, app.net.configured ? tr('Đăng nhập để dùng tính năng bạn bè.', 'Sign in to use friends.') : tr('Cần kết nối online để dùng bạn bè.', 'Friends require an online connection.'))); return; }
    const inp = h('input', { type: 'text', placeholder: tr('Tên người chơi…', 'Player name…'), maxLength: 20 });
    friends.appendChild(h('div', { class: 'row' }, inp, h('button', { class: 'btn small', on: { click: async () => { const r = await app.net.addFriend(inp.value.trim()); app.ui.toast(r.ok ? tr('Đã thêm bạn!', 'Friend added!') : r.error, r.ok ? 'ok' : 'err'); if (r.ok) void buildFriends(); } } }, tr('Thêm', 'Add'))));
    const r = await app.net.friends(); if (r.ok) for (const f of r.data as FriendEntry[]) friends.appendChild(h('div', { class: 'item list', style: 'display:flex;justify-content:space-between;padding:.4rem .7rem;border-radius:12px;background:rgba(0,0,0,.25)' }, h('b', {}, f.name), h('span', {}, formatNumber(f.best))));
  };
  const controls = h('div', { class: 'row wrap' });
  const buildControls = (): void => {
    clear(controls);
    controls.appendChild(tabs(scoredModes.map((m) => ({ id: m, label: loc(MODES[m].name) })), mode, (id) => { mode = id; buildControls(); void loadOnline(); }));
    if (app.net.configured && app.net.signedIn) controls.appendChild(tabs([{ id: 'all', label: tr('Mọi lúc', 'All time') }, { id: 'week', label: tr('Tuần', 'Week') }, { id: 'day', label: tr('Ngày', 'Day') }], period, (id) => { period = id as typeof period; buildControls(); void loadOnline(); }));
  };
  buildControls(); buildPersonal(); void loadOnline(); void buildFriends();
  content.append(controls, online, personal, friends);
  s.el.append(header(app, s, tr('Xếp hạng', 'Leaderboard'), () => app.open('menu')), content);
  return s;
}

// ---------------------------------------------------------------- profile
function download(name: string, text: string): void {
  const a = h('a', { href: URL.createObjectURL(new Blob([text], { type: 'application/json' })), download: name }); document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}
export function profileScreen(app: AppApi): Screen {
  const s = new Scr(), sv = app.save.data, content = h('div', { class: 'content' });
  const lp = app.prog.levelProgress(), skin = SKIN_BY_ID[sv.profile.avatar] ?? SKINS[0];
  const av = h('canvas', { width: 220, height: 180, style: 'width:7rem;border-radius:16px;background:rgba(0,0,0,.25)' }); drawSkinPreview(av.getContext('2d')!, skin, 110, 92, 120, 1.2, { background: true, quality: QUALITY.high });
  const name = h('input', { type: 'text', value: sv.profile.name, maxLength: 20, 'aria-label': 'Name' });
  const saveName = (): void => { const v = name.value.trim().replace(/\s+/g, ' ').slice(0, 20); if (v.length < 3) { app.ui.toast(tr('Tên cần ít nhất 3 ký tự', 'Name needs at least 3 characters'), 'err'); return; } sv.profile.name = v; app.save.touch(); app.ui.toast(tr('Đã lưu tên', 'Name saved'), 'ok', 1500); if (app.net.signedIn) void app.net.setProfile(v, sv.profile.avatar); };
  const st = sv.stats;
  const stat = (a: string, b: string): HTMLElement => h('div', { class: 'stat' }, h('b', {}, b), h('small', {}, a));
  const profile = h('div', { class: 'section glass' }, h('div', { class: 'row' }, av, h('div', { class: 'col grow' }, h('div', { class: 'field' }, h('label', {}, tr('Tên hiển thị', 'Display name')), h('div', { class: 'row' }, name, h('button', { class: 'btn small', on: { click: saveName } }, tr('Lưu', 'Save')))),
    h('div', { class: 'row sb' }, h('b', {}, `${tr('Cấp', 'Level')} ${lp.level}`), h('small', { class: 'muted' }, `${lp.xp}/${lp.need} XP`)), h('div', { class: 'bar' }, h('i', { style: `width:${Math.round(lp.frac * 100)}%` })))));
  const stats = h('div', { class: 'section glass' }, h('h3', {}, tr('Thống kê', 'Statistics')), h('div', { class: 'stat-row', style: 'grid-template-columns:repeat(auto-fill,minmax(7rem,1fr))' },
    stat(tr('Ván chơi', 'Games'), formatNumber(st.games)), stat(tr('Cổng đã qua', 'Gates'), formatNumber(st.gates)), stat(tr('Xu đã nhặt', 'Coins'), formatNumber(st.coins)), stat(tr('Ngọc', 'Gems'), formatNumber(st.gems)), stat(tr('Quãng đường', 'Distance'), `${formatNumber(st.distance)}m`), stat(tr('Thời gian chơi', 'Play time'), formatTime(st.playTime)),
    stat(tr('Combo cao nhất', 'Best combo'), `x${st.maxCombo}`), stat(tr('Trùm đã hạ', 'Bosses'), formatNumber(st.bosses)), stat(tr('Vật phẩm', 'Power-ups'), formatNumber(st.powerups)), stat(tr('Nhân vật', 'Skins'), `${sv.unlockedSkins.length}/${SKINS.length}`), stat(tr('Thành tựu', 'Achievements'), `${Object.keys(sv.achievements).length}/${ACHIEVEMENTS.length}`), stat(tr('Lần vỗ cánh', 'Flaps'), formatNumber(st.flaps))));
  // online account
  const acct = h('div', { class: 'section glass' }); const buildAcct = (): void => {
    clear(acct); acct.appendChild(h('h3', {}, tr('Tài khoản online', 'Online account')));
    if (!app.net.configured) { acct.appendChild(h('div', { class: 'notice' }, icon('wifioff', 20), tr('Online chưa được kết nối (build này chưa có cấu hình Supabase). Mọi tiến trình được lưu trên máy này; bạn có thể xuất/nhập file lưu bên dưới.', 'Online is not connected (this build has no Supabase config). Progress is stored on this device; use export/import below to back it up.'))); return; }
    if (app.net.signedIn) {
      acct.appendChild(h('div', { class: 'row sb' }, h('span', {}, `${tr('Đã đăng nhập', 'Signed in')}: ${app.net.session?.user.email ?? tr('Khách', 'Guest')}`), h('button', { class: 'btn ghost small', on: { click: () => { app.net.signOut(); buildAcct(); } } }, tr('Đăng xuất', 'Sign out'))));
      acct.appendChild(h('div', { class: 'row wrap' },
        h('button', { class: 'btn small blue', on: { click: async () => { const r = await app.net.pushSave(sv); app.ui.toast(r.ok ? tr('Đã sao lưu lên đám mây', 'Cloud backup saved') : r.error, r.ok ? 'ok' : 'err'); } } }, icon('cloud', 16), tr('Sao lưu lên cloud', 'Back up to cloud')),
        h('button', { class: 'btn small ghost', on: { click: async () => { const r = await app.net.pullSave(); if (!r.ok) { app.ui.toast(r.error, 'err'); return; } if (!r.data) { app.ui.toast(tr('Chưa có bản lưu trên cloud', 'No cloud save yet'), 'info'); return; } const ok = await app.ui.confirm({ title: tr('Khôi phục từ cloud?', 'Restore from cloud?'), body: tr('Tiến trình hiện tại trên máy sẽ bị thay thế (một bản sao lưu sẽ được giữ lại).', 'Your local progress will be replaced (a backup copy is kept).'), danger: true }); if (ok && app.save.importJSON(JSON.stringify(r.data.data))) { app.applySettings(); app.ui.toast(tr('Đã khôi phục', 'Restored'), 'ok'); app.open('profile'); } } } }, icon('cloud', 16), tr('Khôi phục từ cloud', 'Restore from cloud'))));
    } else {
      const em = h('input', { type: 'email', placeholder: 'email', autocomplete: 'email' }), pw = h('input', { type: 'password', placeholder: tr('mật khẩu (≥6 ký tự)', 'password (6+ chars)'), autocomplete: 'current-password' });
      const act = async (kind: 'in' | 'up' | 'guest'): Promise<void> => { const r = kind === 'guest' ? await app.net.signInGuest() : kind === 'in' ? await app.net.signIn(em.value.trim(), pw.value) : await app.net.signUp(em.value.trim(), pw.value); app.ui.toast(r.ok ? (app.net.signedIn ? tr('Đăng nhập thành công', 'Signed in') : tr('Kiểm tra email để xác nhận tài khoản', 'Check your email to confirm your account')) : r.error, r.ok ? 'ok' : 'err'); if (app.net.signedIn) { void app.net.setProfile(sv.profile.name, sv.profile.avatar); buildAcct(); } };
      acct.append(h('div', { class: 'grid', style: 'grid-template-columns:repeat(auto-fit,minmax(12rem,1fr))' }, em, pw), h('div', { class: 'row wrap' }, h('button', { class: 'btn small', on: { click: () => void act('in') } }, tr('Đăng nhập', 'Sign in')), h('button', { class: 'btn small blue', on: { click: () => void act('up') } }, tr('Đăng ký', 'Sign up')), h('button', { class: 'btn small ghost', on: { click: () => void act('guest') } }, tr('Chơi khách', 'Guest'))));
    }
  };
  buildAcct();
  content.append(profile, stats, acct, dataSection(app));
  s.el.append(header(app, s, tr('Hồ sơ', 'Profile'), () => app.open('menu')), content);
  return s;
}
function dataSection(app: AppApi): HTMLElement {
  const file = h('input', { type: 'file', accept: 'application/json,.json', style: 'display:none', on: { change: async (e: Event) => { const f = (e.target as HTMLInputElement).files?.[0]; if (!f) return; const ok = app.save.importJSON(await f.text()); app.ui.toast(ok ? tr('Đã nhập dữ liệu', 'Save imported') : tr('File lưu không hợp lệ — dữ liệu hiện tại được giữ nguyên', 'Invalid save file — your current data was kept'), ok ? 'ok' : 'err'); if (ok) { app.applySettings(); app.open('profile'); } } } });
  return h('div', { class: 'section glass' }, h('h3', {}, tr('Dữ liệu', 'Data')), h('div', { class: 'row wrap' },
    h('button', { class: 'btn small blue', on: { click: () => download('skybound-save.json', app.save.exportJSON()) } }, tr('Xuất file lưu', 'Export save')),
    h('button', { class: 'btn small ghost', on: { click: () => file.click() } }, tr('Nhập file lưu', 'Import save')),
    h('button', { class: 'btn small danger', on: { click: async () => { if (await app.ui.confirm({ title: tr('Xoá toàn bộ tiến trình?', 'Erase all progress?'), body: tr('Hành động này không thể hoàn tác. Hãy xuất file lưu trước nếu bạn muốn giữ lại.', 'This cannot be undone. Export your save first if you want to keep it.'), danger: true, ok: tr('Xoá hết', 'Erase') })) app.resetProgress(); } } }, tr('Xoá tiến trình', 'Reset progress')), file));
}

// ---------------------------------------------------------------- settings
export function settingsScreen(app: AppApi): Screen {
  const s = new Scr(), sv = app.save.data, set = sv.settings, content = h('div', { class: 'content' });
  const commit = (): void => { app.applySettings(); app.save.touch(); };
  const sw = (on: boolean, cb: (v: boolean) => void): HTMLElement => { const b = h('button', { class: `switch${on ? ' on' : ''}`, role: 'switch', 'aria-checked': on, on: { click: () => { on = !on; b.classList.toggle('on', on); b.setAttribute('aria-checked', String(on)); app.audio.sfx('toggle', on ? 1 : 0); cb(on); } } }); return b; };
  const row = (label: string, ctl: HTMLElement, hint?: string): HTMLElement => h('div', { class: 'set-row' }, h('span', {}, label, hint ? h('small', { class: 'muted', style: 'display:block' }, hint) : null), ctl);
  const range = (v: number, min: number, max: number, step: number, cb: (v: number) => void, fmt?: (v: number) => string): HTMLElement => { const out = h('small', { style: 'min-width:3rem;text-align:right' }, fmt ? fmt(v) : `${Math.round(v * 100)}%`); const inp = h('input', { type: 'range', min, max, step, value: v, style: 'flex:1;min-width:6rem', on: { input: () => { const n = +inp.value; out.textContent = fmt ? fmt(n) : `${Math.round(n * 100)}%`; cb(n); } } }); return h('div', { class: 'row', style: 'flex:1;max-width:16rem' }, inp, out); };
  const select = (v: string, opts: [string, string][], cb: (v: string) => void): HTMLElement => h('select', { on: { change: (e: Event) => cb((e.target as HTMLSelectElement).value) } }, opts.map(([k, l]) => h('option', { value: k, selected: k === v }, l)));
  const T = set.tuning;
  const tune = (label: string, key: keyof SettingsData['tuning'], min: number, max: number): HTMLElement => row(label, range(T[key], min, max, 0.05, (v) => { T[key] = v; app.save.touch(); }, (v) => `x${v.toFixed(2)}`));
  content.append(
    h('div', { class: 'section glass' }, h('h3', {}, tr('Ngôn ngữ', 'Language')), row(tr('Ngôn ngữ giao diện', 'Interface language'), select(set.lang, [['vi', 'Tiếng Việt'], ['en', 'English']], (v) => { set.lang = v as 'vi' | 'en'; setLang(set.lang); commit(); app.open('settings'); }))),
    h('div', { class: 'section glass' }, h('h3', {}, tr('Đồ hoạ', 'Graphics')),
      row(tr('Chất lượng', 'Quality'), select(set.quality, [['auto', 'Auto'], ['low', tr('Thấp', 'Low')], ['medium', tr('Trung bình', 'Medium')], ['high', tr('Cao', 'High')], ['ultra', 'Ultra']], (v) => { set.quality = v as SettingsData['quality']; commit(); }), tr('Auto sẽ tự giảm đồ hoạ nếu game bị giật.', 'Auto lowers graphics if the game stutters.')),
      row(tr('Hiện FPS', 'Show FPS'), sw(set.fps, (v) => { set.fps = v; commit(); })), row(tr('Rung màn hình', 'Screen shake'), sw(set.shake, (v) => { set.shake = v; commit(); })),
      row(tr('Giảm chuyển động', 'Reduced motion'), sw(set.reducedMotion, (v) => { set.reducedMotion = v; commit(); }), tr('Giảm hiệu ứng chớp sáng, rung và chuyển động mạnh.', 'Fewer flashes, shakes and strong motion.')),
      row(tr('Toàn màn hình', 'Fullscreen'), h('button', { class: 'btn small ghost', on: { click: () => app.toggleFullscreen() } }, icon('full', 16), tr('Bật/tắt', 'Toggle')))),
    h('div', { class: 'section glass' }, h('h3', {}, tr('Âm thanh', 'Audio')), row(tr('Âm lượng tổng', 'Master volume'), range(set.master, 0, 1, 0.05, (v) => { set.master = v; commit(); })), row(tr('Nhạc nền', 'Music'), range(set.music, 0, 1, 0.05, (v) => { set.music = v; commit(); })), row(tr('Hiệu ứng âm thanh', 'Sound effects'), range(set.sfx, 0, 1, 0.05, (v) => { set.sfx = v; commit(); })), row(tr('Tắt tiếng', 'Mute'), sw(set.muted, (v) => { set.muted = v; commit(); }))),
    h('div', { class: 'section glass' }, h('h3', {}, tr('Điều khiển & Hướng dẫn', 'Controls & Tutorial')),
      row(tr('Phương thức điều khiển', 'Control scheme'), select(set.control, [['all', tr('Tất cả', 'All')], ['keyboard', tr('Bàn phím', 'Keyboard')], ['mouse', tr('Chuột', 'Mouse')], ['touch', tr('Cảm ứng', 'Touch')]], (v) => { set.control = v as SettingsData['control']; commit(); })),
      row(tr('Hiện hướng dẫn', 'Show tutorial'), sw(set.tutorial, (v) => { set.tutorial = v; if (v) sv.tutorialSeen = false; commit(); })),
      h('small', { class: 'muted' }, tr('Phím: SPACE / ↑ / W / Click / Chạm = vỗ cánh · ESC / P = tạm dừng · R = chơi lại', 'Keys: SPACE / ↑ / W / Click / Tap = flap · ESC / P = pause · R = restart'))),
    h('div', { class: 'section glass' }, h('h3', {}, tr('Tinh chỉnh nâng cao', 'Advanced tuning')), h('div', { class: 'notice' }, icon('info', 18), tr('Thay đổi các thông số vật lý. Giá trị quá khác biệt có thể làm màn chơi khó hơn hoặc dễ hơn đáng kể.', 'Changes the physics. Extreme values can make runs much harder or easier.')),
      tune(tr('Trọng lực', 'Gravity'), 'gravity', 0.7, 1.4), tune(tr('Lực nhảy', 'Jump power'), 'jump', 0.8, 1.25), tune(tr('Tốc độ', 'Speed'), 'speed', 0.7, 1.4), tune(tr('Khoảng cách cổng', 'Gate spacing'), 'spacing', 0.8, 1.4), tune(tr('Hitbox', 'Hitbox'), 'hitbox', 0.6, 1.2), tune(tr('Độ khó', 'Difficulty'), 'difficulty', 0.5, 2),
      h('button', { class: 'btn small ghost', on: { click: () => { Object.assign(T, { gravity: 1, jump: 1, speed: 1, spacing: 1, hitbox: 1, difficulty: 1 }); app.save.touch(); app.open('settings'); } } }, icon('rotate', 16), tr('Đặt lại mặc định', 'Reset to default'))),
    dataSection(app));
  s.el.append(header(app, s, tr('Cài đặt', 'Settings'), () => app.open('menu')), content);
  return s;
}
