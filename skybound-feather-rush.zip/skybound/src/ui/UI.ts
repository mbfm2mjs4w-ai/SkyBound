// Screen manager + toasts + modals. Screens are plain DOM elements layered over the canvas.
import { h, clear, icon } from './dom';
import { tr } from '../core/i18n';
import type { AudioManager } from '../audio/AudioManager';

export interface Screen { el: HTMLElement; destroy?(): void }

export class UI {
  readonly root: HTMLElement;
  readonly hudLayer: HTMLElement;
  private screenLayer = h('div', { class: 'layer', style: 'position:absolute;inset:0;pointer-events:none' });
  private modalLayer = h('div', { class: 'layer', style: 'position:absolute;inset:0;pointer-events:none' });
  private toastBox = h('div', { class: 'toasts' });
  private cur: Screen | null = null;
  private modals: { el: HTMLElement; onClose?: () => void }[] = [];

  constructor(host: HTMLElement, private audio: AudioManager) {
    this.root = h('div', { id: 'ui' });
    this.hudLayer = h('div', { style: 'position:absolute;inset:0;pointer-events:none' });
    this.root.append(this.hudLayer, this.screenLayer, this.modalLayer, this.toastBox);
    host.appendChild(this.root);
    // hover / click feedback for every button (one delegated listener, no duplicates)
    this.root.addEventListener('pointerover', (e) => { const t = (e.target as HTMLElement).closest('.btn,.tile,.tab,button.card'); if (t && e.pointerType === 'mouse') this.audio.sfx('hover'); });
    this.root.addEventListener('click', (e) => { const t = (e.target as HTMLElement).closest('button'); if (t && !t.classList.contains('quiet')) this.audio.sfx(t.classList.contains('back') ? 'back' : 'click'); }, true);
  }
  get hasScreen(): boolean { return !!this.cur; }
  show(s: Screen | null): void {
    const old = this.cur; this.cur = s;
    if (old) { old.el.classList.add('out'); const o = old; setTimeout(() => { o.destroy?.(); o.el.remove(); }, 180); }
    if (s) this.screenLayer.appendChild(s.el);
  }
  hide(): void { this.show(null); }
  toast(text: string, kind: 'ok' | 'err' | 'info' | 'ach' = 'info', ms = 2800, ico?: string): void {
    const t = h('div', { class: `toast ${kind}` }, ico ? icon(ico, 22) : null, h('span', {}, text));
    this.toastBox.appendChild(t);
    while (this.toastBox.children.length > 4) this.toastBox.firstChild?.remove();
    setTimeout(() => { t.style.transition = 'opacity .3s,transform .3s'; t.style.opacity = '0'; t.style.transform = 'translateY(-10px)'; setTimeout(() => t.remove(), 320); }, ms);
  }
  /** Generic modal. Returns a close() function. */
  modal(content: HTMLElement | HTMLElement[], onClose?: () => void, dismissable = true): () => void {
    const box = h('div', { class: 'modal glass', role: 'dialog', 'aria-modal': 'true' }, ...(Array.isArray(content) ? content : [content]));
    const back = h('div', { class: 'modal-back' }, box);
    const entry = { el: back, onClose };
    const close = (): void => { const i = this.modals.indexOf(entry); if (i >= 0) this.modals.splice(i, 1); back.remove(); onClose?.(); };
    if (dismissable) back.addEventListener('pointerdown', (e) => { if (e.target === back) close(); });
    this.modals.push(entry); this.modalLayer.appendChild(back);
    return close;
  }
  closeTopModal(): boolean { const m = this.modals[this.modals.length - 1]; if (!m) return false; m.el.remove(); this.modals.pop(); m.onClose?.(); return true; }
  confirm(o: { title: string; body: string | HTMLElement; ok?: string; cancel?: string; danger?: boolean; icon?: string }): Promise<boolean> {
    return new Promise((res) => {
      let done = false;
      const fin = (v: boolean): void => { if (done) return; done = true; close(); res(v); };
      const close = this.modal([
        h('h2', {}, o.title), typeof o.body === 'string' ? h('p', {}, o.body) : o.body,
        h('div', { class: 'row', style: 'justify-content:flex-end;gap:.6rem' },
          h('button', { class: 'btn ghost back', on: { click: () => fin(false) } }, o.cancel ?? tr('Huỷ', 'Cancel')),
          h('button', { class: `btn ${o.danger ? 'danger' : 'gold'}`, on: { click: () => fin(true) } }, o.ok ?? tr('Xác nhận', 'Confirm'))),
      ], () => { if (!done) { done = true; res(false); } });
    });
  }
  clearModals(): void { while (this.closeTopModal()) { /* */ } }
  clearAll(): void { this.clearModals(); this.show(null); clear(this.toastBox); }
}
