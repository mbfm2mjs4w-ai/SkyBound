// Unified input: SPACE / ↑ / W / click / touch → flap; ESC / P → pause; R → restart. One listener set, removable, no duplicates.
import { Emitter } from '../core/events';

export interface InputEvents { flap: null; pause: null; restart: null; confirm: null; back: null; [k: string]: unknown }

export class Input {
  readonly ev = new Emitter<InputEvents>();
  enabled = true;          // gameplay flap enabled
  control: 'all' | 'keyboard' | 'mouse' | 'touch' = 'all';
  private offs: (() => void)[] = [];
  private held = new Set<string>();

  constructor(private surface: HTMLElement) {
    const kd = (e: KeyboardEvent): void => {
      if (e.repeat) return;
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) return;
      const k = e.code;
      if (k === 'Space' || k === 'ArrowUp' || k === 'KeyW') {
        if (this.control === 'mouse' || this.control === 'touch') return;
        if (t && (t.tagName === 'BUTTON' || t.tagName === 'A') && k === 'Space') { /* let the focused button handle space unless gameplay is active */ if (!this.enabled) return; }
        if (this.enabled) { e.preventDefault(); this.ev.emit('flap', null); }
        else if (k === 'Space') this.ev.emit('confirm', null);
      } else if (k === 'Escape' || k === 'KeyP') { this.ev.emit('pause', null); this.ev.emit('back', null); }
      else if (k === 'KeyR') this.ev.emit('restart', null);
      else if (k === 'Enter') this.ev.emit('confirm', null);
      this.held.add(k);
    };
    const ku = (e: KeyboardEvent): void => { this.held.delete(e.code); };
    const pd = (e: PointerEvent): void => {
      if (!this.enabled) return;
      if (e.pointerType === 'mouse' && (this.control === 'keyboard' || this.control === 'touch')) return;
      if (e.pointerType !== 'mouse' && this.control === 'keyboard') return;
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      const t = e.target as HTMLElement;
      if (t.closest('[data-noflap]')) return;
      e.preventDefault();
      this.ev.emit('flap', null);
    };
    const cm = (e: Event): void => { if (this.enabled) e.preventDefault(); };
    window.addEventListener('keydown', kd); window.addEventListener('keyup', ku);
    surface.addEventListener('pointerdown', pd);
    surface.addEventListener('contextmenu', cm);
    this.offs.push(() => { window.removeEventListener('keydown', kd); window.removeEventListener('keyup', ku); surface.removeEventListener('pointerdown', pd); surface.removeEventListener('contextmenu', cm); });
  }
  destroy(): void { for (const o of this.offs) o(); this.offs = []; this.ev.clear(); }
}
