import { Emitter } from '../core/events';
import type { RunResult } from '../core/GameSession';
import { dateKey, weekKey, clamp } from '../core/util';
import type { UnlockRule } from '../core/types';
import { ACHIEVEMENTS, ACH_BY_ID, type AchDef } from '../data/achievements';
import { rollMissions, MISSION_BY_ID, type Reward } from '../data/missions';
import { SKINS, SKIN_BY_ID } from '../data/skins';
import { WORLDS, WORLD_BY_ID } from '../data/worlds';
import { ADVENTURE_LEVELS, ADVENTURE_BY_ID, ADVENTURE_WORLDS, MODES } from '../data/modes';
import { ITEMS, TRAILS, PARTICLE_FX, THEMES, type Price } from '../data/cosmetics';
import type { MissionState, SaveManager } from './SaveManager';

export interface RunSummary {
  result: RunResult;
  xpGained: number; coinsGained: number; gemsGained: number;
  levelBefore: number; levelAfter: number; xpBefore: number; xpAfter: number;
  levelUps: { level: number; reward: Reward }[];
  newBest: boolean; previousBest: number;
  achievements: AchDef[];
  missionsDone: { mission: MissionState; text: string }[];
  unlocked: { kind: 'skin' | 'world'; id: string }[];
  stars: number; adventureFirst: boolean; dailyDone: boolean; bonusCoins: number; bonusGems: number;
}

export type BuyResult = { ok: true } | { ok: false; reason: 'owned' | 'funds' | 'level' | 'locked' | 'unknown'; need?: number | string };

export interface ProgressEvents { [k: string]: unknown; achievement: AchDef; levelup: { level: number; reward: Reward }; unlock: { kind: 'skin' | 'world'; id: string }; currency: null }

export function xpToNext(level: number): number { return Math.round(90 + 40 * level + 2.5 * level * level); }
export const MAX_LEVEL = 100;

export class ProgressionManager {
  readonly ev = new Emitter<ProgressEvents>();
  constructor(readonly sm: SaveManager) { this.ensureMissions(); this.syncUnlocks(); }
  get s() { return this.sm.data; }

  // ------------------------------------------------------------------ levels
  levelProgress(): { level: number; xp: number; need: number; frac: number } {
    const need = xpToNext(this.s.level);
    return { level: this.s.level, xp: this.s.xp, need, frac: clamp(this.s.xp / need, 0, 1) };
  }
  /** Adds XP, handles level-ups (xp stored as progress within the current level). */
  addXp(amount: number): { level: number; reward: Reward }[] {
    const ups: { level: number; reward: Reward }[] = [];
    const s = this.s;
    s.xp += Math.max(0, Math.floor(amount));
    while (s.level < MAX_LEVEL && s.xp >= xpToNext(s.level)) {
      s.xp -= xpToNext(s.level);
      s.level++;
      const reward: Reward = { coins: 40 + 10 * s.level, gems: s.level % 5 === 0 ? 2 : 0, xp: 0 };
      s.coins += reward.coins; s.gems += reward.gems;
      ups.push({ level: s.level, reward });
      this.ev.emit('levelup', { level: s.level, reward });
    }
    if (s.level >= MAX_LEVEL) s.xp = Math.min(s.xp, xpToNext(MAX_LEVEL) - 1);
    return ups;
  }

  // ------------------------------------------------------------------ missions
  ensureMissions(): void {
    const m = this.s.missions;
    const dk = dateKey(), wk = weekKey();
    let changed = false;
    if (m.dayKey !== dk || m.daily.length === 0) { m.dayKey = dk; m.daily = rollMissions('daily', dk); changed = true; }
    if (m.weekKey !== wk || m.weekly.length === 0) { m.weekKey = wk; m.weekly = rollMissions('weekly', wk); changed = true; }
    if (changed) this.sm.touch();
  }
  private feedMission(m: MissionState, res: RunResult): boolean {
    const tpl = MISSION_BY_ID[m.tpl];
    if (!tpl || m.claimed || m.progress >= m.target) return false;
    let v = 0;
    switch (tpl.stat) {
      case 'games': v = 1; break;
      case 'gates': v = res.gates; break;
      case 'coins': v = res.coins; break;
      case 'powerups': v = res.powerups; break;
      case 'perfects': v = res.perfects; break;
      case 'distance': v = res.distance; break;
      case 'maxCombo': v = res.maxCombo; break;
      case 'bestScore': v = res.score; break;
      case 'bosses': v = res.bossesDefeated; break;
      case 'adventure': v = res.adventureId && res.completed ? 1 : 0; break;
      case 'gems': v = res.gems; break;
    }
    const before = m.progress;
    m.progress = tpl.kind === 'max' ? Math.max(m.progress, v) : m.progress + v;
    m.progress = Math.min(m.progress, m.target);
    return before < m.target && m.progress >= m.target;
  }
  claimMission(id: string): Reward | null {
    for (const m of [...this.s.missions.daily, ...this.s.missions.weekly]) {
      if (m.id !== id) continue;
      if (m.claimed || m.progress < m.target) return null;
      const tpl = MISSION_BY_ID[m.tpl];
      if (!tpl) return null;
      m.claimed = true;
      this.grant(tpl.reward);
      this.sm.touch();
      return tpl.reward;
    }
    return null;
  }
  grant(r: Reward): void {
    this.s.coins += r.coins; this.s.gems += r.gems;
    if (r.xp) this.addXp(r.xp);
    this.ev.emit('currency', null);
  }

  // ------------------------------------------------------------------ run processing
  processRun(res: RunResult): RunSummary {
    this.ensureMissions();
    const s = this.s;
    const mode = MODES[res.mode];
    const levelBefore = s.level, xpBefore = s.xp;
    const previousBest = s.best[res.mode] ?? 0;
    const summary: RunSummary = {
      result: res, xpGained: 0, coinsGained: res.coins, gemsGained: res.gems, levelBefore, levelAfter: levelBefore, xpBefore, xpAfter: xpBefore,
      levelUps: [], newBest: false, previousBest, achievements: [], missionsDone: [], unlocked: [], stars: res.stars, adventureFirst: false, dailyDone: false, bonusCoins: 0, bonusGems: 0,
    };
    // ---- currencies
    s.coins += res.coins; s.gems += res.gems;
    // ---- stats
    const st = s.stats;
    st.games++; if (!res.completed && mode.scored && res.mode !== 'zen') st.deaths++;
    st.gates += res.gates; st.coins += res.coins; st.gems += res.gems; st.distance += res.distance; st.flaps += res.flaps;
    st.powerups += res.powerups; st.perfects += res.perfects; st.bosses += res.bossesDefeated; st.playTime += res.time;
    st.maxCombo = Math.max(st.maxCombo, res.maxCombo);
    if (res.mode === 'zen') st.zenTime += res.time;
    if (!st.worldsSeen.includes(res.worldId) && WORLD_BY_ID[res.worldId]) st.worldsSeen.push(res.worldId);
    if (!st.modesPlayed.includes(res.mode)) st.modesPlayed.push(res.mode);
    // ---- best score
    if (mode.scored && res.mode !== 'adventure') {
      if (res.score > previousBest) { s.best[res.mode] = res.score; summary.newBest = previousBest > 0 || res.score > 0; }
    }
    s.recent.push(res.score); if (s.recent.length > 8) s.recent.shift();
    // ---- adventure
    if (res.adventureId && ADVENTURE_BY_ID[res.adventureId]) {
      const lvl = ADVENTURE_BY_ID[res.adventureId];
      const cur = s.adventure[lvl.id] ?? { stars: 0, best: 0 };
      if (res.completed) {
        summary.adventureFirst = cur.stars === 0;
        if (summary.adventureFirst) { const bonus = 30 + 10 * lvl.chapter; s.coins += bonus; summary.bonusCoins += bonus; if (lvl.n === 2) { s.gems += 2; summary.bonusGems += 2; } }
        cur.stars = Math.max(cur.stars, res.stars);
      }
      cur.best = Math.max(cur.best, res.score);
      s.adventure[lvl.id] = cur;
    }
    // ---- daily
    if (res.mode === 'daily' && res.dailyKey) {
      if (s.daily.key !== res.dailyKey) { s.daily = { key: res.dailyKey, done: false, best: 0 }; }
      s.daily.best = Math.max(s.daily.best, res.score);
      if (res.completed && !s.daily.done) {
        s.daily.done = true; st.dailyDone++; summary.dailyDone = true;
        s.gems += 5; summary.bonusGems += 5; s.coins += 100; summary.bonusCoins += 100;
      }
    }
    // ---- boss bonuses already included in res.coins / gems; xp for bosses
    // ---- secrets
    if (res.secretFound) { if (!s.secrets.secret_portal) st.secretsFound++; s.secrets.secret_portal = true; }
    if (res.score >= 60 && res.mode !== 'zen') s.secrets.score_60 = true;
    if (res.mode === 'hardcore' && res.score >= 100) s.secrets.hardcore_100 = true;
    // ---- xp
    let xp = (res.score * 3 + res.distance / 15 + res.coins * 0.6 + res.perfects * 0.5 + res.bossesDefeated * 80 + (res.completed ? 60 : 0)) * mode.xpMul;
    xp = Math.max(res.time > 3 ? 5 : 0, Math.floor(xp));
    summary.xpGained = xp;
    summary.levelUps = this.addXp(xp);
    // ---- missions
    for (const m of [...s.missions.daily, ...s.missions.weekly]) {
      if (this.feedMission(m, res)) summary.missionsDone.push({ mission: m, text: m.id });
    }
    // ---- unlocks & achievements (loop: achievements can unlock skins which can unlock achievements)
    for (let i = 0; i < 4; i++) {
      const u = this.syncUnlocks();
      summary.unlocked.push(...u);
      const got = this.checkAchievements(res);
      summary.achievements.push(...got);
      if (!u.length && !got.length) break;
    }
    summary.levelAfter = s.level; summary.xpAfter = s.xp;
    this.sm.touch();
    return summary;
  }

  // ------------------------------------------------------------------ achievements
  checkAchievements(run: Partial<RunResult> | null = null): AchDef[] {
    const out: AchDef[] = [];
    const s = this.s;
    for (const a of ACHIEVEMENTS) {
      if (s.achievements[a.id]) continue;
      let pass = false;
      try { pass = a.check({ save: s, run }); } catch { pass = false; }
      if (!pass) continue;
      s.achievements[a.id] = Date.now();
      s.coins += a.reward.coins; s.gems += a.reward.gems;
      if (a.reward.xp) this.addXp(a.reward.xp);
      out.push(a);
      this.ev.emit('achievement', a);
      this.sm.touch();
    }
    return out;
  }
  /** Live check while playing (cheap): only score-based achievements can trigger. */
  checkLive(run: Partial<RunResult>): AchDef[] { return this.checkAchievements(run); }

  // ------------------------------------------------------------------ unlock rules
  /** Skins / worlds that unlock from achievements or secrets. Returns what was newly unlocked. */
  syncUnlocks(): { kind: 'skin' | 'world'; id: string }[] {
    const s = this.s;
    const out: { kind: 'skin' | 'world'; id: string }[] = [];
    // collection secrets
    const others = SKINS.filter((k) => k.id !== 'ultimate_celestial');
    if (others.every((k) => s.unlockedSkins.includes(k.id))) s.secrets.all_skins = true;
    const otherWorlds = WORLDS.filter((w) => w.id !== 'infinity_universe');
    if (otherWorlds.every((w) => s.unlockedWorlds.includes(w.id)) && s.achievements.adventure_complete) s.secrets.all_worlds = true;
    for (const k of SKINS) {
      if (s.unlockedSkins.includes(k.id)) continue;
      const u = k.unlock;
      if ((u.type === 'achievement' && s.achievements[u.id]) || (u.type === 'secret' && s.secrets[u.id])) {
        s.unlockedSkins.push(k.id); out.push({ kind: 'skin', id: k.id }); this.ev.emit('unlock', { kind: 'skin', id: k.id });
      }
    }
    for (const w of WORLDS) {
      if (s.unlockedWorlds.includes(w.id)) continue;
      const u = w.unlock;
      if (u.type === 'secret' && s.secrets[u.id]) {
        s.unlockedWorlds.push(w.id); out.push({ kind: 'world', id: w.id }); this.ev.emit('unlock', { kind: 'world', id: w.id });
      }
    }
    // adventure chapters unlock their world for free play
    for (let c = 0; c < ADVENTURE_WORLDS.length; c++) {
      const id = ADVENTURE_WORLDS[c];
      const done = ADVENTURE_LEVELS.filter((l) => l.chapter === c).every((l) => (s.adventure[l.id]?.stars ?? 0) > 0);
      if (done && !s.unlockedWorlds.includes(id)) { s.unlockedWorlds.push(id); out.push({ kind: 'world', id }); this.ev.emit('unlock', { kind: 'world', id }); }
    }
    if (out.length) this.sm.touch();
    return out;
  }

  priceOf(rule: UnlockRule): Price {
    switch (rule.type) {
      case 'coins': return { coins: rule.price };
      case 'gems': return { gems: rule.price };
      case 'level': return rule.price ? { coins: rule.price } : {};
      default: return {};
    }
  }
  private pay(p: Price): BuyResult {
    const s = this.s;
    if ((p.coins ?? 0) > s.coins) return { ok: false, reason: 'funds', need: (p.coins ?? 0) - s.coins };
    if ((p.gems ?? 0) > s.gems) return { ok: false, reason: 'funds', need: (p.gems ?? 0) - s.gems };
    s.coins -= p.coins ?? 0; s.gems -= p.gems ?? 0;
    return { ok: true };
  }
  canBuySkin(id: string): BuyResult {
    const k = SKIN_BY_ID[id];
    if (!k) return { ok: false, reason: 'unknown' };
    if (this.s.unlockedSkins.includes(id)) return { ok: false, reason: 'owned' };
    const u = k.unlock;
    if (u.type === 'achievement' || u.type === 'secret') return { ok: false, reason: 'locked' };
    if (u.type === 'gems' && u.minLevel && this.s.level < u.minLevel) return { ok: false, reason: 'level', need: u.minLevel };
    if (u.type === 'level' && this.s.level < u.level) return { ok: false, reason: 'level', need: u.level };
    const p = this.priceOf(u);
    if ((p.coins ?? 0) > this.s.coins || (p.gems ?? 0) > this.s.gems) return { ok: false, reason: 'funds' };
    return { ok: true };
  }
  buySkin(id: string): BuyResult {
    const chk = this.canBuySkin(id);
    if (!chk.ok && chk.reason !== 'funds') return chk;
    const k = SKIN_BY_ID[id];
    const r = this.pay(this.priceOf(k.unlock));
    if (!r.ok) return r;
    this.s.unlockedSkins.push(id);
    this.syncUnlocks(); this.checkAchievements();
    this.ev.emit('unlock', { kind: 'skin', id });
    this.sm.touch();
    return { ok: true };
  }
  canBuyWorld(id: string): BuyResult {
    const w = WORLD_BY_ID[id];
    if (!w) return { ok: false, reason: 'unknown' };
    if (this.s.unlockedWorlds.includes(id)) return { ok: false, reason: 'owned' };
    const u = w.unlock;
    if (u.type === 'secret' || u.type === 'achievement') return { ok: false, reason: 'locked' };
    if (u.type === 'level' && this.s.level < u.level) return { ok: false, reason: 'level', need: u.level };
    const p = this.priceOf(u);
    if ((p.coins ?? 0) > this.s.coins || (p.gems ?? 0) > this.s.gems) return { ok: false, reason: 'funds' };
    return { ok: true };
  }
  buyWorld(id: string): BuyResult {
    const chk = this.canBuyWorld(id);
    if (!chk.ok && chk.reason !== 'funds') return chk;
    const w = WORLD_BY_ID[id];
    const r = this.pay(this.priceOf(w.unlock));
    if (!r.ok) return r;
    this.s.unlockedWorlds.push(id);
    this.syncUnlocks(); this.checkAchievements();
    this.ev.emit('unlock', { kind: 'world', id });
    this.sm.touch();
    return { ok: true };
  }
  buyCosmetic(kind: 'trail' | 'fx' | 'theme' | 'item', id: string): BuyResult {
    const s = this.s;
    let price: Price | undefined; let list: string[];
    switch (kind) {
      case 'trail': price = TRAILS.find((t) => t.id === id)?.price; list = s.ownedTrails; break;
      case 'fx': price = PARTICLE_FX.find((t) => t.id === id)?.price; list = s.ownedFx; break;
      case 'theme': price = THEMES.find((t) => t.id === id)?.price; list = s.ownedThemes; break;
      case 'item': price = ITEMS.find((t) => t.id === id)?.price; list = s.ownedItems; break;
    }
    if (!price) return { ok: false, reason: 'unknown' };
    if (list.includes(id)) return { ok: false, reason: 'owned' };
    const r = this.pay(price);
    if (!r.ok) return r;
    list.push(id);
    this.sm.touch();
    return { ok: true };
  }
  equipSkin(id: string): boolean { if (!this.s.unlockedSkins.includes(id)) return false; this.s.equippedSkin = id; this.s.profile.avatar = id; this.sm.touch(); return true; }
  equipCosmetic(kind: 'trail' | 'fx' | 'theme' | 'item', id: string | null): boolean {
    const s = this.s;
    switch (kind) {
      case 'trail': if (id !== null && !s.ownedTrails.includes(id)) return false; s.equipped.trail = id; break;
      case 'fx': if (id !== null && !s.ownedFx.includes(id)) return false; s.equipped.fx = id; break;
      case 'theme': if (!id || !s.ownedThemes.includes(id)) return false; s.equipped.theme = id; break;
      case 'item': if (id !== null && !s.ownedItems.includes(id)) return false; s.equipped.item = id; break;
    }
    this.sm.touch(); return true;
  }
  selectWorld(id: string): boolean { if (!this.s.unlockedWorlds.includes(id)) return false; this.s.selectedWorld = id; this.sm.touch(); return true; }

  /** 0..1 adaptive assist from recent performance: struggling players get slightly wider gaps / slower pace. */
  assist(): number {
    const r = this.s.recent;
    if (r.length < 3) return 0.35;                 // new players: gentle start
    const avg = r.slice(-4).reduce((a, b) => a + b, 0) / Math.min(4, r.length);
    if (avg < 4) return 1; if (avg < 8) return 0.6; if (avg < 14) return 0.25; return 0;
  }
  adventureUnlocked(index: number): boolean {
    if (index <= 0) return true;
    return (this.s.adventure[ADVENTURE_LEVELS[index - 1].id]?.stars ?? 0) > 0;
  }
}
export { ACH_BY_ID };
