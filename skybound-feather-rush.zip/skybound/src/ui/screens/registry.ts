import type { AppApi, ScreenName } from '../../app/types';
import type { Screen } from '../UI';
import { worldsScreen, collectionScreen, shopScreen } from './collect';
import { missionsScreen, achievementsScreen, leaderboardScreen, profileScreen, settingsScreen } from './social';
export const SCREENS_EXTRA: Partial<Record<ScreenName, (a: AppApi) => Screen>> = {
  worlds: worldsScreen, collection: collectionScreen, shop: shopScreen, missions: missionsScreen, achievements: achievementsScreen, leaderboard: leaderboardScreen, profile: profileScreen, settings: settingsScreen,
};
