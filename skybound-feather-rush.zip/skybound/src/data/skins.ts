import type { L10n, ParticleKind, TrailKind, UnlockRule } from '../core/types';

export type WingStyle = 'feather' | 'bat' | 'crystal' | 'flame' | 'electric' | 'petal' | 'leaf' | 'star' | 'ethereal';
export type TailStyle = 'fan' | 'split' | 'ribbon' | 'peacock' | 'flame' | 'crystal' | 'comet' | 'dragon' | 'halo';
export type CrestStyle = 'none' | 'tuft' | 'spike' | 'plume' | 'crown' | 'horns' | 'flame' | 'halo' | 'antenna' | 'petal' | 'moonhorn';
export type BodyStyle = 'round' | 'sleek' | 'plump';
export type SkinTier = 'standard' | 'premium' | 'secret';
/** Burst style when a power-up / boost is activated with this skin. */
export type BurstKind = 'petals' | 'shards' | 'leaves' | 'lightning' | 'feathers' | 'pixels' | 'stars' | 'flames' | 'rings' | 'smoke';

export interface SkinColors {
  body: string; body2: string; belly: string;
  wing: string; wing2: string; tail: string;
  beak: string; eye: string; accent: string; glow: string;
}
export interface SkinVoice {
  /** Wing flap sound: oscillator wave, base frequency (Hz), pitch glide (semitones), noise (0..1 breathiness) */
  flap: { wave: OscillatorType; base: number; glide: number; noise: number };
  /** Skill (power-up / boost) jingle: wave, root Hz, scale in semitones */
  skill: { wave: OscillatorType; root: number; scale: number[] };
}
export interface SkinDef {
  id: string;
  name: string;
  tier: SkinTier;
  colors: SkinColors;
  rainbow?: boolean;        // renderer cycles the hue over time
  body: BodyStyle;
  wing: WingStyle;
  wingLayers: number;       // 3..6 feather layers per wing
  tail: TailStyle;
  crest: CrestStyle;
  anim: { flapSpeed: number; flapAmp: number; bob: number; tilt: number };
  particle: ParticleKind;   // ambient particle shed while flying
  trail: TrailKind;
  fx: BurstKind;
  voice: SkinVoice;
  unlock: UnlockRule;
  desc: L10n;
}

const hint = (vi: string, en: string): L10n => ({ vi, en });
const pent = [0, 2, 4, 7, 9, 12];
const major = [0, 4, 7, 12, 16, 19];
const minor = [0, 3, 7, 10, 12, 15];
const lydian = [0, 2, 4, 6, 7, 11];

export const SKINS: SkinDef[] = [
  {
    id: 'sakura_bird', name: 'Sakura Bird', tier: 'standard',
    colors: { body: '#ffb7d5', body2: '#ff8fbd', belly: '#fff0f6', wing: '#ff9ac6', wing2: '#ffd1e6', tail: '#ff7fb0', beak: '#ffb347', eye: '#3a1d3f', accent: '#ffffff', glow: '#ffb3d9' },
    body: 'plump', wing: 'petal', wingLayers: 4, tail: 'fan', crest: 'petal',
    anim: { flapSpeed: 1, flapAmp: 1, bob: 1, tilt: 1 }, particle: 'petal', trail: 'petals', fx: 'petals',
    voice: { flap: { wave: 'sine', base: 520, glide: 5, noise: 0.25 }, skill: { wave: 'sine', root: 523, scale: pent } },
    unlock: { type: 'free' }, desc: { vi: 'Chú chim anh đào hiền lành — người bạn đầu tiên của bạn.', en: 'A gentle blossom bird — your very first companion.' },
  },
  {
    id: 'ice_crystal', name: 'Ice Crystal', tier: 'standard',
    colors: { body: '#bfeaff', body2: '#7fd0ff', belly: '#f2fbff', wing: '#9fe0ff', wing2: '#e6f8ff', tail: '#7ac6ff', beak: '#ffd86b', eye: '#12335a', accent: '#ffffff', glow: '#9fe8ff' },
    body: 'round', wing: 'crystal', wingLayers: 4, tail: 'crystal', crest: 'spike',
    anim: { flapSpeed: 0.95, flapAmp: 0.9, bob: 0.8, tilt: 0.9 }, particle: 'snow', trail: 'frost', fx: 'shards',
    voice: { flap: { wave: 'triangle', base: 780, glide: 3, noise: 0.1 }, skill: { wave: 'triangle', root: 659, scale: lydian } },
    unlock: { type: 'coins', price: 600 }, desc: { vi: 'Đôi cánh pha lê lấp lánh như băng giá.', en: 'Crystalline wings that sparkle like fresh ice.' },
  },
  {
    id: 'emerald_guardian', name: 'Emerald Guardian', tier: 'standard',
    colors: { body: '#3ddc84', body2: '#17a35f', belly: '#d8ffe5', wing: '#1d8f58', wing2: '#7affb5', tail: '#14784a', beak: '#f5c542', eye: '#07281a', accent: '#ffe27a', glow: '#6dffb0' },
    body: 'round', wing: 'leaf', wingLayers: 4, tail: 'fan', crest: 'tuft',
    anim: { flapSpeed: 1, flapAmp: 1.05, bob: 1, tilt: 1 }, particle: 'leaf', trail: 'orbs', fx: 'leaves',
    voice: { flap: { wave: 'triangle', base: 330, glide: 4, noise: 0.35 }, skill: { wave: 'triangle', root: 392, scale: major } },
    unlock: { type: 'coins', price: 800 }, desc: { vi: 'Người bảo vệ thung lũng xanh.', en: 'Protector of the green valley.' },
  },
  {
    id: 'thunder_wing', name: 'Thunder Wing', tier: 'standard',
    colors: { body: '#ffd23f', body2: '#f2a900', belly: '#fff4c2', wing: '#3a3f9e', wing2: '#7b86ff', tail: '#2c2f7a', beak: '#ff8a3d', eye: '#10123a', accent: '#fff36b', glow: '#b9c2ff' },
    body: 'sleek', wing: 'electric', wingLayers: 4, tail: 'split', crest: 'spike',
    anim: { flapSpeed: 1.25, flapAmp: 1.1, bob: 0.7, tilt: 1.2 }, particle: 'bolt', trail: 'lightning', fx: 'lightning',
    voice: { flap: { wave: 'sawtooth', base: 240, glide: 7, noise: 0.45 }, skill: { wave: 'square', root: 330, scale: pent } },
    unlock: { type: 'coins', price: 1000 }, desc: { vi: 'Mang theo sấm sét trên đôi cánh.', en: 'Carries thunder on its wings.' },
  },
  {
    id: 'storm_eagle', name: 'Storm Eagle', tier: 'standard',
    colors: { body: '#6b7a99', body2: '#46546f', belly: '#dfe6f2', wing: '#39465f', wing2: '#8da0c4', tail: '#2b3548', beak: '#ffcc4d', eye: '#ffdd55', accent: '#bcd0ff', glow: '#9ab6ff' },
    body: 'sleek', wing: 'feather', wingLayers: 5, tail: 'fan', crest: 'tuft',
    anim: { flapSpeed: 0.85, flapAmp: 1.25, bob: 0.6, tilt: 1.1 }, particle: 'smoke', trail: 'ribbon', fx: 'smoke',
    voice: { flap: { wave: 'sawtooth', base: 170, glide: 3, noise: 0.6 }, skill: { wave: 'sawtooth', root: 262, scale: minor } },
    unlock: { type: 'coins', price: 1200 }, desc: { vi: 'Chúa tể của những cơn bão.', en: 'Lord of the storm winds.' },
  },
  {
    id: 'neon_cyber', name: 'Neon Cyber', tier: 'standard',
    colors: { body: '#1a1f3a', body2: '#0d1127', belly: '#2a3566', wing: '#00e5ff', wing2: '#ff2bd6', tail: '#00e5ff', beak: '#ff2bd6', eye: '#00ffd5', accent: '#00ffd5', glow: '#00e5ff' },
    body: 'sleek', wing: 'electric', wingLayers: 3, tail: 'split', crest: 'antenna',
    anim: { flapSpeed: 1.15, flapAmp: 0.95, bob: 0.9, tilt: 1 }, particle: 'spark', trail: 'neon', fx: 'pixels',
    voice: { flap: { wave: 'square', base: 400, glide: 12, noise: 0.05 }, skill: { wave: 'square', root: 440, scale: pent } },
    unlock: { type: 'coins', price: 1500 }, desc: { vi: 'Android hoá chim từ tương lai.', en: 'A bird rebuilt in the neon future.' },
  },
  {
    id: 'lunar_spirit', name: 'Lunar Spirit', tier: 'standard',
    colors: { body: '#dfe6ff', body2: '#a9b8ff', belly: '#ffffff', wing: '#b8c5ff', wing2: '#f1f4ff', tail: '#8d9cff', beak: '#ffe9a8', eye: '#25306b', accent: '#fff6c7', glow: '#c9d4ff' },
    body: 'plump', wing: 'ethereal', wingLayers: 4, tail: 'comet', crest: 'moonhorn',
    anim: { flapSpeed: 0.8, flapAmp: 1.1, bob: 1.3, tilt: 0.8 }, particle: 'star', trail: 'stardust', fx: 'stars',
    voice: { flap: { wave: 'sine', base: 392, glide: -3, noise: 0.15 }, skill: { wave: 'sine', root: 494, scale: lydian } },
    unlock: { type: 'coins', price: 2000 }, desc: { vi: 'Linh hồn của ánh trăng bạc.', en: 'Spirit of the silver moonlight.' },
  },
  {
    id: 'flame_dragon_bird', name: 'Flame Dragon Bird', tier: 'premium',
    colors: { body: '#ff6a2b', body2: '#d62d20', belly: '#ffd37a', wing: '#ff3d1f', wing2: '#ffb347', tail: '#ff4d1a', beak: '#2a1a14', eye: '#fff17a', accent: '#ffe08a', glow: '#ff7a2b' },
    body: 'sleek', wing: 'flame', wingLayers: 5, tail: 'dragon', crest: 'horns',
    anim: { flapSpeed: 1.1, flapAmp: 1.2, bob: 0.8, tilt: 1.1 }, particle: 'ember', trail: 'flame', fx: 'flames',
    voice: { flap: { wave: 'sawtooth', base: 150, glide: 8, noise: 0.7 }, skill: { wave: 'sawtooth', root: 220, scale: minor } },
    unlock: { type: 'gems', price: 60 }, desc: { vi: 'Nửa rồng nửa chim, thở ra lửa.', en: 'Half dragon, half bird, breathes fire.' },
  },
  {
    id: 'crystal_angel', name: 'Crystal Angel', tier: 'premium',
    colors: { body: '#f7f2ff', body2: '#d7c8ff', belly: '#ffffff', wing: '#ffffff', wing2: '#c9b6ff', tail: '#e8dcff', beak: '#ffd27a', eye: '#6a4cff', accent: '#ffe6a6', glow: '#d9c8ff' },
    body: 'round', wing: 'feather', wingLayers: 6, tail: 'halo', crest: 'halo',
    anim: { flapSpeed: 0.85, flapAmp: 1.2, bob: 1.2, tilt: 0.8 }, particle: 'feather', trail: 'glow', fx: 'feathers',
    voice: { flap: { wave: 'sine', base: 659, glide: 2, noise: 0.08 }, skill: { wave: 'sine', root: 784, scale: major } },
    unlock: { type: 'gems', price: 80 }, desc: { vi: 'Thiên thần pha lê với vầng hào quang.', en: 'A crystal angel with a luminous halo.' },
  },
  {
    id: 'royal_peacock', name: 'Royal Peacock', tier: 'premium',
    colors: { body: '#1f9bd7', body2: '#0e5fb0', belly: '#7ee7d1', wing: '#0b7a75', wing2: '#38e0a8', tail: '#0aa37f', beak: '#ffbf47', eye: '#0a1f3a', accent: '#ffd24a', glow: '#4be3ff' },
    body: 'plump', wing: 'feather', wingLayers: 5, tail: 'peacock', crest: 'plume',
    anim: { flapSpeed: 0.9, flapAmp: 1, bob: 1, tilt: 1 }, particle: 'feather', trail: 'ribbon', fx: 'feathers',
    voice: { flap: { wave: 'triangle', base: 440, glide: 6, noise: 0.2 }, skill: { wave: 'triangle', root: 440, scale: lydian } },
    unlock: { type: 'gems', price: 100 }, desc: { vi: 'Chiếc đuôi hoàng gia đẹp nhất bầu trời.', en: 'The most majestic tail in the sky.' },
  },
  {
    id: 'golden_phoenix', name: 'Golden Phoenix', tier: 'premium',
    colors: { body: '#ffcf3a', body2: '#ff9d1a', belly: '#fff1b0', wing: '#ffb81f', wing2: '#fff2a0', tail: '#ff8a1a', beak: '#ff6a1a', eye: '#5a1a00', accent: '#fff7c2', glow: '#ffd75a' },
    body: 'sleek', wing: 'flame', wingLayers: 6, tail: 'ribbon', crest: 'plume',
    anim: { flapSpeed: 0.9, flapAmp: 1.25, bob: 1, tilt: 1 }, particle: 'ember', trail: 'flame', fx: 'flames',
    voice: { flap: { wave: 'triangle', base: 294, glide: 7, noise: 0.4 }, skill: { wave: 'triangle', root: 349, scale: major } },
    unlock: { type: 'gems', price: 120 }, desc: { vi: 'Phượng hoàng vàng tái sinh từ tro tàn.', en: 'A golden phoenix reborn from ashes.' },
  },
  {
    id: 'solar_phoenix', name: 'Solar Phoenix', tier: 'premium',
    colors: { body: '#ff7b1f', body2: '#ff3d00', belly: '#ffe08a', wing: '#ff9f1a', wing2: '#fff08a', tail: '#ff4d00', beak: '#ffe9a0', eye: '#fff8cc', accent: '#ffffff', glow: '#ffb347' },
    body: 'sleek', wing: 'flame', wingLayers: 6, tail: 'flame', crest: 'flame',
    anim: { flapSpeed: 1, flapAmp: 1.3, bob: 0.9, tilt: 1.1 }, particle: 'spark', trail: 'flame', fx: 'flames',
    voice: { flap: { wave: 'sawtooth', base: 196, glide: 9, noise: 0.55 }, skill: { wave: 'sawtooth', root: 294, scale: major } },
    unlock: { type: 'gems', price: 150 }, desc: { vi: 'Mang trong mình ngọn lửa của mặt trời.', en: 'Carries the fire of the sun.' },
  },
  {
    id: 'galaxy_spirit', name: 'Galaxy Spirit', tier: 'premium',
    colors: { body: '#2a1b5e', body2: '#150d3a', belly: '#5a3ea8', wing: '#6c4bff', wing2: '#ff6ad5', tail: '#4a2fb0', beak: '#ffd24a', eye: '#9ff3ff', accent: '#9ff3ff', glow: '#9a7bff' },
    body: 'round', wing: 'star', wingLayers: 4, tail: 'comet', crest: 'antenna',
    anim: { flapSpeed: 0.9, flapAmp: 1.1, bob: 1.2, tilt: 0.9 }, particle: 'star', trail: 'stardust', fx: 'stars',
    voice: { flap: { wave: 'sine', base: 262, glide: 12, noise: 0.1 }, skill: { wave: 'sine', root: 330, scale: lydian } },
    unlock: { type: 'gems', price: 180 }, desc: { vi: 'Linh hồn chứa cả dải ngân hà.', en: 'A spirit that holds a whole galaxy.' },
  },
  {
    id: 'frozen_legend', name: 'Frozen Legend', tier: 'premium',
    colors: { body: '#a9e5ff', body2: '#4aa9e8', belly: '#ffffff', wing: '#d9f4ff', wing2: '#5ec3ff', tail: '#8fd6ff', beak: '#e8f7ff', eye: '#0c3b6e', accent: '#ffffff', glow: '#b5ecff' },
    body: 'plump', wing: 'crystal', wingLayers: 6, tail: 'crystal', crest: 'crown',
    anim: { flapSpeed: 0.8, flapAmp: 1.15, bob: 0.9, tilt: 0.9 }, particle: 'snow', trail: 'frost', fx: 'shards',
    voice: { flap: { wave: 'triangle', base: 880, glide: 2, noise: 0.12 }, skill: { wave: 'sine', root: 784, scale: major } },
    unlock: { type: 'gems', price: 200 }, desc: { vi: 'Huyền thoại của vương quốc băng giá.', en: 'The legend of the frozen empire.' },
  },
  {
    id: 'rainbow_legend', name: 'Rainbow Legend', tier: 'premium', rainbow: true,
    colors: { body: '#ff6ad5', body2: '#6ad1ff', belly: '#ffffff', wing: '#ffe45e', wing2: '#7affc1', tail: '#b36bff', beak: '#ffb347', eye: '#2a1a4a', accent: '#ffffff', glow: '#ffffff' },
    body: 'plump', wing: 'feather', wingLayers: 6, tail: 'ribbon', crest: 'plume',
    anim: { flapSpeed: 1, flapAmp: 1.2, bob: 1.1, tilt: 1 }, particle: 'confetti', trail: 'rainbow', fx: 'rings',
    voice: { flap: { wave: 'triangle', base: 523, glide: 9, noise: 0.15 }, skill: { wave: 'triangle', root: 523, scale: major } },
    unlock: { type: 'gems', price: 250, minLevel: 20 }, desc: { vi: 'Mọi sắc màu trong một chú chim. Cần cấp 20.', en: 'Every color in one bird. Requires level 20.' },
  },
  {
    id: 'astral_phoenix', name: 'Astral Phoenix', tier: 'premium',
    colors: { body: '#7d5bff', body2: '#3a1fb0', belly: '#cbb8ff', wing: '#4f6bff', wing2: '#ff9bff', tail: '#c06bff', beak: '#ffe5a0', eye: '#ffffff', accent: '#e6dcff', glow: '#a58bff' },
    body: 'sleek', wing: 'flame', wingLayers: 6, tail: 'ribbon', crest: 'flame',
    anim: { flapSpeed: 0.9, flapAmp: 1.3, bob: 1.1, tilt: 1 }, particle: 'star', trail: 'stardust', fx: 'stars',
    voice: { flap: { wave: 'sine', base: 247, glide: 10, noise: 0.3 }, skill: { wave: 'sawtooth', root: 330, scale: lydian } },
    unlock: { type: 'gems', price: 300 }, desc: { vi: 'Phượng hoàng tinh tú, thiêu đốt bầu trời đêm.', en: 'A starfire phoenix that lights the night.' },
  },
  {
    id: 'ancient_dragon', name: 'Ancient Dragon', tier: 'secret',
    colors: { body: '#2e7d5b', body2: '#17503a', belly: '#e8d9a0', wing: '#7a3f2b', wing2: '#c98a3a', tail: '#1b5c43', beak: '#d9b45a', eye: '#ffd23f', accent: '#ffd23f', glow: '#8affc1' },
    body: 'sleek', wing: 'bat', wingLayers: 4, tail: 'dragon', crest: 'horns',
    anim: { flapSpeed: 0.75, flapAmp: 1.35, bob: 0.7, tilt: 1.2 }, particle: 'smoke', trail: 'shadow', fx: 'smoke',
    voice: { flap: { wave: 'sawtooth', base: 110, glide: 4, noise: 0.8 }, skill: { wave: 'sawtooth', root: 165, scale: minor } },
    unlock: { type: 'achievement', id: 'adventure_complete', hint: hint('Hoàn thành toàn bộ 20 màn Phiêu lưu.', 'Complete all 20 Adventure levels.') },
    desc: { vi: 'Rồng cổ đại thức dậy sau ngàn năm.', en: 'An ancient dragon awakened after a thousand years.' },
  },
  {
    id: 'shadow_raven', name: 'Shadow Raven', tier: 'secret',
    colors: { body: '#1b1b2a', body2: '#0a0a14', belly: '#2c2c46', wing: '#262640', wing2: '#6a4cff', tail: '#14141f', beak: '#3a3a58', eye: '#c5a3ff', accent: '#8a5bff', glow: '#7a5bff' },
    body: 'sleek', wing: 'feather', wingLayers: 5, tail: 'split', crest: 'tuft',
    anim: { flapSpeed: 1, flapAmp: 1.1, bob: 0.8, tilt: 1 }, particle: 'smoke', trail: 'shadow', fx: 'smoke',
    voice: { flap: { wave: 'triangle', base: 130, glide: -5, noise: 0.5 }, skill: { wave: 'sawtooth', root: 185, scale: minor } },
    unlock: { type: 'secret', id: 'secret_portal', hint: hint('Tìm và bay qua Cổng Bí Mật (xuất hiện hiếm ở chế độ Endless/Hardcore sau 30 điểm).', 'Find and fly through a Secret Portal (rarely appears in Endless/Hardcore after 30 points).') },
    desc: { vi: 'Con quạ của chiều không gian tối.', en: 'The raven of the dark dimension.' },
  },
  {
    id: 'cosmic_emperor', name: 'Cosmic Emperor', tier: 'secret',
    colors: { body: '#ffd166', body2: '#e09f3e', belly: '#fff3c4', wing: '#7a1fa2', wing2: '#ff5dd1', tail: '#4c1d95', beak: '#fff3c4', eye: '#1a1a40', accent: '#fff3c4', glow: '#ffd166' },
    body: 'plump', wing: 'star', wingLayers: 6, tail: 'peacock', crest: 'crown',
    anim: { flapSpeed: 0.85, flapAmp: 1.3, bob: 1, tilt: 1 }, particle: 'star', trail: 'rainbow', fx: 'stars',
    voice: { flap: { wave: 'triangle', base: 220, glide: 7, noise: 0.25 }, skill: { wave: 'sawtooth', root: 262, scale: major } },
    unlock: { type: 'secret', id: 'hardcore_100', hint: hint('Đạt 100 điểm trong chế độ Hardcore.', 'Reach 100 points in Hardcore mode.') },
    desc: { vi: 'Hoàng đế của vũ trụ.', en: 'Emperor of the cosmos.' },
  },
  {
    id: 'ultimate_celestial', name: 'Ultimate Celestial', tier: 'secret',
    colors: { body: '#ffffff', body2: '#ffe9a0', belly: '#fffdf2', wing: '#fff7d1', wing2: '#ffd36a', tail: '#ffe9a0', beak: '#ffd36a', eye: '#4b2e00', accent: '#ffffff', glow: '#fff2b0' },
    body: 'round', wing: 'ethereal', wingLayers: 6, tail: 'halo', crest: 'halo',
    anim: { flapSpeed: 0.8, flapAmp: 1.3, bob: 1.3, tilt: 0.8 }, particle: 'glow', trail: 'glow', fx: 'rings',
    voice: { flap: { wave: 'sine', base: 880, glide: 4, noise: 0.05 }, skill: { wave: 'sine', root: 1047, scale: major } },
    unlock: { type: 'secret', id: 'all_skins', hint: hint('Sở hữu toàn bộ 19 skin còn lại.', 'Own all 19 other skins.') },
    desc: { vi: 'Tối thượng thiên giới — chỉ dành cho nhà sưu tầm hoàn hảo.', en: 'The ultimate celestial — only for the perfect collector.' },
  },
];

export const SKIN_BY_ID: Record<string, SkinDef> = Object.fromEntries(SKINS.map((s) => [s.id, s]));
export const DEFAULT_SKIN = 'sakura_bird';
