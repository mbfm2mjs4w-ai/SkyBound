// Pooled particle system (no allocation per frame) + ribbon/trail renderer driven by the skin.
import type { ParticleKind, QualityProfile, TrailKind } from '../core/types';
import type { BurstKind, SkinDef } from '../data/skins';
import { clamp, hslToHex, rgba, TAU, mixHex } from '../core/util';
import { drawGlow, polyPath, starPath, type Ctx } from './gfx';

interface P {
  on: boolean; kind: ParticleKind; x: number; y: number; vx: number; vy: number; g: number; drag: number;
  life: number; max: number; size: number; rot: number; vr: number; color: string; add: boolean; follow: number; shrink: boolean; wob: number;
}
export interface SpawnOpts { g?: number; drag?: number; follow?: number; rot?: number; vr?: number; add?: boolean; shrink?: boolean; wob?: number }
const mk = (): P => ({ on: false, kind: 'glow', x: 0, y: 0, vx: 0, vy: 0, g: 0, drag: 0, life: 0, max: 1, size: 4, rot: 0, vr: 0, color: '#fff', add: true, follow: 0, shrink: true, wob: 0 });
const ADDITIVE: ReadonlySet<ParticleKind> = new Set<ParticleKind>(['spark', 'ember', 'star', 'glow', 'ring', 'bolt', 'rune']);

export class ParticleManager {
  private pool: P[] = [];
  private cap = 700;
  private scale = 1;
  private cursor = 0;
  live = 0;
  setQuality(q: QualityProfile): void { this.cap = q.maxParticles; this.scale = q.particleScale; while (this.pool.length < this.cap) this.pool.push(mk()); this.pool.length = Math.max(this.cap, 1); }
  constructor(q: QualityProfile) { this.setQuality(q); }

  private alloc(): P | null {
    const n = this.pool.length;
    for (let i = 0; i < n; i++) { const p = this.pool[(this.cursor + i) % n]; if (!p.on) { this.cursor = (this.cursor + i + 1) % n; return p; } }
    // pool exhausted: recycle the oldest-looking (lowest life fraction) slot
    const p = this.pool[this.cursor]; this.cursor = (this.cursor + 1) % n; return p;
  }
  /** count multiplier from quality */
  n(count: number): number { return Math.max(count > 0 ? 1 : 0, Math.round(count * this.scale)); }

  spawn(kind: ParticleKind, x: number, y: number, vx: number, vy: number, life: number, size: number, color: string, o: SpawnOpts = {}): void {
    const p = this.alloc(); if (!p) return;
    p.on = true; p.kind = kind; p.x = x; p.y = y; p.vx = vx; p.vy = vy; p.life = life; p.max = life; p.size = size; p.color = color;
    p.g = o.g ?? 0; p.drag = o.drag ?? 0; p.follow = o.follow ?? 0; p.rot = o.rot ?? Math.random() * TAU; p.vr = o.vr ?? (Math.random() - 0.5) * 6;
    p.add = o.add ?? ADDITIVE.has(kind); p.shrink = o.shrink ?? true; p.wob = o.wob ?? 0;
  }
  clear(): void { for (const p of this.pool) p.on = false; this.live = 0; }

  update(dt: number, worldSpeed: number): void {
    let live = 0;
    for (const p of this.pool) {
      if (!p.on) continue;
      p.life -= dt;
      if (p.life <= 0) { p.on = false; continue; }
      live++;
      if (p.drag) { const k = Math.max(0, 1 - p.drag * dt); p.vx *= k; p.vy *= k; }
      p.vy += p.g * dt;
      if (p.wob) p.vx += Math.sin(p.life * 6 + p.rot) * p.wob * dt;
      p.x += (p.vx - worldSpeed * p.follow) * dt; p.y += p.vy * dt; p.rot += p.vr * dt;
    }
    this.live = live;
  }

  draw(c: Ctx): void {
    for (let pass = 0; pass < 2; pass++) {
      const add = pass === 1;
      if (add) { c.save(); c.globalCompositeOperation = 'lighter'; }
      for (const p of this.pool) {
        if (!p.on || p.add !== add) continue;
        const f = p.life / p.max, a = clamp(f * 2.2, 0, 1), s = p.shrink ? p.size * (0.35 + 0.65 * f) : p.size;
        this.one(c, p, f, a, s);
      }
      if (add) c.restore();
    }
  }

  private one(c: Ctx, p: P, f: number, a: number, s: number): void {
    switch (p.kind) {
      case 'glow': drawGlow(c, p.x, p.y, s * 2.4, p.color, a * 0.8); break;
      case 'spark': c.fillStyle = rgba(p.color, a); c.beginPath(); c.arc(p.x, p.y, s * 0.5, 0, TAU); c.fill(); drawGlow(c, p.x, p.y, s * 1.6, p.color, a * 0.5); break;
      case 'ember': drawGlow(c, p.x, p.y, s * 2, p.color, a * 0.85); break;
      case 'star': c.fillStyle = rgba(p.color, a); starPath(c, p.x, p.y, s, s * 0.4, 4, p.rot); c.fill(); drawGlow(c, p.x, p.y, s * 1.5, p.color, a * 0.4); break;
      case 'ring': c.strokeStyle = rgba(p.color, a * 0.8); c.lineWidth = 2.4 * f + 0.6; c.beginPath(); c.arc(p.x, p.y, p.size * (1.2 - f) * 1.2 + 2, 0, TAU); c.stroke(); break;
      case 'bolt': { c.strokeStyle = rgba(p.color, a); c.lineWidth = 2; c.beginPath(); c.moveTo(p.x, p.y); const ang = p.rot; let x = p.x, y = p.y; for (let i = 0; i < 4; i++) { x += Math.cos(ang + (i % 2 ? 0.7 : -0.7)) * s * 0.5; y += Math.sin(ang + (i % 2 ? 0.7 : -0.7)) * s * 0.5; c.lineTo(x, y); } c.stroke(); break; }
      case 'rune': c.strokeStyle = rgba(p.color, a); c.lineWidth = 1.6; c.save(); c.translate(p.x, p.y); c.rotate(p.rot); c.strokeRect(-s * 0.4, -s * 0.5, s * 0.8, s); c.beginPath(); c.moveTo(-s * 0.4, 0); c.lineTo(s * 0.4, 0); c.stroke(); c.restore(); break;
      case 'feather': c.save(); c.translate(p.x, p.y); c.rotate(p.rot); c.globalAlpha = a; c.fillStyle = p.color; c.beginPath(); c.ellipse(0, 0, s, s * 0.26, 0, 0, TAU); c.fill(); c.strokeStyle = 'rgba(255,255,255,0.6)'; c.lineWidth = 0.8; c.beginPath(); c.moveTo(-s, 0); c.lineTo(s, 0); c.stroke(); c.restore(); break;
      case 'petal': c.save(); c.translate(p.x, p.y); c.rotate(p.rot); c.scale(1, 0.55 + 0.45 * Math.sin(p.rot * 2)); c.globalAlpha = a; c.fillStyle = p.color; c.beginPath(); c.ellipse(0, 0, s, s * 0.6, 0, 0, TAU); c.fill(); c.restore(); break;
      case 'leaf': c.save(); c.translate(p.x, p.y); c.rotate(p.rot); c.globalAlpha = a; c.fillStyle = p.color; c.beginPath(); c.moveTo(-s, 0); c.quadraticCurveTo(0, -s * 0.8, s, 0); c.quadraticCurveTo(0, s * 0.8, -s, 0); c.fill(); c.restore(); break;
      case 'snow': c.globalAlpha = a; c.fillStyle = p.color; c.beginPath(); c.arc(p.x, p.y, s * 0.55, 0, TAU); c.fill(); c.globalAlpha = 1; break;
      case 'bubble': c.strokeStyle = rgba(p.color, a * 0.9); c.lineWidth = 1.2; c.beginPath(); c.arc(p.x, p.y, s * 0.7, 0, TAU); c.stroke(); c.fillStyle = rgba('#ffffff', a * 0.5); c.beginPath(); c.arc(p.x - s * 0.22, p.y - s * 0.22, s * 0.16, 0, TAU); c.fill(); break;
      case 'smoke': c.fillStyle = rgba(p.color, a * 0.35); c.beginPath(); c.arc(p.x, p.y, s * (1.6 - f * 0.6), 0, TAU); c.fill(); break;
      case 'shard': c.save(); c.translate(p.x, p.y); c.rotate(p.rot); c.globalAlpha = a; c.fillStyle = p.color; polyPath(c, [-s, 0, 0, -s * 0.45, s * 0.8, 0, 0, s * 0.45]); c.fill(); c.restore(); break;
      case 'confetti': c.save(); c.translate(p.x, p.y); c.rotate(p.rot); c.scale(1, Math.abs(Math.sin(p.rot * 3)) * 0.9 + 0.1); c.globalAlpha = a; c.fillStyle = p.color; c.fillRect(-s * 0.5, -s * 0.3, s, s * 0.6); c.restore(); break;
      case 'heart': c.save(); c.translate(p.x, p.y); c.globalAlpha = a; c.fillStyle = p.color; c.scale(s / 10, s / 10); c.beginPath(); c.moveTo(0, 4); c.bezierCurveTo(-10, -2, -6, -10, 0, -5); c.bezierCurveTo(6, -10, 10, -2, 0, 4); c.fill(); c.restore(); break;
    }
  }

  // ---------------------------------------------------------------- composed effects
  /** Skin-specific burst (power-up pick-up, boost, victory, ...). */
  burst(fx: BurstKind, x: number, y: number, skin: SkinDef, power = 1): void {
    const C = skin.colors, n = (k: number): number => this.n(k * power);
    const pick = [C.glow, C.accent, C.wing, C.wing2];
    const col = (i: number): string => pick[i % pick.length];
    this.spawn('ring', x, y, 0, 0, 0.55, 46 * power, C.glow);
    this.spawn('glow', x, y, 0, 0, 0.5, 40 * power, C.glow);
    const radial = (kind: ParticleKind, k: number, sp: number, life: number, size: number, o: SpawnOpts = {}): void => {
      for (let i = 0; i < n(k); i++) { const a = (i / n(k)) * TAU + Math.random() * 0.4, v = sp * (0.5 + Math.random() * 0.7); this.spawn(kind, x, y, Math.cos(a) * v, Math.sin(a) * v, life * (0.7 + Math.random() * 0.5), size * (0.7 + Math.random() * 0.6), col(i), o); }
    };
    switch (fx) {
      case 'petals': radial('petal', 22, 230, 1.3, 7, { g: 90, drag: 1.4, wob: 120 }); break;
      case 'shards': radial('shard', 20, 300, 0.9, 8, { g: 220, drag: 1.2 }); radial('spark', 10, 200, 0.5, 4); break;
      case 'leaves': radial('leaf', 20, 220, 1.3, 7, { g: 110, drag: 1.3, wob: 100 }); break;
      case 'lightning': radial('bolt', 14, 330, 0.4, 24); radial('spark', 14, 260, 0.5, 5); break;
      case 'feathers': radial('feather', 18, 240, 1.4, 11, { g: 60, drag: 1.5, wob: 90 }); break;
      case 'pixels': radial('confetti', 22, 260, 1.0, 6, { g: 200, drag: 1.0 }); break;
      case 'stars': radial('star', 16, 260, 1.0, 9, { drag: 1.2 }); radial('spark', 10, 200, 0.6, 4); break;
      case 'flames': radial('ember', 26, 230, 0.9, 8, { g: -140, drag: 1.2 }); radial('smoke', 6, 90, 0.9, 10, { g: -40 }); break;
      case 'rings': for (let i = 0; i < 4; i++) this.spawn('ring', x, y, 0, 0, 0.5 + i * 0.12, 40 + i * 26, col(i)); radial('spark', 10, 200, 0.5, 4); break;
      case 'smoke': radial('smoke', 14, 130, 1.1, 12, { g: -30 }); radial('spark', 10, 160, 0.5, 4); break;
    }
  }
  /** Feather-flap puff behind the bird. */
  flap(x: number, y: number, skin: SkinDef): void {
    const C = skin.colors;
    for (let i = 0; i < this.n(3); i++) this.spawn(skin.particle, x - 16, y + 8, -50 - Math.random() * 90, 40 + Math.random() * 80, 0.7 + Math.random() * 0.4, 6 + Math.random() * 3, i % 2 ? C.wing2 : C.glow, { g: 140, drag: 1.1, follow: 0.7, wob: 60 });
  }
  shed(x: number, y: number, skin: SkinDef, speed: number): void {
    const C = skin.colors;
    this.spawn(skin.particle, x - 14, y + (Math.random() - 0.5) * 16, -30 - Math.random() * 40, (Math.random() - 0.5) * 40, 0.8 + Math.random() * 0.5, 4 + Math.random() * 3, Math.random() > 0.5 ? C.glow : C.wing2, { g: 30, drag: 0.8, follow: 0.9, wob: 40 });
    void speed;
  }
  coin(x: number, y: number): void {
    for (let i = 0; i < this.n(9); i++) { const a = Math.random() * TAU, v = 80 + Math.random() * 140; this.spawn('spark', x, y, Math.cos(a) * v, Math.sin(a) * v - 40, 0.5, 5, i % 2 ? '#ffe27a' : '#fff6c0', { drag: 2.2, follow: 0.6 }); }
    this.spawn('ring', x, y, 0, 0, 0.35, 24, '#ffe27a');
  }
  gem(x: number, y: number): void {
    for (let i = 0; i < this.n(12); i++) { const a = Math.random() * TAU, v = 90 + Math.random() * 160; this.spawn('star', x, y, Math.cos(a) * v, Math.sin(a) * v, 0.7, 7, i % 2 ? '#7afcff' : '#d6a8ff', { drag: 1.8, follow: 0.6 }); }
    this.spawn('ring', x, y, 0, 0, 0.5, 34, '#7afcff');
  }
  hit(x: number, y: number, skin: SkinDef, blocked: boolean): void {
    const C = skin.colors;
    for (let i = 0; i < this.n(blocked ? 14 : 22); i++) { const a = Math.random() * TAU, v = 120 + Math.random() * 260; this.spawn(i % 3 ? 'feather' : 'spark', x, y, Math.cos(a) * v, Math.sin(a) * v - 60, 0.9 + Math.random() * 0.5, 7 + Math.random() * 4, i % 2 ? C.body : C.wing, { g: 260, drag: 1.0, wob: 40 }); }
    this.spawn('ring', x, y, 0, 0, 0.45, blocked ? 54 : 70, blocked ? '#9fe8ff' : '#ffffff');
  }
  explode(x: number, y: number, skin: SkinDef): void {
    const C = skin.colors;
    for (let i = 0; i < this.n(36); i++) { const a = Math.random() * TAU, v = 80 + Math.random() * 360; this.spawn(i % 2 ? 'feather' : 'shard', x, y, Math.cos(a) * v, Math.sin(a) * v - 120, 1.1 + Math.random() * 0.7, 8 + Math.random() * 6, [C.body, C.wing, C.wing2, C.accent][i % 4], { g: 520, drag: 0.7 }); }
    this.spawn('ring', x, y, 0, 0, 0.6, 90, C.glow); this.spawn('glow', x, y, 0, 0, 0.5, 90, '#ffffff');
  }
  confetti(x: number, y: number, W: number): void {
    for (let i = 0; i < this.n(60); i++) this.spawn('confetti', x + (Math.random() - 0.5) * W, y, (Math.random() - 0.5) * 120, 60 + Math.random() * 120, 2.4 + Math.random(), 8 + Math.random() * 6, hslToHex(Math.random() * 360, 85, 62), { g: 120, drag: 0.5, shrink: false });
  }
}

// ---------------------------------------------------------------- trail
interface TP { x: number; y: number; t: number }
export class Trail {
  private pts: TP[] = [];
  private acc = 0;
  maxPts = 30;
  clear(): void { this.pts.length = 0; }
  update(dt: number, x: number, y: number, worldSpeed: number, emitting: boolean): void {
    for (const p of this.pts) { p.x -= worldSpeed * dt; p.t += dt; }
    this.acc += dt;
    if (emitting && this.acc >= 0.016) { this.acc = 0; this.pts.push({ x, y, t: 0 }); }
    while (this.pts.length > this.maxPts || (this.pts.length && this.pts[0].t > 0.9)) this.pts.shift();
    if (!emitting && this.pts.length) { /* tail fades naturally */ }
  }
  draw(c: Ctx, kind: TrailKind, skin: SkinDef, time: number, q: QualityProfile): void {
    const P = this.pts; if (P.length < 2) return;
    const C = skin.colors, n = P.length, life = 0.9;
    const strip = (w0: number, col: (u: number) => string, a0 = 1, jitter = 0): void => {
      for (let i = 1; i < n; i++) {
        const u = i / (n - 1), p0 = P[i - 1], p1 = P[i], age = 1 - clamp(p1.t / life, 0, 1), w = w0 * u * age;
        c.strokeStyle = col(u); c.globalAlpha = a0 * age * u; c.lineWidth = Math.max(0.5, w); c.lineCap = 'round';
        c.beginPath(); c.moveTo(p0.x, p0.y + (jitter ? Math.sin(time * 20 + i) * jitter * (1 - u) : 0)); c.lineTo(p1.x, p1.y + (jitter ? Math.sin(time * 20 + i + 1) * jitter * (1 - u) : 0)); c.stroke();
      }
      c.globalAlpha = 1;
    };
    c.save();
    switch (kind) {
      case 'ribbon': strip(16, (u) => mixHex(C.wing, C.glow, u), 0.85); break;
      case 'glow': c.globalCompositeOperation = 'lighter'; strip(22, () => C.glow, 0.5); strip(8, () => '#ffffff', 0.6); break;
      case 'neon': c.globalCompositeOperation = 'lighter'; strip(14, () => C.glow, 0.45); strip(5, () => C.accent, 0.95); break;
      case 'flame': c.globalCompositeOperation = 'lighter'; strip(22, (u) => mixHex('#ff3a1a', '#ffd34a', u), 0.7, 3); strip(9, () => '#fff1a0', 0.7, 2); break;
      case 'frost': strip(14, (u) => mixHex('#7fd0ff', '#ffffff', u), 0.85); c.globalCompositeOperation = 'lighter'; for (let i = 2; i < n; i += 3) { const p = P[i], age = 1 - p.t / life; c.fillStyle = rgba('#e6f8ff', age * 0.9); starPath(c, p.x, p.y + Math.sin(i) * 6, 5 * age, 1.6 * age, 6, 0); c.fill(); } break;
      case 'stardust': c.globalCompositeOperation = 'lighter'; for (let i = 0; i < n; i++) { const p = P[i], age = 1 - p.t / life, tw = 0.5 + 0.5 * Math.sin(time * 9 + i * 1.7); c.fillStyle = rgba(i % 2 ? C.glow : '#ffffff', age * tw); starPath(c, p.x, p.y + Math.sin(i * 2.1) * 7, 4.5 * age + 1, 1.2, 4, i); c.fill(); } break;
      case 'petals': for (let i = 1; i < n; i += 2) { const p = P[i], age = 1 - p.t / life; c.save(); c.translate(p.x, p.y + Math.sin(i * 1.3 + time * 3) * 8); c.rotate(i + time * 2); c.globalAlpha = age * 0.9; c.fillStyle = i % 4 === 1 ? C.wing2 : C.glow; c.beginPath(); c.ellipse(0, 0, 6 * age + 1, 3 * age + 0.6, 0, 0, TAU); c.fill(); c.restore(); } break;
      case 'lightning': c.globalCompositeOperation = 'lighter'; { const pass = (w: number, col: string, a: number): void => { c.strokeStyle = col; c.globalAlpha = a; c.lineWidth = w; c.lineJoin = 'round'; c.beginPath(); for (let i = 0; i < n; i++) { const p = P[i]; const j = (Math.sin(time * 40 + i * 3.1) * 8) * (i / n); i ? c.lineTo(p.x, p.y + j) : c.moveTo(p.x, p.y + j); } c.stroke(); }; pass(7, C.glow, 0.35); pass(2.4, '#ffffff', 0.95); } break;
      case 'orbs': c.globalCompositeOperation = 'lighter'; for (let i = 0; i < n; i += 2) { const p = P[i], age = 1 - p.t / life, u = i / n; drawGlow(c, p.x, p.y, (4 + 9 * u) * age + 2, i % 4 ? C.glow : C.accent, age * 0.9); } break;
      case 'rainbow': for (let k = 0; k < 6; k++) { const hue = k * 55 + time * 40; strip(14 - k * 1.6, () => hslToHex(hue % 360, 90, 60), 0.9); } break;
      case 'shadow': strip(20, () => '#120a24', 0.6, 2); c.globalCompositeOperation = 'lighter'; strip(5, () => C.glow, 0.25); break;
    }
    c.restore();
    void q;
  }
}
