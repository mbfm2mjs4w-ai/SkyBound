declare const process: { exit(code?: number): never; argv: string[]; env: Record<string, string | undefined> };
