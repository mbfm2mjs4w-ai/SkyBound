// One run of the game: owns a GameSession, drives rendering / audio / HUD from its events.
import { GameSession, type RunResult, type SessionConfig } from '../core/GameSession';
import { LOGICAL_H, DEFAULT_TUNING, MILESTONES } from '../config/gameConfig';
import type { Engine } from '../engine/Engine';
import type { AudioManager } from '../audio/AudioManager';
import type { SaveManager } from '../systems/SaveManager';
import type { ProgressionManager, RunSummary } from '../systems/ProgressionManager';
import { WorldRenderer } from '../render/WorldRenderer';
import { ObstacleRenderer } from '../render/ObstacleRenderer';
import { ParticleManager, Trail } from '../render/ParticleManager';
import { drawBird, drawBirdShadow } from '../render/BirdRenderer';
import { drawCoin, drawGem, drawPowerUpOrb, drawSecretPortal } from '../render/PowerUpRenderer';
import { drawBoss } from '../render/BossRenderer';
import { drawTransition } from '../render/Transitions';
import { newPose } from '../entities/Bird';
import { gapAt } from '../entities/Obstacle';
import { OBSTACLES } from '../data/obstacles';
import { WORLD_BY_ID } from '../data/worlds';
import { SKIN_BY_ID, DEFAULT_SKIN, type SkinDef } from '../data/skins';
import { POWERUPS } from '../data/powerups';
import { MODES } from '../data/modes';
import type { BirdPose, GateView, QualityProfile, ViewState, TrailKind } from '../core/types';
import type { CosmeticItemId } from '../data/cosmetics';
import { clamp, damp, getDayWeights, rgba, TAU } from '../core/util';
import { tr, loc } from '../core/i18n';
import { Hud } from '../ui/Hud';
import { drawGlow } from '../render/gfx';

export interface GameHost {
  engine: Engine; audio: AudioManager; save: SaveManager; prog: ProgressionManager;
  worldR: WorldRenderer; obstacleR: ObstacleRenderer; quality: QualityProfile; hudParent: HTMLElement;
  onRunEnd(summary: RunSummary, result: RunResult, victory: boolean): void;
  onPause(scene: GameScene): void;
}

interface Floater { on: boolean; x: number; y: number; text: string; life: number; max: number; color: string; size: number }
const FONT = `'Baloo 2','Fredoka','Trebuchet MS',system-ui,sans-serif`;

export class GameScene {
  readonly session: GameSession;
  readonly hud: Hud;
  readonly particles: ParticleManager;
  private trail = new Trail();
  private skin: SkinDef; private item: CosmeticItemId | null; private trailKind: TrailKind;
  private pose: BirdPose = newPose();
  private view: ViewState;
  private gateV: GateView = { kind: 'pillar', worldId: '', x: 0, centerY: 0, gapHalf: 0, halfW: 0, seed: 0, phase: 0, rot: 0, pulse: 0, appear: 1, night: 0 };
  private gapTmp = { center: 0, half: 0 };
  paused = false; private ended = false; private destroyed = false;
  private countdown = 0; private lastCount = 0;
  private shake = 0; private zoom = 1; private zoomT = 1; private camY = 0; private flash = 0; private flashColor = '#fff';
  private timeMul = 1; private timeMulT = 1; private hitstop = 0;
  private shown: string; private tr: { style: string; color: string; t: number; dur: number; swapped: boolean; to: string; cx: number; cy: number } | null = null;
  private loading: Generator<void, void, void> | null = null; private loadingId = '';
  private bossHurt = 0; private bossAppear = 0;
  private floaters: Floater[] = Array.from({ length: 14 }, () => ({ on: false, x: 0, y: 0, text: '', life: 0, max: 1, color: '#fff', size: 22 }));
  private offs: (() => void)[] = [];
  private shedT = 0; private musicT = 0; private clock = 0;
  private scroll = 0;

  constructor(private host: GameHost, cfg: SessionConfig) {
    const s = host.save.data;
    const base = SKIN_BY_ID[s.equippedSkin] ?? SKIN_BY_ID[DEFAULT_SKIN];
    this.skin = s.equipped.fx ? { ...base, particle: s.equipped.fx as SkinDef['particle'] } : base;
    this.item = (s.equipped.item as CosmeticItemId | null) ?? null;
    this.trailKind = (s.equipped.trail as TrailKind | null) ?? this.skin.trail;
    this.session = new GameSession(cfg);
    this.session.animOverride = this.skin.anim;
    this.shown = this.session.worldId;
    this.particles = new ParticleManager(host.quality);
    this.trail.maxPts = host.quality.trailPoints;
    const e = host.engine;
    this.view = { W: e.W, H: e.H, time: 0, scroll: 0, camY: 0, tod: this.session.tod, intensity: 0, quality: host.quality, reducedMotion: s.settings.reducedMotion };
    host.worldR.prepare(this.shown, e.W, e.H, e.dpr);
    this.hud = new Hud(host.hudParent, () => this.pause());
    this.hud.setBest(cfg.bestScore ?? 0); this.hud.setCoins(0); this.hud.setGems(0); this.hud.setScore(0, false);
    this.hud.setLives(this.session.lives, this.session.maxLives);
    this.bind();
    this.applyWorldAudio(this.shown, true);
    const first = !s.tutorialSeen && s.settings.tutorial;
    this.hud.setReady(tr('CHẠM ĐỂ BAY', 'TAP TO FLY'), first ? tr('Chạm / Space để vỗ cánh • Luồn qua khe hở • Nhặt xu & vật phẩm', 'Tap / Space to flap • Fly through the gaps • Grab coins & power-ups') : tr('Chạm / Space / Click', 'Tap / Space / Click'));
    if (this.session.boss) this.hud.showBoss(loc(this.session.boss.name), 1);
    if (this.session.level) this.hud.setSub(`${tr('Chặng', 'Level')} ${this.session.level.id}`);
    else if (this.session.daily) this.hud.setSub(tr('Thử thách hằng ngày', 'Daily Challenge'));
    else this.hud.setSub(loc(MODES[cfg.mode].name));
    this.layout();
  }

  // ------------------------------------------------------------------ wiring
  private bind(): void {
    const S = this.session, ev = S.ev, A = this.host.audio, P = this.particles, skin = this.skin;
    const on = <K extends Parameters<typeof ev.on>[0]>(k: K, fn: Parameters<typeof ev.on<K>>[1]): void => { this.offs.push(ev.on(k, fn)); };
    const birdY = (): number => S.bird.body.y;
    on('start', () => { this.hud.setReady(null); A.sfx('go'); this.host.save.data.tutorialSeen = true; this.host.save.touch(); });
    on('flap', () => { A.flap(skin); P.flap(S.bird.x, birdY(), skin); this.zoomPunch(0.0); });
    on('score', (e) => {
      this.hud.setScore(e.score); this.hud.setCombo(S.combo);
      if (e.perfect && S.combo >= 2) { A.sfx('perfect', S.combo); this.float(tr('HOÀN HẢO', 'PERFECT'), S.bird.x + 26, birdY() - 40, '#ffe27a', 22); } else A.sfx('score');
    });
    on('combo', () => { this.hud.setCombo(S.combo); });
    on('nearMiss', () => { A.sfx('nearMiss'); this.hud.setCombo(0); this.float(tr('SUÝT!', 'CLOSE!'), S.bird.x + 26, birdY() - 36, '#ff9a8a', 18); });
    on('milestone', (e) => { this.hud.say(String(e.value), tr('Cột mốc!', 'Milestone!'), 'milestone'); A.sfx('milestone'); this.addShake(7); P.confetti(this.view.W * 0.5, -10, this.view.W * 0.6); this.flashFx('#ffffff', 0.25); });
    on('record', () => { this.hud.say(tr('KỶ LỤC MỚI!', 'NEW RECORD!'), '', 'record'); A.sfx('record'); P.confetti(this.view.W * 0.5, -10, this.view.W * 0.8); this.flashFx('#ffe27a', 0.3); });
    on('coin', (e) => { this.hud.setCoins(e.total); A.sfx('coin'); P.coin(e.x, e.y); });
    on('gem', (e) => { this.hud.setGems(e.total); A.sfx('gem'); P.gem(e.x, e.y); });
    on('power', (e) => { A.skill(skin); A.sfx('power'); P.burst(skin.fx, S.bird.x, birdY(), skin, 1); this.hud.say(loc(POWERUPS[e.type].name), loc(POWERUPS[e.type].desc), 'power'); this.addShake(3); if (e.type === 'turbo') this.zoomT = 1.08; });
    on('powerEnd', (e) => { if (e.type === 'turbo') this.zoomT = 1; });
    on('hit', (e) => {
      const y = birdY();
      if (e.blocked === 'shield') { A.sfx('shield'); P.hit(S.bird.x, y, skin, true); this.addShake(8); this.flashFx('#9fe8ff', 0.3); }
      else if (e.blocked === 'phoenix') { A.sfx('phoenix'); P.burst('flames', S.bird.x, y, skin, 1.6); this.addShake(12); this.flashFx('#ffb347', 0.5); this.hud.say(tr('PHƯỢNG HOÀNG TÁI SINH', 'PHOENIX REBIRTH'), '', 'power'); }
      else { A.sfx('hit'); P.hit(S.bird.x, y, skin, false); this.addShake(14); this.hitstop = 0.07; this.flashFx('#ff4a4a', 0.35); }
      this.hud.setLives(S.lives, S.maxLives);
    });
    on('death', () => {
      A.sfx('death'); P.explode(S.bird.x, birdY(), skin); this.addShake(18); this.flashFx('#ffffff', 0.5);
      this.timeMulT = 0.35; this.zoomT = 1.14; this.hud.setCombo(0); A.stopMusic(1.4);
    });
    on('gameover', () => this.finish(false));
    on('complete', () => this.finish(true));
    on('worldchange', (e) => this.startTransition(e.to));
    on('bossIntro', (e) => { this.hud.showBoss(loc(e.boss.name), 1); this.hud.say(loc(e.boss.name), loc(e.boss.title), 'boss'); A.sfx('bossIntro'); this.bossAppear = 0; this.addShake(10); });
    on('bossHit', (e) => { this.hud.showBoss(loc(S.boss?.name ?? { vi: '', en: '' }), e.hp / Math.max(1, e.max)); this.bossHurt = 1; A.sfx('bossHit'); this.addShake(5); });
    on('bossDefeat', (e) => {
      A.sfx('bossDefeat'); this.addShake(22); this.flashFx('#ffffff', 0.6); this.hud.say(tr('ĐÃ HẠ GỤC!', 'DEFEATED!'), loc(e.boss.name), 'record'); this.hud.showBoss(null);
      P.confetti(this.view.W * 0.5, -10, this.view.W); P.burst('stars', this.view.W - 140, 340, skin, 2.2);
    });
    on('secret', () => { A.sfx('secret'); this.hud.say(tr('Cổng bí mật!', 'Secret portal!'), '+50', 'power'); P.burst('stars', S.bird.x, birdY(), skin, 1.5); });
    this.offs.push(this.host.engine.ev.on('resize', () => this.layout()));
  }

  private layout(): void {
    const e = this.host.engine, bx = e.W * this.session.tuning.birdXFrac;
    this.session.bird.x = bx; (this.session.cfg as { birdX: number }).birdX = bx;
    this.view.W = e.W; this.view.H = e.H;
  }

  private applyWorldAudio(id: string, first = false): void {
    const w = WORLD_BY_ID[id], A = this.host.audio, S = this.session;
    if (!w) return;
    const theme = S.mode.id === 'zen' ? 'zen' : S.boss ? 'boss' : (w.music === 'boss' ? 'gameplay' : w.music);
    A.playMusic(theme, first ? 1.5 : 2.5); A.setAmbient(id, w.ambient, first ? 1.5 : 3);
  }

  private startTransition(to: string): void {
    const w = WORLD_BY_ID[to]; if (!w) return;
    this.tr = { style: w.transition.style, color: w.transition.color, t: 0, dur: 1.5, swapped: false, to, cx: this.session.bird.x, cy: this.session.bird.body.y };
    this.host.audio.sfx('whoosh');
    this.hud.say(w.name, loc(w.tagline), 'world');
    if (!this.host.worldR.isPrepared(to)) this.host.worldR.prepare(to, this.view.W, this.view.H, this.host.engine.dpr);
  }

  // ------------------------------------------------------------------ helpers
  private addShake(a: number): void { if (this.host.save.data.settings.shake && !this.host.save.data.settings.reducedMotion) this.shake = Math.min(26, this.shake + a); }
  private zoomPunch(_v: number): void { void _v; }
  private flashFx(color: string, a: number): void { if (this.host.save.data.settings.reducedMotion) a *= 0.3; this.flash = Math.max(this.flash, a); this.flashColor = color; }
  private float(text: string, x: number, y: number, color: string, size: number): void {
    const f = this.floaters.find((q) => !q.on) ?? this.floaters[0]; f.on = true; f.x = x; f.y = y; f.text = text; f.life = f.max = 1.0; f.color = color; f.size = size;
  }

  private finish(victory: boolean): void {
    if (this.ended) return; this.ended = true;
    const S = this.session, res = S.result();
    const summary = this.host.prog.processRun(res);
    this.host.save.flush();
    this.hud.setVisible(false);
    this.host.onRunEnd(summary, res, victory);
  }

  // ------------------------------------------------------------------ control
  flap(): void { if (this.paused || this.countdown > 0 || this.ended) return; this.session.flap(); }
  pause(): void {
    if (this.paused || this.ended || this.destroyed) return;
    const st = this.session.state; if (st === 'dying' || st === 'over' || st === 'finished') return;
    this.paused = true; this.host.audio.sfx('pause'); this.host.audio.duck(0.3, 100); this.host.onPause(this);
  }
  resume(): void {
    if (!this.paused) return; this.paused = false; this.countdown = 3; this.lastCount = 4; this.host.audio.duck(1, 0.1);
  }
  endRun(): void { this.paused = false; this.countdown = 0; this.session.finishRun(); if (this.session.state === 'over' && !this.ended) this.finish(false); }

  // ------------------------------------------------------------------ frame
  frame(dt: number, now: number): void {
    if (this.destroyed) return;
    this.clock += dt;
    const S = this.session, hud = this.hud;
    hud.update(dt);
    if (this.countdown > 0) {
      this.countdown -= dt; const n = Math.ceil(this.countdown);
      if (n !== this.lastCount && n > 0) { this.lastCount = n; hud.say(String(n), '', 'count'); this.host.audio.sfx('count'); }
      if (this.countdown <= 0) { hud.say(tr('BAY!', 'GO!'), '', 'count'); this.host.audio.sfx('resume'); }
      this.render(0, now); return;
    }
    if (this.paused) { this.render(0, now); return; }

    // time scale (slow motion on death) and hit-stop
    this.timeMul = damp(this.timeMul, this.timeMulT, 6, dt);
    if (S.state === 'dying' && this.timeMulT < 1 && S.state === 'dying') { /* stays slow until the run ends */ }
    let sdt = dt * this.timeMul;
    if (this.hitstop > 0) { this.hitstop -= dt; sdt *= 0.08; }
    const alpha = S.advance(sdt);
    const vdt = dt * (S.has('timewarp') ? 0.55 : 1) * this.timeMul;
    this.updateVisuals(vdt, dt, alpha);
    this.render(alpha, now);
    this.updateHud(dt);
  }

  private updateVisuals(vdt: number, dt: number, alpha: number): void {
    const S = this.session, W = this.view.W, b = S.bird;
    const ws = S.speed * S.speedFactor * (S.state === 'ready' ? 0.35 : 1);
    this.scroll = S.prevDist + (S.dist - S.prevDist) * alpha;
    this.view.time += dt; this.view.scroll = this.scroll; this.view.tod = S.tod; this.view.intensity = clamp(S.score / 100, 0, 1) * 0.6 + (S.has('turbo') ? 0.4 : 0);
    // camera
    const by = b.body.y;
    this.camY = damp(this.camY, clamp((by - 400) * 0.12, -34, 34), 3, dt);
    this.zoom = damp(this.zoom, this.zoomT, 4, dt);
    this.shake = Math.max(0, this.shake - dt * 38);
    this.flash = Math.max(0, this.flash - dt * 2.2);
    this.bossHurt = Math.max(0, this.bossHurt - dt * 3);
    if (S.boss || S.state === 'bossintro') this.bossAppear = Math.min(1, this.bossAppear + dt * 0.7);
    // effects
    this.particles.update(vdt, ws);
    this.host.worldR.update(vdt, this.shown, ws, this.view);
    const playing = S.state === 'playing' || S.state === 'bossintro' || S.state === 'ready';
    this.trail.update(vdt, b.x - 8, by, ws, playing && S.state !== 'ready' && b.alpha > 0.5);
    this.shedT -= vdt; if (this.shedT <= 0 && S.state === 'playing') { this.shedT = 0.07 / Math.max(0.3, this.host.quality.particleScale); this.particles.shed(b.x, by, this.skin, ws); }
    if (S.has('featherstorm') && Math.random() < 0.5) this.particles.spawn('feather', b.x + (Math.random() - 0.5) * 120, by + (Math.random() - 0.5) * 120, -60, 20, 0.9, 9, this.skin.colors.wing2, { drag: 1, follow: 0.8 });
    if (S.phoenix && Math.random() < 0.25) this.particles.spawn('ember', b.x - 10, by + 6, -30, -40, 0.7, 6, '#ff9a3a', { follow: 0.8 });
    for (const f of this.floaters) if (f.on) { f.life -= dt; f.y -= 34 * dt; if (f.life <= 0) f.on = false; }
    // collect animation of pickups
    for (const p of S.pickups) if (p.collected && p.collectT < 1) p.collectT = Math.min(1, p.collectT + dt * 3.2);
    // world transition
    const t = this.tr;
    if (t) {
      t.t += dt; const k = t.t / t.dur;
      if (!t.swapped && k >= 0.4) { t.swapped = true; this.shown = t.to; this.applyWorldAudio(t.to); }
      if (k >= 1) this.tr = null;
    }
    // pre-load the next world progressively while a portal gate approaches
    if (!this.loading) {
      for (const g of S.gates) if (g.nextWorld && !this.host.worldR.isPrepared(g.nextWorld) && g.wx - S.dist < 1600) { this.loadingId = g.nextWorld; this.loading = this.host.worldR.prepareGen(g.nextWorld, W, this.view.H, this.host.engine.dpr); break; }
    }
    if (this.loading) { const r = this.loading.next(); if (r.done) this.loading = null; }
    // music intensity
    this.musicT -= dt; if (this.musicT <= 0) { this.musicT = 0.5; this.host.audio.setIntensity(S.mode.id === 'zen' ? 0.2 : 0.35 + Math.min(0.65, S.score / 60) + (S.boss ? 0.3 : 0)); }
  }

  private updateHud(dt: number): void {
    void dt;
    const S = this.session, h = this.hud;
    h.setCoins(S.coins); h.setGems(S.gems); h.setScore(S.score, false);
    h.setPowers(S.active, S.shield, S.phoenix);
    const pr = S.progress(); h.setProgress(pr.kind === 'none' ? null : pr.frac, pr.kind);
    h.setTime(S.mode.timeLimit ? S.timeLeft : null);
    if (S.boss) h.showBoss(loc(S.boss.name), S.bossHp / Math.max(1, S.bossMaxHp));
    h.setFps(this.host.save.data.settings.fps ? this.host.engine.fps : null);
    if (S.combo < 2) h.setCombo(S.combo);
  }

  // ------------------------------------------------------------------ rendering
  private render(alpha: number, now: number): void {
    const e = this.host.engine, c = e.begin(), S = this.session, W = this.view.W, H = this.view.H, q = this.host.quality;
    const view = this.view; view.camY = this.camY;
    const bird = S.bird, anim = this.skin.anim;
    bird.toPose(alpha, anim, this.pose);
    const pose = this.pose; pose.scale = 1.0 * (S.state === 'victory' ? 1.15 : 1);
    const distI = this.scroll;
    c.save();
    // camera: shake + zoom around the bird
    if (this.shake > 0.1) c.translate((Math.random() - 0.5) * this.shake, (Math.random() - 0.5) * this.shake);
    if (this.zoom > 1.001) { c.translate(pose.x, pose.y); c.scale(this.zoom, this.zoom); c.translate(-pose.x, -pose.y); }
    const wr = this.host.worldR;
    wr.drawBackground(c, this.shown, view);
    if (this.tr) { const k = this.tr.t / this.tr.dur, p = Math.sin(clamp(k, 0, 1) * Math.PI); drawTransition(c, W, H, this.tr.style as never, this.tr.color, Math.min(1, p * 1.25), view.time, this.tr.cx, this.tr.cy - this.camY); }
    // boss
    if (S.boss) {
      const bx = W - Math.min(190, W * 0.22) + (1 - this.bossAppear) * 400, by = 360 + Math.sin(view.time * 0.8) * 26 - this.camY * 0.5;
      drawBoss(c, S.boss, bx, by, 0.82, view.time, this.bossHurt, clamp((pose.x - bx) / 400, -1, 1), clamp((pose.y - by) / 300, -1, 1), this.bossAppear);
    }
    c.save(); c.translate(0, -this.camY);
    // gates
    const orender = this.host.obstacleR, gv = this.gateV;
    const w = WORLD_BY_ID[S.worldId];
    const night = w ? getDayWeights(w.cycle === 'fixed' ? w.fixedTod ?? 0.5 : S.tod).night : 0;
    for (const g of S.gates) {
      const rel = g.wx - distI, x = bird.x + rel;
      if (x < -220 || x > W + 220) continue;
      gapAt(g, rel, this.gapTmp);
      gv.kind = g.kind; gv.worldId = g.worldId; gv.x = x; gv.centerY = this.gapTmp.center; gv.gapHalf = this.gapTmp.half; gv.halfW = g.halfW || OBSTACLES[g.kind].halfW;
      gv.seed = g.seed; gv.phase = view.time + g.seed * 0.01; gv.rot = view.time * 0.8 + g.seed; gv.pulse = 0.5 + 0.5 * Math.sin(view.time * 3 + g.seed); gv.appear = clamp((W + 140 - x) / 220, 0, 1);
      gv.night = night; gv.nextWorld = g.nextWorld;
      orender.drawGate(c, gv);
    }
    if (q.bloom) { c.save(); c.globalCompositeOperation = 'lighter'; for (const g of S.gates) { const rel = g.wx - distI, x = bird.x + rel; if (x < -120 || x > W + 120) continue; gapAt(g, rel, this.gapTmp); gv.kind = g.kind; gv.worldId = g.worldId; gv.x = x; gv.centerY = this.gapTmp.center; gv.gapHalf = this.gapTmp.half; gv.halfW = g.halfW || OBSTACLES[g.kind].halfW; gv.seed = g.seed; gv.phase = view.time + g.seed * 0.01; gv.rot = view.time * 0.8 + g.seed; gv.pulse = 0.5 + 0.5 * Math.sin(view.time * 3 + g.seed); gv.appear = clamp((W + 140 - x) / 220, 0, 1); gv.night = night; gv.nextWorld = g.nextWorld; orender.drawGateLight(c, gv); } c.restore(); }
    // pickups
    for (const p of S.pickups) {
      const x = bird.x + (p.wx - distI), y = p.y;
      if (x < -60 || x > W + 60) continue;
      if (p.collected && p.collectT >= 1) continue;
      switch (p.kind) {
        case 'coin': drawCoin(c, x, y, 13, view.time, p.collected ? p.collectT : 0); break;
        case 'gem': if (!p.collected) drawGem(c, x, y, 15, view.time); break;
        case 'power': if (!p.collected && p.power) drawPowerUpOrb(c, p.power, x, y, 21, view.time); break;
        case 'secret': if (!p.collected) drawSecretPortal(c, x, y, 30, view.time); break;
      }
    }
    c.restore();
    wr.drawForeground(c, this.shown, view);
    c.save(); c.translate(0, -this.camY);
    // bird shadow on the ground
    const fy = S.tuning.floorY;
    if (q.shadows) drawBirdShadow(c, pose.x, fy + 4, 1 - clamp((fy - pose.y) / 500, 0, 0.7), 0.35 * (1 - clamp((fy - pose.y) / 520, 0, 1)) * pose.alpha);
    this.trail.draw(c, this.trailKind, this.skin, view.time, q);
    if (S.has('magnet')) { c.strokeStyle = rgba('#ff6a9a', 0.35 + 0.15 * Math.sin(view.time * 8)); c.lineWidth = 2; c.setLineDash([6, 8]); c.beginPath(); c.arc(pose.x, pose.y, 118 + Math.sin(view.time * 6) * 4, 0, TAU); c.stroke(); c.setLineDash([]); }
    if (S.invuln > 0 && S.state === 'playing') pose.alpha *= 0.55 + 0.45 * Math.sin(view.time * 30);
    drawBird(c, this.skin, pose, { item: this.item, quality: q });
    this.particles.draw(c);
    for (const f of this.floaters) if (f.on) { const a = clamp(f.life / f.max * 2, 0, 1); c.font = `800 ${f.size}px ${FONT}`; c.textAlign = 'center'; c.lineWidth = 4; c.strokeStyle = `rgba(20,20,50,${0.55 * a})`; c.globalAlpha = a; c.strokeText(f.text, f.x, f.y); c.fillStyle = f.color; c.fillText(f.text, f.x, f.y); c.globalAlpha = 1; }
    c.restore();
    // speed lines / time warp overlay
    if (S.has('turbo') || S.speed > 330) {
      c.save(); c.globalCompositeOperation = 'lighter'; c.strokeStyle = 'rgba(255,255,255,0.22)'; c.lineWidth = 2; const turbo = S.has('turbo') ? 1 : 0.4;
      for (let i = 0; i < 14 * turbo + 4; i++) { const y = ((i * 97.3 + view.time * 30) % H), x = ((i * 211 - view.time * 1400 * (0.5 + (i % 3) * 0.3)) % (W + 300) + W + 300) % (W + 300) - 150; c.beginPath(); c.moveTo(x, y); c.lineTo(x + 90 + (i % 4) * 30, y); c.stroke(); }
      c.restore();
    }
    if (S.has('timewarp')) { const g = c.createRadialGradient(W / 2, H / 2, H * 0.25, W / 2, H / 2, H * 0.85); g.addColorStop(0, 'rgba(140,110,255,0)'); g.addColorStop(1, 'rgba(120,90,255,0.35)'); c.fillStyle = g; c.fillRect(0, 0, W, H); }
    wr.drawLighting(c, this.shown, view);
    c.restore();
    if (this.flash > 0.01) { c.globalAlpha = Math.min(1, this.flash); c.fillStyle = this.flashColor; c.fillRect(0, 0, W, H); c.globalAlpha = 1; }
    void now; void LOGICAL_H; void DEFAULT_TUNING; void MILESTONES; void drawGlow;
  }

  destroy(): void {
    if (this.destroyed) return; this.destroyed = true;
    for (const o of this.offs) o(); this.offs = []; this.session.ev.clear();
    this.hud.destroy(); this.particles.clear();
  }
}
