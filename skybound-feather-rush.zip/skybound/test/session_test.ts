import { GameSession, NON_HIDDEN_WORLDS, type SessionConfig } from '../src/core/GameSession';
import { FIXED_DT } from '../src/config/gameConfig';
import { gapAt } from '../src/entities/Obstacle';
import { POWERUP_TYPES } from '../src/data/powerups';
import { BOSSES } from '../src/data/bosses';
import { ADVENTURE_LEVELS } from '../src/data/modes';

let failures = 0;
const ok = (cond: boolean, msg: string): void => { if (!cond) { failures++; console.log('  FAIL: ' + msg); } else console.log('  ok: ' + msg); };

const base = (over: Partial<SessionConfig> = {}): SessionConfig => ({ mode: 'classic', worldId: 'emerald_valley', worldCycle: NON_HIDDEN_WORLDS, birdX: 250, seed: 12345, ...over });

/** Drive the session with the same bot policy used for the generator test. */
function fly(s: GameSession, maxSeconds: number, opts: { stopAt?: () => boolean; latency?: number } = {}): void {
  const t = s.tuning;
  const lat = opts.latency ?? 0.05;
  let step = 0, pending = -1;
  const max = maxSeconds / FIXED_DT;
  while (step++ < max && s.state !== 'over' && s.state !== 'finished') {
    if (opts.stopAt && opts.stopAt()) return;
    if (s.state === 'ready') s.flap();
    if (step % 2 === 0 && (s.state === 'playing' || s.state === 'bossintro')) {
      let tg = null as (typeof s.gates)[number] | null;
      for (const g of s.gates) if (g.wx + g.halfW + t.birdRadius + 6 > s.dist) { tg = g; break; }
      const b = s.bird.body;
      const aim = tg ? gapAt(tg, Math.max(0, tg.wx - s.dist) > 330 ? 0 : Math.max(0, tg.wx - s.dist), { center: 0, half: 0 }).center : 400;
      const yPred = b.y + b.vy * lat + 0.5 * t.gravity * lat * lat;
      if (pending < 0 && yPred > aim + 42 && b.vy > -80) pending = step + Math.round(lat / FIXED_DT);   // human reaction delay
    }
    if (pending >= 0 && step >= pending) { s.flap(); pending = -1; }
    s.step(FIXED_DT);
  }
}

console.log('1) Classic: bot flies 80 gates; score, events, state machine');
{
  const s = new GameSession(base());
  let scoreEvents = 0, flapEvents = 0;
  s.ev.on('score', () => scoreEvents++); s.ev.on('flap', () => flapEvents++);
  fly(s, 400, { stopAt: () => s.score >= 80 });
  ok(s.score >= 80 && s.state === 'playing', `reached score ${s.score}, still playing`);
  ok(scoreEvents === s.score, `score events (${scoreEvents}) == score (${s.score})`);
  ok(flapEvents === s.flaps && flapEvents > 50, `flap events counted (${flapEvents})`);
  ok(s.coins > 0, `bot collected coins (${s.coins})`);
}
console.log('2) Death flow: no input after start → floor → dying → over, gameover event once');
{
  const s = new GameSession(base());
  let over = 0, death = 0; s.ev.on('gameover', () => over++); s.ev.on('death', () => death++);
  s.flap();
  for (let i = 0; i < 120 * 10 && s.state !== 'over'; i++) s.step(FIXED_DT);
  ok(s.state === 'over' && over === 1 && death === 1, `state=${s.state} gameover=${over} death=${death}`);
  const r = s.result();
  ok(r.score === 0 && !r.completed, 'result has score 0 and not completed');
}
console.log('3) Frame-rate independence: 60 Hz vs 144 Hz vs 30 Hz advance() give the same simulation');
{
  const sim = (hz: number): { dist: number; y: number; vy: number } => {
    const s = new GameSession(base({ seed: 99 }));
    s.flap();
    let t = 0, nextFlap = 0.45;
    const dt = 1 / hz;
    while (t < 1.2) { if (t >= nextFlap) { s.flap(); nextFlap += 0.4; } s.advance(dt); t += dt; }
    return { dist: s.dist, y: s.bird.body.y, vy: s.bird.body.vy };
  };
  const a = sim(60), b = sim(144), c = sim(30);
  ok(Math.abs(a.dist - b.dist) < 8 && Math.abs(a.dist - c.dist) < 8, `dist 60=${a.dist.toFixed(1)} 144=${b.dist.toFixed(1)} 30=${c.dist.toFixed(1)}`);
  ok(Math.abs(a.y - b.y) < 20 && Math.abs(a.y - c.y) < 25, `y 60=${a.y.toFixed(1)} 144=${b.y.toFixed(1)} 30=${c.y.toFixed(1)}`);
}
console.log('4) Power-ups');
{
  // shield: absorbs exactly one hit
  let s = new GameSession(base()); s.flap(); s.grant('shield');
  ok(s.shield, 'shield granted');
  for (let i = 0; i < 120 * 3 && s.shield; i++) s.step(FIXED_DT);
  ok(!s.shield && s.state === 'playing' && s.invuln > 0, `floor hit consumed the shield, bird alive + brief invulnerability (state=${s.state})`);
  // phoenix: revive once
  s = new GameSession(base()); s.flap(); s.grant('phoenix');
  for (let i = 0; i < 120 * 3 && s.phoenix; i++) s.step(FIXED_DT);
  ok(!s.phoenix && s.state === 'playing' && s.invuln > 2, `phoenix used once, bird revived (state=${s.state})`);
  for (let i = 0; i < 120 * 6 && s.state === 'playing'; i++) s.step(FIXED_DT);
  ok(s.state !== 'playing', 'a second failure is final (phoenix is single use)');
  // ghost passes through gates
  s = new GameSession(base({ seed: 5 })); s.flap(); s.grant('ghost');
  s.bird.body.y = 100;
  let alive = true; for (let i = 0; i < 120 * 3; i++) { if (i % 30 === 0) s.flap(); s.step(FIXED_DT); if (s.state === 'dying') alive = false; }
  ok(alive, 'ghost flight survives 3 s of random flapping');
  // multiplier doubles gate points
  s = new GameSession(base({ seed: 21 })); s.flap(); s.grant('multiplier');
  let gained = 0; s.ev.on('score', (e) => { gained = e.gained; });
  fly(s, 20, { stopAt: () => s.score > 0 });
  ok(gained === 2, `multiplier gives +${gained} per gate`);
  // durations & end events
  s = new GameSession(base()); s.flap(); let ended = ''; s.ev.on('powerEnd', (e) => { ended = e.type; });
  s.grant('magnet'); s.invuln = 99; s.bird.body.vy = 0; s.bird.body.y = 380;
  for (let i = 0; i < 120 * 10.5; i++) { s.bird.body.y = 380; s.bird.body.vy = 0; s.step(FIXED_DT); }
  ok(ended === 'magnet' && !s.has('magnet'), 'magnet expires after its 10 s duration');
  // time warp slows the world
  s = new GameSession(base()); s.flap(); const d0 = s.dist; s.grant('timewarp');
  for (let i = 0; i < 120; i++) { s.bird.body.y = 380; s.bird.body.vy = 0; s.step(FIXED_DT); }
  const warped = s.dist - d0;
  const s2 = new GameSession(base()); s2.flap(); const e0 = s2.dist;
  for (let i = 0; i < 120; i++) { s2.bird.body.y = 380; s2.bird.body.vy = 0; s2.step(FIXED_DT); }
  ok(warped < (s2.dist - e0) * 0.7, `time warp slows scrolling (${warped.toFixed(0)} vs ${(s2.dist - e0).toFixed(0)})`);
  // every power-up type can be granted without errors
  for (const t of POWERUP_TYPES) { const q = new GameSession(base()); q.flap(); q.grant(t); for (let i = 0; i < 240; i++) q.step(FIXED_DT); }
  ok(true, 'all 8 power-up types grant + tick without errors');
}
console.log('5) Time Attack ends by itself after 60 s (+hit penalty)');
{
  const s = new GameSession(base({ mode: 'timeattack' }));
  fly(s, 100);
  ok(s.state === 'over' && s.time >= 55 && s.time <= 62, `timer ended the run at ${s.time.toFixed(1)} s with score ${s.score}`);
}
console.log('6) Zen never dies');
{
  const s = new GameSession(base({ mode: 'zen' }));
  s.flap();
  for (let i = 0; i < 120 * 30; i++) s.step(FIXED_DT);   // never flap again: falls onto the floor repeatedly
  ok(s.state === 'playing', `30 s of free-fall in zen: state=${s.state}`);
}
console.log('7) Adventure: reaching the goal gives victory → finished with stars');
{
  const lvl = ADVENTURE_LEVELS[0];
  const s = new GameSession(base({ mode: 'adventure', adventureId: lvl.id, worldId: lvl.worldId }));
  let stars = -1; s.ev.on('complete', (e) => { stars = e.stars; });
  fly(s, 200);
  ok(s.state === 'finished' && stars >= 1 && s.score >= lvl.goal, `level ${lvl.id}: finished, stars=${stars}, score=${s.score}/${lvl.goal}`);
}
console.log('8) Every adventure level is completable by the bot');
{
  let all = true;
  for (const lvl of ADVENTURE_LEVELS) {
    const s = new GameSession(base({ mode: 'adventure', adventureId: lvl.id, worldId: lvl.worldId, seed: lvl.chapter * 77 + lvl.n }));
    fly(s, 300);
    if (s.state !== 'finished') { all = false; console.log('   level failed', lvl.id, s.state, s.score); }
  }
  ok(all, `${ADVENTURE_LEVELS.length} adventure levels completed`);
}
console.log('9) Boss Rush: bot with 3 hearts defeats all 5 bosses');
{
  const s = new GameSession(base({ mode: 'bossrush', worldId: 'emerald_valley', seed: 4242 }));
  let defeated = 0, intros = 0, wc = 0; s.ev.on('bossDefeat', () => defeated++); s.ev.on('bossIntro', () => intros++); s.ev.on('worldchange', () => wc++);
  fly(s, 900);
  ok(defeated === BOSSES.length && s.state === 'finished', `defeated ${defeated}/${BOSSES.length}, state=${s.state}, intros=${intros}, worldchanges=${wc}, hits=${s.hits}`);
}
console.log('10) Endless rotates through worlds via portal gates');
{
  const s = new GameSession(base({ mode: 'endless', seed: 777 }));
  const seen = new Set<string>([s.worldId]); s.ev.on('worldchange', (e) => seen.add(e.to));
  fly(s, 500, { stopAt: () => s.score >= 120 });
  ok(seen.size >= 5, `visited ${seen.size} worlds in ${s.score} gates: ${[...seen].join(', ')}`);
}
console.log('11) Daily challenge is deterministic for a given date');
{
  const a = new GameSession(base({ mode: 'daily', seed: undefined })), b = new GameSession(base({ mode: 'daily', seed: undefined }));
  const same = a.gates.slice(0, 8).every((g, i) => g.wx === b.gates[i].wx && g.baseCenter === b.gates[i].baseCenter && g.kind === b.gates[i].kind);
  ok(same && a.worldId === b.worldId, `identical gates and world (${a.worldId}), mods: ${a.daily?.mods.map((m) => m.id).join(',')}`);
}
console.log('12) Milestones fire at 10/25/50 exactly once, record fires once');
{
  const s = new GameSession(base({ seed: 31, bestScore: 20 }));
  const ms: number[] = []; let rec = 0; s.ev.on('milestone', (e) => ms.push(e.value)); s.ev.on('record', () => rec++);
  fly(s, 300, { stopAt: () => s.score >= 52 });
  ok(JSON.stringify(ms) === '[10,25,50]' && rec === 1, `milestones ${JSON.stringify(ms)} record events ${rec}`);
}
console.log(failures ? `\n${failures} FAILURES` : '\nSESSION OK');
if (failures) process.exit(1);
