import type { ObstacleKind } from '../core/types';
import type { GapMotion } from '../data/obstacles';
import { OBSTACLES } from '../data/obstacles';

/** One obstacle with a vertical gap. `wx` is the absolute world distance of the gate center. */
export interface Gate {
  id: number;
  kind: ObstacleKind;
  worldId: string;
  wx: number;
  baseCenter: number;
  baseHalf: number;      // nominal half gap (for 'breathe' gates this is the MAX; the minimum is baseHalf - amp*2)
  halfW: number;
  motion: GapMotion;
  amp: number;
  k: number;             // radians per unit of distance
  phase: number;
  seed: number;
  passed: boolean;
  spawnedAt: number;     // session time (for fade-in)
  bossIndex?: number;
  /** set on the gate that carries the player into the next world (rendered as a big portal) */
  nextWorld?: string;
}

export interface Gap { center: number; half: number }

/** Gap at relative distance `rel` (gate center minus bird distance): a pure function of position,
 *  so slow-motion, speed changes and time warp never break the generator's reachability guarantees. */
export function gapAt(g: Gate, rel: number, out: Gap): Gap {
  switch (g.motion) {
    case 'bob':
      out.center = g.baseCenter + g.amp * Math.sin(g.k * rel + g.phase);
      out.half = g.baseHalf;
      break;
    case 'breathe':
      out.center = g.baseCenter;
      out.half = g.baseHalf - g.amp * (1 - Math.sin(g.k * rel + g.phase)) ;
      break;
    default:
      out.center = g.baseCenter;
      out.half = g.baseHalf;
  }
  return out;
}

/** Gap center as the bird will meet it (rel = 0). */
export function crossingGap(g: Gate): Gap {
  return gapAt(g, 0, { center: 0, half: 0 });
}
export const kindSpec = (k: ObstacleKind) => OBSTACLES[k];
