import type { PowerUpType } from '../core/types';
import { POWERUPS, POWERUP_TYPES } from '../data/powerups';
import type { RNG } from '../core/util';

/** Weighted random power-up. `exclude` lets the caller avoid re-offering something already active. */
export function pickPowerUp(rng: RNG, exclude: ReadonlySet<PowerUpType> = new Set()): PowerUpType {
  let total = 0;
  for (const t of POWERUP_TYPES) if (!exclude.has(t)) total += POWERUPS[t].weight;
  if (total <= 0) return 'shield';
  let r = rng.next() * total;
  for (const t of POWERUP_TYPES) {
    if (exclude.has(t)) continue;
    r -= POWERUPS[t].weight;
    if (r <= 0) return t;
  }
  return 'shield';
}

export interface ActivePowerUp { type: PowerUpType; remaining: number; total: number }
