import type { SaveManager } from '../systems/SaveManager';
import type { ProgressionManager, RunSummary } from '../systems/ProgressionManager';
import type { AudioManager } from '../audio/AudioManager';
import type { NetworkManager } from '../net/NetworkManager';
import type { Engine } from '../engine/Engine';
import type { UI } from '../ui/UI';
import type { ModeId } from '../data/modes';
import type { RunResult } from '../core/GameSession';

export type ScreenName = 'menu' | 'play' | 'adventure' | 'worlds' | 'collection' | 'shop' | 'missions' | 'achievements' | 'leaderboard' | 'profile' | 'settings';
export interface RunOptions { mode: ModeId; worldId?: string; adventureId?: string }

/** What screens may use from the application (keeps screens decoupled from the App class). */
export interface AppApi {
  save: SaveManager; prog: ProgressionManager; audio: AudioManager; net: NetworkManager; engine: Engine; ui: UI;
  open(name: ScreenName): void;
  startRun(o: RunOptions): void;
  lastRun: RunOptions | null;
  showGameOver(s: RunSummary, r: RunResult, victory: boolean): void;
  applySettings(): void;
  toggleFullscreen(): void;
  resetProgress(): void;
}
