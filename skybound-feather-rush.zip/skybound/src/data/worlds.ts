import type { L10n, ObstacleKind, UnlockRule } from '../core/types';

export type Tri = readonly [string, string, string];

/** Parallax layers, listed far → near. Every kind MUST be implemented by WorldRenderer. */
export type LayerKind =
  | 'mountains' | 'hills' | 'forest' | 'city' | 'castle' | 'ice_spires' | 'volcano'
  | 'crystals' | 'asteroids' | 'islands' | 'temple' | 'reef' | 'sakura' | 'dark_spires'
  | 'celestial_city' | 'geometry' | 'neon_rail' | 'cloud_sea' | 'torii' | 'rocks'
  | 'nebula' | 'stars' | 'kelp';

export interface LayerDef {
  kind: LayerKind;
  /** parallax factor relative to the world scroll (0 = static, 1 = same speed as obstacles) */
  speed: number;
  /** vertical position (fraction of H) of the layer's ground line; shapes grow upward from here and the fill continues to the bottom */
  base: number;
  /** maximum height of the shapes as a fraction of H */
  height: number;
  /** [main/body color, secondary/highlight color] */
  colors: readonly [string, string];
  seed: number;
  /** emissive features (lit windows, lava, neon…) are baked into a second additive texture that scales with night/intensity */
  emissive?: boolean;
  /** free-form style options, see comments in each world below */
  params?: Record<string, number | string>;
}

export type DecorKind =
  | 'clouds' | 'birds_flock' | 'butterflies' | 'lanterns' | 'swallows' | 'drones' | 'holo_billboards'
  | 'meteors' | 'ringed_planet' | 'floating_islands' | 'jellyfish' | 'fish_school' | 'whale' | 'turtle'
  | 'petal_swirl' | 'wisps' | 'rune_circle' | 'lightning' | 'angels' | 'cubes' | 'portals_far'
  | 'aurora' | 'waterfall_mist' | 'lava_eruption' | 'god_rays' | 'caustics' | 'data_streams' | 'shooting_stars' | 'airships';

export type WeatherKind =
  | 'pollen' | 'rain' | 'snow' | 'blizzard' | 'ash' | 'embers' | 'digital_rain' | 'cosmic_dust'
  | 'light_motes' | 'bubbles' | 'petals' | 'wisps' | 'feathers' | 'stars' | 'leaves' | 'fireflies' | 'sparks';

export type GroundKind =
  | 'grass' | 'rooftop' | 'snow' | 'lava' | 'grid' | 'dust' | 'clouds' | 'sand' | 'petals' | 'void' | 'light' | 'prism';

export type TransitionStyle =
  | 'iris' | 'sunburst' | 'frost' | 'flame' | 'glitch' | 'warp' | 'light' | 'ripple' | 'petals' | 'void' | 'halo' | 'kaleido';

export interface AmbientDef {
  noise: 'white' | 'pink' | 'brown';
  noiseGain: number;       // 0..0.3
  lowpass: number;         // Hz
  highpass: number;        // Hz
  lfoRate: number;         // Hz (slow gusting of the noise)
  lfoDepth: number;        // 0..1
  drones: { freq: number; type: OscillatorType; gain: number; detune?: number }[];
  chimes?: { scale: number[]; root: number; rate: number; gain: number; wave: OscillatorType };
  crackle?: number;        // 0..1 random fire pops
  bubbles?: number;        // 0..1 random bubble blips
  beeps?: number;          // 0..1 digital blips
  thunder?: number;        // 0..1 distant rumbles
}

export interface WorldDef {
  id: string;
  index: number;           // 1..12
  name: string;
  tagline: L10n;
  desc: L10n;
  /** sky gradient [top, middle, horizon] for each phase of the day */
  sky: { day: Tri; dusk: Tri; night: Tri };
  cycle: 'full' | 'fixed';
  fixedTod?: number;       // used when cycle === 'fixed'
  palette: { primary: string; secondary: string; accent: string; glow: string; fog: string };
  /** which celestial bodies the sky has */
  celestial: 'sunmoon' | 'sunset' | 'moon' | 'none' | 'planet' | 'halo';
  layers: LayerDef[];
  decor: DecorKind[];
  weather: { kind: WeatherKind; density: number }[];
  clouds?: { count: number; color: string; shade: string; y: [number, number]; speed: number };
  ground: GroundKind;
  groundColors: readonly [string, string];
  obstacles: ObstacleKind[];
  obstaclePalette: { main: string; dark: string; light: string; glow: string; accent: string };
  /** decorative motif drawn on obstacles */
  motif: 'moss' | 'gold' | 'frost' | 'lava' | 'neon' | 'asteroid' | 'cloud' | 'coral' | 'petal' | 'void' | 'halo' | 'prism';
  ambient: AmbientDef;
  music: 'gameplay' | 'adventure' | 'galaxy' | 'zen' | 'boss';
  transition: { style: TransitionStyle; color: string };
  unlock: UnlockRule;
  hidden?: boolean;
}

const L = (vi: string, en: string): L10n => ({ vi, en });

export const WORLDS: WorldDef[] = [
  // ---------------------------------------------------------------- 1
  {
    id: 'emerald_valley', index: 1, name: 'Emerald Valley',
    tagline: L('Thung lũng xanh mướt', 'The green valley'),
    desc: L('Rừng cây rộng lớn, thác nước và mây trắng — nơi hành trình bắt đầu.', 'Vast forests, waterfalls and white clouds — where the journey begins.'),
    sky: { day: ['#2f9bea', '#7fd2ff', '#e2f8ff'], dusk: ['#3b2f7a', '#e0687a', '#ffc58b'], night: ['#050b2b', '#0e2552', '#1c4a63'] },
    cycle: 'full',
    palette: { primary: '#3fae6a', secondary: '#7fd2ff', accent: '#ffe27a', glow: '#b6ffd0', fog: '#dff7ff' },
    celestial: 'sunmoon',
    layers: [
      { kind: 'mountains', speed: 0.05, base: 0.62, height: 0.34, colors: ['#8fc0dd', '#e3f4fb'], seed: 11, params: { peaks: 5, snow: 1, waterfall: 1 } },
      { kind: 'mountains', speed: 0.1, base: 0.72, height: 0.28, colors: ['#4f9f9a', '#a8dccb'], seed: 12, params: { peaks: 6 } },
      { kind: 'hills', speed: 0.18, base: 0.8, height: 0.18, colors: ['#3fae6a', '#7edc8c'], seed: 13 },
      { kind: 'forest', speed: 0.32, base: 0.88, height: 0.22, colors: ['#1b7a4a', '#34ad6a'], seed: 14, params: { style: 'round' } },
      { kind: 'forest', speed: 0.55, base: 0.97, height: 0.2, colors: ['#0e5535', '#17824f'], seed: 15, params: { style: 'conifer' } },
    ],
    decor: ['clouds', 'birds_flock', 'butterflies', 'waterfall_mist', 'god_rays'],
    weather: [{ kind: 'pollen', density: 0.5 }, { kind: 'leaves', density: 0.35 }, { kind: 'fireflies', density: 0.4 }],
    clouds: { count: 9, color: '#ffffff', shade: '#cfe6f5', y: [0.08, 0.5], speed: 0.12 },
    ground: 'grass', groundColors: ['#2c9a58', '#145c37'],
    obstacles: ['pillar', 'ruins', 'crystal'],
    obstaclePalette: { main: '#8d9a7a', dark: '#4b5a3f', light: '#cfe0b0', glow: '#9dffb8', accent: '#3fae6a' },
    motif: 'moss',
    ambient: { noise: 'pink', noiseGain: 0.05, lowpass: 1800, highpass: 200, lfoRate: 0.12, lfoDepth: 0.6, drones: [{ freq: 110, type: 'sine', gain: 0.015 }], chimes: { scale: [0, 2, 4, 7, 9], root: 523, rate: 0.12, gain: 0.03, wave: 'sine' } },
    music: 'gameplay',
    transition: { style: 'iris', color: '#7affc1' },
    unlock: { type: 'free' },
  },
  // ---------------------------------------------------------------- 2
  {
    id: 'sunset_kingdom', index: 2, name: 'Sunset Kingdom',
    tagline: L('Vương quốc hoàng hôn', 'The kingdom of golden hours'),
    desc: L('Thành phố fantasy rực nắng vàng, mái vòm và những ngọn tháp.', 'A fantasy city bathed in golden light, domes and towers.'),
    sky: { day: ['#ff9a5a', '#ffc27a', '#ffe9b0'], dusk: ['#5b2a86', '#ff6b6b', '#ffc86b'], night: ['#1a1040', '#5b2a6b', '#d0627a'] },
    cycle: 'fixed', fixedTod: 0.5,
    palette: { primary: '#ff9a5a', secondary: '#ffd36b', accent: '#ff5d7a', glow: '#ffd27a', fog: '#ffd9a8' },
    celestial: 'sunset',
    layers: [
      { kind: 'mountains', speed: 0.04, base: 0.66, height: 0.3, colors: ['#c0587a', '#ff9a7a'], seed: 21, params: { peaks: 4, haze: 1 } },
      { kind: 'castle', speed: 0.1, base: 0.74, height: 0.36, colors: ['#7a3a6a', '#ffb070'], seed: 22, emissive: true, params: { style: 'far' } },
      { kind: 'castle', speed: 0.22, base: 0.84, height: 0.34, colors: ['#4a244f', '#ff9a5a'], seed: 23, emissive: true, params: { style: 'near', bridges: 1 } },
      { kind: 'city', speed: 0.5, base: 0.98, height: 0.18, colors: ['#2a1238', '#7a3a5a'], seed: 24, emissive: true, params: { style: 'rooftops' } },
    ],
    decor: ['clouds', 'lanterns', 'swallows', 'airships', 'god_rays'],
    weather: [{ kind: 'light_motes', density: 0.6 }, { kind: 'petals', density: 0.2 }],
    clouds: { count: 8, color: '#ffd9b0', shade: '#e0809a', y: [0.1, 0.5], speed: 0.1 },
    ground: 'rooftop', groundColors: ['#6a2f55', '#2f1238'],
    obstacles: ['ruins', 'crystal', 'platform'],
    obstaclePalette: { main: '#d9a066', dark: '#7a4a3a', light: '#ffe2a8', glow: '#ffc86b', accent: '#ff5d7a' },
    motif: 'gold',
    ambient: { noise: 'pink', noiseGain: 0.03, lowpass: 1200, highpass: 150, lfoRate: 0.08, lfoDepth: 0.5, drones: [{ freq: 98, type: 'triangle', gain: 0.02 }, { freq: 147, type: 'sine', gain: 0.012 }], chimes: { scale: [0, 3, 5, 7, 10], root: 440, rate: 0.2, gain: 0.035, wave: 'triangle' } },
    music: 'adventure',
    transition: { style: 'sunburst', color: '#ffd36b' },
    unlock: { type: 'coins', price: 300 },
  },
  // ---------------------------------------------------------------- 3
  {
    id: 'frozen_empire', index: 3, name: 'Frozen Empire',
    tagline: L('Vương quốc băng giá', 'The frozen realm'),
    desc: L('Núi tuyết, bão tuyết và cực quang rực rỡ trên bầu trời.', 'Snowy peaks, drifting snow and shimmering auroras.'),
    sky: { day: ['#5aa9e6', '#a9dcff', '#eaf8ff'], dusk: ['#3a3f8f', '#b07ad0', '#ffc9d8'], night: ['#040a22', '#0c2050', '#1d5a7a'] },
    cycle: 'full',
    palette: { primary: '#8fd6ff', secondary: '#e6f8ff', accent: '#7affd9', glow: '#b5ecff', fog: '#e6f6ff' },
    celestial: 'sunmoon',
    layers: [
      { kind: 'mountains', speed: 0.05, base: 0.64, height: 0.36, colors: ['#7fb4e0', '#f2fbff'], seed: 31, params: { peaks: 4, snow: 2 } },
      { kind: 'ice_spires', speed: 0.12, base: 0.76, height: 0.3, colors: ['#6fc0f0', '#e6faff'], seed: 32, emissive: true },
      { kind: 'mountains', speed: 0.2, base: 0.84, height: 0.2, colors: ['#4a86b8', '#cfeaff'], seed: 33, params: { peaks: 7, snow: 1 } },
      { kind: 'forest', speed: 0.5, base: 0.98, height: 0.22, colors: ['#1e4a66', '#3a7fa8'], seed: 34, params: { style: 'conifer', snow: 1 } },
    ],
    decor: ['clouds', 'aurora', 'god_rays'],
    weather: [{ kind: 'snow', density: 0.9 }, { kind: 'blizzard', density: 0.25 }, { kind: 'light_motes', density: 0.2 }],
    clouds: { count: 6, color: '#f4fbff', shade: '#bcdcf0', y: [0.06, 0.4], speed: 0.08 },
    ground: 'snow', groundColors: ['#eaf8ff', '#9fc9e6'],
    obstacles: ['ice', 'crystal'],
    obstaclePalette: { main: '#8fd6ff', dark: '#2c6fa8', light: '#f2fbff', glow: '#b5ecff', accent: '#ffffff' },
    motif: 'frost',
    ambient: { noise: 'white', noiseGain: 0.09, lowpass: 2400, highpass: 600, lfoRate: 0.2, lfoDepth: 0.8, drones: [{ freq: 82, type: 'sine', gain: 0.015 }], chimes: { scale: [0, 4, 7, 11, 14], root: 880, rate: 0.1, gain: 0.025, wave: 'sine' } },
    music: 'gameplay',
    transition: { style: 'frost', color: '#d9f4ff' },
    unlock: { type: 'level', level: 3, price: 500 },
  },
  // ---------------------------------------------------------------- 4
  {
    id: 'inferno_realm', index: 4, name: 'Inferno Realm',
    tagline: L('Cõi dung nham', 'The realm of lava'),
    desc: L('Núi lửa phun trào, dòng dung nham và ánh sáng đỏ cam.', 'Erupting volcanoes, rivers of lava and an orange glow.'),
    sky: { day: ['#2a0a0a', '#8a2a14', '#ff8a3a'], dusk: ['#1c0606', '#7a1e10', '#ff6a2a'], night: ['#0a0202', '#3a0e0a', '#c4381a'] },
    cycle: 'fixed', fixedTod: 0.3,
    palette: { primary: '#ff5a1f', secondary: '#ffb347', accent: '#ffe08a', glow: '#ff7a2b', fog: '#7a2a1a' },
    celestial: 'none',
    layers: [
      { kind: 'volcano', speed: 0.05, base: 0.7, height: 0.46, colors: ['#3a1410', '#ff6a2a'], seed: 41, emissive: true, params: { count: 3 } },
      { kind: 'mountains', speed: 0.12, base: 0.8, height: 0.26, colors: ['#2a0e0c', '#7a2a1a'], seed: 42, emissive: true, params: { peaks: 8, jagged: 1 } },
      { kind: 'rocks', speed: 0.3, base: 0.9, height: 0.2, colors: ['#1a0807', '#5a1a10'], seed: 43, emissive: true, params: { lava: 1 } },
      { kind: 'rocks', speed: 0.6, base: 1.0, height: 0.16, colors: ['#0e0404', '#3a0e0a'], seed: 44, params: { jagged: 1 } },
    ],
    decor: ['lava_eruption', 'lightning', 'god_rays'],
    weather: [{ kind: 'embers', density: 1 }, { kind: 'ash', density: 0.6 }],
    clouds: { count: 7, color: '#5a2418', shade: '#2a0e0c', y: [0.05, 0.45], speed: 0.1 },
    ground: 'lava', groundColors: ['#ff5a1f', '#6a1408'],
    obstacles: ['fire', 'pillar', 'ring'],
    obstaclePalette: { main: '#4a2a28', dark: '#1c0c0a', light: '#ffb347', glow: '#ff6a2a', accent: '#ffe08a' },
    motif: 'lava',
    ambient: { noise: 'brown', noiseGain: 0.12, lowpass: 600, highpass: 40, lfoRate: 0.15, lfoDepth: 0.7, drones: [{ freq: 55, type: 'sawtooth', gain: 0.02 }, { freq: 82.4, type: 'sine', gain: 0.02 }], crackle: 0.8, thunder: 0.3 },
    music: 'gameplay',
    transition: { style: 'flame', color: '#ff6a2a' },
    unlock: { type: 'coins', price: 800 },
  },
  // ---------------------------------------------------------------- 5
  {
    id: 'cyber_nexus', index: 5, name: 'Cyber Nexus',
    tagline: L('Thành phố tương lai', 'The neon megacity'),
    desc: L('Neon, hologram và hiệu ứng kỹ thuật số trong màn đêm bất tận.', 'Neon, holograms and digital rain in an endless night.'),
    sky: { day: ['#0a0a2e', '#2a1060', '#7a2aa0'], dusk: ['#0a0a2e', '#3a1470', '#a02ab0'], night: ['#05051a', '#150a45', '#4a1a8a'] },
    cycle: 'fixed', fixedTod: 0.78,
    palette: { primary: '#00e5ff', secondary: '#ff2bd6', accent: '#00ffd5', glow: '#00e5ff', fog: '#3a1a7a' },
    celestial: 'moon',
    layers: [
      { kind: 'city', speed: 0.06, base: 0.74, height: 0.4, colors: ['#1a1450', '#3a2a8a'], seed: 51, emissive: true, params: { style: 'skyline', haze: 1 } },
      { kind: 'city', speed: 0.16, base: 0.86, height: 0.5, colors: ['#0e0a35', '#2a1a70'], seed: 52, emissive: true, params: { style: 'towers', neon: 1 } },
      { kind: 'neon_rail', speed: 0.5, base: 0.97, height: 0.2, colors: ['#0a0828', '#ff2bd6'], seed: 53, emissive: true },
    ],
    decor: ['drones', 'holo_billboards', 'data_streams', 'airships'],
    weather: [{ kind: 'digital_rain', density: 0.8 }, { kind: 'sparks', density: 0.3 }],
    ground: 'grid', groundColors: ['#12083a', '#00e5ff'],
    obstacles: ['laser', 'energy', 'platform'],
    obstaclePalette: { main: '#1e1a4a', dark: '#0a0830', light: '#6a5aff', glow: '#00e5ff', accent: '#ff2bd6' },
    motif: 'neon',
    ambient: { noise: 'white', noiseGain: 0.02, lowpass: 3000, highpass: 1500, lfoRate: 0.3, lfoDepth: 0.4, drones: [{ freq: 55, type: 'square', gain: 0.012 }, { freq: 110.5, type: 'sawtooth', gain: 0.01 }], beeps: 0.6 },
    music: 'adventure',
    transition: { style: 'glitch', color: '#00e5ff' },
    unlock: { type: 'level', level: 6, price: 1200 },
  },
  // ---------------------------------------------------------------- 6
  {
    id: 'galaxy_odyssey', index: 6, name: 'Galaxy Odyssey',
    tagline: L('Hành trình vũ trụ', 'Journey through the cosmos'),
    desc: L('Hành tinh, tinh vân và những cơn mưa sao băng.', 'Planets, nebulae and showers of shooting stars.'),
    sky: { day: ['#04061c', '#10104a', '#3a1a7a'], dusk: ['#04061c', '#14104a', '#4a1a7a'], night: ['#02030f', '#0a0a35', '#2a1060'] },
    cycle: 'fixed', fixedTod: 0.76,
    palette: { primary: '#7a5bff', secondary: '#ff6ad5', accent: '#9ff3ff', glow: '#9a7bff', fog: '#2a1a6a' },
    celestial: 'planet',
    layers: [
      { kind: 'stars', speed: 0.02, base: 1, height: 1, colors: ['#ffffff', '#9ff3ff'], seed: 61, params: { density: 1 } },
      { kind: 'nebula', speed: 0.04, base: 0.9, height: 0.8, colors: ['#7a3aff', '#ff4ad0'], seed: 62 },
      { kind: 'stars', speed: 0.08, base: 1, height: 1, colors: ['#ffffff', '#ffd9a8'], seed: 63, params: { density: 0.5, big: 1 } },
      { kind: 'asteroids', speed: 0.2, base: 0.95, height: 0.3, colors: ['#3a3260', '#9a8ad0'], seed: 64 },
      { kind: 'asteroids', speed: 0.5, base: 1.0, height: 0.22, colors: ['#1e1a3a', '#6a5a9a'], seed: 65, params: { big: 1 } },
    ],
    decor: ['ringed_planet', 'shooting_stars', 'meteors', 'aurora'],
    weather: [{ kind: 'stars', density: 0.8 }, { kind: 'light_motes', density: 0.3 }],
    ground: 'dust', groundColors: ['#4a2a9a', '#10083a'],
    obstacles: ['ring', 'energy', 'pillar'],
    obstaclePalette: { main: '#4a4478', dark: '#1a1636', light: '#b5a8ff', glow: '#9ff3ff', accent: '#ff6ad5' },
    motif: 'asteroid',
    ambient: { noise: 'brown', noiseGain: 0.05, lowpass: 400, highpass: 30, lfoRate: 0.05, lfoDepth: 0.8, drones: [{ freq: 65.4, type: 'sine', gain: 0.03 }, { freq: 98, type: 'sine', gain: 0.02, detune: 7 }, { freq: 196, type: 'triangle', gain: 0.008, detune: -9 }], chimes: { scale: [0, 2, 7, 9, 14], root: 660, rate: 0.08, gain: 0.02, wave: 'sine' } },
    music: 'galaxy',
    transition: { style: 'warp', color: '#9ff3ff' },
    unlock: { type: 'coins', price: 1500 },
  },
  // ---------------------------------------------------------------- 7
  {
    id: 'sky_temple', index: 7, name: 'Sky Temple',
    tagline: L('Đền cổ trên mây', 'The temple above the clouds'),
    desc: L('Ngôi đền cổ giữa biển mây với ánh sáng thần thánh.', 'An ancient temple in a sea of clouds, lit by holy light.'),
    sky: { day: ['#4a8be8', '#9fd0ff', '#fff4d6'], dusk: ['#4a3a9a', '#e08aa0', '#ffd9a0'], night: ['#0a1240', '#2a3a8a', '#7a8ad0'] },
    cycle: 'full',
    palette: { primary: '#ffe9a8', secondary: '#9fd0ff', accent: '#ffd36b', glow: '#fff2c0', fog: '#fff4e0' },
    celestial: 'sunmoon',
    layers: [
      { kind: 'islands', speed: 0.05, base: 0.55, height: 0.3, colors: ['#8aa8d8', '#e8f2ff'], seed: 71, params: { temples: 1, far: 1 } },
      { kind: 'temple', speed: 0.14, base: 0.8, height: 0.4, colors: ['#c9b890', '#fff4d6'], seed: 72, emissive: true },
      { kind: 'cloud_sea', speed: 0.3, base: 0.92, height: 0.14, colors: ['#ffffff', '#c8dcf4'], seed: 73 },
      { kind: 'cloud_sea', speed: 0.6, base: 1.0, height: 0.14, colors: ['#ffffff', '#b0c8ee'], seed: 74 },
    ],
    decor: ['clouds', 'god_rays', 'floating_islands', 'birds_flock', 'angels'],
    weather: [{ kind: 'light_motes', density: 0.8 }, { kind: 'feathers', density: 0.3 }],
    clouds: { count: 10, color: '#ffffff', shade: '#d8e6f8', y: [0.05, 0.55], speed: 0.14 },
    ground: 'clouds', groundColors: ['#ffffff', '#a8c4ec'],
    obstacles: ['ruins', 'pillar', 'portal'],
    obstaclePalette: { main: '#e8dcc0', dark: '#8a7a5a', light: '#fffbe8', glow: '#ffe9a8', accent: '#ffd36b' },
    motif: 'cloud',
    ambient: { noise: 'pink', noiseGain: 0.05, lowpass: 1000, highpass: 120, lfoRate: 0.1, lfoDepth: 0.7, drones: [{ freq: 130.8, type: 'sine', gain: 0.02 }, { freq: 196, type: 'sine', gain: 0.015, detune: 5 }, { freq: 261.6, type: 'sine', gain: 0.01, detune: -6 }], chimes: { scale: [0, 2, 4, 7, 9, 12], root: 587, rate: 0.15, gain: 0.03, wave: 'sine' } },
    music: 'adventure',
    transition: { style: 'light', color: '#fff2c0' },
    unlock: { type: 'level', level: 9, price: 2000 },
  },
  // ---------------------------------------------------------------- 8
  {
    id: 'underwater_dream', index: 8, name: 'Underwater Dream',
    tagline: L('Giấc mơ đại dương', 'The ocean dream'),
    desc: L('San hô rực rỡ, sứa phát sáng và những đàn cá lung linh.', 'Colorful coral, glowing jellyfish and shimmering fish schools.'),
    sky: { day: ['#0a6ac0', '#1ab0d8', '#7af0e0'], dusk: ['#0a3a8a', '#1a7ab0', '#5ad0c0'], night: ['#020a30', '#06285a', '#0a5a7a'] },
    cycle: 'full',
    palette: { primary: '#1ab0d8', secondary: '#7af0e0', accent: '#ff7ab8', glow: '#9ffff0', fog: '#2a90c0' },
    celestial: 'none',
    layers: [
      { kind: 'reef', speed: 0.06, base: 0.78, height: 0.34, colors: ['#0a4a8a', '#2a8ac0'], seed: 81, params: { far: 1 } },
      { kind: 'reef', speed: 0.14, base: 0.86, height: 0.3, colors: ['#0a5a7a', '#ff7ab8'], seed: 82, emissive: true },
      { kind: 'kelp', speed: 0.3, base: 0.96, height: 0.4, colors: ['#0a6a4a', '#3ad08a'], seed: 83 },
      { kind: 'reef', speed: 0.55, base: 1.0, height: 0.2, colors: ['#052a4a', '#ff9a4a'], seed: 84, params: { near: 1 } },
    ],
    decor: ['caustics', 'god_rays', 'jellyfish', 'fish_school', 'whale', 'turtle'],
    weather: [{ kind: 'bubbles', density: 1 }, { kind: 'light_motes', density: 0.3 }],
    ground: 'sand', groundColors: ['#e8d09a', '#9a7a4a'],
    obstacles: ['crystal', 'platform', 'portal'],
    obstaclePalette: { main: '#ff7ab8', dark: '#8a2a6a', light: '#ffd0e8', glow: '#9ffff0', accent: '#ffb347' },
    motif: 'coral',
    ambient: { noise: 'brown', noiseGain: 0.08, lowpass: 500, highpass: 50, lfoRate: 0.18, lfoDepth: 0.6, drones: [{ freq: 73.4, type: 'sine', gain: 0.02 }, { freq: 110, type: 'sine', gain: 0.012, detune: 4 }], bubbles: 0.8, chimes: { scale: [0, 3, 7, 10], root: 392, rate: 0.06, gain: 0.02, wave: 'sine' } },
    music: 'zen',
    transition: { style: 'ripple', color: '#9ffff0' },
    unlock: { type: 'coins', price: 2200 },
  },
  // ---------------------------------------------------------------- 9
  {
    id: 'sakura_dream', index: 9, name: 'Sakura Dream',
    tagline: L('Giấc mơ anh đào', 'The blossom dream'),
    desc: L('Cánh hoa anh đào bay trong ánh sáng dịu nhẹ của bình minh.', 'Cherry blossom petals dancing in soft dawn light.'),
    sky: { day: ['#ffb0d0', '#ffd9e8', '#fff4f8'], dusk: ['#6a3a8a', '#ff8ab0', '#ffd0b0'], night: ['#1a1245', '#4a2a7a', '#a05a9a'] },
    cycle: 'full',
    palette: { primary: '#ff9ac6', secondary: '#ffe0ee', accent: '#ffffff', glow: '#ffc0dc', fog: '#ffe8f2' },
    celestial: 'sunmoon',
    layers: [
      { kind: 'mountains', speed: 0.04, base: 0.62, height: 0.4, colors: ['#c8a0d8', '#f4e0f4'], seed: 91, params: { peaks: 2, haze: 1, fuji: 1 } },
      { kind: 'torii', speed: 0.12, base: 0.8, height: 0.3, colors: ['#c8384a', '#ff8a9a'], seed: 92, emissive: true },
      { kind: 'sakura', speed: 0.3, base: 0.9, height: 0.34, colors: ['#8a4a5a', '#ff9ac6'], seed: 93 },
      { kind: 'sakura', speed: 0.6, base: 1.0, height: 0.3, colors: ['#5a2a3a', '#ff7ab0'], seed: 94, params: { near: 1 } },
    ],
    decor: ['clouds', 'petal_swirl', 'lanterns', 'butterflies', 'birds_flock'],
    weather: [{ kind: 'petals', density: 1 }, { kind: 'light_motes', density: 0.4 }],
    clouds: { count: 7, color: '#fff0f6', shade: '#f0b8d0', y: [0.06, 0.45], speed: 0.1 },
    ground: 'petals', groundColors: ['#ffc0dc', '#b85a8a'],
    obstacles: ['pillar', 'platform', 'portal'],
    obstaclePalette: { main: '#b0484e', dark: '#5a1a2a', light: '#ffc8d0', glow: '#ffc0dc', accent: '#ffe27a' },
    motif: 'petal',
    ambient: { noise: 'pink', noiseGain: 0.035, lowpass: 1400, highpass: 250, lfoRate: 0.1, lfoDepth: 0.6, drones: [{ freq: 110, type: 'sine', gain: 0.012 }], chimes: { scale: [0, 2, 3, 7, 8], root: 523, rate: 0.18, gain: 0.035, wave: 'triangle' } },
    music: 'zen',
    transition: { style: 'petals', color: '#ffc0dc' },
    unlock: { type: 'level', level: 12, price: 2600 },
  },
  // ---------------------------------------------------------------- 10 (hidden)
  {
    id: 'dark_dimension', index: 10, name: 'Dark Dimension',
    tagline: L('Chiều không gian tối', 'The shadow dimension'),
    desc: L('Sương mù huyền bí, ánh sáng ma thuật và những ngọn tháp méo mó.', 'Mysterious fog, arcane light and twisted spires.'),
    sky: { day: ['#0a0418', '#2a0a4a', '#6a1a7a'], dusk: ['#0a0418', '#2a0a4a', '#7a1a6a'], night: ['#040210', '#140630', '#3a0a5a'] },
    cycle: 'fixed', fixedTod: 0.8,
    palette: { primary: '#8a5bff', secondary: '#ff4ad0', accent: '#c5a3ff', glow: '#a070ff', fog: '#2a0a4a' },
    celestial: 'moon',
    layers: [
      { kind: 'dark_spires', speed: 0.05, base: 0.72, height: 0.5, colors: ['#1a0a30', '#5a2a8a'], seed: 101, emissive: true },
      { kind: 'crystals', speed: 0.14, base: 0.86, height: 0.4, colors: ['#3a1a6a', '#b070ff'], seed: 102, emissive: true },
      { kind: 'rocks', speed: 0.4, base: 0.98, height: 0.24, colors: ['#0a0418', '#3a1a5a'], seed: 103, params: { thorns: 1 } },
    ],
    decor: ['rune_circle', 'wisps', 'lightning', 'god_rays'],
    weather: [{ kind: 'wisps', density: 0.8 }, { kind: 'ash', density: 0.3 }],
    clouds: { count: 6, color: '#3a1a5a', shade: '#1a0a30', y: [0.05, 0.5], speed: 0.06 },
    ground: 'void', groundColors: ['#2a0a4a', '#050210'],
    obstacles: ['crystal', 'energy', 'portal'],
    obstaclePalette: { main: '#3a1a6a', dark: '#0e0420', light: '#c09aff', glow: '#a070ff', accent: '#ff4ad0' },
    motif: 'void',
    ambient: { noise: 'brown', noiseGain: 0.07, lowpass: 350, highpass: 30, lfoRate: 0.07, lfoDepth: 0.9, drones: [{ freq: 55, type: 'sawtooth', gain: 0.015 }, { freq: 58.3, type: 'sawtooth', gain: 0.015 }, { freq: 82.4, type: 'sine', gain: 0.02, detune: 11 }], thunder: 0.4, chimes: { scale: [0, 1, 6, 7], root: 311, rate: 0.07, gain: 0.02, wave: 'sine' } },
    music: 'boss',
    transition: { style: 'void', color: '#a070ff' },
    unlock: { type: 'secret', id: 'score_60', hint: L('Đạt 60 điểm trong bất kỳ lượt chơi nào.', 'Reach 60 points in any run.') },
    hidden: true,
  },
  // ---------------------------------------------------------------- 11
  {
    id: 'celestial_kingdom', index: 11, name: 'Celestial Kingdom',
    tagline: L('Vương quốc thiên giới', 'The kingdom of heaven'),
    desc: L('Thành phố vàng trắng trên thiên giới, nơi ánh sáng không bao giờ tắt.', 'A gold and white city in the heavens where the light never fades.'),
    sky: { day: ['#ffe9a0', '#fff4cf', '#ffffff'], dusk: ['#ffb870', '#ffe0a0', '#fff8e0'], night: ['#6a5ac0', '#c0a8f0', '#ffe9c0'] },
    cycle: 'fixed', fixedTod: 0.2,
    palette: { primary: '#ffd36b', secondary: '#ffffff', accent: '#ffe9a0', glow: '#fff2b0', fog: '#fff8e0' },
    celestial: 'halo',
    layers: [
      { kind: 'celestial_city', speed: 0.06, base: 0.74, height: 0.5, colors: ['#e8d8a8', '#ffffff'], seed: 111, emissive: true, params: { far: 1 } },
      { kind: 'temple', speed: 0.16, base: 0.86, height: 0.42, colors: ['#ffe9a0', '#ffffff'], seed: 112, emissive: true, params: { gold: 1 } },
      { kind: 'cloud_sea', speed: 0.35, base: 0.95, height: 0.16, colors: ['#ffffff', '#ffe9b8'], seed: 113 },
      { kind: 'cloud_sea', speed: 0.6, base: 1.0, height: 0.14, colors: ['#fffdf4', '#ffd890'], seed: 114 },
    ],
    decor: ['god_rays', 'angels', 'clouds', 'birds_flock'],
    weather: [{ kind: 'feathers', density: 0.6 }, { kind: 'light_motes', density: 1 }, { kind: 'stars', density: 0.3 }],
    clouds: { count: 9, color: '#ffffff', shade: '#ffe9b8', y: [0.05, 0.5], speed: 0.1 },
    ground: 'light', groundColors: ['#fff8e0', '#ffd36b'],
    obstacles: ['ruins', 'ring', 'portal'],
    obstaclePalette: { main: '#fff4d0', dark: '#c0a050', light: '#ffffff', glow: '#fff2b0', accent: '#ffd36b' },
    motif: 'halo',
    ambient: { noise: 'pink', noiseGain: 0.03, lowpass: 900, highpass: 100, lfoRate: 0.08, lfoDepth: 0.5, drones: [{ freq: 130.8, type: 'sine', gain: 0.022 }, { freq: 164.8, type: 'sine', gain: 0.018, detune: 3 }, { freq: 196, type: 'sine', gain: 0.015, detune: -4 }, { freq: 261.6, type: 'sine', gain: 0.01 }], chimes: { scale: [0, 4, 7, 11, 12], root: 784, rate: 0.2, gain: 0.03, wave: 'sine' } },
    music: 'adventure',
    transition: { style: 'halo', color: '#fff2b0' },
    unlock: { type: 'level', level: 20, price: 4000 },
  },
  // ---------------------------------------------------------------- 12 (hidden)
  {
    id: 'infinity_universe', index: 12, name: 'Infinity Universe',
    tagline: L('Vũ trụ vô cực', 'The infinite multiverse'),
    desc: L('Thế giới cuối cùng, nơi mọi chiều không gian hội tụ.', 'The final world where every dimension converges.'),
    sky: { day: ['#1a0a4a', '#6a1aa0', '#ff4ad0'], dusk: ['#0a2a6a', '#1a8ad0', '#7affd9'], night: ['#2a0a5a', '#a01a8a', '#ffb347'] },
    cycle: 'full',
    palette: { primary: '#ff4ad0', secondary: '#4ae0ff', accent: '#ffe27a', glow: '#ffffff', fog: '#4a1a8a' },
    celestial: 'planet',
    layers: [
      { kind: 'stars', speed: 0.03, base: 1, height: 1, colors: ['#ffffff', '#ffd9ff'], seed: 121, params: { density: 1 } },
      { kind: 'nebula', speed: 0.05, base: 0.9, height: 0.9, colors: ['#ff4ad0', '#4ae0ff'], seed: 122 },
      { kind: 'geometry', speed: 0.12, base: 0.85, height: 0.6, colors: ['#8a5bff', '#4ae0ff'], seed: 123, emissive: true },
      { kind: 'geometry', speed: 0.4, base: 1.0, height: 0.36, colors: ['#ff4ad0', '#ffe27a'], seed: 124, emissive: true, params: { near: 1 } },
    ],
    decor: ['cubes', 'portals_far', 'shooting_stars', 'aurora', 'ringed_planet'],
    weather: [{ kind: 'stars', density: 0.6 }, { kind: 'sparks', density: 0.4 }, { kind: 'petals', density: 0.2 }, { kind: 'snow', density: 0.2 }],
    ground: 'prism', groundColors: ['#8a5bff', '#ff4ad0'],
    obstacles: ['ring', 'laser', 'energy', 'portal', 'platform', 'crystal'],
    obstaclePalette: { main: '#4a2a9a', dark: '#14083a', light: '#ffd9ff', glow: '#ffffff', accent: '#4ae0ff' },
    motif: 'prism',
    ambient: { noise: 'pink', noiseGain: 0.04, lowpass: 1600, highpass: 60, lfoRate: 0.2, lfoDepth: 0.8, drones: [{ freq: 55, type: 'sine', gain: 0.025 }, { freq: 82.4, type: 'triangle', gain: 0.02, detune: 8 }, { freq: 123.5, type: 'sine', gain: 0.015, detune: -8 }], chimes: { scale: [0, 2, 4, 6, 8, 10], root: 523, rate: 0.25, gain: 0.03, wave: 'sine' }, beeps: 0.2 },
    music: 'galaxy',
    transition: { style: 'kaleido', color: '#ffffff' },
    unlock: { type: 'secret', id: 'all_worlds', hint: L('Mở khóa 11 thế giới còn lại và hoàn thành Phiêu lưu.', 'Unlock the other 11 worlds and complete Adventure.') },
    hidden: true,
  },
];

export const WORLD_BY_ID: Record<string, WorldDef> = Object.fromEntries(WORLDS.map((w) => [w.id, w]));
export const DEFAULT_WORLD = 'emerald_valley';
