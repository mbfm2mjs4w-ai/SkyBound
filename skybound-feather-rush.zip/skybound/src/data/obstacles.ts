import type { L10n, ObstacleKind } from '../core/types';

/** 'rect': axis-aligned column. 'spike': column ending with a triangle pointing into the gap.
 *  'circles': column built from stacked circles of radius halfW (rotating ring gears). */
export type HitShape = 'rect' | 'spike' | 'circles';
export type GapMotion = 'static' | 'bob' | 'breathe';

export interface ObstacleSpec {
  kind: ObstacleKind;
  halfW: number;           // half width of the solid column (hitbox AND visual)
  shape: HitShape;
  tip: number;             // spike length (only 'spike'); apex sits exactly at the gap edge
  motion: GapMotion;       // default movement style
  amp: [number, number];   // motion amplitude range (units): bob = vertical travel, breathe = gap half change
  name: L10n;
}

export const OBSTACLES: Record<ObstacleKind, ObstacleSpec> = {
  crystal:  { kind: 'crystal',  halfW: 34, shape: 'spike',   tip: 54, motion: 'static',  amp: [0, 0],   name: { vi: 'Cổng Pha Lê', en: 'Crystal Gate' } },
  pillar:   { kind: 'pillar',   halfW: 40, shape: 'rect',    tip: 0,  motion: 'bob',     amp: [14, 34], name: { vi: 'Trụ Đá Lơ Lửng', en: 'Floating Stone Pillar' } },
  ruins:    { kind: 'ruins',    halfW: 38, shape: 'rect',    tip: 0,  motion: 'static',  amp: [0, 0],   name: { vi: 'Tàn Tích Cổ', en: 'Ancient Ruins' } },
  energy:   { kind: 'energy',   halfW: 22, shape: 'rect',    tip: 0,  motion: 'breathe', amp: [10, 20], name: { vi: 'Rào Năng Lượng', en: 'Energy Barrier' } },
  platform: { kind: 'platform', halfW: 58, shape: 'rect',    tip: 0,  motion: 'bob',     amp: [30, 68], name: { vi: 'Bệ Di Động', en: 'Moving Platform' } },
  ring:     { kind: 'ring',     halfW: 36, shape: 'circles', tip: 0,  motion: 'bob',     amp: [10, 28], name: { vi: 'Vòng Xoay', en: 'Rotating Ring' } },
  laser:    { kind: 'laser',    halfW: 14, shape: 'rect',    tip: 0,  motion: 'breathe', amp: [8, 16],  name: { vi: 'Cổng Laser', en: 'Laser Gate' } },
  fire:     { kind: 'fire',     halfW: 30, shape: 'rect',    tip: 0,  motion: 'static',  amp: [0, 0],   name: { vi: 'Tường Lửa', en: 'Fire Wall' } },
  ice:      { kind: 'ice',      halfW: 30, shape: 'spike',   tip: 72, motion: 'static',  amp: [0, 0],   name: { vi: 'Gai Băng', en: 'Ice Spikes' } },
  portal:   { kind: 'portal',   halfW: 26, shape: 'rect',    tip: 0,  motion: 'bob',     amp: [8, 22],  name: { vi: 'Cổng Ma Thuật', en: 'Magical Portal' } },
};
export const OBSTACLE_KINDS = Object.keys(OBSTACLES) as ObstacleKind[];
