// Stateless animated background actors. Everything is a pure function of time/scroll so two worlds can render in one frame.
import type { DecorKind, WorldDef } from '../../data/worlds';
import { clamp, rgba, shadeHex, TAU } from '../../core/util';
import { drawGlow, starPath, type Ctx } from '../gfx';
import { mulberry32 } from '../../core/util';

export interface DecorEnv {
  W: number; H: number; t: number; scroll: number; camY: number;
  night: number; day: number; dusk: number; def: WorldDef; reduced: boolean; fixedDark: boolean;
}
const hash = (n: number): number => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
/** x that loops across the screen: wraps over (W + 2*m) */
const loop = (seed: number, speed: number, t: number, W: number, m: number, dir = -1): number => {
  const range = W + m * 2; let v = (hash(seed) * range + dir * speed * t) % range; if (v < 0) v += range; return v - m;
};
const px = (E: DecorEnv, speed: number, off = 0, m = 200): number => { const range = E.W + m * 2; let v = (off - E.scroll * speed) % range; if (v < 0) v += range; return v - m; };

function bird(c: Ctx, x: number, y: number, s: number, ph: number, color: string): void {
  const f = Math.sin(ph) * 5 * s;
  c.strokeStyle = color; c.lineWidth = 1.8 * s; c.lineCap = 'round';
  c.beginPath(); c.moveTo(x - 9 * s, y - f); c.quadraticCurveTo(x - 4 * s, y - 3 * s, x, y); c.quadraticCurveTo(x + 4 * s, y - 3 * s, x + 9 * s, y - f); c.stroke();
}

export const DECOR: Partial<Record<DecorKind, (c: Ctx, E: DecorEnv) => void>> = {
  clouds: () => { /* drawn by the renderer from sprites */ },
  god_rays: () => { /* drawn by the renderer */ },
  birds_flock(c, E) {
    const col = E.night > 0.5 ? 'rgba(10,15,40,0.7)' : 'rgba(30,40,70,0.55)';
    for (let f = 0; f < 2; f++) {
      const x0 = loop(f * 7 + 3, 36 + f * 10, E.t, E.W, 260), y0 = E.H * (0.17 + f * 0.15) + Math.sin(E.t * 0.6 + f) * 12 - E.camY * 0.2;
      for (let i = 0; i < 6; i++) { const k = Math.ceil(i / 2) * (i % 2 ? 1 : -1); bird(c, x0 + Math.abs(k) * 18, y0 + k * 9, 1 - Math.abs(k) * 0.08, E.t * 7 + i + f, col); }
    }
  },
  swallows(c, E) {
    const col = 'rgba(40,20,50,0.75)';
    for (let i = 0; i < 5; i++) bird(c, loop(i + 40, 70 + i * 9, E.t, E.W, 120, i % 2 ? -1 : 1), E.H * (0.2 + hash(i + 40) * 0.35) + Math.sin(E.t * 2 + i) * 18 - E.camY * 0.2, 0.9, E.t * 11 + i, col);
  },
  butterflies(c, E) {
    for (let i = 0; i < 5; i++) {
      const x = loop(i + 11, 18 + i * 4, E.t, E.W, 80) + Math.sin(E.t * 1.3 + i) * 30, y = E.H * (0.55 + hash(i) * 0.22) + Math.sin(E.t * 2.1 + i * 2) * 24 - E.camY * 0.5;
      const f = Math.abs(Math.sin(E.t * 9 + i)), col = i % 2 ? E.def.palette.accent : '#ff9ac6';
      c.fillStyle = col; c.beginPath(); c.ellipse(x - 3, y, 4.2 * f + 0.8, 5, -0.4, 0, TAU); c.ellipse(x + 3, y, 4.2 * f + 0.8, 5, 0.4, 0, TAU); c.fill();
    }
  },
  lanterns(c, E) {
    for (let i = 0; i < 8; i++) {
      const sp = 12 + hash(i) * 8, x = px(E, 0.18, hash(i + 5) * (E.W + 400), 120) + Math.sin(E.t * 0.8 + i) * 14;
      let y = (hash(i + 20) * (E.H * 0.9) - E.t * sp) % (E.H * 0.95); if (y < 0) y += E.H * 0.95;
      y += 20 - E.camY * 0.3;
      drawGlow(c, x, y, 34, '#ffb347', 0.55 + 0.2 * Math.sin(E.t * 3 + i));
      c.fillStyle = '#ff7a2b'; c.beginPath(); c.roundRect ? c.roundRect(x - 6, y - 8, 12, 16, 4) : c.rect(x - 6, y - 8, 12, 16); c.fill();
      c.fillStyle = '#ffe9a0'; c.fillRect(x - 3, y - 4, 6, 8);
    }
  },
  drones(c, E) {
    for (let i = 0; i < 3; i++) {
      const x = px(E, 0.16, hash(i + 3) * E.W * 1.3, 100) + Math.sin(E.t + i) * 20, y = E.H * (0.2 + hash(i + 8) * 0.3) + Math.sin(E.t * 1.7 + i * 3) * 8 - E.camY * 0.25;
      c.fillStyle = '#0a0830'; c.fillRect(x - 8, y - 2, 16, 5); c.fillStyle = '#2a1a70'; c.fillRect(x - 12, y - 4, 24, 2);
      c.fillStyle = (Math.floor(E.t * 3 + i) % 2) ? '#ff2b4a' : '#00e5ff'; c.beginPath(); c.arc(x, y + 3, 1.8, 0, TAU); c.fill();
      drawGlow(c, x, y + 3, 16, '#00e5ff', 0.35);
    }
  },
  holo_billboards(c, E) {
    for (let i = 0; i < 3; i++) {
      const x = px(E, 0.1, i * (E.W * 0.6 + 90) + 120, 220), y = E.H * (0.2 + i * 0.1) - E.camY * 0.12, w = 90, h = 120;
      const col = i % 2 ? '#ff2bd6' : '#00e5ff';
      c.save(); c.globalAlpha = 0.5 + 0.12 * Math.sin(E.t * 5 + i);
      c.fillStyle = rgba(col, 0.12); c.fillRect(x, y, w, h); c.strokeStyle = rgba(col, 0.95); c.lineWidth = 1.6; c.strokeRect(x, y, w, h);
      c.fillStyle = rgba(col, 0.55); for (let k = 0; k < 7; k++) c.fillRect(x + 8, y + 12 + k * 15, (30 + hash(i * 9 + k + Math.floor(E.t)) * 50), 3.4);
      c.fillStyle = rgba('#ffffff', 0.12); for (let k = 0; k < h; k += 4) c.fillRect(x, y + k, w, 1);
      c.restore();
    }
  },
  meteors(c, E) {
    for (let i = 0; i < 2; i++) {
      const per = 7 + i * 4, ph = ((E.t + i * 3.1) % per) / per; if (ph > 0.18) continue;
      const k = ph / 0.18, x = E.W * (0.2 + hash(Math.floor((E.t + i * 3.1) / per) + i) * 0.8) - k * 260, y = -20 + k * 260 + i * 80;
      const g = c.createLinearGradient(x, y, x + 120, y - 120); g.addColorStop(0, 'rgba(255,255,255,0.95)'); g.addColorStop(1, 'rgba(255,200,120,0)');
      c.strokeStyle = g; c.lineWidth = 2.6; c.lineCap = 'round'; c.beginPath(); c.moveTo(x, y); c.lineTo(x + 120, y - 120); c.stroke(); drawGlow(c, x, y, 14, '#ffd9a8', 0.8);
    }
  },
  shooting_stars(c, E) {
    for (let i = 0; i < 3; i++) {
      const per = 5 + i * 2.3, ph = ((E.t + i * 1.7) % per) / per; if (ph > 0.12) continue;
      const k = ph / 0.12, seed = Math.floor((E.t + i * 1.7) / per) + i * 9, x = E.W * (0.1 + hash(seed) * 0.9) - k * 300, y = E.H * (hash(seed + 1) * 0.5) + k * 150;
      const g = c.createLinearGradient(x, y, x + 150, y - 75); g.addColorStop(0, 'rgba(255,255,255,0.95)'); g.addColorStop(1, 'rgba(160,220,255,0)');
      c.strokeStyle = g; c.lineWidth = 2; c.lineCap = 'round'; c.beginPath(); c.moveTo(x, y); c.lineTo(x + 150, y - 75); c.stroke();
    }
  },
  ringed_planet(c, E) {
    const x = px(E, 0.025, E.W * 0.75, 300), y = E.H * 0.26 - E.camY * 0.05, r = 96;
    drawGlow(c, x, y, r * 2.2, E.def.palette.glow, 0.35);
    c.save(); c.translate(x, y); c.rotate(-0.3);
    c.strokeStyle = 'rgba(255,214,160,0.55)'; c.lineWidth = 10; c.beginPath(); c.ellipse(0, 0, r * 1.7, r * 0.42, 0, Math.PI, TAU); c.stroke();
    const g = c.createRadialGradient(-r * 0.4, -r * 0.4, 6, 0, 0, r); g.addColorStop(0, shadeHex(E.def.palette.accent, 0.1)); g.addColorStop(0.6, E.def.palette.primary); g.addColorStop(1, shadeHex(E.def.palette.primary, -0.6));
    c.fillStyle = g; c.beginPath(); c.arc(0, 0, r, 0, TAU); c.fill();
    c.save(); c.beginPath(); c.arc(0, 0, r, 0, TAU); c.clip(); c.strokeStyle = 'rgba(255,255,255,0.14)'; c.lineWidth = 9; for (let k = -2; k <= 2; k++) { c.beginPath(); c.moveTo(-r, k * 24); c.quadraticCurveTo(0, k * 24 + 10, r, k * 24); c.stroke(); } c.restore();
    c.strokeStyle = 'rgba(255,214,160,0.7)'; c.lineWidth = 10; c.beginPath(); c.ellipse(0, 0, r * 1.7, r * 0.42, 0, 0, Math.PI); c.stroke();
    c.restore();
  },
  floating_islands(c, E) {
    for (let i = 0; i < 3; i++) {
      const x = px(E, 0.07 + i * 0.03, hash(i + 70) * (E.W + 300), 160), y = E.H * (0.22 + i * 0.12) + Math.sin(E.t * 0.6 + i * 2) * 8 - E.camY * 0.18, w = 70 + i * 14;
      c.fillStyle = '#8a7a6a'; c.beginPath(); c.moveTo(x - w / 2, y); c.quadraticCurveTo(x, y + w * 0.9, x + w / 2, y); c.closePath(); c.fill();
      c.fillStyle = '#7edc8c'; c.beginPath(); c.ellipse(x, y, w / 2, 8, 0, 0, TAU); c.fill();
      c.fillStyle = '#fff4d6'; c.fillRect(x - 6, y - 16, 3, 14); c.fillRect(x + 3, y - 16, 3, 14); c.fillRect(x - 9, y - 19, 18, 3);
    }
  },
  jellyfish(c, E) {
    for (let i = 0; i < 4; i++) {
      const x = px(E, 0.12 + i * 0.02, hash(i + 50) * (E.W + 200), 100) + Math.sin(E.t * 0.7 + i) * 16, y = E.H * (0.2 + hash(i + 60) * 0.45) + Math.sin(E.t * 0.9 + i * 2) * 22 - E.camY * 0.3;
      const pulse = 1 + Math.sin(E.t * 2.4 + i) * 0.12, r = (16 + i * 3) * pulse, col = i % 2 ? '#ff7ab8' : '#9ffff0';
      drawGlow(c, x, y, r * 3, col, 0.35);
      c.fillStyle = rgba(col, 0.75); c.beginPath(); c.ellipse(x, y, r, r * 0.8, 0, Math.PI, TAU); c.quadraticCurveTo(x, y + r * 0.35, x - r, y); c.fill();
      c.strokeStyle = rgba(col, 0.55); c.lineWidth = 1.6; for (let k = -2; k <= 2; k++) { c.beginPath(); c.moveTo(x + k * r * 0.4, y + 2); for (let s = 1; s <= 6; s++) c.lineTo(x + k * r * 0.4 + Math.sin(E.t * 2 + s + k) * 4, y + 2 + s * r * 0.5); c.stroke(); }
    }
  },
  fish_school(c, E) {
    for (let s = 0; s < 2; s++) {
      const bx = loop(s * 13 + 90, 30 + s * 12, E.t, E.W, 120, s ? 1 : -1), by = E.H * (0.25 + s * 0.3) + Math.sin(E.t * 0.5 + s) * 20 - E.camY * 0.3, dir = s ? 1 : -1;
      for (let i = 0; i < 9; i++) {
        const x = bx + (i % 3) * 20 * -dir + Math.sin(E.t * 2 + i) * 4, y = by + Math.floor(i / 3) * 16 + Math.sin(E.t * 3 + i * 1.7) * 3;
        c.save(); c.translate(x, y); c.scale(dir, 1); c.fillStyle = s ? '#ffb347' : '#9ffff0'; c.beginPath(); c.ellipse(0, 0, 7, 3.4, 0, 0, TAU); c.fill(); c.beginPath(); c.moveTo(-6, 0); c.lineTo(-11, -3.5 + Math.sin(E.t * 14 + i) * 1.5); c.lineTo(-11, 3.5); c.fill(); c.restore();
      }
    }
  },
  whale(c, E) {
    const x = loop(120, 9, E.t, E.W, 360, -1), y = E.H * 0.32 + Math.sin(E.t * 0.3) * 14 - E.camY * 0.15;
    c.save(); c.translate(x, y); c.fillStyle = 'rgba(20,70,130,0.55)';
    c.beginPath(); c.moveTo(-130, 0); c.quadraticCurveTo(-60, -50, 40, -22); c.quadraticCurveTo(110, -6, 140, 8 + Math.sin(E.t) * 6); c.lineTo(168, -14 + Math.sin(E.t) * 8); c.lineTo(160, 18); c.lineTo(138, 14); c.quadraticCurveTo(40, 42, -130, 0); c.closePath(); c.fill(); c.restore();
  },
  turtle(c, E) {
    const x = loop(130, 20, E.t, E.W, 100, 1), y = E.H * 0.5 + Math.sin(E.t * 0.8) * 14 - E.camY * 0.3;
    c.save(); c.translate(x, y); c.fillStyle = 'rgba(40,120,80,0.8)'; c.beginPath(); c.ellipse(0, 0, 22, 14, 0, 0, TAU); c.fill(); c.fillStyle = 'rgba(120,200,120,0.9)'; c.beginPath(); c.ellipse(24, -2, 7, 5, 0, 0, TAU); c.fill();
    c.fillStyle = 'rgba(80,170,110,0.9)'; const f = Math.sin(E.t * 3) * 0.5; c.save(); c.rotate(f); c.beginPath(); c.ellipse(4, 14, 11, 4, 0.6, 0, TAU); c.fill(); c.restore(); c.save(); c.rotate(-f); c.beginPath(); c.ellipse(4, -14, 11, 4, -0.6, 0, TAU); c.fill(); c.restore(); c.restore();
  },
  petal_swirl(c, E) {
    for (let i = 0; i < 16; i++) {
      const u = (E.t * 0.07 + i / 16) % 1, x = E.W * 1.05 - u * (E.W * 1.2), y = E.H * 0.35 + Math.sin(u * 9 + i) * 70 + (i % 4) * 22 - E.camY * 0.3;
      c.save(); c.translate(x, y); c.rotate(E.t * 2 + i); c.fillStyle = rgba('#ffc0dc', 0.85); c.beginPath(); c.ellipse(0, 0, 5, 2.8, 0, 0, TAU); c.fill(); c.restore();
    }
  },
  wisps(c, E) {
    for (let i = 0; i < 7; i++) {
      const x = px(E, 0.15, hash(i + 140) * (E.W + 200), 80) + Math.sin(E.t * 0.9 + i * 2) * 26, y = E.H * (0.25 + hash(i + 150) * 0.55) + Math.cos(E.t * 0.7 + i) * 24 - E.camY * 0.35;
      drawGlow(c, x, y, 28, i % 2 ? '#ff4ad0' : '#a070ff', 0.55 + 0.2 * Math.sin(E.t * 3 + i)); drawGlow(c, x, y, 7, '#ffffff', 0.8);
    }
  },
  rune_circle(c, E) {
    const x = E.W * 0.55, y = E.H * 0.3 - E.camY * 0.08, r = 170;
    c.save(); c.translate(x, y); c.globalCompositeOperation = 'lighter'; c.strokeStyle = rgba('#a070ff', 0.5); c.lineWidth = 2;
    c.rotate(E.t * 0.15); c.beginPath(); c.arc(0, 0, r, 0, TAU); c.stroke(); c.beginPath(); c.arc(0, 0, r * 0.82, 0, TAU); c.stroke();
    for (let k = 0; k < 12; k++) { const a = (k / 12) * TAU; c.save(); c.rotate(a); c.translate(r * 0.91, 0); c.strokeRect(-4, -6, 8, 12); c.restore(); }
    c.rotate(-E.t * 0.4); c.strokeStyle = rgba('#ff4ad0', 0.5); c.beginPath(); for (let k = 0; k < 6; k++) { const a = (k / 6) * TAU; k ? c.lineTo(Math.cos(a) * r * 0.7, Math.sin(a) * r * 0.7) : c.moveTo(Math.cos(a) * r * 0.7, Math.sin(a) * r * 0.7); } c.closePath(); c.stroke();
    c.restore();
  },
  lightning(c, E) {
    if (E.reduced) return;
    const per = 7, k = Math.floor(E.t / per), ph = (E.t % per) / per; if (ph > 0.05) return;
    const a = (1 - ph / 0.05) * 0.4; c.fillStyle = `rgba(255,255,255,${a})`; c.fillRect(-100, -200, E.W + 200, E.H + 400);
    c.strokeStyle = `rgba(255,255,255,${a * 2})`; c.lineWidth = 3; c.beginPath(); let x = E.W * (0.2 + hash(k) * 0.6), y = -20; c.moveTo(x, y); for (let i = 0; i < 9; i++) { x += (hash(k * 9 + i) - 0.5) * 60; y += 50; c.lineTo(x, y); } c.stroke();
  },
  angels(c, E) {
    for (let i = 0; i < 2; i++) {
      const x = loop(i + 160, 14, E.t, E.W, 140, i ? 1 : -1), y = E.H * (0.24 + i * 0.12) + Math.sin(E.t * 0.8 + i) * 10 - E.camY * 0.2;
      drawGlow(c, x, y, 40, '#fff2c0', 0.5);
      c.fillStyle = 'rgba(255,255,255,0.9)'; const f = Math.sin(E.t * 2.4 + i) * 0.35;
      for (const s of [-1, 1]) { c.save(); c.translate(x, y); c.scale(s, 1); c.rotate(-0.5 + f); c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(14, -16, 30, -8); c.quadraticCurveTo(18, -2, 26, 6); c.quadraticCurveTo(12, 6, 0, 3); c.fill(); c.restore(); }
      c.fillStyle = '#fff6d8'; c.beginPath(); c.arc(x, y - 8, 4, 0, TAU); c.fill(); c.fillRect(x - 3, y - 4, 6, 12);
    }
  },
  cubes(c, E) {
    for (let i = 0; i < 6; i++) {
      const x = px(E, 0.09 + (i % 3) * 0.03, hash(i + 170) * (E.W + 300), 120) , y = E.H * (0.15 + hash(i + 180) * 0.55) + Math.sin(E.t + i) * 10 - E.camY * 0.25, s = 18 + hash(i + 190) * 22;
      c.save(); c.translate(x, y); c.rotate(E.t * 0.4 + i); c.globalCompositeOperation = 'lighter'; c.strokeStyle = rgba(i % 2 ? '#4ae0ff' : '#ff4ad0', 0.8); c.lineWidth = 1.6;
      c.strokeRect(-s / 2, -s / 2, s, s); c.strokeRect(-s / 2 + s * 0.3, -s / 2 - s * 0.3, s, s);
      c.beginPath(); for (const [a, b] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) { c.moveTo(a * s / 2, b * s / 2); c.lineTo(a * s / 2 + s * 0.3, b * s / 2 - s * 0.3); } c.stroke(); c.restore();
    }
  },
  portals_far(c, E) {
    for (let i = 0; i < 3; i++) {
      const x = px(E, 0.05, i * (E.W * 0.5 + 100) + 80, 160), y = E.H * (0.3 + (i % 2) * 0.12) - E.camY * 0.1, r = 40 + i * 8;
      c.save(); c.translate(x, y); c.globalCompositeOperation = 'lighter';
      for (let k = 0; k < 3; k++) { c.save(); c.rotate(E.t * (k % 2 ? -1 : 1) * 0.8 + k); c.strokeStyle = rgba(k % 2 ? '#ffe27a' : '#4ae0ff', 0.7); c.lineWidth = 2.4 - k * 0.5; c.beginPath(); c.ellipse(0, 0, r * (1 - k * 0.2), r * 0.5, 0, 0, TAU * 0.8); c.stroke(); c.restore(); }
      c.restore(); drawGlow(c, x, y, r * 1.6, '#c9b0ff', 0.25);
    }
  },
  aurora(c, E) {
    const base = E.fixedDark ? 0.55 : 0.18 + E.night * 0.55 + E.dusk * 0.2;
    if (base < 0.05) return;
    c.save(); c.globalCompositeOperation = 'lighter';
    for (let r = 0; r < 3; r++) {
      const col = ['#4affc8', '#7a8aff', '#ff6ad5'][r], y0 = E.H * (0.12 + r * 0.07) - E.camY * 0.08;
      const g = c.createLinearGradient(0, y0 - 60, 0, y0 + 150); g.addColorStop(0, rgba(col, 0)); g.addColorStop(0.4, rgba(col, 0.4 * base)); g.addColorStop(1, rgba(col, 0));
      c.fillStyle = g; c.beginPath(); c.moveTo(-20, y0 + 150);
      for (let x = -20; x <= E.W + 20; x += 20) c.lineTo(x, y0 + Math.sin(x * 0.006 + E.t * 0.5 + r * 2) * 34 + Math.sin(x * 0.017 - E.t * 0.8 + r) * 12);
      c.lineTo(E.W + 20, y0 + 150); c.closePath(); c.fill();
    }
    c.restore();
  },
  waterfall_mist(c, E) {
    const x = px(E, 0.05, 1024 * 0.33, 600) , y = E.H * 0.62 - E.camY * 0.05;
    for (let k = -1; k <= 1; k++) { const xx = x + k * 1024; if (xx < -200 || xx > E.W + 200) continue; drawGlow(c, xx, y, 90 + Math.sin(E.t * 0.8) * 8, '#ffffff', 0.28); }
  },
  lava_eruption(c, E) {
    for (let i = 0; i < 3; i++) {
      const per = 5 + i * 1.7, ph = ((E.t + i * 2.1) % per) / per; if (ph > 0.45) continue;
      const k = ph / 0.45, vx = px(E, 0.05, (i + 0.5) * (1024 / 3) + (i * 7), 700), x0 = vx, y0 = E.H * 0.34 - E.camY * 0.05;
      c.save(); c.globalCompositeOperation = 'lighter';
      for (let n = 0; n < 12; n++) { const a = -Math.PI / 2 + (hash(n + i * 20) - 0.5) * 1.1, sp = 160 + hash(n + 5) * 160, tt = k * 1.6; const x = x0 + Math.cos(a) * sp * tt * 0.5, y = y0 + Math.sin(a) * sp * tt + 260 * tt * tt; drawGlow(c, x, y, 9, '#ff8a2b', 0.9 * (1 - k)); }
      c.restore();
    }
  },
  caustics(c, E) {
    c.save(); c.globalCompositeOperation = 'lighter'; c.lineWidth = 3;
    for (let i = 0; i < 7; i++) { c.strokeStyle = rgba('#bfffff', 0.1 + 0.05 * Math.sin(E.t + i)); c.beginPath(); for (let x = -20; x <= E.W + 20; x += 24) { const y = 30 + i * 46 + Math.sin(x * 0.01 + E.t * 0.9 + i * 1.3) * 18 + Math.sin(x * 0.027 - E.t * 0.6) * 9 - E.camY * 0.1; x < 0 ? c.moveTo(x, y) : c.lineTo(x, y); } c.stroke(); }
    c.restore();
  },
  data_streams(c, E) {
    c.save(); c.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 18; i++) {
      const x = px(E, 0.07, hash(i + 210) * (E.W + 200), 60), len = 60 + hash(i) * 120, sp = 60 + hash(i + 3) * 120;
      let y = (hash(i + 7) * 900 + E.t * sp) % (E.H + len + 100) - len;
      const g = c.createLinearGradient(x, y, x, y + len); g.addColorStop(0, 'rgba(0,229,255,0)'); g.addColorStop(1, 'rgba(0,229,255,0.7)');
      c.fillStyle = g; c.fillRect(x, y, 2, len);
    }
    c.restore();
  },
  airships(c, E) {
    for (let i = 0; i < 2; i++) {
      const x = loop(i + 230, 8 + i * 3, E.t, E.W, 240, i ? 1 : -1), y = E.H * (0.24 + i * 0.14) + Math.sin(E.t * 0.4 + i) * 8 - E.camY * 0.2, s = 0.8 + i * 0.35;
      c.save(); c.translate(x, y); c.scale(s * (i ? -1 : 1), s); c.fillStyle = E.night > 0.5 ? 'rgba(20,20,50,0.85)' : 'rgba(90,60,90,0.8)';
      c.beginPath(); c.ellipse(0, 0, 52, 16, 0, 0, TAU); c.fill(); c.fillRect(-12, 16, 24, 8); c.beginPath(); c.moveTo(-50, 0); c.lineTo(-64, -12); c.lineTo(-60, 10); c.fill();
      c.fillStyle = 'rgba(255,210,120,0.9)'; c.fillRect(-8, 18, 4, 4); c.fillRect(2, 18, 4, 4); c.restore();
    }
  },
};
void clamp; void starPath; void mulberry32;
