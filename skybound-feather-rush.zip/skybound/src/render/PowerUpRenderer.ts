import type { PowerUpType } from '../core/types';
import { POWERUPS } from '../data/powerups';
import { clamp, rgba, shadeHex, TAU } from '../core/util';
import { drawGlow, roundRect, starPath, type Ctx } from './gfx';

/** Flat glyph in a size x size box centered at (x, y). */
export function drawPowerUpGlyph(c: Ctx, type: PowerUpType, x: number, y: number, size: number, color = '#ffffff'): void {
  const s = size / 40;
  c.save(); c.translate(x, y); c.scale(s, s);
  c.fillStyle = color; c.strokeStyle = color; c.lineWidth = 3.2; c.lineCap = 'round'; c.lineJoin = 'round';
  switch (type) {
    case 'shield':
      c.beginPath(); c.moveTo(0, -15); c.quadraticCurveTo(12, -13, 14, -9); c.quadraticCurveTo(14, 8, 0, 16); c.quadraticCurveTo(-14, 8, -14, -9); c.quadraticCurveTo(-12, -13, 0, -15); c.closePath(); c.fill();
      c.globalCompositeOperation = 'destination-out'; c.beginPath(); c.moveTo(0, -9); c.lineTo(0, 9); c.moveTo(-7, -1); c.lineTo(7, -1); c.lineWidth = 3; c.stroke(); c.globalCompositeOperation = 'source-over'; break;
    case 'timewarp':
      c.beginPath(); c.moveTo(-9, -15); c.lineTo(9, -15); c.lineTo(9, -11); c.quadraticCurveTo(9, -2, 0, 0); c.quadraticCurveTo(9, 2, 9, 11); c.lineTo(9, 15); c.lineTo(-9, 15); c.lineTo(-9, 11); c.quadraticCurveTo(-9, 2, 0, 0); c.quadraticCurveTo(-9, -2, -9, -11); c.closePath(); c.stroke();
      c.beginPath(); c.moveTo(-5, 12); c.lineTo(5, 12); c.lineTo(0, 6); c.closePath(); c.fill(); c.beginPath(); c.moveTo(-3, -11); c.lineTo(3, -11); c.lineTo(0, -6); c.closePath(); c.fill(); break;
    case 'phoenix':
      c.beginPath(); c.moveTo(0, 15); c.bezierCurveTo(-13, 6, -13, -8, -3, -16); c.bezierCurveTo(-4, -8, 0, -6, 3, -10); c.bezierCurveTo(5, -4, 14, 0, 12, 7); c.bezierCurveTo(10, 13, 4, 15, 0, 15); c.closePath(); c.fill();
      c.globalCompositeOperation = 'destination-out'; c.beginPath(); c.moveTo(0, 12); c.bezierCurveTo(-5, 8, -3, 2, 0, -2); c.bezierCurveTo(4, 2, 4, 8, 0, 12); c.fill(); c.globalCompositeOperation = 'source-over'; break;
    case 'multiplier':
      c.lineWidth = 4.2; c.beginPath(); c.moveTo(-14, -8); c.lineTo(-5, 1); c.moveTo(-5, -8); c.lineTo(-14, 1); c.stroke();
      c.lineWidth = 3.2; c.beginPath(); c.moveTo(2, -10); c.quadraticCurveTo(14, -10, 11, -3); c.quadraticCurveTo(9, 1, 2, 9); c.lineTo(14, 9); c.stroke(); break;
    case 'magnet':
      c.lineWidth = 7; c.lineCap = 'butt'; c.beginPath(); c.arc(0, 1, 10, Math.PI, 0); c.lineTo(10, 12); c.moveTo(-10, 1); c.lineTo(-10, 12); c.stroke();
      c.fillStyle = '#ffffff'; c.fillRect(-13.5, 8, 7, 6); c.fillRect(6.5, 8, 7, 6); break;
    case 'ghost':
      c.beginPath(); c.moveTo(-12, 14); c.lineTo(-12, -2); c.bezierCurveTo(-12, -18, 12, -18, 12, -2); c.lineTo(12, 14); c.lineTo(7, 10); c.lineTo(2.5, 14); c.lineTo(-2.5, 10); c.lineTo(-7, 14); c.closePath(); c.fill();
      c.globalCompositeOperation = 'destination-out'; c.beginPath(); c.arc(-4.5, -3, 2.6, 0, TAU); c.arc(4.5, -3, 2.6, 0, TAU); c.fill(); c.globalCompositeOperation = 'source-over'; break;
    case 'turbo':
      c.beginPath(); c.moveTo(4, -17); c.lineTo(-9, 2); c.lineTo(-1, 2); c.lineTo(-5, 17); c.lineTo(10, -4); c.lineTo(2, -4); c.closePath(); c.fill(); break;
    case 'featherstorm':
      for (let i = 0; i < 3; i++) { c.save(); c.rotate(i * (TAU / 3) - 0.4); c.beginPath(); c.moveTo(0, 0); c.bezierCurveTo(4, -6, 12, -8, 16, -3); c.bezierCurveTo(10, 3, 4, 3, 0, 0); c.fill(); c.restore(); }
      c.beginPath(); c.arc(0, 0, 2.6, 0, TAU); c.fill(); break;
  }
  c.restore();
}

/** Collectible: glowing bubble with the glyph inside. */
export function drawPowerUpOrb(c: Ctx, type: PowerUpType, x: number, y: number, r: number, t: number): void {
  const def = POWERUPS[type];
  const by = y + Math.sin(t * 3 + x * 0.01) * 4;
  const pulse = 1 + Math.sin(t * 5) * 0.06;
  drawGlow(c, x, by, r * 2.6 * pulse, def.glow, 0.55);
  c.save(); c.translate(x, by);
  const g = c.createRadialGradient(-r * 0.35, -r * 0.4, 1, 0, 0, r);
  g.addColorStop(0, shadeHex(def.color, 0.55)); g.addColorStop(0.6, def.color); g.addColorStop(1, shadeHex(def.color, -0.35));
  c.fillStyle = g; c.beginPath(); c.arc(0, 0, r, 0, TAU); c.fill();
  c.strokeStyle = 'rgba(255,255,255,0.85)'; c.lineWidth = 2.2; c.stroke();
  c.fillStyle = 'rgba(255,255,255,0.5)'; c.beginPath(); c.ellipse(-r * 0.32, -r * 0.45, r * 0.3, r * 0.17, -0.6, 0, TAU); c.fill();
  c.restore();
  drawPowerUpGlyph(c, type, x, by, r * 1.3, '#ffffff');
  // orbiting sparkles
  c.fillStyle = '#ffffff';
  for (let i = 0; i < 3; i++) { const a = t * 2.2 + i * TAU / 3; starPath(c, x + Math.cos(a) * (r + 7), by + Math.sin(a) * (r + 7), 2.6, 1, 4, a); c.fill(); }
}

export function drawCoin(c: Ctx, x: number, y: number, r: number, t: number, collect = 0): void {
  if (collect >= 1) return;
  const k = 1 - collect;
  const yy = y - collect * 40;
  const sx = Math.max(0.12, Math.abs(Math.cos(t * 4 + x * 0.02)));
  c.save(); c.translate(x, yy); c.scale(sx * k, k); c.globalAlpha *= clamp(1 - collect * 0.8, 0, 1);
  const g = c.createLinearGradient(-r, -r, r, r);
  g.addColorStop(0, '#fff3a0'); g.addColorStop(0.5, '#ffc928'); g.addColorStop(1, '#d98a00');
  c.fillStyle = g; c.beginPath(); c.arc(0, 0, r, 0, TAU); c.fill();
  c.strokeStyle = '#a86400'; c.lineWidth = 2; c.stroke();
  c.strokeStyle = 'rgba(255,255,255,0.7)'; c.lineWidth = 1.6; c.beginPath(); c.arc(0, 0, r * 0.66, 0, TAU); c.stroke();
  c.fillStyle = '#b87400'; starPath(c, 0, 0, r * 0.42, r * 0.18, 5); c.fill();
  c.restore();
}
export function drawGem(c: Ctx, x: number, y: number, r: number, t: number): void {
  const by = y + Math.sin(t * 3) * 3;
  drawGlow(c, x, by, r * 3, '#7affea', 0.5);
  c.save(); c.translate(x, by); c.rotate(Math.sin(t * 2) * 0.12);
  const top: [number, number][] = [[-r, -r * 0.2], [-r * 0.55, -r], [r * 0.55, -r], [r, -r * 0.2], [0, r * 1.1]];
  c.fillStyle = '#31e0c4'; c.beginPath(); c.moveTo(top[0][0], top[0][1]); for (const p of top.slice(1)) c.lineTo(p[0], p[1]); c.closePath(); c.fill();
  c.fillStyle = '#9ffff0'; c.beginPath(); c.moveTo(-r * 0.55, -r); c.lineTo(r * 0.55, -r); c.lineTo(0, -r * 0.2); c.closePath(); c.fill();
  c.fillStyle = '#12a894'; c.beginPath(); c.moveTo(r, -r * 0.2); c.lineTo(0, r * 1.1); c.lineTo(0, -r * 0.2); c.closePath(); c.fill();
  c.strokeStyle = 'rgba(255,255,255,0.9)'; c.lineWidth = 1.6; c.beginPath(); for (let i = 0; i < top.length; i++) { const p = top[i]; if (i) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); } c.closePath(); c.stroke();
  c.restore();
  c.fillStyle = '#fff'; const a = t * 3; starPath(c, x + Math.cos(a) * r * 1.3, by - r * 0.8 + Math.sin(a) * 2, 2.6, 0.9, 4, a); c.fill();
}
export function drawSecretPortal(c: Ctx, x: number, y: number, r: number, t: number): void {
  drawGlow(c, x, y, r * 3, '#b070ff', 0.7); drawGlow(c, x, y, r * 1.6, '#ffd36b', 0.4);
  c.save(); c.translate(x, y);
  for (let i = 0; i < 4; i++) {
    c.save(); c.rotate(t * (i % 2 ? -1.6 : 1.2) + i); c.strokeStyle = i % 2 ? rgba('#ffd36b', 0.85) : rgba('#c98aff', 0.9); c.lineWidth = 3.4 - i * 0.5;
    c.beginPath(); c.ellipse(0, 0, r * (1 - i * 0.18), r * (0.45 + i * 0.08), 0, 0, Math.PI * 1.5); c.stroke(); c.restore();
  }
  const g = c.createRadialGradient(0, 0, 0, 0, 0, r * 0.7); g.addColorStop(0, 'rgba(10,0,30,0.95)'); g.addColorStop(1, 'rgba(60,10,120,0)');
  c.fillStyle = g; c.beginPath(); c.arc(0, 0, r * 0.7, 0, TAU); c.fill(); c.restore();
}
export function drawShieldBubble(c: Ctx, x: number, y: number, r: number, t: number, strength = 1): void {
  c.save(); c.translate(x, y); c.globalAlpha *= clamp(strength, 0, 1);
  const g = c.createRadialGradient(0, 0, r * 0.5, 0, 0, r); g.addColorStop(0, 'rgba(120,220,255,0)'); g.addColorStop(1, 'rgba(180,240,255,0.7)');
  c.fillStyle = g; c.beginPath(); c.arc(0, 0, r + Math.sin(t * 5), 0, TAU); c.fill(); c.restore();
}
export function drawHeart(c: Ctx, x: number, y: number, r: number, filled: boolean): void {
  c.save(); c.translate(x, y); c.scale(r / 10, r / 10);
  c.beginPath(); c.moveTo(0, 9); c.bezierCurveTo(-14, -1, -9, -12, 0, -5); c.bezierCurveTo(9, -12, 14, -1, 0, 9); c.closePath();
  if (filled) { const g = c.createLinearGradient(0, -10, 0, 10); g.addColorStop(0, '#ff7a9a'); g.addColorStop(1, '#e01f55'); c.fillStyle = g; c.fill(); c.strokeStyle = '#fff'; c.lineWidth = 1.4; c.stroke(); }
  else { c.fillStyle = 'rgba(255,255,255,0.12)'; c.fill(); c.strokeStyle = 'rgba(255,255,255,0.5)'; c.lineWidth = 1.4; c.stroke(); }
  c.restore();
}
export function drawStarRating(c: Ctx, x: number, y: number, size: number, filled: boolean): void {
  c.save();
  if (filled) { drawGlow(c, x, y, size * 1.3, '#ffd23f', 0.4); const g = c.createLinearGradient(x, y - size, x, y + size); g.addColorStop(0, '#fff3a0'); g.addColorStop(1, '#ffb000'); c.fillStyle = g; }
  else c.fillStyle = 'rgba(255,255,255,0.16)';
  starPath(c, x, y, size, size * 0.46, 5); c.fill(); c.strokeStyle = filled ? '#b86e00' : 'rgba(255,255,255,0.3)'; c.lineWidth = 1.5; c.stroke(); c.restore();
}

/** Treasure chest: openT 0 closed (idle wiggle) → 1 open with light burst. */
export function drawRewardBox(c: Ctx, x: number, y: number, size: number, openT: number, t: number, color = '#ffb347'): void {
  const s = size / 100;
  c.save(); c.translate(x, y); c.scale(s, s);
  if (openT > 0.02) {
    c.save(); c.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 14; i++) {
      c.save(); c.rotate(i * TAU / 14 + t * 0.3); const g = c.createLinearGradient(0, 0, 0, -210 * openT);
      g.addColorStop(0, 'rgba(255,240,170,0.55)'); g.addColorStop(1, 'rgba(255,240,170,0)'); c.fillStyle = g;
      c.beginPath(); c.moveTo(-6, -20); c.lineTo(6, -20); c.lineTo(22, -210 * openT); c.lineTo(-22, -210 * openT); c.closePath(); c.fill(); c.restore();
    }
    c.restore();
    drawGlow(c, 0, -30, 150 * openT, '#fff2a0', 0.8 * openT);
  }
  const wig = openT < 0.02 ? Math.sin(t * 9) * 0.04 : 0;
  c.rotate(wig);
  // base
  c.fillStyle = shadeHex(color, -0.3); roundRect(c, -48, -22, 96, 56, 8); c.fill(); c.strokeStyle = '#5a3200'; c.lineWidth = 3; c.stroke();
  c.fillStyle = color; roundRect(c, -44, -18, 88, 22, 5); c.fill();
  c.fillStyle = '#ffe9a0'; c.fillRect(-44, 4, 88, 5);
  // lid (rotates open around the back hinge)
  c.save(); c.translate(0, -22); c.rotate(-openT * 1.35);
  c.fillStyle = color; c.beginPath(); c.moveTo(-48, 0); c.lineTo(-48, -14); c.quadraticCurveTo(0, -46, 48, -14); c.lineTo(48, 0); c.closePath(); c.fill(); c.strokeStyle = '#5a3200'; c.lineWidth = 3; c.stroke();
  c.fillStyle = '#ffe9a0'; c.fillRect(-6, -30, 12, 28); c.restore();
  // lock
  c.fillStyle = '#ffd23f'; roundRect(c, -9, -8, 18, 20, 4); c.fill(); c.strokeStyle = '#5a3200'; c.lineWidth = 2; c.stroke();
  c.fillStyle = '#5a3200'; c.beginPath(); c.arc(0, 0, 2.5, 0, TAU); c.fill();
  c.restore();
}
