import type { QualityName, QualityProfile } from '../core/types';

/** Logical world height. Width varies with the screen aspect ratio. */
export const LOGICAL_H = 800;
export const MIN_LOGICAL_W = 450;
export const MAX_LOGICAL_W = 1500;
/** Fixed simulation step (120 Hz). Rendering interpolates, so 60 / 120 / 144 Hz displays all stay smooth. */
export const FIXED_DT = 1 / 120;
export const MAX_FRAME_DT = 0.1;

/** Every gameplay knob lives here and can be tuned at runtime (Settings → Advanced tuning). */
export interface Tuning {
  gravity: number;        // units/s²
  jump: number;           // jump impulse (negative = up) units/s
  terminal: number;       // max fall speed units/s
  birdXFrac: number;      // horizontal bird position as a fraction of the logical width
  birdRadius: number;     // physics hitbox radius
  hitboxScale: number;    // multiplier on bird radius (<1 = more forgiving)
  floorY: number;         // lethal floor line
  speedBase: number;      // obstacle speed at score 0 (units/s)
  speedMax: number;
  speedPerPoint: number;
  spacingTime: number;    // seconds between gates at score 0
  spacingMin: number;     // seconds between gates at max difficulty
  gapBase: number;        // gap height at score 0
  gapMin: number;
  gapPerPoint: number;    // gap shrink per point
  difficultyRamp: number; // score at which difficulty reaches 1
  maxClimbRate: number;   // generator assumption: comfortable climb rate (units/s)
}

export const DEFAULT_TUNING: Tuning = {
  gravity: 1900,
  jump: -610,
  terminal: 980,
  birdXFrac: 0.27,
  birdRadius: 17,
  hitboxScale: 1,
  floorY: 730,
  speedBase: 235,
  speedMax: 400,
  speedPerPoint: 2.6,
  spacingTime: 1.55,
  spacingMin: 1.22,
  gapBase: 276,
  gapMin: 214,
  gapPerPoint: 1.0,
  difficultyRamp: 70,
  maxClimbRate: 270,
};

export const QUALITY: Record<QualityName, QualityProfile> = {
  low:    { name: 'low',    dprCap: 1,   maxParticles: 160, particleScale: 0.4, fog: false, shafts: false, bloom: false, decor: false, shadows: false, weather: 0.35, layerScale: 0.5,  trailPoints: 14 },
  medium: { name: 'medium', dprCap: 1.5, maxParticles: 360, particleScale: 0.7, fog: true,  shafts: false, bloom: true,  decor: true,  shadows: false, weather: 0.65, layerScale: 0.7,  trailPoints: 22 },
  high:   { name: 'high',   dprCap: 2,   maxParticles: 700, particleScale: 1,   fog: true,  shafts: true,  bloom: true,  decor: true,  shadows: true,  weather: 1,    layerScale: 0.85, trailPoints: 30 },
  ultra:  { name: 'ultra',  dprCap: 3,   maxParticles: 1200, particleScale: 1.4, fog: true,  shafts: true,  bloom: true,  decor: true,  shadows: true,  weather: 1.4,  layerScale: 1,    trailPoints: 42 },
};

export const GAME_TITLE = 'SKYBOUND: FEATHER RUSH ∞';
export const SLOGAN = 'ONE TAP. INFINITE SKY. LEGENDARY FLIGHT.';
export const SAVE_KEY = 'skybound.save.v1';
export const BACKUP_KEY = 'skybound.save.backup';
export const SAVE_VERSION = 3;
export const MILESTONES = [10, 25, 50, 100, 200];

declare const __SUPABASE_URL__: string;
declare const __SUPABASE_ANON_KEY__: string;
declare const __DEV__: boolean;
export const BUILD = {
  supabaseUrl: typeof __SUPABASE_URL__ !== 'undefined' ? __SUPABASE_URL__ : '',
  supabaseKey: typeof __SUPABASE_ANON_KEY__ !== 'undefined' ? __SUPABASE_ANON_KEY__ : '',
  dev: typeof __DEV__ !== 'undefined' ? __DEV__ : false,
};
