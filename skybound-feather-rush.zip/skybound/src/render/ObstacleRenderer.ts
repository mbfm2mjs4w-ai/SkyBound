import type { GateView, QualityProfile, ObstacleKind } from '../core/types';
import { OBSTACLES } from '../data/obstacles';
import { WORLD_BY_ID, type WorldDef } from '../data/worlds';
import { clamp, hslToHex, mixHex, rgba, shadeHex, TAU } from '../core/util';
import { drawGlow, roundRect, starPath, type Ctx } from './gfx';

type Pal = WorldDef['obstaclePalette'];
const FAR = 1250;    // how far a column extends away from the gap edge (covers any screen)
const rnd = (seed: number, i: number): number => { const s = Math.sin(seed * 12.9898 + i * 78.233) * 43758.5453; return s - Math.floor(s); };

export class ObstacleRenderer {
  private q: QualityProfile | null = null;
  setQuality(q: QualityProfile): void { this.q = q; }
  prewarm(_worldId: string): void { /* all art is vector-drawn; nothing to bake */ }
  release(_worldId: string): void { /* no cached state */ }

  /** Solid body of one gate in world coordinates. */
  drawGate(c: Ctx, g: GateView): void {
    const w = WORLD_BY_ID[g.worldId];
    if (!w) return;
    const pal = w.obstaclePalette;
    const spec = OBSTACLES[g.kind];
    const edgeT = g.centerY - g.gapHalf, edgeB = g.centerY + g.gapHalf;
    c.save();
    c.globalAlpha *= clamp(g.appear, 0, 1);
    if (g.appear < 1) c.translate(0, (1 - g.appear) * 30);
    for (let side = 0; side < 2; side++) {
      c.save();
      c.translate(g.x, side === 0 ? edgeT : edgeB);
      if (side === 1) c.scale(1, -1);       // local frame: column grows toward -y, the gap is at +y
      this.column(c, g, w, pal, spec.halfW, side);
      c.restore();
    }
    // the world-change gate gets a big glowing frame
    c.restore();
  }

  private column(c: Ctx, g: GateView, w: WorldDef, pal: Pal, hw: number, side: number): void {
    const kind: ObstacleKind = g.kind;
    const spec = OBSTACLES[kind];
    const t = g.phase;
    const seed = g.seed + side * 17;
    const night = g.night;
    const base = (x0: number, x1: number, top: number, bottom: number, lighten = 0): void => {
      const gr = c.createLinearGradient(x0, 0, x1, 0);
      gr.addColorStop(0, shadeHex(pal.main, 0.22 + lighten)); gr.addColorStop(0.5, pal.main); gr.addColorStop(1, pal.dark);
      c.fillStyle = gr; c.fillRect(x0, top, x1 - x0, bottom - top);
    };
    const rim = (y: number, x0: number, x1: number): void => {
      c.fillStyle = rgba(pal.light, 0.9); c.fillRect(x0, y - 2, x1 - x0, 3);
      c.fillStyle = rgba(pal.glow, 0.55 + night * 0.3); c.fillRect(x0, y - 5, x1 - x0, 3);
    };
    const outline = (): void => { c.strokeStyle = 'rgba(10,8,30,0.4)'; c.lineWidth = 2; };
    switch (kind) {
      case 'crystal': {
        const tip = spec.tip;
        // faceted body
        const g1 = c.createLinearGradient(-hw, 0, hw, 0);
        g1.addColorStop(0, shadeHex(pal.main, 0.3)); g1.addColorStop(0.45, pal.main); g1.addColorStop(1, pal.dark);
        c.fillStyle = g1; c.beginPath(); c.moveTo(-hw, -tip); c.lineTo(-hw + 6, -FAR); c.lineTo(hw - 6, -FAR); c.lineTo(hw, -tip); c.lineTo(0, 0); c.closePath(); c.fill();
        outline(); c.stroke();
        c.fillStyle = rgba(pal.light, 0.5); c.beginPath(); c.moveTo(-hw, -tip); c.lineTo(0, 0); c.lineTo(-hw * 0.2, -tip - 6); c.closePath(); c.fill();
        c.fillStyle = rgba(pal.dark, 0.5); c.beginPath(); c.moveTo(hw, -tip); c.lineTo(0, 0); c.lineTo(hw * 0.25, -tip - 6); c.closePath(); c.fill();
        c.strokeStyle = rgba(pal.light, 0.35); c.lineWidth = 1.5;
        for (let i = 0; i < 6; i++) { const y = -tip - 20 - i * 70 - rnd(seed, i) * 30; c.beginPath(); c.moveTo(-hw + 4, y); c.lineTo(hw - 4, y - 18); c.stroke(); }
        // side shards
        for (let i = 0; i < 3; i++) { const s = i % 2 ? 1 : -1, y = -tip - 40 - i * 90; c.fillStyle = shadeHex(pal.main, 0.1 + i * 0.05); c.beginPath(); c.moveTo(s * hw, y); c.lineTo(s * (hw + 14), y - 36 - rnd(seed, i + 9) * 20); c.lineTo(s * hw, y - 30); c.closePath(); c.fill(); }
        // inner glow
        const ig = c.createLinearGradient(0, -tip - 200, 0, 0); ig.addColorStop(0, rgba(pal.glow, 0)); ig.addColorStop(1, rgba(pal.glow, 0.55 + night * 0.3 + g.pulse * 0.15));
        c.fillStyle = ig; c.beginPath(); c.moveTo(-hw * 0.5, -tip - 200); c.lineTo(hw * 0.5, -tip - 200); c.lineTo(hw * 0.5, -tip); c.lineTo(0, -4); c.lineTo(-hw * 0.5, -tip); c.closePath(); c.fill();
        break;
      }
      case 'ice': {
        const tip = spec.tip;
        const g1 = c.createLinearGradient(-hw, 0, hw, 0);
        g1.addColorStop(0, '#f2fbff'); g1.addColorStop(0.5, pal.main); g1.addColorStop(1, pal.dark);
        c.fillStyle = g1; c.beginPath(); c.moveTo(-hw, -tip); c.lineTo(-hw - 3, -FAR); c.lineTo(hw + 3, -FAR); c.lineTo(hw, -tip); c.lineTo(0, 0); c.closePath(); c.fill(); outline(); c.stroke();
        c.fillStyle = 'rgba(255,255,255,0.55)'; c.beginPath(); c.moveTo(-hw, -tip); c.lineTo(0, 0); c.lineTo(-4, -tip - 30); c.lineTo(-hw, -tip - 40); c.closePath(); c.fill();
        for (let i = 0; i < 4; i++) { const s = i % 2 ? 1 : -1, y = -tip - 30 - i * 70; c.fillStyle = rgba(pal.light, 0.9); c.beginPath(); c.moveTo(s * hw, y); c.lineTo(s * (hw + 12), y + 26 + rnd(seed, i) * 22); c.lineTo(s * (hw - 8), y + 10); c.closePath(); c.fill(); }
        c.strokeStyle = 'rgba(255,255,255,0.7)'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(-6, -tip - 10); c.lineTo(-2, -tip - 120); c.stroke();
        break;
      }
      case 'pillar': case 'ruins': {
        const capH = 18;
        base(-hw, hw, -FAR, -capH);
        outline(); c.strokeRect(-hw, -FAR, hw * 2, FAR - capH);
        // carved bands + runes
        for (let i = 0; i < 9; i++) {
          const y = -capH - 40 - i * 92 - rnd(seed, i) * 10;
          c.fillStyle = rgba(pal.dark, 0.55); c.fillRect(-hw, y, hw * 2, 7);
          c.fillStyle = rgba(pal.light, 0.25); c.fillRect(-hw, y + 7, hw * 2, 2);
          const gl = 0.35 + night * 0.5 + 0.15 * Math.sin(t * 2 + i);
          c.fillStyle = rgba(pal.glow, clamp(gl, 0, 1)); c.fillRect(-4, y - 34, 8, 14); c.fillRect(-10, y - 28, 20, 3);
        }
        // capital slab (extends sideways, never into the gap)
        c.fillStyle = shadeHex(pal.main, 0.18); roundRect(c, -hw - 7, -capH - 2, hw * 2 + 14, capH + 2, 4); c.fill(); c.stroke();
        rim(0, -hw - 7, hw + 7);
        if (kind === 'ruins') { // broken top piece & vines hanging
          c.fillStyle = pal.dark; c.beginPath(); c.moveTo(-hw, -FAR + 600); c.lineTo(-hw * 0.4, -FAR + 590); c.lineTo(0, -FAR + 612); c.lineTo(hw * 0.5, -FAR + 586); c.lineTo(hw, -FAR + 600); c.lineTo(hw, -FAR + 640); c.lineTo(-hw, -FAR + 640); c.closePath();
          c.strokeStyle = rgba(pal.accent, 0.9); c.lineWidth = 3; c.lineCap = 'round';
          for (let i = 0; i < 3; i++) { const x = -hw + 8 + i * (hw * 0.8); c.beginPath(); c.moveTo(x, -capH - 3); c.quadraticCurveTo(x + 6 * Math.sin(t + i), -capH - 40, x - 3, -capH - 76 - rnd(seed, i) * 40); c.stroke(); }
        } else { // floating debris
          c.fillStyle = shadeHex(pal.main, 0.1);
          for (let i = 0; i < 3; i++) { const a = t * (0.9 + i * 0.3) + i * 2, r = hw + 14 + i * 6; c.save(); c.translate(Math.cos(a) * r, -capH - 60 - i * 70 + Math.sin(a) * 6); c.rotate(a); c.fillRect(-3.5, -3.5, 7, 7); c.restore(); }
        }
        break;
      }
      case 'energy': {
        const pw = 7 + g.pulse * 3;
        // plasma beam
        const bg = c.createLinearGradient(-pw * 2.5, 0, pw * 2.5, 0); bg.addColorStop(0, rgba(pal.glow, 0)); bg.addColorStop(0.5, rgba(pal.glow, 0.55 + g.pulse * 0.25)); bg.addColorStop(1, rgba(pal.glow, 0));
        c.fillStyle = bg; c.fillRect(-pw * 2.5, -FAR, pw * 5, FAR);
        c.fillStyle = rgba('#ffffff', 0.85); c.fillRect(-pw * 0.45, -FAR, pw * 0.9, FAR);
        c.strokeStyle = rgba(pal.accent, 0.8); c.lineWidth = 2;
        c.beginPath(); for (let y = 0; y > -460; y -= 8) { const x = Math.sin(y * 0.09 + t * 11) * pw * 0.8; if (y === 0) c.moveTo(x, y); else c.lineTo(x, y); } c.stroke();
        // emitter node
        c.fillStyle = pal.dark; roundRect(c, -hw - 4, -44, hw * 2 + 8, 44, 8); c.fill(); outline(); c.stroke();
        c.fillStyle = pal.main; roundRect(c, -hw, -40, hw * 2, 14, 5); c.fill();
        c.fillStyle = rgba(pal.glow, 0.9); c.beginPath(); c.arc(0, -16, 7 + g.pulse * 2, 0, TAU); c.fill();
        c.fillStyle = '#fff'; c.beginPath(); c.arc(0, -16, 3, 0, TAU); c.fill();
        break;
      }
      case 'laser': {
        const fl = 0.7 + 0.3 * Math.sin(t * 40) * Math.sin(t * 13);
        c.fillStyle = rgba(pal.glow, 0.28 * fl); c.fillRect(-hw * 0.9, -FAR, hw * 1.8, FAR);
        c.fillStyle = rgba(pal.accent, 0.95 * fl); c.fillRect(-2.4, -FAR, 4.8, FAR); c.fillStyle = '#fff'; c.fillRect(-1, -FAR, 2, FAR);
        c.fillStyle = pal.dark; roundRect(c, -hw - 3, -30, hw * 2 + 6, 30, 5); c.fill(); outline(); c.stroke();
        c.fillStyle = pal.light; c.fillRect(-hw, -26, hw * 2, 4);
        c.fillStyle = rgba(pal.accent, 1); c.fillRect(-5, -14, 10, 8);
        for (let i = 0; i < 8; i++) { const y = -90 - i * 110; c.fillStyle = pal.dark; c.fillRect(-hw * 0.55, y, hw * 1.1, 10); c.fillStyle = rgba(pal.glow, 0.8); c.fillRect(-2, y + 3, 4, 4); }
        break;
      }
      case 'fire': {
        base(-hw, hw, -FAR, 0); c.fillStyle = rgba('#120808', 0.6); c.fillRect(-hw, -FAR, hw * 2, FAR - 120);
        // lava cracks
        c.strokeStyle = rgba(pal.glow, 0.7 + 0.3 * Math.sin(t * 4)); c.lineWidth = 2.2;
        for (let i = 0; i < 8; i++) { const y = -140 - i * 120; c.beginPath(); c.moveTo(-hw + rnd(seed, i) * hw * 1.6, y); c.lineTo(-hw + rnd(seed, i + 3) * hw * 1.6, y - 40); c.lineTo(-hw + rnd(seed, i + 6) * hw * 1.6, y - 70); c.stroke(); }
        // flames licking the gap-facing end (vector flames pointing back along the column)
        for (let i = 0; i < 5; i++) {
          const x = -hw + 6 + i * ((hw * 2 - 12) / 4), h = 70 + 38 * Math.sin(t * 7 + i * 1.9) + (i % 2) * 22;
          const fg = c.createLinearGradient(0, 0, 0, -h); fg.addColorStop(0, '#fff6a8'); fg.addColorStop(0.35, '#ffb23a'); fg.addColorStop(1, rgba(pal.glow, 0));
          c.fillStyle = fg; c.beginPath(); c.moveTo(x - 11, 0); c.quadraticCurveTo(x - 7, -h * 0.5, x + Math.sin(t * 9 + i) * 5, -h); c.quadraticCurveTo(x + 7, -h * 0.5, x + 11, 0); c.closePath(); c.fill();
        }
        c.fillStyle = '#ffdb6a'; c.fillRect(-hw, -3, hw * 2, 3);
        break;
      }
      case 'platform': {
        // chains / support going away from the gap + a thick hovering slab at the gap end
        c.strokeStyle = rgba(pal.dark, 0.9); c.lineWidth = 4;
        for (const x of [-hw * 0.55, hw * 0.55]) { c.setLineDash([9, 6]); c.beginPath(); c.moveTo(x, -34); c.lineTo(x, -FAR); c.stroke(); }
        c.setLineDash([]);
        const slabH = 36;
        const sg = c.createLinearGradient(0, -slabH, 0, 0); sg.addColorStop(0, shadeHex(pal.main, 0.25)); sg.addColorStop(1, pal.dark);
        c.fillStyle = sg; roundRect(c, -hw, -slabH, hw * 2, slabH, 9); c.fill(); outline(); c.stroke();
        c.fillStyle = rgba(pal.light, 0.5); c.fillRect(-hw + 8, -slabH + 4, hw * 2 - 16, 4);
        for (let i = 0; i < 5; i++) { c.fillStyle = rgba(pal.glow, 0.45 + 0.55 * Math.max(0, Math.sin(t * 6 - i))); c.beginPath(); c.arc(-hw + 14 + i * ((hw * 2 - 28) / 4), -slabH * 0.55, 3.2, 0, TAU); c.fill(); }
        // body mass behind
        base(-hw * 0.8, hw * 0.8, -FAR, -slabH + 4);
        c.fillStyle = rgba(pal.accent, 0.8); c.fillRect(-hw * 0.8, -slabH - 6, hw * 1.6, 5);
        break;
      }
      case 'ring': {
        // rotating gear-circles stacked away from the gap edge (matches the hit circles exactly)
        const r = hw, step = r * 1.4;
        for (let i = 0; i < 12; i++) {
          const cy = -r - i * step; if (cy < -FAR + 100) break;
          c.save(); c.translate(0, cy); c.rotate(g.rot * (i % 2 ? -1 : 1) + i);
          const rg = c.createRadialGradient(-r * 0.3, -r * 0.3, 2, 0, 0, r); rg.addColorStop(0, shadeHex(pal.main, 0.3)); rg.addColorStop(1, pal.dark);
          c.fillStyle = rg; c.beginPath();
          for (let k = 0; k < 12; k++) { const a0 = k * TAU / 12; const rr = k % 2 ? r : r * 0.88; c.lineTo(Math.cos(a0) * rr, Math.sin(a0) * rr); c.lineTo(Math.cos(a0 + TAU / 24) * rr, Math.sin(a0 + TAU / 24) * rr); }
          c.closePath(); c.fill(); outline(); c.stroke();
          c.fillStyle = rgba(pal.glow, 0.5 + 0.3 * Math.sin(t * 3 + i)); c.beginPath(); c.arc(0, 0, r * 0.28, 0, TAU); c.fill();
          c.strokeStyle = rgba(pal.light, 0.6); c.lineWidth = 2; c.beginPath(); c.arc(0, 0, r * 0.62, 0.2, 2.4); c.stroke();
          c.restore();
        }
        break;
      }
      case 'portal': {
        base(-hw * 0.7, hw * 0.7, -FAR, -10, 0.1);
        outline(); c.strokeRect(-hw * 0.7, -FAR, hw * 1.4, FAR - 10);
        // swirling arcane ring at the gap end
        c.save(); c.translate(0, -hw * 0.9);
        for (let i = 0; i < 3; i++) { c.save(); c.rotate(t * (i % 2 ? -2 : 1.6) + i * 2); c.strokeStyle = rgba(i % 2 ? pal.accent : pal.glow, 0.9 - i * 0.15); c.lineWidth = 3.4 - i; c.beginPath(); c.ellipse(0, 0, hw * (1.05 - i * 0.16), hw * 0.55, 0, 0, Math.PI * 1.55); c.stroke(); c.restore(); }
        c.fillStyle = rgba(pal.glow, 0.7); c.beginPath(); c.arc(0, 0, 6 + g.pulse * 2, 0, TAU); c.fill(); c.restore();
        for (let i = 0; i < 6; i++) { const y = -90 - i * 150; c.save(); c.translate(0, y); c.rotate(t + i); c.strokeStyle = rgba(pal.glow, 0.7); c.lineWidth = 2; c.strokeRect(-9, -9, 18, 18); c.restore(); }
        break;
      }
    }
    // world motif overlay (cosmetic only, clipped to the column body)
    if (kind !== 'energy' && kind !== 'laser' && kind !== 'ring' && kind !== 'platform') this.motif(c, w.motif, pal, hw, seed, t, night, kind);
    if (g.nextWorld) {
      c.save(); drawGlow(c, 0, 20, 110, pal.glow, 0.6 + g.pulse * 0.2); c.restore();
    }
  }

  private motif(c: Ctx, m: WorldDef['motif'], pal: Pal, hw: number, seed: number, t: number, night: number, kind: ObstacleKind): void {
    const bodyHW = kind === 'portal' ? hw * 0.7 : hw;
    const tip = kind === 'crystal' || kind === 'ice' ? OBSTACLES[kind].tip + 6 : 6;
    c.save();
    switch (m) {
      case 'moss': c.fillStyle = rgba(pal.accent, 0.85); for (let i = 0; i < 6; i++) { const y = -tip - 10 - i * 110 - rnd(seed, i) * 30; c.beginPath(); c.ellipse((rnd(seed, i + 2) - 0.5) * bodyHW, y, 8 + rnd(seed, i) * 9, 5, 0, 0, TAU); c.fill(); } break;
      case 'gold': c.fillStyle = rgba('#ffd36b', 0.9); for (let i = 0; i < 5; i++) { const y = -tip - 24 - i * 130; c.fillRect(-bodyHW, y, bodyHW * 2, 4); c.fillRect(-bodyHW, y + 8, bodyHW * 2, 1.6); } break;
      case 'frost': c.fillStyle = 'rgba(255,255,255,0.85)'; for (let i = 0; i < 5; i++) { const y = -tip - 6 - i * 120; c.beginPath(); c.moveTo(-bodyHW, y); c.quadraticCurveTo(0, y - 16 - rnd(seed, i) * 8, bodyHW, y); c.lineTo(bodyHW, y + 4); c.lineTo(-bodyHW, y + 4); c.fill(); } break;
      case 'lava': c.strokeStyle = rgba('#ff7a2b', 0.75 + 0.25 * Math.sin(t * 3)); c.lineWidth = 2; for (let i = 0; i < 5; i++) { const y = -tip - 30 - i * 100; c.beginPath(); c.moveTo(-bodyHW * 0.6, y); c.lineTo(bodyHW * 0.2, y - 18); c.lineTo(-bodyHW * 0.1, y - 40); c.stroke(); } break;
      case 'neon': c.shadowBlur = 0; c.strokeStyle = rgba(pal.accent, 0.9); c.lineWidth = 2; for (let i = 0; i < 6; i++) { const y = -tip - 20 - i * 100; c.beginPath(); c.moveTo(-bodyHW + 4, y); c.lineTo(bodyHW - 4, y); c.stroke(); } c.strokeStyle = rgba(pal.glow, 0.9); c.beginPath(); c.moveTo(bodyHW - 6, -tip); c.lineTo(bodyHW - 6, -tip - 400); c.stroke(); break;
      case 'asteroid': c.fillStyle = rgba(pal.dark, 0.6); for (let i = 0; i < 7; i++) { c.beginPath(); c.ellipse((rnd(seed, i) - 0.5) * bodyHW * 1.4, -tip - 20 - i * 70, 5 + rnd(seed, i + 1) * 7, 3.5, 0, 0, TAU); c.fill(); } break;
      case 'cloud': c.fillStyle = 'rgba(255,255,255,0.8)'; for (let i = 0; i < 5; i++) { const y = -tip - 10 - i * 120; for (let k = -1; k <= 1; k++) { c.beginPath(); c.arc(k * 11 + Math.sin(t + i + k) * 2, y, 9 + (k === 0 ? 3 : 0), 0, TAU); c.fill(); } } break;
      case 'coral': c.fillStyle = rgba(pal.accent, 0.9); for (let i = 0; i < 6; i++) { const s = i % 2 ? 1 : -1, y = -tip - 16 - i * 90; c.beginPath(); c.arc(s * bodyHW, y, 5 + rnd(seed, i) * 3, 0, TAU); c.arc(s * (bodyHW + 4), y - 7, 3.5, 0, TAU); c.fill(); } break;
      case 'petal': c.fillStyle = rgba('#ffc0dc', 0.9); for (let i = 0; i < 7; i++) { c.save(); c.translate((rnd(seed, i) - 0.5) * bodyHW * 1.6, -tip - 14 - i * 70); c.rotate(rnd(seed, i + 4) * 3); c.beginPath(); c.ellipse(0, 0, 4.5, 2.6, 0, 0, TAU); c.fill(); c.restore(); } break;
      case 'void': c.strokeStyle = rgba(pal.accent, 0.8); c.lineWidth = 2; for (let i = 0; i < 4; i++) { const x = (i % 2 ? 1 : -1) * bodyHW; c.beginPath(); c.moveTo(x, -tip - 20 - i * 110); c.bezierCurveTo(x + 18 * Math.sin(t + i), -tip - 50 - i * 110, x - 12, -tip - 80 - i * 110, x + 6 * Math.cos(t), -tip - 120 - i * 110); c.stroke(); } break;
      case 'halo': c.strokeStyle = rgba('#ffe9a0', 0.9); c.lineWidth = 2.4; for (let i = 0; i < 4; i++) { c.beginPath(); c.ellipse(0, -tip - 40 - i * 140, bodyHW + 5, 6, 0, 0, TAU); c.stroke(); } break;
      case 'prism': for (let i = 0; i < 6; i++) { c.fillStyle = hslToHex((t * 40 + i * 60) % 360, 90, 65); c.globalAlpha = 0.5; c.fillRect(-bodyHW, -tip - 20 - i * 90, bodyHW * 2, 6); } c.globalAlpha = 1; break;
    }
    void night; void mixHex; void starPath;
    c.restore();
  }

  /** Additive glow pass — call once after all solid gates (skip when quality.bloom is false). */
  drawGateLight(c: Ctx, g: GateView): void {
    const w = WORLD_BY_ID[g.worldId];
    if (!w) return;
    const pal = w.obstaclePalette;
    const a = clamp(g.appear, 0, 1) * (0.28 + g.night * 0.45 + g.pulse * 0.12);
    const hw = OBSTACLES[g.kind].halfW;
    drawGlow(c, g.x, g.centerY - g.gapHalf, hw * 2.4, pal.glow, a);
    drawGlow(c, g.x, g.centerY + g.gapHalf, hw * 2.4, pal.glow, a);
    if (g.kind === 'energy' || g.kind === 'laser' || g.kind === 'fire' || g.kind === 'portal') {
      for (let k = 1; k <= 2; k++) {
        drawGlow(c, g.x, g.centerY - g.gapHalf - k * 130, hw * 2.2, pal.glow, a * 0.7);
        drawGlow(c, g.x, g.centerY + g.gapHalf + k * 130, hw * 2.2, pal.glow, a * 0.7);
      }
    }
    if (g.nextWorld) { drawGlow(c, g.x, g.centerY, g.gapHalf * 1.4, '#ffffff', 0.15 + g.pulse * 0.1); }
  }
}
