import type { BirdPose, BirdState } from '../core/types';
import { clamp, damp, lerp } from '../core/util';
import type { BirdBody } from '../systems/PhysicsSystem';

/** Animation state of the hero. The simulation owns `body`; this class turns it into a BirdPose. */
export class Bird {
  body: BirdBody = { y: 400, prevY: 400, vy: 0, rot: 0 };
  x = 0;
  state: BirdState = 'idle';
  t = 0;
  flapPhase = 0.5;
  private flapActive = 0;      // seconds left in the current beat
  wingPower = 0;
  blink = 0;
  private blinkTimer = 2;
  private blinkHold = 0;
  squash = 0;
  glow = 0;
  hurt = 0;
  alpha = 1;
  scale = 1;
  lookX = 0.4;
  lookY = 0;
  shield = false;
  ghost = false;
  deathT = 0;
  victoryT = 0;
  mood = 0.3;
  boost = false;
  private sinceFlap = 99;
  private tilt = 0;
  private idleSeed = Math.random() * 100;

  reset(y: number, x: number): void {
    this.body.y = this.body.prevY = y; this.body.vy = 0; this.body.rot = 0;
    this.x = x; this.state = 'idle'; this.alpha = 1; this.deathT = 0; this.victoryT = 0; this.hurt = 0; this.glow = 0;
    this.squash = 0; this.wingPower = 0; this.flapActive = 0; this.sinceFlap = 99; this.boost = false; this.shield = false; this.ghost = false;
    this.scale = 1; this.mood = 0.3;
  }
  onFlap(power = 1): void {
    this.flapActive = 0.3 / Math.max(0.5, this.flapSpeed);
    this.flapPhase = 0;
    this.wingPower = power;
    this.squash = 0.22;
    this.sinceFlap = 0;
  }
  flapSpeed = 1;
  onHurt(): void { this.hurt = 1; this.squash = -0.25; }

  update(dt: number, anim: { flapSpeed: number; flapAmp: number; bob: number; tilt: number }): void {
    this.t += dt;
    this.flapSpeed = anim.flapSpeed;
    this.sinceFlap += dt;
    this.hurt = Math.max(0, this.hurt - dt * 2.2);
    this.squash = damp(this.squash, 0, 14, dt);
    // blink
    this.blinkTimer -= dt;
    if (this.blinkTimer <= 0 && this.blinkHold <= 0) { this.blinkHold = 0.12; this.blinkTimer = 1.6 + Math.random() * 2.8; }
    if (this.blinkHold > 0) { this.blinkHold -= dt; this.blink = 1; } else this.blink = damp(this.blink, 0, 30, dt);
    // wing beat
    if (this.flapActive > 0) {
      this.flapActive -= dt;
      const total = 0.3 / Math.max(0.5, this.flapSpeed);
      this.flapPhase = clamp(1 - this.flapActive / total, 0, 1) * 0.999;
      this.wingPower = damp(this.wingPower, 0.35, 3, dt);
    } else {
      this.wingPower = damp(this.wingPower, this.state === 'falling' ? 0.1 : 0.05, 2.5, dt);
      if (this.state === 'idle' || this.state === 'victory') {
        this.flapPhase = (this.flapPhase + dt * (this.state === 'victory' ? 3.4 : 1.1) * anim.flapSpeed) % 1;
      } else if (this.state === 'death') {
        this.flapPhase = 0.5;
      } else {
        // after a beat the wings settle open and gently flutter while gliding / falling
        this.flapPhase = 0.55 + 0.05 * Math.sin(this.t * 14);
      }
    }
    // glow
    this.glow = damp(this.glow, this.boost ? 1 : 0, 8, dt);
    // eyes follow the vertical motion
    this.lookY = damp(this.lookY, clamp(this.body.vy / 700, -1, 1) * 0.6, 8, dt);
    this.lookX = damp(this.lookX, 0.45, 4, dt);
    const targetMood = this.state === 'falling' ? -0.6 : this.state === 'victory' ? 1 : this.state === 'damage' ? -1 : this.state === 'boost' ? 0.8 : 0.25;
    this.mood = damp(this.mood, targetMood, 6, dt);
    this.tilt = damp(this.tilt, this.body.rot, 14, dt);
    if (this.state === 'death') this.deathT = clamp(this.deathT + dt / 1.1, 0, 1);
    if (this.state === 'victory') this.victoryT += dt;
  }

  /** Smooth pose for rendering. `alpha` is the fixed-step interpolation factor. */
  toPose(alpha: number, anim: { bob: number; tilt: number }, out: BirdPose): BirdPose {
    const y = lerp(this.body.prevY, this.body.y, alpha);
    const bob = this.state === 'idle' ? Math.sin(this.t * 2.4 + this.idleSeed) * 5 * anim.bob : 0;
    out.x = this.x;
    out.y = y + bob + (this.state === 'victory' ? -Math.abs(Math.sin(this.victoryT * 5)) * 14 : 0);
    out.rot = (this.state === 'idle' ? Math.sin(this.t * 1.7) * 0.06 : this.tilt * anim.tilt) + (this.state === 'death' ? this.deathT * 6.0 : 0);
    out.vy = this.body.vy;
    out.state = this.state;
    out.t = this.t;
    out.flapPhase = this.flapPhase;
    out.wingPower = this.wingPower;
    out.blink = this.blink;
    out.squash = this.squash;
    out.glow = this.glow;
    out.hurt = this.hurt;
    out.alpha = this.alpha;
    out.scale = this.scale;
    out.lookX = this.lookX;
    out.lookY = this.lookY;
    out.shield = this.shield;
    out.ghost = this.ghost;
    out.deathT = this.deathT;
    out.victoryT = this.victoryT;
    out.mood = this.mood;
    return out;
  }
}

export function newPose(): BirdPose {
  return { x: 0, y: 0, rot: 0, vy: 0, state: 'idle', t: 0, flapPhase: 0, wingPower: 0, blink: 0, squash: 0, glow: 0, hurt: 0, alpha: 1, scale: 1, lookX: 0.4, lookY: 0, shield: false, ghost: false, deathT: 0, victoryT: 0, mood: 0.3 };
}
