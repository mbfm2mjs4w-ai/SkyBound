import type { L10n, PowerUpType } from '../core/types';

export interface PowerUpDef {
  id: PowerUpType;
  color: string;
  glow: string;
  duration: number;   // seconds; 0 = stays until consumed
  weight: number;     // spawn weight
  name: L10n;
  desc: L10n;
}

export const POWERUPS: Record<PowerUpType, PowerUpDef> = {
  shield:       { id: 'shield', color: '#5ad1ff', glow: '#9fe8ff', duration: 0, weight: 3, name: { vi: 'Khiên Chắn', en: 'Shield' }, desc: { vi: 'Chặn một lần va chạm.', en: 'Blocks one collision.' } },
  timewarp:     { id: 'timewarp', color: '#b48cff', glow: '#d9c4ff', duration: 6, weight: 2, name: { vi: 'Bẻ Cong Thời Gian', en: 'Time Warp' }, desc: { vi: 'Làm chậm thời gian trong 6 giây.', en: 'Slows time for 6 seconds.' } },
  phoenix:      { id: 'phoenix', color: '#ff8a3d', glow: '#ffd27a', duration: 0, weight: 1.2, name: { vi: 'Phượng Hoàng Tái Sinh', en: 'Phoenix Rebirth' }, desc: { vi: 'Hồi sinh một lần sau khi thất bại.', en: 'Revive once after failing.' } },
  multiplier:   { id: 'multiplier', color: '#ffd23f', glow: '#fff2a0', duration: 10, weight: 2.5, name: { vi: 'Nhân Đôi Điểm', en: 'Score x2' }, desc: { vi: 'Nhân đôi điểm trong 10 giây.', en: 'Doubles score for 10 seconds.' } },
  magnet:       { id: 'magnet', color: '#ff5d7a', glow: '#ffb0c0', duration: 10, weight: 3, name: { vi: 'Nam Châm', en: 'Magnet' }, desc: { vi: 'Hút xu xung quanh trong 10 giây.', en: 'Attracts coins for 10 seconds.' } },
  ghost:        { id: 'ghost', color: '#c9f0ff', glow: '#ffffff', duration: 5, weight: 1.5, name: { vi: 'Bay Xuyên Ảo Ảnh', en: 'Ghost Flight' }, desc: { vi: 'Xuyên qua chướng ngại vật trong 5 giây.', en: 'Phase through obstacles for 5 seconds.' } },
  turbo:        { id: 'turbo', color: '#ff7a1f', glow: '#ffd37a', duration: 4, weight: 1.5, name: { vi: 'Tăng Tốc Turbo', en: 'Turbo Boost' }, desc: { vi: 'Lao nhanh, bất tử trong 4 giây.', en: 'Dash invincibly for 4 seconds.' } },
  featherstorm: { id: 'featherstorm', color: '#7affc1', glow: '#c9ffe6', duration: 8, weight: 1.5, name: { vi: 'Bão Lông Vũ', en: 'Feather Storm' }, desc: { vi: 'Bão lông vũ: +2 điểm mỗi cổng, tự thu xu gần, 8 giây.', en: 'Feather storm: +2 per gate and auto-collect nearby coins for 8s.' } },
};
export const POWERUP_TYPES = Object.keys(POWERUPS) as PowerUpType[];
