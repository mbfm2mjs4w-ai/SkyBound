// Canvas + DPR + resize + main loop (requestAnimationFrame, clamped dt, auto-pause when the tab is hidden).
import { LOGICAL_H } from '../config/gameConfig';
import { Emitter } from '../core/events';
import { clamp } from '../core/util';

export interface EngineEvents { resize: { W: number; H: number; scale: number; dpr: number }; hidden: null; visible: null; [k: string]: unknown }

export class Engine {
  readonly ev = new Emitter<EngineEvents>();
  readonly canvas: HTMLCanvasElement;
  readonly ctx: CanvasRenderingContext2D;
  W = 450; H = LOGICAL_H; scale = 1; dpr = 1; dprCap = 2;
  private raf = 0; private last = 0; private running = false;
  private frame: (dt: number, now: number) => void = () => {};
  fps = 60; private fpsAcc = 0; private fpsN = 0;
  private offs: (() => void)[] = [];

  constructor(readonly host: HTMLElement) {
    this.canvas = document.createElement('canvas');
    this.canvas.id = 'game-canvas';
    host.appendChild(this.canvas);
    this.ctx = this.canvas.getContext('2d', { alpha: false, desynchronized: true }) as CanvasRenderingContext2D;
    const rs = (): void => this.resize();
    window.addEventListener('resize', rs); window.addEventListener('orientationchange', rs);
    const vis = (): void => { if (document.hidden) this.ev.emit('hidden', null); else { this.last = performance.now(); this.ev.emit('visible', null); } };
    document.addEventListener('visibilitychange', vis);
    window.addEventListener('blur', () => this.ev.emit('hidden', null));
    this.offs.push(() => { window.removeEventListener('resize', rs); window.removeEventListener('orientationchange', rs); document.removeEventListener('visibilitychange', vis); });
    this.resize();
  }
  setDprCap(c: number): void { this.dprCap = c; this.resize(); }

  resize(): void {
    const cw = Math.max(240, this.host.clientWidth || window.innerWidth), ch = Math.max(240, this.host.clientHeight || window.innerHeight);
    const dpr = clamp(window.devicePixelRatio || 1, 1, this.dprCap);
    let W = (cw / ch) * LOGICAL_H;
    W = clamp(W, 400, 1500);
    const scale = Math.min(cw / W, ch / LOGICAL_H);
    const cssW = W * scale, cssH = LOGICAL_H * scale;
    this.canvas.style.width = `${cssW}px`; this.canvas.style.height = `${cssH}px`;
    this.canvas.width = Math.round(cssW * dpr); this.canvas.height = Math.round(cssH * dpr);
    this.W = W; this.H = LOGICAL_H; this.scale = scale; this.dpr = dpr;
    document.documentElement.style.setProperty('--ui-scale', String(clamp(cssH / 800, 0.62, 1.35)));
    document.documentElement.style.setProperty('--game-w', `${cssW}px`);
    document.documentElement.style.setProperty('--game-h', `${cssH}px`);
    this.ev.emit('resize', { W, H: LOGICAL_H, scale, dpr });
  }
  /** Reset the context transform so that logical units are 0..W × 0..800. */
  begin(): CanvasRenderingContext2D {
    const k = this.canvas.width / this.W;
    this.ctx.setTransform(k, 0, 0, k, 0, 0);
    return this.ctx;
  }
  start(frame: (dt: number, now: number) => void): void {
    this.frame = frame;
    if (this.running) return;
    this.running = true; this.last = performance.now();
    const loop = (now: number): void => {
      if (!this.running) return;
      this.raf = requestAnimationFrame(loop);
      const dt = Math.min(0.1, Math.max(0, (now - this.last) / 1000)); this.last = now;
      this.fpsAcc += dt; this.fpsN++;
      if (this.fpsAcc >= 0.5) { this.fps = Math.round(this.fpsN / this.fpsAcc); this.fpsAcc = 0; this.fpsN = 0; }
      this.frame(dt, now / 1000);
    };
    this.raf = requestAnimationFrame(loop);
  }
  stop(): void { this.running = false; cancelAnimationFrame(this.raf); }
  destroy(): void { this.stop(); for (const o of this.offs) o(); this.offs = []; this.canvas.remove(); }
}
