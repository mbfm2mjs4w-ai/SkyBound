// Shared type contracts used by data, systems, renderers and UI.

export type Lang = 'vi' | 'en';
export interface L10n { vi: string; en: string }
export type QualityName = 'low' | 'medium' | 'high' | 'ultra';

export interface QualityProfile {
  name: QualityName;
  dprCap: number;          // max devicePixelRatio used for the main canvas
  maxParticles: number;    // hard cap of the particle pool
  particleScale: number;   // multiplier applied to emission counts (0..1.5)
  fog: boolean;            // animated fog bands
  shafts: boolean;         // volumetric light shafts
  bloom: boolean;          // additive glow passes
  decor: boolean;          // moving background decor actors
  shadows: boolean;        // soft shadows
  weather: number;         // weather density multiplier (0..1.5)
  layerScale: number;      // texture resolution multiplier for pre-rendered layers (0.5..1)
  trailPoints: number;     // trail ribbon length
}

/** Per-frame view state passed to world / obstacle renderers. The ctx they draw on is already
 *  scaled so that logical coordinates are 0..W x 0..H (H is always LOGICAL_H = 800). */
export interface ViewState {
  W: number;
  H: number;
  time: number;            // seconds, monotonically increasing (real time)
  scroll: number;          // distance scrolled by the world (logical units) — drives parallax
  camY: number;            // camera vertical offset in logical units (layers shift by camY * depth)
  tod: number;             // time of day 0..1 (see getDayWeights / getCelestial in util.ts)
  intensity: number;       // 0..1 game intensity (difficulty / boost) for mood effects
  quality: QualityProfile;
  reducedMotion: boolean;
}

export type BirdState = 'idle' | 'flying' | 'falling' | 'boost' | 'damage' | 'victory' | 'death';

export interface BirdPose {
  x: number;               // center of body (world coordinates)
  y: number;
  rot: number;             // body tilt radians (positive = nose down)
  vy: number;              // vertical velocity (units/s, positive = falling)
  state: BirdState;
  t: number;               // animation clock in seconds
  flapPhase: number;       // 0..1 wing cycle phase (0 = wings up, 0.5 = wings down)
  wingPower: number;       // 0..1 recent flap strength (decays after each flap)
  blink: number;           // 0 open .. 1 closed
  squash: number;          // -0.3 (squashed) .. +0.3 (stretched)
  glow: number;            // 0..1 boost glow
  hurt: number;            // 0..1 damage flash
  alpha: number;           // 0..1 overall opacity
  scale: number;           // 1 = normal (logical bird body ~ 46 units wide)
  lookX: number;           // -1..1 eye look direction
  lookY: number;
  shield: boolean;         // draw shield bubble
  ghost: boolean;          // draw translucent ghost look
  deathT: number;          // 0..1 progress of the death animation (state = 'death')
  victoryT: number;        // seconds since victory started
  mood: number;            // -1 (scared) .. 0 neutral .. 1 (happy)
}

export type ObstacleKind =
  | 'crystal' | 'pillar' | 'ruins' | 'energy' | 'platform'
  | 'ring' | 'laser' | 'fire' | 'ice' | 'portal';

/** What a gate (one obstacle with a vertical gap) looks like this frame. */
export interface GateView {
  kind: ObstacleKind;
  worldId: string;
  x: number;               // center x (world coords, already interpolated)
  centerY: number;         // center of the free gap
  gapHalf: number;         // half-height of the free gap (to the solid edge / spike apex)
  halfW: number;           // half-width of the solid column
  seed: number;            // per-gate random seed (stable) for variation
  phase: number;           // animation clock for this gate (seconds)
  rot: number;             // rotation angle for ring gates (radians)
  pulse: number;           // 0..1 breathing / energy pulse
  appear: number;          // 0..1 spawn fade-in (1 = fully visible)
  night: number;           // 0..1 how dark it is (for emissive intensity)
  nextWorld?: string;      // set on the world-change portal gate
}

export type PowerUpType =
  | 'shield' | 'timewarp' | 'phoenix' | 'multiplier'
  | 'magnet' | 'ghost' | 'turbo' | 'featherstorm';

export type ParticleKind =
  | 'feather' | 'spark' | 'petal' | 'snow' | 'ember' | 'bubble' | 'star'
  | 'leaf' | 'smoke' | 'bolt' | 'shard' | 'rune' | 'confetti' | 'glow' | 'ring' | 'heart';

export type TrailKind =
  | 'ribbon' | 'stardust' | 'flame' | 'frost' | 'neon' | 'petals'
  | 'lightning' | 'orbs' | 'rainbow' | 'shadow' | 'glow';

export type UnlockRule =
  | { type: 'free' }
  | { type: 'coins'; price: number }
  | { type: 'gems'; price: number; minLevel?: number }
  | { type: 'level'; level: number; price?: number }
  | { type: 'achievement'; id: string; hint: L10n }
  | { type: 'secret'; id: string; hint: L10n };

export interface GameEvents {
  [event: string]: unknown;
}
