import type { L10n } from '../core/types';
import { RNG, hashString } from '../core/util';
import type { MissionState } from '../systems/SaveManager';

export type MissionStat = 'games' | 'gates' | 'coins' | 'powerups' | 'perfects' | 'distance' | 'maxCombo' | 'bestScore' | 'bosses' | 'adventure' | 'gems';
export interface Reward { coins: number; gems: number; xp: number }
export interface MissionTpl {
  id: string;
  stat: MissionStat;
  /** 'sum' adds up over runs, 'max' keeps the best single-run value */
  kind: 'sum' | 'max';
  target: number;
  reward: Reward;
  text: L10n;          // {n} is replaced by the target
}

const T = (id: string, stat: MissionStat, kind: 'sum' | 'max', target: number, reward: Reward, vi: string, en: string): MissionTpl => ({ id, stat, kind, target, reward, text: { vi, en } });

export const DAILY_POOL: MissionTpl[] = [
  T('d_games', 'games', 'sum', 3, { coins: 60, gems: 0, xp: 40 }, 'Chơi {n} ván', 'Play {n} games'),
  T('d_gates', 'gates', 'sum', 50, { coins: 70, gems: 0, xp: 50 }, 'Bay qua {n} cổng', 'Fly through {n} gates'),
  T('d_coins', 'coins', 'sum', 60, { coins: 60, gems: 1, xp: 40 }, 'Thu thập {n} xu', 'Collect {n} coins'),
  T('d_power', 'powerups', 'sum', 3, { coins: 70, gems: 0, xp: 50 }, 'Nhặt {n} vật phẩm', 'Pick up {n} power-ups'),
  T('d_perfect', 'perfects', 'sum', 15, { coins: 80, gems: 0, xp: 60 }, 'Bay hoàn hảo qua {n} cổng', 'Fly {n} perfect gates'),
  T('d_dist', 'distance', 'sum', 600, { coins: 60, gems: 0, xp: 40 }, 'Bay {n} mét', 'Fly {n} meters'),
  T('d_combo', 'maxCombo', 'max', 6, { coins: 80, gems: 1, xp: 60 }, 'Đạt combo {n} trong một ván', 'Reach a {n} combo in one run'),
  T('d_score', 'bestScore', 'max', 20, { coins: 80, gems: 0, xp: 60 }, 'Đạt {n} điểm trong một ván', 'Score {n} in one run'),
];
export const WEEKLY_POOL: MissionTpl[] = [
  T('w_games', 'games', 'sum', 20, { coins: 250, gems: 3, xp: 160 }, 'Chơi {n} ván', 'Play {n} games'),
  T('w_gates', 'gates', 'sum', 400, { coins: 300, gems: 3, xp: 200 }, 'Bay qua {n} cổng', 'Fly through {n} gates'),
  T('w_coins', 'coins', 'sum', 500, { coins: 250, gems: 4, xp: 180 }, 'Thu thập {n} xu', 'Collect {n} coins'),
  T('w_power', 'powerups', 'sum', 15, { coins: 300, gems: 3, xp: 200 }, 'Nhặt {n} vật phẩm', 'Pick up {n} power-ups'),
  T('w_perfect', 'perfects', 'sum', 120, { coins: 350, gems: 4, xp: 220 }, '{n} lần bay hoàn hảo', '{n} perfect gates'),
  T('w_dist', 'distance', 'sum', 4000, { coins: 300, gems: 3, xp: 200 }, 'Bay {n} mét', 'Fly {n} meters'),
  T('w_score', 'bestScore', 'max', 50, { coins: 350, gems: 5, xp: 240 }, 'Đạt {n} điểm trong một ván', 'Score {n} in one run'),
  T('w_boss', 'bosses', 'sum', 3, { coins: 400, gems: 6, xp: 300 }, 'Đánh bại {n} trùm', 'Defeat {n} bosses'),
  T('w_adv', 'adventure', 'sum', 4, { coins: 350, gems: 5, xp: 260 }, 'Hoàn thành {n} màn Phiêu lưu', 'Complete {n} Adventure levels'),
];
export const MISSION_BY_ID: Record<string, MissionTpl> = Object.fromEntries([...DAILY_POOL, ...WEEKLY_POOL].map((t) => [t.id, t]));

function pickDistinct(pool: MissionTpl[], seed: number, n: number): MissionTpl[] {
  const rng = new RNG(seed);
  const rest = pool.slice();
  const out: MissionTpl[] = [];
  const stats = new Set<string>();
  while (out.length < n && rest.length) {
    const i = rng.int(0, rest.length - 1);
    const t = rest.splice(i, 1)[0];
    if (stats.has(t.stat)) continue;
    stats.add(t.stat); out.push(t);
  }
  return out;
}
export function rollMissions(kind: 'daily' | 'weekly', key: string): MissionState[] {
  const pool = kind === 'daily' ? DAILY_POOL : WEEKLY_POOL;
  return pickDistinct(pool, hashString(kind + ':' + key), 3).map((t) => ({ id: `${t.id}@${key}`, tpl: t.id, progress: 0, target: t.target, claimed: false }));
}
export function missionText(m: MissionState, lang: 'vi' | 'en'): string {
  const t = MISSION_BY_ID[m.tpl];
  return t ? t.text[lang].replace('{n}', String(m.target)) : m.id;
}
