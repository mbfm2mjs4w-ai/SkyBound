import { SKINS } from '../../src/data/skins';
import { drawBird, idlePose } from '../../src/render/BirdRenderer';
import { QUALITY } from '../../src/config/gameConfig';
import { drawGlow } from '../../src/render/gfx';

const cv = document.getElementById('c') as HTMLCanvasElement;
const ctx = cv.getContext('2d')!;
const cols = 5, cw = 220, ch = 190;
cv.width = cols * cw; cv.height = Math.ceil(SKINS.length / cols) * ch + 200;
ctx.fillStyle = '#243a63'; ctx.fillRect(0, 0, cv.width, cv.height);
const mk = (t: number, ph: number, st: any = 'flying') => { const p = idlePose(t); p.state = st; p.flapPhase = ph; p.wingPower = 0.8; p.scale = 1.7; p.mood = 0.3; return p; };
SKINS.forEach((s, i) => {
  const x = (i % cols) * cw + cw / 2, y = Math.floor(i / cols) * ch + ch / 2;
  ctx.fillStyle = 'rgba(255,255,255,0.06)'; ctx.fillRect((i % cols) * cw + 4, Math.floor(i / cols) * ch + 4, cw - 8, ch - 8);
  const p = mk(1.3 + i * 0.37, 0.12 + (i % 4) * 0.2); p.x = x; p.y = y;
  drawBird(ctx, s, p, { quality: QUALITY.high });
  ctx.fillStyle = '#fff'; ctx.font = '13px sans-serif'; ctx.textAlign = 'center'; ctx.fillText(s.name, x, (Math.floor(i / cols) + 1) * ch - 10);
});
// state strip
const states = ['idle', 'flying', 'falling', 'boost', 'damage', 'victory', 'death'] as const;
const y0 = Math.ceil(SKINS.length / cols) * ch + 80;
states.forEach((st, i) => {
  const p = mk(2.1, 0.0 + i * 0.07, st); p.x = 90 + i * 150; p.y = y0; p.scale = 1.3;
  if (st === 'falling') { p.rot = 0.9; p.vy = 700; p.mood = -0.8; }
  if (st === 'boost') { p.glow = 1; p.rot = -0.05; }
  if (st === 'damage') { p.hurt = 0.8; p.mood = -1; }
  if (st === 'death') { p.rot = 2.6; p.deathT = 0.5; }
  if (st === 'victory') { p.victoryT = 1; p.mood = 1; }
  if (i === 1) { p.shield = true; }
  drawBird(ctx, SKINS[0], p, { quality: QUALITY.high, item: i === 5 ? 'crown' : i === 0 ? 'sunglasses' : null });
  ctx.fillStyle = '#fff'; ctx.font = '12px sans-serif'; ctx.textAlign = 'center'; ctx.fillText(st, p.x, y0 + 70);
});
(window as any).done = true;
