// Shared math / color / time helpers. No DOM dependencies (usable from headless tests).

export const TAU = Math.PI * 2;
export const clamp = (v: number, a: number, b: number): number => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number): number => a + (b - a) * t;
export const invLerp = (a: number, b: number, v: number): number => (b === a ? 0 : (v - a) / (b - a));
export const smoothstep = (e0: number, e1: number, x: number): number => {
  const t = clamp((x - e0) / (e1 - e0), 0, 1);
  return t * t * (3 - 2 * t);
};
export const damp = (cur: number, target: number, lambda: number, dt: number): number =>
  lerp(cur, target, 1 - Math.exp(-lambda * dt));

export const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);
export const easeInCubic = (t: number) => t * t * t;
export const easeInOutCubic = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
export const easeOutBack = (t: number) => {
  const c1 = 1.70158, c3 = c1 + 1;
  return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
};
export const easeOutElastic = (t: number) => {
  if (t === 0 || t === 1) return t;
  return Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * ((2 * Math.PI) / 3)) + 1;
};

// ---------- RNG ----------
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export function hashString(s: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h >>> 0;
}
export class RNG {
  private f: () => number;
  constructor(seed: number) { this.f = mulberry32(seed); }
  next(): number { return this.f(); }
  range(a: number, b: number): number { return a + (b - a) * this.f(); }
  int(a: number, b: number): number { return Math.floor(this.range(a, b + 1)); }
  chance(p: number): boolean { return this.f() < p; }
  pick<T>(arr: readonly T[]): T { return arr[Math.floor(this.f() * arr.length) % arr.length]; }
  sign(): number { return this.f() < 0.5 ? -1 : 1; }
}

// ---------- Color ----------
export function hexToRgb(hex: string): [number, number, number] {
  let h = hex.trim();
  if (h[0] === '#') h = h.slice(1);
  if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
  const n = parseInt(h.slice(0, 6), 16);
  if (Number.isNaN(n)) return [255, 255, 255];
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
export function rgbToHex(r: number, g: number, b: number): string {
  const c = (v: number) => clamp(Math.round(v), 0, 255).toString(16).padStart(2, '0');
  return '#' + c(r) + c(g) + c(b);
}
export function mixHex(a: string, b: string, t: number): string {
  const A = hexToRgb(a), B = hexToRgb(b);
  return rgbToHex(lerp(A[0], B[0], t), lerp(A[1], B[1], t), lerp(A[2], B[2], t));
}
/** amt in -1..1: negative darkens, positive lightens */
export function shadeHex(hex: string, amt: number): string {
  return amt >= 0 ? mixHex(hex, '#ffffff', amt) : mixHex(hex, '#000000', -amt);
}
export function rgba(hex: string, a: number): string {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r},${g},${b},${clamp(a, 0, 1)})`;
}
export function hsl(h: number, s: number, l: number, a = 1): string {
  return `hsla(${((h % 360) + 360) % 360},${s}%,${l}%,${a})`;
}
export function hslToHex(h: number, s: number, l: number): string {
  s /= 100; l /= 100;
  const k = (n: number) => (n + h / 30) % 12;
  const a = s * Math.min(l, 1 - l);
  const f = (n: number) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  return rgbToHex(f(0) * 255, f(8) * 255, f(4) * 255);
}
export function mix3(a: readonly [string, string, string], b: readonly [string, string, string], t: number): [string, string, string] {
  return [mixHex(a[0], b[0], t), mixHex(a[1], b[1], t), mixHex(a[2], b[2], t)];
}

// ---------- Day / night cycle ----------
/** tod in [0,1): 0 = dawn, ~0.25 = noon, ~0.5 = dusk, ~0.75 = deep night. Weights sum to 1. */
export function getDayWeights(tod: number): { day: number; dusk: number; night: number } {
  const t = ((tod % 1) + 1) % 1;
  let day = 0, dusk = 0, night = 0;
  if (t < 0.08) { const k = smoothstep(0, 0.08, t); dusk = 1 - k; day = k; }
  else if (t < 0.42) day = 1;
  else if (t < 0.54) { const k = smoothstep(0.42, 0.54, t); day = 1 - k; dusk = k; }
  else if (t < 0.64) { const k = smoothstep(0.54, 0.64, t); dusk = 1 - k; night = k; }
  else if (t < 0.9) night = 1;
  else { const k = smoothstep(0.9, 1, t); night = 1 - k; dusk = k; }
  return { day, dusk, night };
}
/** Sun & moon placement as fractions of the screen (x: 0..1 left→right, y: 0..1 top→bottom). */
export function getCelestial(tod: number): { sunX: number; sunY: number; sunVisible: boolean; moonX: number; moonY: number; moonVisible: boolean } {
  const t = ((tod % 1) + 1) % 1;
  const sunT = t / 0.58;
  const moonT = (t - 0.52) / 0.48;
  return {
    sunVisible: sunT >= 0 && sunT <= 1,
    sunX: lerp(0.08, 0.92, clamp(sunT, 0, 1)),
    sunY: 0.82 - 0.62 * Math.sin(Math.PI * clamp(sunT, 0, 1)),
    moonVisible: moonT >= 0 && moonT <= 1,
    moonX: lerp(0.08, 0.92, clamp(moonT, 0, 1)),
    moonY: 0.82 - 0.6 * Math.sin(Math.PI * clamp(moonT, 0, 1)),
  };
}

// ---------- Dates ----------
export function dateKey(d: Date = new Date()): string {
  const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0'), day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}
export function weekKey(d: Date = new Date()): string {
  const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dayNum = t.getUTCDay() || 7;
  t.setUTCDate(t.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
  const week = Math.ceil(((t.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  return `${t.getUTCFullYear()}-W${String(week).padStart(2, '0')}`;
}
export function daysBetween(a: string, b: string): number {
  const pa = a.split('-').map(Number), pb = b.split('-').map(Number);
  const da = Date.UTC(pa[0], pa[1] - 1, pa[2]), db = Date.UTC(pb[0], pb[1] - 1, pb[2]);
  return Math.round((db - da) / 86400000);
}
export function formatNumber(n: number): string {
  return Math.floor(n).toLocaleString('en-US');
}
export function formatTime(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}
