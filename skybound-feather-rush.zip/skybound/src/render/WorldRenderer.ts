// Renders a world: sky → celestial → clouds → parallax layers (baked) → decor → emissive → rays; foreground = weather + ground; lighting = vignette/bloom.
// Contract: ctx is already scaled so that logical coordinates are 0..W x 0..LOGICAL_H.
import { WORLD_BY_ID, type LayerDef, type WorldDef, type GroundKind } from '../data/worlds';
import type { QualityProfile, ViewState } from '../core/types';
import { QUALITY, DEFAULT_TUNING } from '../config/gameConfig';
import { clamp, getCelestial, getDayWeights, hexToRgb, mix3, mixHex, mulberry32, rgba, shadeHex, TAU } from '../core/util';
import { bake, drawGlow, ctx2d, makeCanvas, type Ctx } from './gfx';
import { PAINTERS, makeRnd, type PaintCtx } from './world/layers';
import { DECOR, type DecorEnv } from './world/decor';
import { WeatherSystem } from './world/weather';

const TILE_W = 1024;      // logical width of one parallax tile
const BAND_H = 1000;      // logical height of one layer band
const BAND_TOP = -100;    // screen y of the band top
const GROUND_TILE = 256;

interface BakedLayer { def: LayerDef; tex: HTMLCanvasElement; emit: HTMLCanvasElement | null }
interface CloudSprite { tex: HTMLCanvasElement; w: number; h: number }
interface Prepared {
  id: string; def: WorldDef; layers: BakedLayer[]; clouds: CloudSprite[]; ground: HTMLCanvasElement; groundRatio: number;
  stars: Float32Array; weather: WeatherSystem; ratio: number; quality: QualityProfile;
}

const hash = (n: number): number => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };

export function worldTod(def: WorldDef, tod: number): number { return def.cycle === 'fixed' ? def.fixedTod ?? 0.5 : tod; }

export function skyColors(def: WorldDef, tod: number): [string, string, string] {
  const w = getDayWeights(worldTod(def, tod));
  let c = mix3(def.sky.day, def.sky.day, 0);
  if (w.dusk > 0) c = mix3(c, def.sky.dusk, w.dusk / Math.max(0.0001, w.day + w.dusk));
  if (w.night > 0) c = mix3(c, def.sky.night, w.night);
  return c;
}

export class WorldRenderer {
  private prepared = new Map<string, Prepared>();
  private buf: HTMLCanvasElement | null = null;
  private bufG: Ctx | null = null;
  private bufKey = '';
  private vignette: HTMLCanvasElement | null = null;
  private vigKey = '';
  private lastDpr = 1;

  constructor(private quality: QualityProfile = QUALITY.high) {}

  setQuality(q: QualityProfile): void {
    if (q === this.quality) return;
    this.quality = q;
    const ids = [...this.prepared.keys()];
    const dims = this.lastDims;
    this.prepared.clear();
    for (const id of ids) this.prepare(id, dims.W, dims.H, dims.dpr);
  }
  private lastDims = { W: 800, H: 800, dpr: 1 };

  isPrepared(id: string): boolean { return this.prepared.has(id); }
  release(id: string): void { this.prepared.delete(id); }
  releaseExcept(keep: string[]): void { for (const id of [...this.prepared.keys()]) if (!keep.includes(id)) this.prepared.delete(id); }

  /** Bake all textures for a world in one go (a few ms per layer). */
  prepare(id: string, W: number, H: number, dpr: number): void {
    const it = this.prepareGen(id, W, H, dpr);
    while (!it.next().done) { /* run to completion */ }
  }
  /** Incremental bake: call `.next()` once per frame to spread the cost (used to pre-load the next world during play). */
  *prepareGen(id: string, W: number, H: number, dpr: number): Generator<void, void, void> {
    this.lastDims = { W, H, dpr }; this.lastDpr = dpr;
    if (this.prepared.has(id)) return;
    const def = WORLD_BY_ID[id];
    if (!def) return;
    const q = this.quality;
    const ratio = clamp(Math.min(dpr, q.dprCap) * q.layerScale, 0.4, 2.2);
    const layers: BakedLayer[] = [];
    const n = def.layers.length;
    for (let i = 0; i < n; i++) { layers.push(this.bakeLayer(def, def.layers[i], i, n, ratio)); yield; }
    const clouds = def.clouds ? this.bakeClouds(def, ratio) : [];
    yield;
    const ground = this.bakeGround(def.ground, def.groundColors, def, Math.min(dpr, q.dprCap));
    const rnd = mulberry32(def.index * 977 + 5);
    const stars = new Float32Array(160 * 3);
    for (let i = 0; i < 160; i++) { stars[i * 3] = rnd(); stars[i * 3 + 1] = Math.pow(rnd(), 1.3) * 0.75; stars[i * 3 + 2] = 0.5 + rnd() * 1.5; }
    const weather = new WeatherSystem(def.weather, def.palette.accent, q.weather, W, H);
    this.prepared.set(id, { id, def, layers, clouds, ground, groundRatio: Math.min(dpr, q.dprCap), stars, weather, ratio, quality: q });
  }

  // ---------------------------------------------------------------- baking
  private bakeLayer(def: WorldDef, ld: LayerDef, index: number, count: number, ratio: number): BakedLayer {
    const painter = PAINTERS[ld.kind];
    const base = ld.base * DEFAULT_TUNING_H - BAND_TOP;      // band-local ground line
    const maxH = ld.height * DEFAULT_TUNING_H;
    const depth = count <= 1 ? 1 : index / (count - 1);
    const fogA = this.quality.fog ? clamp(0.42 * (1 - depth) + 0.05, 0, 0.5) : 0;
    const make = (pass: 'base' | 'emit'): HTMLCanvasElement => bake(TILE_W, BAND_H, ratio, (g) => {
      const P: PaintCtx = {
        g, w: TILE_W, h: BAND_H, base, maxH, c0: ld.colors[0], c1: ld.colors[1], rnd: makeRnd(ld.seed + (pass === 'emit' ? 0 : 0)),
        p: ld.params ?? {}, pass, def: ld, fog: def.palette.fog,
      };
      if (painter) painter(P);
      if (pass === 'base' && fogA > 0.01) {      // atmospheric haze baked only onto this layer's pixels
        g.save(); g.globalCompositeOperation = 'source-atop';
        const gr = g.createLinearGradient(0, base - maxH, 0, base + 40);
        gr.addColorStop(0, rgba(def.palette.fog, 0)); gr.addColorStop(0.7, rgba(def.palette.fog, fogA * 0.7)); gr.addColorStop(1, rgba(def.palette.fog, fogA));
        g.fillStyle = gr; g.fillRect(0, 0, TILE_W, BAND_H); g.restore();
      }
    });
    const tex = make('base');
    const emit = ld.emissive ? make('emit') : null;
    return { def: ld, tex, emit };
  }

  private bakeClouds(def: WorldDef, ratio: number): CloudSprite[] {
    const cd = def.clouds!;
    const out: CloudSprite[] = [];
    for (let v = 0; v < 3; v++) {
      const w = 300, h = 140, r = mulberry32(v * 31 + def.index * 7);
      const tex = bake(w, h, ratio, (g) => {
        const puffs: [number, number, number][] = [];
        const n = 6 + Math.floor(r() * 3);
        for (let i = 0; i < n; i++) { const t = i / (n - 1); puffs.push([40 + t * (w - 80), h * 0.62 - Math.sin(t * Math.PI) * (18 + r() * 28), 24 + Math.sin(t * Math.PI) * (16 + r() * 16)]); }
        g.fillStyle = cd.shade; for (const [x, y, rr] of puffs) { g.beginPath(); g.arc(x, y + 8, rr, 0, TAU); g.fill(); }
        g.beginPath(); g.ellipse(w / 2, h * 0.66, w * 0.42, 17, 0, 0, TAU); g.fill();
        g.fillStyle = cd.color; for (const [x, y, rr] of puffs) { g.beginPath(); g.arc(x, y, rr, 0, TAU); g.fill(); }
        const hl = g.createLinearGradient(0, 0, 0, h); hl.addColorStop(0, 'rgba(255,255,255,0.45)'); hl.addColorStop(0.55, 'rgba(255,255,255,0)');
        g.globalCompositeOperation = 'source-atop'; g.fillStyle = hl; g.fillRect(0, 0, w, h);
      });
      out.push({ tex, w, h });
    }
    return out;
  }

  private bakeGround(kind: GroundKind, colors: readonly [string, string], def: WorldDef, ratio: number): HTMLCanvasElement {
    const h = 150;
    const [c0, c1] = colors;
    return bake(GROUND_TILE, h, ratio, (g, w) => {
      const r = mulberry32(def.index * 53 + 9);
      const body = g.createLinearGradient(0, 0, 0, h); body.addColorStop(0, c0); body.addColorStop(1, c1);
      g.fillStyle = body; g.fillRect(0, 0, w, h);
      const edge = (col: string, th: number): void => { g.fillStyle = col; g.fillRect(0, 0, w, th); };
      switch (kind) {
        case 'grass': {
          edge(shadeHex(c0, 0.25), 7);
          g.fillStyle = shadeHex(c0, 0.35);
          for (let x = 0; x < w; x += 8) { const hh = 6 + r() * 9; g.beginPath(); g.moveTo(x, 8); g.lineTo(x + 3, -hh + 8); g.lineTo(x + 6, 8); g.fill(); }
          g.fillStyle = rgba(shadeHex(c1, -0.4), 0.45); for (let i = 0; i < 12; i++) g.fillRect(r() * w, 24 + r() * 100, 5 + r() * 12, 3);
          g.fillStyle = 'rgba(255,240,150,0.7)'; for (let i = 0; i < 4; i++) { g.beginPath(); g.arc(r() * w, 14 + r() * 8, 1.8, 0, TAU); g.fill(); }
          break;
        }
        case 'rooftop': {
          g.fillStyle = shadeHex(c1, -0.25); for (let x = 0; x < w; x += 32) for (let y = 14; y < h; y += 16) g.fillRect(x + ((y / 16) % 2) * 16, y, 30, 1.6);
          edge(shadeHex(c0, 0.3), 6); g.fillStyle = 'rgba(255,200,120,0.35)'; g.fillRect(0, 6, w, 2);
          break;
        }
        case 'snow': {
          edge('#ffffff', 10); g.fillStyle = 'rgba(255,255,255,0.9)';
          for (let x = 0; x < w; x += 22) { g.beginPath(); g.ellipse(x + 11, 10, 14, 7 + r() * 5, 0, 0, TAU); g.fill(); }
          g.fillStyle = 'rgba(140,200,240,0.35)'; for (let i = 0; i < 10; i++) g.fillRect(r() * w, 30 + r() * 100, 8 + r() * 20, 2);
          break;
        }
        case 'lava': {
          g.fillStyle = '#1a0807'; g.fillRect(0, 0, w, h);
          const gl = g.createLinearGradient(0, 0, 0, h); gl.addColorStop(0, '#ffb347'); gl.addColorStop(0.25, '#ff5a1a'); gl.addColorStop(1, '#5a0f08'); g.fillStyle = gl; g.fillRect(0, 10, w, h);
          g.fillStyle = '#2b100b'; for (let x = 0; x < w; x += 16) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x + 8, 14 + r() * 10); g.lineTo(x + 16, 0); g.fill(); }
          g.fillStyle = 'rgba(255,230,140,0.7)'; for (let i = 0; i < 9; i++) { g.beginPath(); g.ellipse(r() * w, 30 + r() * 100, 8 + r() * 12, 2, 0, 0, TAU); g.fill(); }
          break;
        }
        case 'grid': {
          g.fillStyle = '#0a0830'; g.fillRect(0, 0, w, h);
          g.strokeStyle = 'rgba(0,229,255,0.7)'; g.lineWidth = 1.6; g.beginPath(); for (let x = 0; x <= w; x += 32) { g.moveTo(x, 0); g.lineTo(x, h); } for (let y = 0; y <= h; y += 24) { g.moveTo(0, y); g.lineTo(w, y); } g.stroke();
          g.fillStyle = '#ff2bd6'; g.fillRect(0, 0, w, 3); g.fillStyle = 'rgba(255,43,214,0.35)'; g.fillRect(0, 3, w, 8);
          break;
        }
        case 'dust': {
          edge(shadeHex(c0, 0.2), 5); g.fillStyle = rgba(shadeHex(c0, 0.3), 0.5);
          for (let i = 0; i < 26; i++) { g.beginPath(); g.arc(r() * w, 8 + r() * 130, 1 + r() * 3, 0, TAU); g.fill(); }
          g.fillStyle = rgba('#000000', 0.25); for (let i = 0; i < 4; i++) { g.beginPath(); g.ellipse(r() * w, 30 + r() * 90, 18 + r() * 14, 6, 0, 0, TAU); g.fill(); }
          break;
        }
        case 'clouds': {
          g.fillStyle = '#ffffff'; for (let x = -10; x < w + 20; x += 26) { g.beginPath(); g.arc(x + r() * 6, 14 + r() * 6, 18 + r() * 10, 0, TAU); g.fill(); }
          const hz = g.createLinearGradient(0, 0, 0, h); hz.addColorStop(0, 'rgba(255,255,255,0)'); hz.addColorStop(0.2, 'rgba(255,255,255,0.7)'); hz.addColorStop(1, rgba(c1, 0.9)); g.fillStyle = hz; g.fillRect(0, 10, w, h);
          break;
        }
        case 'sand': {
          edge(shadeHex(c0, 0.25), 6); g.strokeStyle = rgba(shadeHex(c0, -0.2), 0.5); g.lineWidth = 2;
          for (let i = 0; i < 6; i++) { g.beginPath(); const y = 18 + i * 20; g.moveTo(0, y); for (let x = 0; x <= w; x += 16) g.lineTo(x, y + Math.sin(x * 0.05 + i) * 3); g.stroke(); }
          g.fillStyle = '#fff1d6'; for (let i = 0; i < 3; i++) { g.beginPath(); g.ellipse(r() * w, 30 + r() * 80, 6, 4, 0, 0, TAU); g.fill(); }
          break;
        }
        case 'petals': {
          edge(shadeHex(c0, 0.2), 6); g.fillStyle = '#ffc0dc';
          for (let i = 0; i < 38; i++) { g.save(); g.translate(r() * w, 3 + r() * 120); g.rotate(r() * 6); g.beginPath(); g.ellipse(0, 0, 4, 2.2, 0, 0, TAU); g.fill(); g.restore(); }
          break;
        }
        case 'void': {
          g.fillStyle = '#05010a'; g.fillRect(0, 0, w, h);
          g.strokeStyle = 'rgba(160,112,255,0.8)'; g.lineWidth = 2; g.beginPath(); g.moveTo(0, 2); for (let x = 0; x <= w; x += 8) g.lineTo(x, 2 + Math.sin(x * 0.1) * 2); g.stroke();
          g.fillStyle = 'rgba(160,112,255,0.35)'; g.fillRect(0, 4, w, 10);
          g.fillStyle = 'rgba(255,74,208,0.5)'; for (let i = 0; i < 14; i++) g.fillRect(r() * w, 20 + r() * 110, 1.6, 1.6);
          break;
        }
        case 'light': {
          g.fillStyle = '#fff6d8'; g.fillRect(0, 0, w, h);
          const lh = g.createLinearGradient(0, 0, 0, h); lh.addColorStop(0, '#fffbe8'); lh.addColorStop(1, rgba(c1, 1)); g.fillStyle = lh; g.fillRect(0, 0, w, h);
          g.fillStyle = 'rgba(255,215,120,0.7)'; g.fillRect(0, 0, w, 4);
          g.strokeStyle = 'rgba(255,230,150,0.55)'; g.lineWidth = 1.5; g.beginPath(); for (let x = 0; x <= w; x += 64) { g.moveTo(x, 6); g.lineTo(x, h); } g.stroke();
          break;
        }
        case 'prism': {
          for (let x = 0; x < w; x += 32) { const hue = (x / w) * 300; g.fillStyle = `hsla(${hue},80%,60%,0.55)`; g.beginPath(); g.moveTo(x, 0); g.lineTo(x + 32, 0); g.lineTo(x + 32, h); g.lineTo(x, h); g.fill(); }
          g.fillStyle = 'rgba(255,255,255,0.7)'; g.fillRect(0, 0, w, 3);
          g.fillStyle = 'rgba(255,255,255,0.12)'; for (let y = 8; y < h; y += 8) g.fillRect(0, y, w, 1);
          break;
        }
      }
      // soft top shadow line so the ground reads as a solid edge
      g.fillStyle = 'rgba(0,0,0,0.22)'; g.fillRect(0, 0, w, 2);
    });
  }

  // ---------------------------------------------------------------- per-frame update
  update(dt: number, worldId: string, scrollSpeed: number, view: ViewState): void {
    const p = this.prepared.get(worldId);
    if (!p || !view.quality.weather) return;
    p.weather.update(dt, scrollSpeed, view.reducedMotion);
  }

  // ---------------------------------------------------------------- drawing
  drawBackground(c: Ctx, worldId: string, view: ViewState): void {
    let p = this.prepared.get(worldId);
    if (!p) { this.prepare(worldId, view.W, view.H, this.lastDpr); p = this.prepared.get(worldId); }
    if (!p) { c.fillStyle = '#0b1030'; c.fillRect(0, 0, view.W, view.H); return; }
    const { def } = p, W = view.W, H = view.H, q = view.quality;
    const tod = worldTod(def, view.tod);
    const wts = getDayWeights(tod);
    const sc = skyColors(def, view.tod);
    const camY = view.camY;

    // sky (extends beyond the logical frame so camera shake / vertical camera never reveals a gap)
    const sg = c.createLinearGradient(0, -160, 0, H + 160);
    sg.addColorStop(0, sc[0]); sg.addColorStop(0.55, sc[1]); sg.addColorStop(1, sc[2]);
    c.fillStyle = sg; c.fillRect(-20, -160, W + 40, H + 320);

    this.drawCelestial(c, p, view, tod, wts);
    this.drawStars(c, p, view, wts);
    if (q.decor) this.drawDecor(c, def, view, tod, wts, 'back');

    // clouds
    if (def.clouds && p.clouds.length) this.drawClouds(c, p, view);

    // layers (tinted via an offscreen buffer only for full day/night worlds at dusk/night)
    const tintA = def.cycle === 'full' ? wts.night * 0.5 + wts.dusk * 0.2 : 0;
    if (tintA > 0.03) {
      const tint = wts.night >= wts.dusk ? mixHex('#0a1030', def.palette.primary, 0.12) : mixHex('#ff7a5a', def.palette.accent, 0.3);
      const bg = this.getBuf(c, W, H);
      if (bg) {
        bg.clearRect(-50, -200, W + 100, H + 400);
        this.drawLayers(bg, p, view, 'base');
        bg.save(); bg.globalCompositeOperation = 'source-atop'; bg.fillStyle = rgba(tint, tintA); bg.fillRect(-50, -200, W + 100, H + 400); bg.restore();
        c.drawImage(this.buf!, -50, -200, W + 100, H + 400);
      } else this.drawLayers(c, p, view, 'base');
    } else this.drawLayers(c, p, view, 'base');

    if (q.decor) this.drawDecor(c, def, view, tod, wts, 'front');

    // emissive passes (lit windows, lava, neon) — additive, strength follows darkness
    const emitK = clamp(0.35 + wts.night * 0.75 + wts.dusk * 0.4 + view.intensity * 0.1, 0, 1.1);
    c.save(); c.globalCompositeOperation = 'lighter';
    for (const L of p.layers) if (L.emit) this.blitLayer(c, L, L.emit, view, emitK);
    c.restore();

    // god rays
    if (q.shafts && def.decor.includes('god_rays') && (wts.day + wts.dusk) > 0.2) this.drawRays(c, p, view, tod, wts);
    void camY;
  }

  drawForeground(c: Ctx, worldId: string, view: ViewState): void {
    const p = this.prepared.get(worldId);
    if (!p) return;
    const W = view.W, H = view.H;
    // weather (in front of the layers, behind the gameplay would look flat; this is drawn after obstacles by the scene)
    if (view.quality.weather > 0) { c.save(); p.weather.draw(c, view.time, view.quality.bloom); c.restore(); }
    // ground strip
    const fy = DEFAULT_TUNING.floorY - view.camY;
    if (fy < H + 160) {
      const g = p.ground, th = g.height / p.groundRatio;
      const off = -((view.scroll % GROUND_TILE) + GROUND_TILE) % GROUND_TILE;
      for (let x = off; x < W + GROUND_TILE; x += GROUND_TILE) c.drawImage(g, x, fy, GROUND_TILE, th);
      c.fillStyle = p.def.groundColors[1];
      if (fy + th < H + 200) c.fillRect(0, fy + th - 0.5, W, H + 200 - (fy + th) + 0.5);
      // light bleed at the ground edge for lava / grid / light grounds
      if (view.quality.bloom && (p.def.ground === 'lava' || p.def.ground === 'grid' || p.def.ground === 'void' || p.def.ground === 'prism' || p.def.ground === 'light')) {
        c.save(); c.globalCompositeOperation = 'lighter';
        const col = p.def.ground === 'lava' ? '#ff6a2a' : p.def.ground === 'grid' ? '#ff2bd6' : p.def.ground === 'void' ? '#a070ff' : p.def.ground === 'prism' ? '#ffffff' : '#ffe27a';
        const gr = c.createLinearGradient(0, fy - 60, 0, fy + 6); gr.addColorStop(0, rgba(col, 0)); gr.addColorStop(1, rgba(col, p.def.ground === 'light' ? 0.28 : 0.4));
        c.fillStyle = gr; c.fillRect(0, fy - 60, W, 66); c.restore();
      }
    }
  }

  drawLighting(c: Ctx, worldId: string, view: ViewState): void {
    const p = this.prepared.get(worldId);
    const W = view.W, H = view.H;
    // vignette
    const key = `${Math.round(W)}x${H}`;
    if (!this.vignette || this.vigKey !== key) {
      const v = makeCanvas(256, 256 * H / W > 512 ? 512 : Math.max(64, Math.round(256 * H / W))); const g = ctx2d(v);
      const gr = g.createRadialGradient(v.width / 2, v.height / 2, Math.min(v.width, v.height) * 0.38, v.width / 2, v.height / 2, Math.hypot(v.width, v.height) * 0.62);
      gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,0.5)'); g.fillStyle = gr; g.fillRect(0, 0, v.width, v.height);
      this.vignette = v; this.vigKey = key;
    }
    c.save(); c.globalAlpha = 0.55 + view.intensity * 0.25; c.drawImage(this.vignette, 0, 0, W, H); c.restore();
    if (!p) return;
    // gentle ambient colour wash from the world palette (screen-blended so it never darkens the bird)
    if (view.quality.bloom) {
      const wts = getDayWeights(worldTod(p.def, view.tod));
      c.save(); c.globalCompositeOperation = 'lighter';
      const a = 0.04 + wts.dusk * 0.06 + view.intensity * 0.03;
      const gr = c.createLinearGradient(0, H * 0.45, 0, H); gr.addColorStop(0, rgba(p.def.palette.glow, 0)); gr.addColorStop(1, rgba(p.def.palette.glow, a));
      c.fillStyle = gr; c.fillRect(0, H * 0.45, W, H * 0.55); c.restore();
    }
  }

  // ---------------------------------------------------------------- internals
  private getBuf(c: Ctx, W: number, H: number): Ctx | null {
    const tr = c.getTransform();
    const sx = tr.a, sy = tr.d;
    const q = this.quality;
    const k = q.name === 'low' ? 0.5 : q.name === 'medium' ? 0.75 : 1;
    const pw = Math.max(2, Math.round((W + 100) * sx * k)), ph = Math.max(2, Math.round((H + 400) * sy * k));
    const key = `${pw}x${ph}`;
    if (!this.buf || this.bufKey !== key) {
      if (pw * ph > 5e7) return null;
      this.buf = makeCanvas(pw, ph); this.bufG = ctx2d(this.buf); this.bufKey = key;
    }
    const g = this.bufG!;
    g.setTransform(pw / (W + 100), 0, 0, ph / (H + 400), 50 * pw / (W + 100), 200 * ph / (H + 400));
    return g;
  }

  private blitLayer(c: Ctx, L: BakedLayer, tex: HTMLCanvasElement, view: ViewState, alpha: number): void {
    const ld = L.def, W = view.W;
    const off = -((view.scroll * ld.speed) % TILE_W + TILE_W) % TILE_W;
    const y = BAND_TOP - view.camY * (0.04 + ld.speed * 0.35);
    if (alpha < 1) c.globalAlpha = alpha;
    for (let x = off; x < W + 2; x += TILE_W) c.drawImage(tex, x - (x > off ? 0.5 : 0), y, TILE_W + 1, BAND_H);
    if (alpha < 1) c.globalAlpha = 1;
  }
  private drawLayers(c: Ctx, p: Prepared, view: ViewState, pass: 'base'): void {
    void pass;
    for (const L of p.layers) this.blitLayer(c, L, L.tex, view, 1);
  }

  private drawCelestial(c: Ctx, p: Prepared, view: ViewState, tod: number, wts: { day: number; dusk: number; night: number }): void {
    const { def } = p, W = view.W, H = view.H;
    const cel = getCelestial(tod);
    const sun = (x: number, y: number, r: number, col: string, a = 1): void => {
      drawGlow(c, x, y, r * 4.2, col, 0.55 * a); drawGlow(c, x, y, r * 2, '#ffffff', 0.5 * a);
      c.fillStyle = rgba(mixHex(col, '#ffffff', 0.55), a); c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
    };
    const moon = (x: number, y: number, r: number, a = 1): void => {
      drawGlow(c, x, y, r * 3.2, '#bcd2ff', 0.4 * a);
      c.fillStyle = rgba('#eef3ff', a); c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
      c.fillStyle = rgba('#b9c4e6', 0.5 * a); for (const [dx, dy, rr] of [[-0.3, -0.2, 0.22], [0.25, 0.15, 0.3], [-0.1, 0.4, 0.15], [0.35, -0.35, 0.12]]) { c.beginPath(); c.arc(x + dx * r, y + dy * r, rr * r, 0, TAU); c.fill(); }
    };
    switch (def.celestial) {
      case 'sunmoon':
        if (cel.sunVisible) sun(cel.sunX * W, cel.sunY * H, 44, wts.dusk > 0.4 ? '#ff9a5a' : '#fff0b0', 1 - wts.night * 0.8);
        if (cel.moonVisible && wts.night > 0.05) moon(cel.moonX * W, cel.moonY * H, 34, clamp(wts.night * 1.4, 0, 1));
        break;
      case 'sunset': sun(W * 0.68, H * 0.52, 62, '#ff8a4a'); break;
      case 'moon': moon(W * 0.74, H * 0.2, 42); break;
      case 'halo': {
        const x = W * 0.5, y = H * 0.36; drawGlow(c, x, y, 330, '#fff2c0', 0.28);
        c.save(); c.translate(x, y); c.globalCompositeOperation = 'lighter'; c.strokeStyle = 'rgba(255,240,180,0.55)'; c.lineWidth = 6; c.beginPath(); c.arc(0, 0, 150, 0, TAU); c.stroke(); c.lineWidth = 2; c.beginPath(); c.arc(0, 0, 182, 0, TAU); c.stroke();
        c.rotate(view.time * 0.05); for (let i = 0; i < 24; i++) { c.rotate(TAU / 24); c.fillStyle = 'rgba(255,240,180,0.3)'; c.fillRect(190, -1.5, 90 + (i % 3) * 30, 3); }
        c.restore(); break;
      }
      case 'planet': {
        const x = W * 0.78, y = H * 0.22, r = 54;
        drawGlow(c, x, y, r * 3, def.palette.glow, 0.35);
        const gr = c.createRadialGradient(x - r * 0.4, y - r * 0.4, 4, x, y, r); gr.addColorStop(0, shadeHex(def.palette.accent, 0.25)); gr.addColorStop(1, shadeHex(def.palette.primary, -0.55));
        c.fillStyle = gr; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); break;
      }
      case 'none': break;
    }
  }

  private drawStars(c: Ctx, p: Prepared, view: ViewState, wts: { day: number; dusk: number; night: number }): void {
    const def = p.def;
    const a = def.cycle === 'fixed' && def.fixedTod! > 0.6 ? 1 : clamp(wts.night * 1.2 + wts.dusk * 0.2, 0, 1);
    if (a < 0.02 || def.celestial === 'none' && def.id === 'inferno_realm') return;
    const W = view.W, H = view.H, s = p.stars, t = view.time;
    c.save();
    for (let i = 0; i < s.length / 3; i++) {
      const x = ((s[i * 3] * W * 1.3 - view.scroll * 0.01) % (W + 40) + W + 40) % (W + 40) - 20, y = s[i * 3 + 1] * H - view.camY * 0.03, r = s[i * 3 + 2];
      c.globalAlpha = a * (0.45 + 0.55 * Math.abs(Math.sin(t * (0.7 + (i % 5) * 0.3) + i)));
      c.fillStyle = '#ffffff'; c.fillRect(x, y, r, r);
    }
    c.restore();
  }

  private drawClouds(c: Ctx, p: Prepared, view: ViewState): void {
    const cd = p.def.clouds!, W = view.W, H = view.H, m = 160, range = W + m * 2;
    const dark = p.def.cycle === 'full' ? getDayWeights(view.tod).night : 0;
    for (let i = 0; i < cd.count; i++) {
      const spr = p.clouds[i % p.clouds.length], d = 0.4 + hash(i + 2) * 0.9, y0 = cd.y[0] + hash(i + 9) * (cd.y[1] - cd.y[0]);
      let x = hash(i * 3.7) * range - view.time * cd.speed * 40 * d - view.scroll * 0.045 * d; x = ((x % range) + range) % range - m;
      const sw = spr.w * d * 1.1, sh = spr.h * d * 1.1, y = y0 * H - view.camY * 0.06 * d - sh / 2;
      c.globalAlpha = clamp(0.55 + d * 0.4, 0, 1) * (1 - dark * 0.35);
      c.drawImage(spr.tex, x, y, sw, sh);
    }
    c.globalAlpha = 1;
  }

  private drawDecor(c: Ctx, def: WorldDef, view: ViewState, tod: number, wts: { day: number; dusk: number; night: number }, phase: 'back' | 'front'): void {
    const E: DecorEnv = { W: view.W, H: view.H, t: view.time, scroll: view.scroll, camY: view.camY, night: wts.night, day: wts.day, dusk: wts.dusk, def, reduced: view.reducedMotion, fixedDark: def.cycle === 'fixed' && tod > 0.6 };
    // 'back' decor sits behind the parallax layers (sky objects), 'front' decor floats in front of them
    const back = new Set(['ringed_planet', 'aurora', 'meteors', 'shooting_stars', 'floating_islands', 'rune_circle', 'portals_far', 'angels', 'whale', 'cubes', 'airships', 'holo_billboards']);
    for (const k of def.decor) {
      const fn = DECOR[k]; if (!fn) continue;
      if ((phase === 'back') !== back.has(k)) continue;
      c.save(); fn(c, E); c.restore();
    }
  }

  private drawRays(c: Ctx, p: Prepared, view: ViewState, tod: number, wts: { day: number; dusk: number; night: number }): void {
    const W = view.W, H = view.H, cel = getCelestial(tod);
    const sx = p.def.celestial === 'sunset' ? W * 0.68 : cel.sunX * W, sy = p.def.celestial === 'sunset' ? H * 0.52 : cel.sunY * H;
    c.save(); c.globalCompositeOperation = 'lighter';
    const a = 0.026 * clamp(wts.day + wts.dusk, 0, 1);
    for (let i = 0; i < 7; i++) {
      const ang = 0.9 + i * 0.22 + Math.sin(view.time * 0.12 + i) * 0.05;
      const len = H * 1.6, w0 = 20 + (i % 3) * 14, w1 = 120 + (i % 4) * 40;
      const x1 = sx + Math.cos(ang) * len, y1 = sy + Math.sin(ang) * len, nx = -Math.sin(ang), ny = Math.cos(ang);
      const gr = c.createLinearGradient(sx, sy, x1, y1); gr.addColorStop(0, rgba('#fff4c0', a * 1.6)); gr.addColorStop(1, rgba('#fff4c0', 0));
      c.fillStyle = gr; c.beginPath(); c.moveTo(sx + nx * w0, sy + ny * w0); c.lineTo(x1 + nx * w1, y1 + ny * w1); c.lineTo(x1 - nx * w1, y1 - ny * w1); c.lineTo(sx - nx * w0, sy - ny * w0); c.closePath(); c.fill();
    }
    c.restore();
  }
}

const DEFAULT_TUNING_H = 800;
void hexToRgb;

// ---------------------------------------------------------------- thumbnails (World Select cards etc.)
interface ThumbEntry { src: HTMLCanvasElement | null; pending: { c: HTMLCanvasElement }[]; queued: boolean }
const thumbs = new Map<string, ThumbEntry>();
const thumbQueue: string[] = [];
let thumbRenderer: WorldRenderer | null = null;
let thumbTimer = 0;

function bakeThumb(key: string): void {
  const [id, ws, hs] = key.split('|'); const w = +ws, h = +hs;
  const e = thumbs.get(key); if (!e) return;
  try {
    thumbRenderer ??= new WorldRenderer(QUALITY.medium);
    const VW = Math.round(800 * (w / h)), VH = 800;
    thumbRenderer.prepare(id, VW, VH, 1);
    const c = makeCanvas(w, h); const g = ctx2d(c); g.scale(w / VW, h / VH);
    const q = QUALITY.medium;
    const view: ViewState = { W: VW, H: VH, time: 3.3, scroll: 2400, camY: 0, tod: 0.22, intensity: 0.2, quality: { ...q, weather: 0, decor: true }, reducedMotion: true };
    thumbRenderer.drawBackground(g, id, view);
    thumbRenderer.drawForeground(g, id, view);
    thumbRenderer.drawLighting(g, id, view);
    thumbRenderer.release(id);
    e.src = c;
  } catch { e.src = null; }
  for (const p of e.pending) { const pg = p.c.getContext('2d'); if (pg && e.src) pg.drawImage(e.src, 0, 0, p.c.width, p.c.height); }
  e.pending.length = 0;
}
function pumpThumbs(): void {
  thumbTimer = 0;
  const k = thumbQueue.shift();
  if (k) bakeThumb(k);
  if (thumbQueue.length) thumbTimer = window.setTimeout(pumpThumbs, 16);
}

/** Returns a canvas that is filled with a rendered snapshot of the world as soon as it is baked (staggered to avoid frame spikes). */
export function getWorldThumbnail(worldId: string, w = 320, h = 180): HTMLCanvasElement {
  const key = `${worldId}|${w}|${h}`;
  const out = makeCanvas(w, h);
  const def = WORLD_BY_ID[worldId];
  const og = ctx2d(out);
  if (def) { const sc = skyColors(def, 0.22); const gr = og.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, sc[0]); gr.addColorStop(1, sc[2]); og.fillStyle = gr; og.fillRect(0, 0, w, h); }
  let e = thumbs.get(key);
  if (!e) { e = { src: null, pending: [], queued: false }; thumbs.set(key, e); }
  if (e.src) { og.drawImage(e.src, 0, 0, w, h); return out; }
  e.pending.push({ c: out });
  if (!e.queued) { e.queued = true; thumbQueue.push(key); if (!thumbTimer) thumbTimer = window.setTimeout(pumpThumbs, 30); }
  return out;
}
