// World select, character collection (360° preview) and the shop (skins / trails / effects / accessories / themes).
import { h, icon, clear } from '../dom';
import { Scr, header, tabs, price } from './common';
import type { AppApi } from '../../app/types';
import type { Screen } from '../UI';
import { tr, loc } from '../../core/i18n';
import { SKINS, SKIN_BY_ID, type SkinDef } from '../../data/skins';
import { WORLDS, WORLD_BY_ID } from '../../data/worlds';
import { ITEMS, TRAILS, PARTICLE_FX, THEMES, type CosmeticItemId, type Price } from '../../data/cosmetics';
import type { UnlockRule, ParticleKind, TrailKind } from '../../core/types';
import { drawSkinPreview } from '../../render/BirdRenderer';
import { getWorldThumbnail, skyColors } from '../../render/WorldRenderer';
import { Trail, ParticleManager } from '../../render/ParticleManager';
import { QUALITY } from '../../config/gameConfig';
import { drawBird } from '../../render/BirdRenderer';
import { idlePose } from '../../render/BirdRenderer';

export function ruleText(r: UnlockRule): string {
  switch (r.type) {
    case 'free': return tr('Miễn phí', 'Free');
    case 'coins': return `${r.price} ${tr('xu', 'coins')}`;
    case 'gems': return `${r.price} ${tr('ngọc', 'gems')}${r.minLevel ? ` · ${tr('cấp', 'lvl')} ${r.minLevel}` : ''}`;
    case 'level': return `${tr('Cấp', 'Level')} ${r.level}${r.price ? ` + ${r.price} ${tr('xu', 'coins')}` : ''}`;
    case 'achievement': case 'secret': return loc(r.hint);
  }
}
const asPrice = (r: UnlockRule): Price => (r.type === 'coins' ? { coins: r.price } : r.type === 'gems' ? { gems: r.price } : r.type === 'level' && r.price ? { coins: r.price } : {});

/** Interactive turntable preview: drag to rotate 360°, auto-spins when idle. */
export function turntable(scr: Scr, skin: SkinDef, o: { item?: CosmeticItemId | null; w?: number; h?: number } = {}): HTMLElement {
  const W = o.w ?? 520, H = o.h ?? 400, cv = h('canvas', { width: W, height: H });
  const g = cv.getContext('2d')!; let yaw = 0, drag = false, lastX = 0, vel = 0, raf = 0; const t0 = performance.now();
  const loop = (now: number): void => {
    const t = (now - t0) / 1000; if (!drag) { vel *= 0.95; yaw += vel + 0.012; } yaw %= Math.PI * 2;
    g.clearRect(0, 0, W, H); drawSkinPreview(g, skin, W / 2, H / 2, Math.min(W, H) * 0.62, t, { yaw, item: o.item ?? null, background: true, quality: QUALITY.high });
    raf = requestAnimationFrame(loop);
  };
  raf = requestAnimationFrame(loop); scr.on(() => cancelAnimationFrame(raf));
  const el = h('div', { class: 'preview', 'data-noflap': '1' }, cv, h('div', { class: 'hint' }, tr('Kéo để xoay 360°', 'Drag to rotate 360°')));
  el.addEventListener('pointerdown', (e) => { drag = true; lastX = e.clientX; vel = 0; el.setPointerCapture(e.pointerId); });
  el.addEventListener('pointermove', (e) => { if (!drag) return; const dx = (e.clientX - lastX) * 0.018; yaw += dx; vel = dx; lastX = e.clientX; });
  const up = (): void => { drag = false; }; el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
  return el;
}
function staticSkin(skin: SkinDef, item: CosmeticItemId | null = null): HTMLCanvasElement {
  const cv = h('canvas', { width: 320, height: 220 }); const g = cv.getContext('2d')!;
  drawSkinPreview(g, skin, 160, 112, 150, 1.25, { background: true, item, quality: QUALITY.high }); return cv;
}

// ---------------------------------------------------------------- worlds
export function worldsScreen(app: AppApi): Screen {
  const s = new Scr(), sv = app.save.data, content = h('div', { class: 'content' }), grid = h('div', { class: 'grid wide' });
  const build = (): void => {
    clear(grid);
    for (const w of WORLDS) {
      const owned = sv.unlockedWorlds.includes(w.id), sel = sv.selectedWorld === w.id, hidden = !!w.hidden && !owned;
      const chk = app.prog.canBuyWorld(w.id), canBuy = !owned && w.unlock.type !== 'secret' && w.unlock.type !== 'achievement';
      const thumb = hidden ? h('div', { style: 'aspect-ratio:16/9;border-radius:12px;background:#0a0a1e;display:grid;place-items:center;font-size:2rem' }, '?') : getWorldThumbnail(w.id, 400, 225);
      thumb.style.width = '100%'; thumb.style.borderRadius = '12px'; thumb.style.display = 'block';
      if (!owned && !hidden) thumb.style.filter = 'brightness(.6) saturate(.8)';
      const frame = h('div', { style: 'position:relative' }, thumb, !owned ? h('div', { style: 'position:absolute;top:.4rem;right:.4rem;background:rgba(6,10,36,.7);border-radius:50%;padding:.3rem;display:grid;place-items:center' }, icon('lock', 18)) : null);
      const card = h('div', { class: `card click${sel ? ' sel' : ''}`, on: { click: () => { if (owned) { if (app.prog.selectWorld(w.id)) { app.audio.sfx('equip'); build(); } } } } },
        frame,
        h('div', { class: 'row sb' }, h('h3', {}, hidden ? '???' : `${w.index}. ${w.name}`), sel ? h('span', { class: 'tag ok' }, tr('Đang chọn', 'Selected')) : owned ? h('span', { class: 'tag' }, tr('Đã mở', 'Unlocked')) : null),
        h('p', {}, hidden ? tr('Thế giới bí mật — hãy khám phá để mở khoá.', 'A secret world — explore to unlock it.') : loc(w.desc)));
      if (!owned) {
        card.appendChild(h('small', { class: 'muted', style: 'display:flex;gap:.3rem;align-items:center' }, icon('lock', 14), ruleText(w.unlock)));
        if (canBuy) card.appendChild(h('button', { class: `btn small gold${chk.ok ? '' : ' disabled'}`, on: { click: async (e: Event) => { e.stopPropagation(); await buyConfirm(app, loc({ vi: `Mở khoá ${w.name}?`, en: `Unlock ${w.name}?` }), asPrice(w.unlock), () => app.prog.buyWorld(w.id), () => { app.prog.selectWorld(w.id); build(); }); } } }, tr('Mở khoá', 'Unlock'), ' ', price(asPrice(w.unlock))));
      }
      grid.appendChild(card);
    }
  };
  build(); content.appendChild(grid);
  s.el.append(header(app, s, tr('Thế giới', 'Worlds'), () => app.open('menu')), content);
  return s;
}

/** Purchase confirmation modal → performs buy() → feedback. */
export async function buyConfirm(app: AppApi, title: string, p: Price, buy: () => { ok: boolean; reason?: string; need?: number | string }, after: () => void, preview?: HTMLElement): Promise<void> {
  const sv = app.save.data;
  const afford = (p.coins ?? 0) <= sv.coins && (p.gems ?? 0) <= sv.gems;
  const body = h('div', { class: 'col' }, preview ?? null, h('div', { class: 'row', style: 'justify-content:center;font-size:1.3rem' }, price(p)),
    h('div', { class: 'muted center', style: 'font-size:.85rem' }, `${tr('Bạn có', 'You have')}: ${sv.coins} ${tr('xu', 'coins')} · ${sv.gems} ${tr('ngọc', 'gems')}`),
    afford ? null : h('div', { class: 'notice' }, icon('info', 18), tr('Chưa đủ tiền. Hãy chơi thêm hoặc hoàn thành nhiệm vụ để kiếm xu & ngọc!', 'Not enough funds. Play more or finish missions to earn coins & gems!')));
  const ok = await app.ui.confirm({ title, body, ok: tr('Mua', 'Buy'), cancel: tr('Huỷ', 'Cancel') });
  if (!ok) return;
  const r = buy();
  if (r.ok) { app.audio.sfx('purchase'); app.ui.toast(tr('Mua thành công!', 'Purchase complete!'), 'ok', 2200, 'check'); app.save.flush(); after(); }
  else { app.audio.sfx('error'); app.ui.toast(r.reason === 'funds' ? tr('Không đủ tiền', 'Not enough funds') : r.reason === 'level' ? `${tr('Cần cấp', 'Requires level')} ${r.need}` : tr('Không thể mua', 'Cannot buy'), 'err'); }
}

// ---------------------------------------------------------------- collection
export function collectionScreen(app: AppApi): Screen {
  const s = new Scr(), sv = app.save.data, content = h('div', { class: 'content' }), grid = h('div', { class: 'grid' });
  const owned = (): number => SKINS.filter((k) => sv.unlockedSkins.includes(k.id)).length;
  const count = h('span', { class: 'chip' }, '');
  const build = (): void => {
    clear(grid); count.textContent = `${owned()}/${SKINS.length}`;
    for (const k of SKINS) {
      const have = sv.unlockedSkins.includes(k.id), eq = sv.equippedSkin === k.id, secret = k.tier === 'secret' && !have;
      const card = h('button', { class: `card${eq ? ' sel' : ''}`, on: { click: () => openDetail(k) } }, secret ? h('canvas', { width: 320, height: 220, style: 'filter:brightness(0) opacity(.35)' }) : staticSkin(k, have ? (sv.equipped.item as CosmeticItemId | null) : null),
        h('div', { class: 'row sb' }, h('h3', {}, secret ? '???' : k.name), h('span', { class: `tag ${k.tier === 'secret' ? 'secret' : k.tier === 'premium' ? 'epic' : 'common'}` }, k.tier === 'secret' ? tr('Bí mật', 'Secret') : k.tier === 'premium' ? 'Premium' : 'Standard')),
        h('p', {}, secret ? tr('Bí mật chưa được khám phá.', 'An undiscovered secret.') : eq ? tr('Đang trang bị', 'Equipped') : have ? tr('Đã sở hữu', 'Owned') : ruleText(k.unlock)));
      if (secret) { const cv = card.querySelector('canvas'); if (cv) { const g = (cv as HTMLCanvasElement).getContext('2d')!; drawSkinPreview(g, k, 160, 112, 150, 1.2, {}); } }
      if (!have && !secret) { const cv0 = card.querySelector('canvas'); if (cv0) (cv0 as HTMLCanvasElement).style.filter = 'brightness(.75) saturate(.85)'; card.appendChild(h('div', { style: 'position:absolute;top:1rem;right:1rem;background:rgba(6,10,36,.7);border-radius:50%;padding:.3rem;display:grid;place-items:center' }, icon('lock', 16))); }
      grid.appendChild(card);
    }
  };
  const openDetail = (k: SkinDef): void => {
    const have = sv.unlockedSkins.includes(k.id), secret = k.tier === 'secret' && !have, ds = new Scr();
    const body: HTMLElement[] = [];
    if (secret) { body.push(h('h2', {}, '???'), h('div', { class: 'notice' }, icon('lock', 18), k.unlock.type === 'secret' || k.unlock.type === 'achievement' ? loc(k.unlock.hint) : '')); }
    else {
      const info = (a: string, b: string): HTMLElement => h('div', { class: 'row sb' }, h('span', { class: 'muted' }, a), h('b', {}, b));
      body.push(h('h2', {}, k.name), turntable(ds, k, { item: have ? (sv.equipped.item as CosmeticItemId | null) : null }), h('p', {}, loc(k.desc)),
        h('div', { class: 'list' }, info(tr('Cánh', 'Wings'), k.wing), info(tr('Đuôi', 'Tail'), k.tail), info(tr('Vệt bay', 'Trail'), k.trail), info(tr('Hạt', 'Particles'), k.particle), info(tr('Hiệu ứng kỹ năng', 'Skill FX'), k.fx), info(tr('Mở khoá', 'Unlock'), have ? tr('Đã sở hữu', 'Owned') : ruleText(k.unlock))));
      if (have) body.push(h('button', { class: 'btn', on: { click: () => { app.prog.equipSkin(k.id); app.audio.sfx('equip'); app.ui.toast(`${tr('Đã trang bị', 'Equipped')} ${k.name}`, 'ok', 1800); close(); build(); } } }, icon('check', 20), tr('Trang bị', 'Equip')));
      else if (k.unlock.type !== 'achievement' && k.unlock.type !== 'secret') body.push(h('button', { class: 'btn gold', on: { click: () => { close(); void buyConfirm(app, `${tr('Mở khoá', 'Unlock')} ${k.name}?`, asPrice(k.unlock), () => app.prog.buySkin(k.id), build, staticSkin(k)); } } }, tr('Mở khoá', 'Unlock'), ' ', price(asPrice(k.unlock))));
    }
    const close = app.ui.modal(body, () => ds.destroy());
  };
  build(); content.appendChild(grid);
  s.el.append(header(app, s, tr('Bộ sưu tập nhân vật', 'Character collection'), () => app.open('menu'), count), content);
  return s;
}

// ---------------------------------------------------------------- shop
type ShopTab = 'skins' | 'trails' | 'fx' | 'items' | 'themes';
let lastTab: ShopTab = 'skins';
export function shopScreen(app: AppApi): Screen {
  const s = new Scr(), sv = app.save.data, content = h('div', { class: 'content' });
  let tab: ShopTab = lastTab;
  const skin = (): SkinDef => SKIN_BY_ID[sv.equippedSkin] ?? SKINS[0];
  const trailSample = (kind: TrailKind): HTMLCanvasElement => {
    const cv = h('canvas', { width: 320, height: 130 }), g = cv.getContext('2d')!, tr0 = new Trail(); tr0.maxPts = 40;
    for (let i = 0; i < 60; i++) tr0.update(0.016, 230, 70 + Math.sin(i * 0.22) * 22, 330, true);
    tr0.draw(g, kind, skin(), 1.1, QUALITY.high); const p = idlePose(1); p.x = 244; p.y = 70 + Math.sin(60 * 0.22) * 22; p.state = 'flying'; p.scale = 0.9; drawBird(g, skin(), p, { quality: QUALITY.high }); return cv;
  };
  const fxSample = (kind: ParticleKind): HTMLCanvasElement => {
    const cv = h('canvas', { width: 320, height: 130 }), g = cv.getContext('2d')!, pm = new ParticleManager(QUALITY.high), sk = skin();
    for (let i = 0; i < 26; i++) pm.spawn(kind, 40 + i * 9, 30 + ((i * 37) % 70), -30, 10, 1.6 + (i % 5) * 0.2, 9, [sk.colors.glow, sk.colors.wing2, sk.colors.accent][i % 3], { rot: i, shrink: false });
    pm.update(0.3, 0); pm.draw(g); return cv;
  };
  const itemSample = (id: CosmeticItemId): HTMLCanvasElement => staticSkin(skin(), id);
  const themeSample = (id: string): HTMLCanvasElement => {
    const cv = h('canvas', { width: 320, height: 130 }), g = cv.getContext('2d')!, th = THEMES.find((t) => t.id === id)!, c = skyColors(WORLD_BY_ID.emerald_valley, 0.22);
    const gr = g.createLinearGradient(0, 0, 0, 130); gr.addColorStop(0, c[0]); gr.addColorStop(1, c[2]); g.fillStyle = gr; g.fillRect(0, 0, 320, 130);
    g.fillStyle = '#2c9a58'; g.beginPath(); g.moveTo(0, 130); g.quadraticCurveTo(80, 50, 160, 95); g.quadraticCurveTo(240, 130, 320, 70); g.lineTo(320, 130); g.fill();
    if (th.tint) { g.globalCompositeOperation = th.tint.mode; g.globalAlpha = Math.min(1, th.tint.alpha * 2.2); g.fillStyle = th.tint.color; g.fillRect(0, 0, 320, 130); g.globalAlpha = 1; g.globalCompositeOperation = 'source-over'; }
    const v = g.createRadialGradient(160, 65, 40, 160, 65, 200); v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, `rgba(0,0,0,${th.vignette * 1.4})`); g.fillStyle = v; g.fillRect(0, 0, 320, 130); return cv;
  };
  const productCard = (name: string, sample: HTMLElement, owned: boolean, equipped: boolean, pr: Price, onBuy: () => void, onEquip: () => void, onUnequip?: () => void): HTMLElement =>
    h('div', { class: `card${equipped ? ' sel' : ''}` }, sample, h('div', { class: 'row sb' }, h('h3', {}, name), equipped ? h('span', { class: 'tag ok' }, tr('Đang dùng', 'Equipped')) : owned ? h('span', { class: 'tag' }, tr('Đã sở hữu', 'Owned')) : null),
      owned ? (equipped ? (onUnequip ? h('button', { class: 'btn ghost small', on: { click: onUnequip } }, tr('Bỏ trang bị', 'Unequip')) : h('span', { class: 'muted' }, tr('Đang dùng', 'In use'))) : h('button', { class: 'btn small', on: { click: onEquip } }, tr('Trang bị', 'Equip')))
        : h('button', { class: 'btn small gold', on: { click: onBuy } }, tr('Mua', 'Buy'), ' ', price(pr)));
  const build = (): void => {
    const top = content.scrollTop; clear(content); const grid = h('div', { class: 'grid' }); lastTab = tab;
    if (tab === 'skins') {
      for (const k of SKINS) {
        const have = sv.unlockedSkins.includes(k.id), eq = sv.equippedSkin === k.id, buyable = k.unlock.type !== 'achievement' && k.unlock.type !== 'secret' && k.unlock.type !== 'free';
        const secret = k.tier === 'secret' && !have;
        if (secret) continue;
        const card = h('div', { class: `card${eq ? ' sel' : ''}` }, h('div', { class: 'click', on: { click: () => { const ds = new Scr(); const c = app.ui.modal([h('h2', {}, k.name), turntable(ds, k), h('button', { class: 'btn ghost', on: { click: () => c() } }, tr('Đóng', 'Close'))], () => ds.destroy()); } } }, staticSkin(k)),
          h('div', { class: 'row sb' }, h('h3', {}, k.name), eq ? h('span', { class: 'tag ok' }, tr('Đang dùng', 'Equipped')) : have ? h('span', { class: 'tag' }, tr('Đã sở hữu', 'Owned')) : null),
          have ? (eq ? h('span', { class: 'muted' }, tr('Đang dùng', 'In use')) : h('button', { class: 'btn small', on: { click: () => { app.prog.equipSkin(k.id); app.audio.sfx('equip'); build(); } } }, tr('Trang bị', 'Equip')))
            : buyable ? h('button', { class: 'btn small gold', on: { click: () => { const chk = app.prog.canBuySkin(k.id); if (!chk.ok && chk.reason === 'level') { app.audio.sfx('error'); app.ui.toast(`${tr('Cần cấp', 'Requires level')} ${chk.need}`, 'err'); return; } void buyConfirm(app, `${tr('Mua', 'Buy')} ${k.name}?`, asPrice(k.unlock), () => app.prog.buySkin(k.id), build, staticSkin(k)); } } }, tr('Mở khoá', 'Unlock'), ' ', price(asPrice(k.unlock)))
              : h('span', { class: 'muted' }, ruleText(k.unlock)));
        grid.appendChild(card);
      }
    } else if (tab === 'trails') {
      for (const t of TRAILS) grid.appendChild(productCard(loc(t.name), trailSample(t.id), sv.ownedTrails.includes(t.id), sv.equipped.trail === t.id, t.price, () => void buyConfirm(app, `${tr('Mua', 'Buy')} ${loc(t.name)}?`, t.price, () => app.prog.buyCosmetic('trail', t.id), build, trailSample(t.id)), () => { app.prog.equipCosmetic('trail', t.id); app.audio.sfx('equip'); build(); }, () => { app.prog.equipCosmetic('trail', null); build(); }));
    } else if (tab === 'fx') {
      for (const t of PARTICLE_FX) grid.appendChild(productCard(loc(t.name), fxSample(t.id), sv.ownedFx.includes(t.id), sv.equipped.fx === t.id, t.price, () => void buyConfirm(app, `${tr('Mua', 'Buy')} ${loc(t.name)}?`, t.price, () => app.prog.buyCosmetic('fx', t.id), build, fxSample(t.id)), () => { app.prog.equipCosmetic('fx', t.id); app.audio.sfx('equip'); build(); }, () => { app.prog.equipCosmetic('fx', null); build(); }));
    } else if (tab === 'items') {
      for (const t of ITEMS) grid.appendChild(productCard(loc(t.name), itemSample(t.id), sv.ownedItems.includes(t.id), sv.equipped.item === t.id, t.price, () => void buyConfirm(app, `${tr('Mua', 'Buy')} ${loc(t.name)}?`, t.price, () => app.prog.buyCosmetic('item', t.id), build, itemSample(t.id)), () => { app.prog.equipCosmetic('item', t.id); app.audio.sfx('equip'); build(); }, () => { app.prog.equipCosmetic('item', null); build(); }));
    } else {
      for (const t of THEMES) grid.appendChild(productCard(loc(t.name), themeSample(t.id), sv.ownedThemes.includes(t.id), sv.equipped.theme === t.id, t.price, () => void buyConfirm(app, `${tr('Mua', 'Buy')} ${loc(t.name)}?`, t.price, () => app.prog.buyCosmetic('theme', t.id), build, themeSample(t.id)), () => { app.prog.equipCosmetic('theme', t.id); app.audio.sfx('equip'); build(); }));
    }
    content.append(tabs([{ id: 'skins', label: tr('Nhân vật', 'Skins') }, { id: 'trails', label: tr('Vệt bay', 'Trails') }, { id: 'fx', label: tr('Hạt', 'Particles') }, { id: 'items', label: tr('Phụ kiện', 'Accessories') }, { id: 'themes', label: tr('Giao diện', 'Themes') }], tab, (id) => { tab = id as ShopTab; app.audio.sfx('tab'); build(); }), grid);
    content.scrollTop = top;
  };
  build();
  s.el.append(header(app, s, tr('Cửa hàng', 'Shop'), () => app.open('menu')), content);
  return s;
}
