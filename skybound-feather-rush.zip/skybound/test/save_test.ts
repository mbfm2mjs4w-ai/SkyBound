import { SaveManager, defaultSave, validateSave, type KV } from '../src/systems/SaveManager';
import { ProgressionManager, xpToNext } from '../src/systems/ProgressionManager';
import { SAVE_KEY, BACKUP_KEY } from '../src/config/gameConfig';
import type { RunResult } from '../src/core/GameSession';
import { SKINS } from '../src/data/skins';
import { WORLDS } from '../src/data/worlds';
import { ADVENTURE_LEVELS } from '../src/data/modes';
import { ACHIEVEMENTS } from '../src/data/achievements';

let failures = 0;
const ok = (c: boolean, m: string): void => { if (!c) { failures++; console.log('  FAIL: ' + m); } else console.log('  ok: ' + m); };

class MemKV implements KV {
  m = new Map<string, string>();
  getItem(k: string): string | null { return this.m.get(k) ?? null; }
  setItem(k: string, v: string): void { this.m.set(k, v); }
  removeItem(k: string): void { this.m.delete(k); }
}
const run = (o: Partial<RunResult> = {}): RunResult => ({ mode: 'endless', score: 12, coins: 20, gems: 0, distance: 150, time: 40, gates: 12, maxCombo: 4, perfects: 5, powerups: 2, bossesDefeated: 0, stars: 0, completed: false, newRecord: false, worldId: 'emerald_valley', secretFound: false, flaps: 90, hits: 0, worldsVisited: 1, ...o });

console.log('1) Fresh save → persists → reloads identically');
{
  const kv = new MemKV(); const a = new SaveManager(kv); const p = new ProgressionManager(a);
  const sum = p.processRun(run());
  a.flush();
  const b = new SaveManager(kv);
  ok(b.loadedFrom === 'primary' && b.data.stats.games === 1 && b.data.best.endless === 12, `reloaded: games=${b.data.stats.games}, best=${b.data.best.endless}`);
  ok(sum.xpGained > 0 && b.data.coins >= 150 + 20, `xp ${sum.xpGained}, coins ${b.data.coins}`);
}
console.log('2) Corrupt primary → backup restores; corrupt both → rescue copy kept, fresh game');
{
  const kv = new MemKV(); const a = new SaveManager(kv); const p = new ProgressionManager(a);
  p.processRun(run({ score: 30 })); a.flush();
  p.processRun(run({ score: 31 })); a.flush();           // rotates previous into backup
  kv.setItem(SAVE_KEY, '{"broken json');
  const b = new SaveManager(kv);
  ok(b.loadedFrom === 'backup' && b.data.stats.games >= 1, `restored from backup (games=${b.data.stats.games}), error flag=${b.error}`);
  kv.setItem(SAVE_KEY, 'garbage'); kv.setItem(BACKUP_KEY, 'also garbage');
  const c = new SaveManager(kv);
  ok(c.loadedFrom === 'fresh' && kv.getItem(SAVE_KEY + '.corrupt') === 'garbage', 'both corrupt: fresh game, original payload rescued under .corrupt key');
}
console.log('3) A blank save never overwrites real progress');
{
  const kv = new MemKV(); const a = new SaveManager(kv); const p = new ProgressionManager(a);
  for (let i = 0; i < 5; i++) p.processRun(run({ score: 20 + i })); a.flush();
  const before = kv.getItem(SAVE_KEY);
  const rogue = new SaveManager(kv); rogue.data = defaultSave(); rogue.touch(); const wrote = rogue.flush();
  ok(!wrote && kv.getItem(SAVE_KEY) === before, 'blank overwrite refused, stored progress intact');
  rogue.reset();
  ok(kv.getItem(BACKUP_KEY) === before, 'explicit reset keeps the previous save as backup');
}
console.log('4) Validation: garbage fields are repaired, unknown ids dropped, numbers clamped');
{
  const v = validateSave({ version: 3, coins: -50, gems: 'x', xp: 1e99, level: 9999, unlockedSkins: ['nope', 'ice_crystal', 'ice_crystal'], equippedSkin: 'zzz', unlockedWorlds: ['frozen_empire', 'bad'], selectedWorld: 'bad', settings: { master: 7, lang: 'fr', quality: 'x' }, stats: { games: 'a' }, best: { classic: 99999999 } })!;
  ok(v.coins === 0 && v.gems === 5 && v.level === 200 && v.xp <= 1e10, `numbers sanitised (coins=${v.coins}, gems=${v.gems}, level=${v.level})`);
  ok(v.unlockedSkins.includes('sakura_bird') && v.unlockedSkins.includes('ice_crystal') && v.unlockedSkins.length === 2 && v.equippedSkin === 'sakura_bird', `skins repaired: ${v.unlockedSkins.join(',')}`);
  ok(v.selectedWorld === 'emerald_valley' && v.unlockedWorlds.includes('frozen_empire') && !v.unlockedWorlds.includes('bad' as never), 'worlds repaired');
  ok(v.settings.master === 1 && v.settings.lang === 'vi' && v.settings.quality === 'auto' && v.stats.games === 0 && v.best.classic === 1e6, 'settings / stats / best clamped');
  ok(validateSave('x') === null && validateSave(null) === null && validateSave([]) === null, 'non-objects rejected');
}
console.log('5) Version migration: v1 and v2 saves load into v3');
{
  const v1 = validateSave({ version: 1, skins: ['ice_crystal'], bestScore: 42, coins: 500 })!;
  ok(v1.version === 3 && v1.unlockedSkins.includes('ice_crystal') && v1.best.classic === 42 && v1.coins === 500, 'v1 → v3 (skins, bestScore, coins kept)');
  const v2 = validateSave({ version: 2, volume: 0.3, stats: { totalGames: 17 } })!;
  ok(v2.version === 3 && v2.settings.master === 0.3 && v2.stats.games === 17, 'v2 → v3 (volume, totalGames mapped)');
}
console.log('6) Levels, missions, achievements');
{
  const kv = new MemKV(); const sm = new SaveManager(kv); const p = new ProgressionManager(sm);
  ok(sm.data.missions.daily.length === 3 && sm.data.missions.weekly.length === 3, '3 daily + 3 weekly missions rolled');
  const ups = p.addXp(5000);
  ok(sm.data.level > 5 && ups.length === sm.data.level - 1, `5000 xp → level ${sm.data.level} (${ups.length} level-ups, xpToNext(1)=${xpToNext(1)})`);
  const sum = p.processRun(run({ score: 52, coins: 80, gates: 52, perfects: 30, maxCombo: 12, distance: 700 }));
  const ids = sum.achievements.map((a) => a.id);
  ok(ids.includes('first_flight') && ids.includes('score_10') && ids.includes('score_50') && ids.includes('combo_10'), `achievements unlocked: ${ids.join(', ')}`);
  ok(sm.data.coins > 150 + 80, 'achievement rewards paid');
  const again = p.processRun(run({ score: 52 }));
  ok(!again.achievements.some((a) => a.id === 'score_50'), 'achievements unlock only once');
  // mission completion + claim
  const m = sm.data.missions.daily[0];
  m.progress = m.target; const coins0 = sm.data.coins;
  const reward = p.claimMission(m.id);
  ok(!!reward && sm.data.coins >= coins0 + reward.coins && m.claimed && p.claimMission(m.id) === null, 'mission claimed once, reward paid, second claim refused');
  ok(sm.data.secrets.score_60 !== true && sm.data.unlockedWorlds.length === 1, 'score 52 does not unlock secrets');
  p.processRun(run({ score: 61 }));
  ok(sm.data.secrets.score_60 === true && sm.data.unlockedWorlds.includes('dark_dimension'), 'score ≥ 60 unlocks the hidden Dark Dimension world');
}
console.log('7) Shop: buy / equip / insufficient funds / level gate / secrets locked');
{
  const kv = new MemKV(); const sm = new SaveManager(kv); const p = new ProgressionManager(sm);
  sm.data.coins = 700; sm.data.gems = 10;
  let r = p.buySkin('ice_crystal');
  ok(r.ok && sm.data.coins === 100 && sm.data.unlockedSkins.includes('ice_crystal'), 'ice_crystal bought for 600 coins');
  ok(!p.buySkin('ice_crystal').ok, 'double purchase refused');
  r = p.buySkin('golden_phoenix'); ok(!r.ok && r.reason === 'funds' && sm.data.gems === 10, 'golden phoenix (120 gems) refused, gems untouched');
  r = p.buySkin('rainbow_legend'); ok(!r.ok, 'rainbow legend needs level 20 + 250 gems');
  r = p.buySkin('shadow_raven'); ok(!r.ok && r.reason === 'locked', 'secret skin cannot be bought');
  ok(p.equipSkin('ice_crystal') && sm.data.equippedSkin === 'ice_crystal' && !p.equipSkin('storm_eagle'), 'equip works only for owned skins');
  r = p.buyWorld('sunset_kingdom'); ok(!r.ok && r.reason === 'funds', 'world needs 300 coins (have 100)');
  sm.data.coins = 5000; r = p.buyWorld('frozen_empire'); ok(!r.ok && r.reason === 'level', 'Frozen Empire gated by level 3');
  sm.data.level = 3; r = p.buyWorld('frozen_empire'); ok(r.ok && sm.data.unlockedWorlds.includes('frozen_empire'), 'Frozen Empire bought at level 3');
  r = p.buyCosmetic('trail', 'flame'); ok(r.ok && p.equipCosmetic('trail', 'flame') && sm.data.equipped.trail === 'flame', 'trail bought + equipped');
  ok(!p.equipCosmetic('fx', 'rune'), 'cannot equip unowned particle effect');
}
console.log('8) Adventure progression, chapter world unlock, Ancient Dragon from full completion');
{
  const kv = new MemKV(); const sm = new SaveManager(kv); const p = new ProgressionManager(sm);
  ok(p.adventureUnlocked(0) && !p.adventureUnlocked(1), 'only level 1 open at start');
  p.processRun(run({ mode: 'adventure', adventureId: ADVENTURE_LEVELS[0].id, completed: true, stars: 2, score: 10, worldId: 'emerald_valley' }));
  ok(p.adventureUnlocked(1) && sm.data.adventure[ADVENTURE_LEVELS[0].id].stars === 2, 'level 1 done → level 2 open, 2 stars stored');
  for (const l of ADVENTURE_LEVELS) p.processRun(run({ mode: 'adventure', adventureId: l.id, completed: true, stars: 3, score: l.goal, worldId: l.worldId }));
  ok(!!sm.data.achievements.adventure_complete && !!sm.data.achievements.three_stars, 'adventure_complete + three_stars achievements');
  ok(sm.data.unlockedSkins.includes('ancient_dragon'), 'Ancient Dragon unlocked by completing Adventure');
  ok(sm.data.unlockedWorlds.includes('celestial_kingdom'), 'chapter completion unlocks its world for free play');
}
console.log('9) Collection secrets: all 19 skins → Ultimate Celestial; hardcore 100 → Cosmic Emperor; portal → Shadow Raven');
{
  const kv = new MemKV(); const sm = new SaveManager(kv); const p = new ProgressionManager(sm);
  p.processRun(run({ mode: 'hardcore', score: 101 }));
  ok(sm.data.unlockedSkins.includes('cosmic_emperor'), 'hardcore 100 → cosmic_emperor');
  p.processRun(run({ secretFound: true }));
  ok(sm.data.unlockedSkins.includes('shadow_raven') && !!sm.data.achievements.secret_portal, 'secret portal → shadow_raven + legendary achievement');
  for (const k of SKINS) if (k.id !== 'ultimate_celestial' && !sm.data.unlockedSkins.includes(k.id)) sm.data.unlockedSkins.push(k.id);
  p.syncUnlocks();
  ok(sm.data.unlockedSkins.includes('ultimate_celestial') && sm.data.unlockedSkins.length === SKINS.length, `all ${SKINS.length} skins owned`);
}
console.log('10) Data integrity');
{
  ok(SKINS.length >= 20, `${SKINS.length} skins`);
  ok(new Set(SKINS.map((s) => s.id)).size === SKINS.length, 'unique skin ids');
  ok(WORLDS.length === 12, `${WORLDS.length} worlds`);
  ok(new Set(SKINS.map((s) => s.colors.body + s.colors.wing + s.wing + s.tail + s.crest)).size === SKINS.length, 'every skin has a distinct look signature');
  ok(new Set(SKINS.map((s) => s.trail + '|' + s.particle + '|' + s.fx)).size >= 14, 'skins have varied trails / particles / bursts');
  ok(ACHIEVEMENTS.length >= 35 && new Set(ACHIEVEMENTS.map((a) => a.id)).size === ACHIEVEMENTS.length, `${ACHIEVEMENTS.length} achievements, unique ids`);
  const secretSkins = SKINS.filter((s) => s.unlock.type === 'secret' || s.unlock.type === 'achievement');
  ok(secretSkins.every((s) => 'hint' in s.unlock), 'every secret skin states its unlock condition');
}
console.log(failures ? `\n${failures} FAILURES` : '\nSAVE/PROGRESSION OK');
if (failures) process.exit(1);
