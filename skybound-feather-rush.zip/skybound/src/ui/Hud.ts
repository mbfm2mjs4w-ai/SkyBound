// In-game HUD (DOM overlay): score, best, coins, gems, power-up chips, progress bar, combo, banners, boss HP, hearts, timer.
import { h, icon, clear } from './dom';
import { POWERUPS } from '../data/powerups';
import type { PowerUpType } from '../core/types';
import { tr, loc } from '../core/i18n';
import { formatNumber } from '../core/util';
import type { ActivePowerUp } from '../entities/PowerUp';

export class Hud {
  readonly root: HTMLElement;
  private score = h('div', { class: 'hud-score' }, '0');
  private best = h('span', {}, '0');
  private coins = h('span', {}, '0');
  private gems = h('span', {}, '0');
  private combo = h('div', { class: 'hud-combo' });
  private sub = h('div', { class: 'hud-sub' });
  private bar = h('i');
  private barWrap = h('div', { class: 'hud-progress' }, this.bar);
  private powers = h('div', { class: 'hud-powers' });
  private lives = h('div', { class: 'hud-lives' });
  private banner = h('div', { class: 'hud-banner' });
  private bossName = h('div', { class: 'boss-name' });
  private bossFill = h('i');
  private boss = h('div', { class: 'hud-boss' }, this.bossName, h('div', { class: 'boss-bar' }, this.bossFill));
  private ready = h('div', { class: 'hud-ready' });
  private timer = h('div', { class: 'hud-timer' });
  private fpsEl = h('div', { class: 'hud-fps' });
  private pauseBtn: HTMLButtonElement;
  private lastScore = -1; private lastPowers = ''; private bannerT = 0; private lastCombo = -1;

  constructor(parent: HTMLElement, onPause: () => void) {
    this.pauseBtn = h('button', { class: 'hud-pause glass-btn', 'aria-label': 'Pause', 'data-noflap': '1', on: { click: (e) => { e.stopPropagation(); onPause(); } } }, icon('pause', 22));
    this.root = h('div', { class: 'hud' },
      h('div', { class: 'hud-top' },
        h('div', { class: 'hud-left glass' }, h('div', { class: 'chip' }, icon('coin', 18), this.coins), h('div', { class: 'chip' }, icon('gem', 18), this.gems), h('div', { class: 'chip dim' }, icon('trophy', 16), this.best)),
        h('div', { class: 'hud-center' }, this.score, this.combo, this.sub, this.barWrap, this.powers),
        h('div', { class: 'hud-right' }, this.pauseBtn, this.lives)),
      this.timer, this.boss, this.banner, this.ready, this.fpsEl);
    parent.appendChild(this.root);
  }
  setScore(n: number, pop = true): void {
    if (n === this.lastScore) return; this.lastScore = n; this.score.textContent = formatNumber(n);
    if (pop) { this.score.classList.remove('pop'); void this.score.offsetWidth; this.score.classList.add('pop'); }
  }
  setBest(n: number): void { this.best.textContent = formatNumber(n); }
  setCoins(n: number): void { this.coins.textContent = formatNumber(n); }
  setGems(n: number): void { this.gems.textContent = formatNumber(n); }
  setCombo(n: number): void {
    if (n === this.lastCombo) return; this.lastCombo = n;
    if (n >= 2) { this.combo.textContent = `${tr('COMBO', 'COMBO')} x${n}`; this.combo.classList.remove('pop'); void this.combo.offsetWidth; this.combo.classList.add('pop', 'on'); } else this.combo.classList.remove('on');
  }
  setSub(text: string): void { this.sub.textContent = text; }
  setProgress(frac: number | null, kind: string): void {
    if (frac === null) { this.barWrap.style.display = 'none'; return; }
    this.barWrap.style.display = ''; this.barWrap.dataset.kind = kind; this.bar.style.width = `${Math.round(frac * 1000) / 10}%`;
  }
  setPowers(active: ActivePowerUp[], shield: boolean, phoenix: boolean): void {
    const key = active.map((a) => `${a.type}:${Math.ceil(a.remaining * 4)}`).join(',') + (shield ? 'S' : '') + (phoenix ? 'P' : '');
    if (key === this.lastPowers) return; this.lastPowers = key;
    clear(this.powers);
    const chip = (t: PowerUpType, frac: number | null): HTMLElement => {
      const d = POWERUPS[t];
      return h('div', { class: 'pchip', title: loc(d.name), style: `--c:${d.color}` }, h('span', { class: 'pdot' }), h('span', {}, loc(d.name)), frac !== null ? h('i', { style: `width:${Math.round(frac * 100)}%` }) : null);
    };
    if (shield) this.powers.appendChild(chip('shield', null));
    if (phoenix) this.powers.appendChild(chip('phoenix', null));
    for (const a of active) this.powers.appendChild(chip(a.type, a.remaining / Math.max(0.01, a.total)));
  }
  setLives(n: number, max: number): void {
    clear(this.lives); if (max <= 1) return;
    for (let i = 0; i < max; i++) this.lives.appendChild(h('span', { class: i < n ? 'heart on' : 'heart' }, icon('heart', 22)));
  }
  setTime(sec: number | null): void { if (sec === null) { this.timer.style.display = 'none'; return; } this.timer.style.display = ''; this.timer.textContent = `${Math.ceil(sec)}s`; this.timer.classList.toggle('low', sec <= 10); }
  showBoss(name: string | null, frac = 1): void {
    if (!name) { this.boss.classList.remove('on'); return; }
    this.boss.classList.add('on'); this.bossName.textContent = name; this.bossFill.style.width = `${Math.round(frac * 100)}%`;
  }
  say(text: string, sub = '', kind = ''): void {
    clear(this.banner); this.banner.appendChild(h('div', { class: `bn ${kind}` }, h('b', {}, text), sub ? h('small', {}, sub) : null));
    this.banner.classList.remove('show'); void this.banner.offsetWidth; this.banner.classList.add('show'); this.bannerT = 2.2;
  }
  setReady(text: string | null, sub = ''): void {
    if (!text) { this.ready.classList.remove('on'); return; }
    clear(this.ready); this.ready.appendChild(h('div', { class: 'tap' }, h('div', { class: 'tap-ring' }), h('b', {}, text), sub ? h('small', {}, sub) : null)); this.ready.classList.add('on');
  }
  setFps(n: number | null): void { this.fpsEl.textContent = n === null ? '' : `${n} FPS`; }
  update(dt: number): void { if (this.bannerT > 0) { this.bannerT -= dt; if (this.bannerT <= 0) this.banner.classList.remove('show'); } }
  setVisible(v: boolean): void { this.root.style.display = v ? '' : 'none'; }
  destroy(): void { this.root.remove(); }
}
