import type { L10n, ParticleKind, TrailKind } from '../core/types';

export type CosmeticSlot = 'head' | 'face' | 'neck';
export type CosmeticItemId = 'sunglasses' | 'crown' | 'halo' | 'scarf' | 'wizard_hat' | 'headphones';
export interface Price { coins?: number; gems?: number }

export interface CosmeticItem { id: CosmeticItemId; slot: CosmeticSlot; name: L10n; price: Price }
export const ITEMS: CosmeticItem[] = [
  { id: 'sunglasses', slot: 'face', name: { vi: 'Kính Râm', en: 'Sunglasses' }, price: { coins: 400 } },
  { id: 'scarf', slot: 'neck', name: { vi: 'Khăn Quàng', en: 'Scarf' }, price: { coins: 300 } },
  { id: 'headphones', slot: 'head', name: { vi: 'Tai Nghe', en: 'Headphones' }, price: { coins: 500 } },
  { id: 'wizard_hat', slot: 'head', name: { vi: 'Mũ Phù Thủy', en: 'Wizard Hat' }, price: { coins: 700 } },
  { id: 'halo', slot: 'head', name: { vi: 'Vầng Hào Quang', en: 'Halo' }, price: { gems: 25 } },
  { id: 'crown', slot: 'head', name: { vi: 'Vương Miện', en: 'Crown' }, price: { gems: 40 } },
];

export interface TrailItem { id: TrailKind; name: L10n; price: Price }
export const TRAILS: TrailItem[] = [
  { id: 'ribbon', name: { vi: 'Dải Lụa', en: 'Silk Ribbon' }, price: { coins: 400 } },
  { id: 'petals', name: { vi: 'Cánh Hoa', en: 'Petal Stream' }, price: { coins: 500 } },
  { id: 'orbs', name: { vi: 'Quả Cầu Sáng', en: 'Light Orbs' }, price: { coins: 600 } },
  { id: 'stardust', name: { vi: 'Bụi Sao', en: 'Stardust' }, price: { coins: 600 } },
  { id: 'glow', name: { vi: 'Hào Quang', en: 'Aura Glow' }, price: { coins: 700 } },
  { id: 'frost', name: { vi: 'Băng Giá', en: 'Frostbite' }, price: { coins: 700 } },
  { id: 'neon', name: { vi: 'Neon', en: 'Neon Line' }, price: { coins: 800 } },
  { id: 'flame', name: { vi: 'Ngọn Lửa', en: 'Flame Tail' }, price: { coins: 900 } },
  { id: 'shadow', name: { vi: 'Bóng Tối', en: 'Shadow Veil' }, price: { coins: 900 } },
  { id: 'lightning', name: { vi: 'Tia Chớp', en: 'Lightning' }, price: { coins: 1000 } },
  { id: 'rainbow', name: { vi: 'Cầu Vồng', en: 'Rainbow' }, price: { gems: 20 } },
];

export interface ParticleItem { id: ParticleKind; name: L10n; price: Price }
export const PARTICLE_FX: ParticleItem[] = [
  { id: 'feather', name: { vi: 'Lông Vũ', en: 'Feathers' }, price: { coins: 300 } },
  { id: 'spark', name: { vi: 'Tia Lửa', en: 'Sparks' }, price: { coins: 300 } },
  { id: 'petal', name: { vi: 'Cánh Hoa', en: 'Blossoms' }, price: { coins: 300 } },
  { id: 'snow', name: { vi: 'Bông Tuyết', en: 'Snowflakes' }, price: { coins: 300 } },
  { id: 'leaf', name: { vi: 'Lá Xanh', en: 'Leaves' }, price: { coins: 300 } },
  { id: 'bubble', name: { vi: 'Bong Bóng', en: 'Bubbles' }, price: { coins: 400 } },
  { id: 'ember', name: { vi: 'Than Hồng', en: 'Embers' }, price: { coins: 500 } },
  { id: 'star', name: { vi: 'Ngôi Sao', en: 'Stars' }, price: { coins: 600 } },
  { id: 'confetti', name: { vi: 'Pháo Giấy', en: 'Confetti' }, price: { coins: 700 } },
  { id: 'rune', name: { vi: 'Ký Tự Cổ', en: 'Ancient Runes' }, price: { gems: 15 } },
];

export interface ThemeItem {
  id: string; name: L10n; price: Price;
  /** color grade overlay: tint color + alpha + blend mode */
  tint: { color: string; alpha: number; mode: GlobalCompositeOperation } | null;
  /** extra saturation boost applied by multiply/overlay passes (purely cosmetic) */
  vignette: number;
}
export const THEMES: ThemeItem[] = [
  { id: 'default', name: { vi: 'Mặc Định', en: 'Default' }, price: {}, tint: null, vignette: 0.28 },
  { id: 'pastel', name: { vi: 'Pastel Mộng Mơ', en: 'Pastel Dream' }, price: { coins: 600 }, tint: { color: '#ffd9f0', alpha: 0.2, mode: 'soft-light' }, vignette: 0.15 },
  { id: 'golden', name: { vi: 'Giờ Vàng', en: 'Golden Hour' }, price: { coins: 800 }, tint: { color: '#ffb347', alpha: 0.22, mode: 'soft-light' }, vignette: 0.3 },
  { id: 'midnight', name: { vi: 'Nửa Đêm', en: 'Midnight' }, price: { coins: 900 }, tint: { color: '#1a2a7a', alpha: 0.3, mode: 'multiply' }, vignette: 0.42 },
  { id: 'neonwave', name: { vi: 'Neon Wave', en: 'Neon Wave' }, price: { gems: 20 }, tint: { color: '#ff2bd6', alpha: 0.18, mode: 'overlay' }, vignette: 0.38 },
  { id: 'dream', name: { vi: 'Giấc Mơ Xanh', en: 'Teal Dream' }, price: { gems: 20 }, tint: { color: '#2bffd5', alpha: 0.16, mode: 'overlay' }, vignette: 0.3 },
];
export const THEME_BY_ID: Record<string, ThemeItem> = Object.fromEntries(THEMES.map((t) => [t.id, t]));
