import type { Gate, Gap } from '../entities/Obstacle';
import { gapAt } from '../entities/Obstacle';
import { OBSTACLES } from '../data/obstacles';

/** Circle (bird, at x = 0 relative to the gate frame, y = cy) vs the solid part of a gate.
 *  The geometry here is the single source of truth; renderers draw the same shapes. */

function circleRect(cy: number, r: number, x0: number, x1: number, y0: number, y1: number): boolean {
  // bird center at x = 0
  const nx = Math.max(x0, Math.min(0, x1));
  const ny = Math.max(y0, Math.min(cy, y1));
  const dx = nx, dy = ny - cy;
  return dx * dx + dy * dy < r * r;
}

function segDist2(px: number, py: number, ax: number, ay: number, bx: number, by: number): number {
  const abx = bx - ax, aby = by - ay;
  const l2 = abx * abx + aby * aby;
  let t = l2 > 0 ? ((px - ax) * abx + (py - ay) * aby) / l2 : 0;
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  const cx = ax + abx * t - px, cy = ay + aby * t - py;
  return cx * cx + cy * cy;
}

function circleTri(cy: number, r: number, ax: number, ay: number, bx: number, by: number, cx: number, cyy: number): boolean {
  const px = 0, py = cy;
  // inside test
  const d1 = (px - bx) * (ay - by) - (ax - bx) * (py - by);
  const d2 = (px - cx) * (by - cyy) - (bx - cx) * (py - cyy);
  const d3 = (px - ax) * (cyy - ay) - (cx - ax) * (py - ay);
  const neg = d1 < 0 || d2 < 0 || d3 < 0;
  const pos = d1 > 0 || d2 > 0 || d3 > 0;
  if (!(neg && pos)) return true;
  const r2 = r * r;
  return segDist2(px, py, ax, ay, bx, by) < r2 || segDist2(px, py, bx, by, cx, cyy) < r2 || segDist2(px, py, cx, cyy, ax, ay) < r2;
}

const BIG = 2000;
const _gap: Gap = { center: 0, half: 0 };

export function gateHitsCircle(g: Gate, rel: number, cy: number, r: number): boolean {
  const spec = OBSTACLES[g.kind];
  const hw = g.halfW;
  const reach = spec.shape === 'circles' ? hw * 2 + r : hw + r;
  if (rel > reach || rel < -reach) return false;
  const gap = gapAt(g, rel, _gap);
  const top = gap.center - gap.half;
  const bottom = gap.center + gap.half;
  switch (spec.shape) {
    case 'rect':
      return circleRect(cy, r, rel - hw, rel + hw, -BIG, top) || circleRect(cy, r, rel - hw, rel + hw, bottom, BIG);
    case 'spike': {
      const t = spec.tip;
      if (circleRect(cy, r, rel - hw, rel + hw, -BIG, top - t) || circleRect(cy, r, rel - hw, rel + hw, bottom + t, BIG)) return true;
      return circleTri(cy, r, rel - hw, top - t, rel + hw, top - t, rel, top) ||
             circleTri(cy, r, rel - hw, bottom + t, rel + hw, bottom + t, rel, bottom);
    }
    case 'circles': {
      const step = hw * 1.4;
      const rr = (r + hw) * (r + hw);
      // top column: centers at top - hw - i*step
      let iMin = Math.max(0, Math.floor((top - hw - cy - (r + hw)) / step));
      let iMax = Math.ceil((top - hw - cy + (r + hw)) / step);
      for (let i = iMin; i <= iMax; i++) {
        const cyc = top - hw - i * step;
        if (cyc < -450) break;
        const dy = cyc - cy;
        if (rel * rel + dy * dy < rr) return true;
      }
      iMin = Math.max(0, Math.floor((cy - bottom - hw - (r + hw)) / step));
      iMax = Math.ceil((cy - bottom - hw + (r + hw)) / step);
      for (let i = iMin; i <= iMax; i++) {
        const cyc = bottom + hw + i * step;
        if (cyc > 1250) break;
        const dy = cyc - cy;
        if (rel * rel + dy * dy < rr) return true;
      }
      return false;
    }
  }
}

export function circleCircle(dx: number, dy: number, r: number): boolean {
  return dx * dx + dy * dy < r * r;
}
