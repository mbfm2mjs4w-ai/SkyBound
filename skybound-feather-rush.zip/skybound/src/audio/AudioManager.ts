// 100% synthesized audio (Web Audio): SFX, 6 generative music themes with intensity layers, per-world ambience, ducking, fades.
import type { AmbientDef } from '../data/worlds';
import type { SkinDef } from '../data/skins';

export type SfxName =
  | 'click' | 'hover' | 'back' | 'tab' | 'error' | 'confirm' | 'purchase' | 'equip' | 'unlock' | 'toggle'
  | 'score' | 'perfect' | 'coin' | 'gem' | 'power' | 'shield' | 'hit' | 'death' | 'gameover' | 'milestone' | 'record'
  | 'levelup' | 'achievement' | 'bossIntro' | 'bossHit' | 'bossDefeat' | 'victory' | 'reward' | 'rewardOpen' | 'whoosh'
  | 'count' | 'go' | 'secret' | 'nearMiss' | 'phoenix' | 'warp' | 'pause' | 'resume';
export type MusicTheme = 'menu' | 'gameplay' | 'adventure' | 'galaxy' | 'zen' | 'boss';

interface Theme {
  bpm: number; root: number; scale: number[]; prog: number[][];   // prog: per bar chord = semitone offsets from root (first = bass note)
  pad: OscillatorType; bass: OscillatorType; arp: OscillatorType; lead: OscillatorType;
  kick: string; snare: string; hat: string; arpPat: number[]; gain: number; swing: number;
}
const THEMES: Record<MusicTheme, Theme> = {
  menu:      { bpm: 84,  root: 261.63, scale: [0, 2, 4, 6, 7, 9, 11], prog: [[0, 4, 7, 11], [5, 9, 12, 16], [9, 12, 16, 19], [7, 11, 14, 17]], pad: 'sine', bass: 'sine', arp: 'triangle', lead: 'sine', kick: 'x...............', snare: '........x.......', hat: 'x.x.x.x.x.x.x.x.', arpPat: [0, 2, 1, 3, 2, 1, 3, 2], gain: 0.9, swing: 0 },
  gameplay:  { bpm: 112, root: 220,    scale: [0, 2, 4, 7, 9],           prog: [[0, 4, 7, 12], [-4, 0, 4, 7], [-2, 2, 5, 9], [-5, -1, 2, 7]], pad: 'triangle', bass: 'triangle', arp: 'square', lead: 'triangle', kick: 'x...x...x...x...', snare: '....x.......x...', hat: '..x...x...x...x.', arpPat: [0, 1, 2, 3, 2, 1, 2, 3], gain: 1, swing: 0.1 },
  adventure: { bpm: 104, root: 293.66, scale: [0, 2, 3, 5, 7, 9, 10], prog: [[0, 3, 7, 10], [-2, 2, 5, 9], [3, 7, 10, 14], [-4, 0, 3, 7]], pad: 'sawtooth', bass: 'triangle', arp: 'triangle', lead: 'square', kick: 'x..x..x...x.x...', snare: '....x.......x..x', hat: 'x.x.x.x.x.x.x.xx', arpPat: [0, 2, 1, 3, 1, 2, 3, 2], gain: 0.85, swing: 0.05 },
  galaxy:    { bpm: 92,  root: 220,    scale: [0, 2, 3, 5, 7, 8, 10], prog: [[0, 3, 7, 10], [-4, 0, 3, 7], [-2, 2, 5, 9], [-7, -4, 0, 3]], pad: 'sine', bass: 'sine', arp: 'sine', lead: 'triangle', kick: 'x.......x.......', snare: '........x.......', hat: '..x...x...x...x.', arpPat: [0, 3, 1, 2, 3, 1, 2, 0], gain: 0.9, swing: 0 },
  zen:       { bpm: 64,  root: 196,    scale: [0, 2, 4, 7, 9],           prog: [[0, 7, 12, 16], [5, 12, 16, 19], [-3, 4, 9, 12], [-5, 2, 7, 11]], pad: 'sine', bass: 'sine', arp: 'sine', lead: 'sine', kick: '................', snare: '................', hat: '................', arpPat: [0, 2, 3, 1, 3, 2, 1, 0], gain: 0.75, swing: 0 },
  boss:      { bpm: 140, root: 164.81, scale: [0, 1, 3, 5, 7, 8, 10], prog: [[0, 7, 12, 15], [0, 7, 12, 15], [-4, 3, 8, 12], [-2, 5, 10, 13]], pad: 'sawtooth', bass: 'sawtooth', arp: 'square', lead: 'sawtooth', kick: 'x..x..x.x..x..x.', snare: '....x.......x...', hat: 'x.x.x.x.x.x.x.x.', arpPat: [0, 1, 2, 1, 3, 1, 2, 1], gain: 0.8, swing: 0 },
};

const semi = (f: number, s: number): number => f * Math.pow(2, s / 12);

export class AudioManager {
  ctx: AudioContext | null = null;
  private master!: GainNode; private musicBus!: GainNode; private sfxBus!: GainNode; private ambBus!: GainNode; private duckBus!: GainNode;
  private reverb!: ConvolverNode; private revSend!: GainNode; private delay!: DelayNode; private delaySend!: GainNode;
  private noiseBufs: Partial<Record<'white' | 'pink' | 'brown', AudioBuffer>> = {};
  vol = { master: 0.8, music: 0.7, sfx: 0.9, muted: false };
  // music state
  private theme: MusicTheme | null = null; private timer = 0; private nextT = 0; private step = 0; private bar = 0; private intensity = 0.3; private musicGain: GainNode | null = null;
  // ambience
  private amb: { stop: (fade: number) => void } | null = null; private ambKey = '';
  private lastSfx = new Map<string, number>();

  /** Must be called from a user gesture (first click / key / touch). Safe to call repeatedly. */
  unlock(): void {
    if (!this.ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      try { this.ctx = new AC({ latencyHint: 'interactive' }); } catch { return; }
      this.build();
    }
    if (this.ctx && this.ctx.state !== 'running') void this.ctx.resume().catch(() => {});
  }
  private build(): void {
    const c = this.ctx!;
    const comp = c.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 4; comp.attack.value = 0.005; comp.release.value = 0.2;
    this.master = c.createGain(); this.master.connect(comp); comp.connect(c.destination);
    this.duckBus = c.createGain(); this.duckBus.connect(this.master);
    this.musicBus = c.createGain(); this.sfxBus = c.createGain(); this.ambBus = c.createGain();
    this.musicBus.connect(this.duckBus); this.ambBus.connect(this.duckBus); this.sfxBus.connect(this.master);
    // shared effects: reverb + feedback delay for music
    this.reverb = c.createConvolver(); const len = Math.floor(c.sampleRate * 1.8), ir = c.createBuffer(2, len, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = ir.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.6); }
    this.reverb.buffer = ir; this.revSend = c.createGain(); this.revSend.gain.value = 0.35; this.revSend.connect(this.reverb); const rg = c.createGain(); rg.gain.value = 0.6; this.reverb.connect(rg); rg.connect(this.musicBus);
    this.delay = c.createDelay(1); this.delay.delayTime.value = 0.32; const fb = c.createGain(); fb.gain.value = 0.32; this.delaySend = c.createGain(); this.delaySend.gain.value = 0.25;
    this.delaySend.connect(this.delay); this.delay.connect(fb); fb.connect(this.delay); const dl = c.createGain(); dl.gain.value = 0.5; this.delay.connect(dl); dl.connect(this.musicBus);
    this.applyVolumes();
  }
  private noise(kind: 'white' | 'pink' | 'brown'): AudioBuffer {
    const c = this.ctx!; let b = this.noiseBufs[kind];
    if (b) return b;
    const len = c.sampleRate * 3; b = c.createBuffer(1, len, c.sampleRate); const d = b.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0, last = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      if (kind === 'white') d[i] = w;
      else if (kind === 'pink') { b0 = 0.99765 * b0 + w * 0.099046; b1 = 0.963 * b1 + w * 0.2965164; b2 = 0.57 * b2 + w * 1.0526913; d[i] = (b0 + b1 + b2 + w * 0.1848) * 0.2; }
      else { last = (last + 0.02 * w) / 1.02; d[i] = last * 3.2; }
    }
    this.noiseBufs[kind] = b; return b;
  }

  setVolumes(v: Partial<{ master: number; music: number; sfx: number; muted: boolean }>): void { Object.assign(this.vol, v); this.applyVolumes(); }
  private applyVolumes(): void {
    if (!this.ctx) return;
    const t = this.ctx.currentTime, m = this.vol.muted ? 0 : 1;
    this.master.gain.setTargetAtTime(this.vol.master * m, t, 0.03);
    this.musicBus.gain.setTargetAtTime(this.vol.music * 0.55, t, 0.05);
    this.ambBus.gain.setTargetAtTime(this.vol.music * 0.9, t, 0.05);
    this.sfxBus.gain.setTargetAtTime(this.vol.sfx, t, 0.03);
  }
  duck(level = 0.35, time = 0.8): void { if (!this.ctx) return; const t = this.ctx.currentTime; this.duckBus.gain.cancelScheduledValues(t); this.duckBus.gain.setTargetAtTime(level, t, 0.05); this.duckBus.gain.setTargetAtTime(1, t + time, 0.25); }
  suspend(): void { if (this.ctx && this.ctx.state === 'running') void this.ctx.suspend().catch(() => {}); }
  resume(): void { if (this.ctx && this.ctx.state === 'suspended') void this.ctx.resume().catch(() => {}); }

  // ---------------------------------------------------------------- primitives
  private tone(f: number, dur: number, o: { type?: OscillatorType; gain?: number; attack?: number; glide?: number; when?: number; bus?: AudioNode; detune?: number; rev?: number; lp?: number } = {}): void {
    const c = this.ctx; if (!c) return;
    const t = c.currentTime + (o.when ?? 0), osc = c.createOscillator(), g = c.createGain();
    osc.type = o.type ?? 'sine'; osc.frequency.setValueAtTime(f, t); if (o.glide) osc.frequency.exponentialRampToValueAtTime(Math.max(20, o.glide), t + dur);
    if (o.detune) osc.detune.value = o.detune;
    const a = o.attack ?? 0.008, peak = o.gain ?? 0.2;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(peak, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    let out: AudioNode = osc;
    if (o.lp) { const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = o.lp; osc.connect(lp); out = lp; }
    out.connect(g); g.connect(o.bus ?? this.sfxBus);
    if (o.rev) { const s = c.createGain(); s.gain.value = o.rev; g.connect(s); s.connect(this.revSend); }
    osc.start(t); osc.stop(t + dur + 0.05);
  }
  private nz(dur: number, o: { type?: BiquadFilterType; f0?: number; f1?: number; q?: number; gain?: number; when?: number; kind?: 'white' | 'pink' | 'brown'; attack?: number } = {}): void {
    const c = this.ctx; if (!c) return;
    const t = c.currentTime + (o.when ?? 0), src = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    src.buffer = this.noise(o.kind ?? 'white'); src.loop = true; f.type = o.type ?? 'bandpass'; f.Q.value = o.q ?? 1;
    f.frequency.setValueAtTime(o.f0 ?? 1000, t); if (o.f1) f.frequency.exponentialRampToValueAtTime(Math.max(30, o.f1), t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(o.gain ?? 0.2, t + (o.attack ?? 0.005)); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(g); g.connect(this.sfxBus); src.start(t, Math.random() * 2); src.stop(t + dur + 0.05);
  }
  private arpeggio(root: number, semis: number[], gap: number, o: { type?: OscillatorType; gain?: number; dur?: number; rev?: number } = {}): void {
    semis.forEach((s, i) => this.tone(semi(root, s), o.dur ?? 0.22, { type: o.type ?? 'triangle', gain: o.gain ?? 0.16, when: i * gap, rev: o.rev ?? 0.3 }));
  }
  private throttle(key: string, ms: number): boolean { const n = performance.now(); if (n - (this.lastSfx.get(key) ?? -1e9) < ms) return false; this.lastSfx.set(key, n); return true; }

  // ---------------------------------------------------------------- SFX
  flap(skin: SkinDef): void {
    if (!this.ctx || !this.throttle('flap', 60)) return;
    const v = skin.voice.flap, j = 1 + (Math.random() - 0.5) * 0.06;
    this.tone(v.base * j, 0.13, { type: v.wave, gain: 0.1, glide: semi(v.base, v.glide), attack: 0.004 });
    this.nz(0.11, { type: 'bandpass', f0: 1800, f1: 600, q: 0.8, gain: 0.05 + v.noise * 0.12 });
  }
  skill(skin: SkinDef): void {
    if (!this.ctx) return; const v = skin.voice.skill;
    const sc = v.scale.slice(0, 5); this.arpeggio(v.root, sc, 0.055, { type: v.wave, gain: 0.14, dur: 0.3, rev: 0.45 });
    this.nz(0.35, { type: 'highpass', f0: 3000, gain: 0.04, when: 0.05 });
  }
  sfx(n: SfxName, arg = 0): void {
    if (!this.ctx) return;
    switch (n) {
      case 'click': this.tone(660, 0.07, { type: 'triangle', gain: 0.1, glide: 520 }); break;
      case 'hover': if (!this.throttle('hover', 70)) return; this.tone(880, 0.04, { type: 'sine', gain: 0.04 }); break;
      case 'tab': this.tone(740, 0.08, { type: 'triangle', gain: 0.09, glide: 900 }); break;
      case 'back': this.tone(520, 0.09, { type: 'triangle', gain: 0.1, glide: 360 }); break;
      case 'toggle': this.tone(arg ? 880 : 520, 0.07, { type: 'square', gain: 0.05 }); break;
      case 'error': this.tone(180, 0.18, { type: 'sawtooth', gain: 0.09, glide: 120, lp: 800 }); this.tone(150, 0.2, { type: 'sawtooth', gain: 0.07, when: 0.1, glide: 100, lp: 700 }); break;
      case 'confirm': this.arpeggio(523, [0, 7], 0.07, { type: 'triangle', gain: 0.12 }); break;
      case 'purchase': this.arpeggio(659, [0, 4, 7, 12], 0.07, { type: 'triangle', gain: 0.14, rev: 0.4 }); this.nz(0.2, { type: 'highpass', f0: 5000, gain: 0.05, when: 0.2 }); break;
      case 'equip': this.tone(440, 0.09, { type: 'triangle', gain: 0.12, glide: 880 }); this.tone(1320, 0.12, { type: 'sine', gain: 0.07, when: 0.08 }); break;
      case 'unlock': this.arpeggio(523, [0, 4, 7, 12, 16], 0.08, { type: 'sine', gain: 0.15, dur: 0.5, rev: 0.6 }); break;
      case 'score': this.tone(880, 0.09, { type: 'sine', gain: 0.12, glide: 1320 }); break;
      case 'perfect': { const k = Math.min(arg, 12); this.tone(semi(880, k), 0.12, { type: 'sine', gain: 0.13, glide: semi(880, k + 7) }); this.tone(semi(1320, k), 0.16, { type: 'triangle', gain: 0.06, when: 0.04 }); break; }
      case 'coin': this.tone(1318, 0.07, { type: 'square', gain: 0.06 }); this.tone(1760, 0.18, { type: 'square', gain: 0.06, when: 0.06 }); break;
      case 'gem': this.arpeggio(1046, [0, 4, 7, 12], 0.05, { type: 'sine', gain: 0.1, dur: 0.3, rev: 0.5 }); break;
      case 'power': this.arpeggio(392, [0, 4, 7, 12, 16], 0.05, { type: 'triangle', gain: 0.13, rev: 0.4 }); break;
      case 'shield': this.tone(300, 0.25, { type: 'sine', gain: 0.18, glide: 900 }); this.nz(0.2, { type: 'bandpass', f0: 2500, f1: 800, gain: 0.1 }); break;
      case 'hit': this.nz(0.22, { type: 'lowpass', f0: 1400, f1: 200, gain: 0.35, kind: 'brown' }); this.tone(160, 0.22, { type: 'sine', gain: 0.3, glide: 50 }); break;
      case 'death': this.tone(420, 0.7, { type: 'sawtooth', gain: 0.12, glide: 60, lp: 1200 }); this.nz(0.5, { type: 'lowpass', f0: 800, f1: 100, gain: 0.2, kind: 'brown' }); break;
      case 'gameover': this.arpeggio(392, [0, -3, -7, -12], 0.16, { type: 'triangle', gain: 0.14, dur: 0.5, rev: 0.5 }); break;
      case 'milestone': this.arpeggio(523, [0, 4, 7, 12, 7, 12, 16], 0.06, { type: 'triangle', gain: 0.15, rev: 0.5 }); this.duck(0.5, 0.7); break;
      case 'record': this.arpeggio(523, [0, 4, 7, 12, 16, 19, 24], 0.07, { type: 'square', gain: 0.09, dur: 0.35, rev: 0.5 }); this.arpeggio(523, [0, 4, 7, 12], 0.07, { type: 'sine', gain: 0.14, dur: 0.6, rev: 0.7 }); this.duck(0.4, 1.2); break;
      case 'levelup': this.arpeggio(392, [0, 4, 7, 12, 16, 19], 0.07, { type: 'triangle', gain: 0.16, dur: 0.45, rev: 0.6 }); this.nz(0.5, { type: 'highpass', f0: 4000, gain: 0.06, when: 0.3 }); this.duck(0.4, 1); break;
      case 'achievement': this.arpeggio(659, [0, 7, 12, 16], 0.09, { type: 'sine', gain: 0.15, dur: 0.6, rev: 0.7 }); this.tone(1318, 0.8, { type: 'sine', gain: 0.07, when: 0.3, rev: 0.7 }); break;
      case 'bossIntro': this.tone(55, 1.6, { type: 'sawtooth', gain: 0.22, glide: 40, lp: 400 }); this.tone(82, 1.4, { type: 'sawtooth', gain: 0.15, glide: 61, lp: 500, when: 0.3 }); this.nz(1.2, { type: 'lowpass', f0: 300, f1: 900, gain: 0.2, kind: 'brown', attack: 0.4 }); this.duck(0.5, 2); break;
      case 'bossHit': this.tone(140, 0.25, { type: 'square', gain: 0.15, glide: 60, lp: 900 }); this.nz(0.2, { type: 'bandpass', f0: 1500, f1: 300, gain: 0.2 }); break;
      case 'bossDefeat': this.nz(0.9, { type: 'lowpass', f0: 2000, f1: 80, gain: 0.35, kind: 'brown' }); this.arpeggio(262, [0, 4, 7, 12, 16, 19, 24], 0.09, { type: 'triangle', gain: 0.15, dur: 0.5, rev: 0.6 }); this.duck(0.4, 1.6); break;
      case 'victory': this.arpeggio(392, [0, 4, 7, 12, 4, 7, 12, 16, 19], 0.1, { type: 'triangle', gain: 0.15, dur: 0.5, rev: 0.7 }); this.duck(0.4, 2); break;
      case 'reward': this.tone(660, 0.12, { type: 'triangle', gain: 0.1, glide: 990 }); break;
      case 'rewardOpen': this.nz(0.35, { type: 'bandpass', f0: 400, f1: 4000, gain: 0.18 }); this.arpeggio(523, [0, 4, 7, 12, 16], 0.06, { type: 'sine', gain: 0.14, dur: 0.5, rev: 0.7 }); break;
      case 'whoosh': this.nz(0.5, { type: 'bandpass', f0: 300, f1: 3000, q: 0.7, gain: 0.16, attack: 0.15 }); break;
      case 'count': this.tone(440, 0.14, { type: 'triangle', gain: 0.14 }); break;
      case 'go': this.tone(880, 0.35, { type: 'triangle', gain: 0.16, glide: 1320 }); break;
      case 'secret': this.arpeggio(440, [0, 3, 6, 9, 12, 15], 0.07, { type: 'sine', gain: 0.1, dur: 0.6, rev: 0.9 }); break;
      case 'nearMiss': this.nz(0.12, { type: 'bandpass', f0: 3000, f1: 1500, gain: 0.06 }); break;
      case 'phoenix': this.tone(300, 0.7, { type: 'sawtooth', gain: 0.1, glide: 1400, lp: 3000 }); this.arpeggio(523, [0, 7, 12, 19], 0.08, { type: 'triangle', gain: 0.12, rev: 0.7 }); break;
      case 'warp': this.tone(600, 0.6, { type: 'sine', gain: 0.12, glide: 120 }); this.nz(0.6, { type: 'bandpass', f0: 2500, f1: 300, gain: 0.07 }); break;
      case 'pause': this.tone(440, 0.1, { type: 'triangle', gain: 0.1, glide: 330 }); break;
      case 'resume': this.tone(330, 0.1, { type: 'triangle', gain: 0.1, glide: 440 }); break;
    }
  }

  // ---------------------------------------------------------------- music
  playMusic(theme: MusicTheme, fade = 1.2): void {
    if (!this.ctx) { this.pendingTheme = theme; return; }
    if (this.theme === theme && this.timer) return;
    this.stopMusic(fade * 0.6);
    this.theme = theme; this.step = 0; this.bar = 0;
    const c = this.ctx; this.musicGain = c.createGain(); this.musicGain.gain.value = 0.0001; this.musicGain.gain.linearRampToValueAtTime(1, c.currentTime + fade);
    this.musicGain.connect(this.musicBus); this.musicGain.connect(this.revSend); this.musicGain.connect(this.delaySend);
    this.nextT = c.currentTime + 0.1;
    this.timer = window.setInterval(() => this.schedule(), 90);
  }
  private pendingTheme: MusicTheme | null = null;
  flushPending(): void { if (this.pendingTheme && this.ctx) { const t = this.pendingTheme; this.pendingTheme = null; this.playMusic(t); } }
  stopMusic(fade = 0.8): void {
    if (this.timer) { clearInterval(this.timer); this.timer = 0; }
    const g = this.musicGain; this.musicGain = null; this.theme = null;
    if (g && this.ctx) { const t = this.ctx.currentTime; g.gain.cancelScheduledValues(t); g.gain.setValueAtTime(g.gain.value, t); g.gain.linearRampToValueAtTime(0.0001, t + fade); setTimeout(() => { try { g.disconnect(); } catch { /* */ } }, fade * 1000 + 200); }
  }
  setIntensity(x: number): void { this.intensity = Math.max(0, Math.min(1, x)); }
  private schedule(): void {
    const c = this.ctx, th = this.theme && THEMES[this.theme];
    if (!c || !th || !this.musicGain) return;
    const stepDur = 60 / th.bpm / 4;
    while (this.nextT < c.currentTime + 0.35) {
      this.playStep(th, this.step, this.bar, this.nextT + ((this.step % 2) ? th.swing * stepDur : 0));
      this.nextT += stepDur; this.step++;
      if (this.step % 16 === 0) this.bar++;
    }
  }
  private note(f: number, t: number, dur: number, type: OscillatorType, gain: number, lp = 0): void {
    const c = this.ctx!, o = c.createOscillator(), g = c.createGain(); o.type = type; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(gain, t + Math.min(0.04, dur * 0.3)); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    let out: AudioNode = o; if (lp) { const l = c.createBiquadFilter(); l.type = 'lowpass'; l.frequency.value = lp; o.connect(l); out = l; }
    out.connect(g); g.connect(this.musicGain!); o.start(t); o.stop(t + dur + 0.05);
  }
  private drum(kind: 'kick' | 'snare' | 'hat', t: number, gain: number): void {
    const c = this.ctx!;
    if (kind === 'kick') { const o = c.createOscillator(), g = c.createGain(); o.frequency.setValueAtTime(150, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.12); g.gain.setValueAtTime(gain * 0.9, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.2); o.connect(g); g.connect(this.musicGain!); o.start(t); o.stop(t + 0.25); return; }
    const s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain(); s.buffer = this.noise('white'); f.type = kind === 'hat' ? 'highpass' : 'bandpass'; f.frequency.value = kind === 'hat' ? 7000 : 1800; f.Q.value = 0.7;
    const d = kind === 'hat' ? 0.05 : 0.14; g.gain.setValueAtTime(gain * (kind === 'hat' ? 0.25 : 0.5), t); g.gain.exponentialRampToValueAtTime(0.0001, t + d); s.connect(f); f.connect(g); g.connect(this.musicGain!); s.start(t, Math.random()); s.stop(t + d + 0.02);
  }
  private playStep(th: Theme, step: number, bar: number, t: number): void {
    const I = this.intensity, s16 = step % 16, chord = th.prog[bar % th.prog.length], beat = 60 / th.bpm, root = th.root;
    // pad: one chord per bar
    if (s16 === 0) chord.forEach((s, i) => this.note(semi(root, s + 12), t, beat * 4.1, th.pad, 0.05 * th.gain / (1 + i * 0.2), th.pad === 'sawtooth' ? 900 : 0));
    // bass (on kick positions / quarter notes)
    if (s16 % 4 === 0 || (I > 0.55 && s16 % 8 === 6)) this.note(semi(root, chord[0] - 12), t, beat * 0.9, th.bass, 0.2 * th.gain, 500);
    // arpeggio
    if (I > 0.15 && s16 % 2 === 0) { const idx = th.arpPat[(s16 / 2) % th.arpPat.length]; this.note(semi(root, chord[idx % chord.length] + 12 * (I > 0.6 && s16 % 8 === 6 ? 2 : 1)), t, beat * 0.45, th.arp, 0.07 * th.gain, 3200); }
    // lead sparkle in calm themes
    if (th.kick === '................' && s16 % 8 === 4 && Math.random() < 0.5) this.note(semi(root, th.scale[Math.floor(Math.random() * th.scale.length)] + 24), t, beat * 1.6, 'sine', 0.05);
    else if (I > 0.7 && s16 % 4 === 2 && Math.random() < 0.35) this.note(semi(root, th.scale[Math.floor(Math.random() * th.scale.length)] + 24), t, beat * 0.5, th.lead, 0.05, 4000);
    // drums
    if (I > 0.3) { if (th.kick[s16] === 'x') this.drum('kick', t, 0.5 * th.gain); if (th.snare[s16] === 'x' && I > 0.45) this.drum('snare', t, 0.4); if (th.hat[s16] === 'x' && I > 0.5) this.drum('hat', t, 0.3); }
  }

  // ---------------------------------------------------------------- ambience
  setAmbient(key: string, def: AmbientDef | null, fade = 1.5): void {
    if (!this.ctx) { this.pendingAmb = { key, def }; return; }
    if (key === this.ambKey) return;
    this.ambKey = key; this.amb?.stop(fade); this.amb = null;
    if (!def) return;
    const c = this.ctx, out = c.createGain(); out.gain.value = 0.0001; out.gain.linearRampToValueAtTime(1, c.currentTime + fade); out.connect(this.ambBus);
    const nodes: AudioNode[] = [out], stops: (() => void)[] = [];
    // filtered noise bed with slow gusting LFO
    const src = c.createBufferSource(); src.buffer = this.noise(def.noise); src.loop = true;
    const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = def.lowpass; const hp = c.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = def.highpass;
    const ng = c.createGain(); ng.gain.value = def.noiseGain; src.connect(hp); hp.connect(lp); lp.connect(ng); ng.connect(out); src.start(); nodes.push(src, lp, hp, ng);
    const lfo = c.createOscillator(), lg = c.createGain(); lfo.frequency.value = def.lfoRate; lg.gain.value = def.noiseGain * def.lfoDepth; lfo.connect(lg); lg.connect(ng.gain); lfo.start(); nodes.push(lfo, lg);
    for (const d of def.drones) { const o = c.createOscillator(), g = c.createGain(); o.type = d.type; o.frequency.value = d.freq; if (d.detune) o.detune.value = d.detune; g.gain.value = d.gain; o.connect(g); g.connect(out); o.start(); nodes.push(o, g); }
    // random events
    const ev = window.setInterval(() => {
      if (!this.ctx || this.ctx.state !== 'running') return;
      const r = Math.random;
      if (def.chimes && r() < def.chimes.rate * 0.25) { const ch = def.chimes, s = ch.scale[Math.floor(r() * ch.scale.length)] + (r() < 0.3 ? 12 : 0); this.tone(semi(ch.root, s), 1.6, { type: ch.wave, gain: ch.gain, bus: this.ambBus, rev: 0.6, attack: 0.02 }); }
      if (def.crackle && r() < def.crackle * 0.5) this.nz(0.05 + r() * 0.06, { type: 'bandpass', f0: 1500 + r() * 3000, gain: 0.05 + r() * 0.06 });
      if (def.bubbles && r() < def.bubbles * 0.3) this.tone(500 + r() * 700, 0.09, { type: 'sine', gain: 0.04, glide: 1200 + r() * 600, bus: this.ambBus });
      if (def.beeps && r() < def.beeps * 0.25) this.tone(1200 + Math.floor(r() * 6) * 200, 0.05, { type: 'square', gain: 0.018, bus: this.ambBus });
      if (def.thunder && r() < def.thunder * 0.03) this.nz(1.8, { type: 'lowpass', f0: 400, f1: 60, gain: 0.25, kind: 'brown', attack: 0.2 });
    }, 220);
    stops.push(() => clearInterval(ev));
    this.amb = { stop: (f: number) => { stops.forEach((s) => s()); const t = c.currentTime; out.gain.cancelScheduledValues(t); out.gain.setValueAtTime(out.gain.value, t); out.gain.linearRampToValueAtTime(0.0001, t + f); setTimeout(() => { for (const n of nodes) { try { (n as AudioScheduledSourceNode).stop?.(); } catch { /* */ } try { n.disconnect(); } catch { /* */ } } }, f * 1000 + 150); } };
  }
  private pendingAmb: { key: string; def: AmbientDef | null } | null = null;
  flushAmbient(): void { if (this.pendingAmb && this.ctx) { const p = this.pendingAmb; this.pendingAmb = null; this.setAmbient(p.key, p.def); } }
  /** Call after unlock() so anything requested before the first gesture starts playing. */
  ready(): void { this.flushPending(); this.flushAmbient(); }
}
